# Research using Snapshot for Respect Games as a front-end for Firmament

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to explore the use of Snapshot for Respect Games as a front-end for Firmament. The page provides information about the research project, including its creator, status, and contribution ranking. It also highlights the functionality of the UI for ranked choice voting and the ease of changing votes during an active proposal.
Summary: The UI for ranked choice voting in Snapshot for Respect Games is effective with dragging and dropping. It also allows users to change their votes while a proposal is active, which is easy and works well.
Created time: June 3, 2024 9:11 AM
Last edited time: June 3, 2024 9:12 AM
Created by: Dan Singjoy

### Contribution Ranking

The UI for ranked choice voting works well with dragging and dropping

![Untitled](Research%20using%20Snapshot%20for%20Respect%20Games%20as%20a%20fro%20589ea02763b54b93a93d6482072abce8/Untitled.png)

also you can change your votes while proposal is active. changing the vote works perfectly and is easy