# Explore integrations with Notion and Hats Protocol for Optimism Fractal

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: This document discusses exploring integrations between Notion and Hats Protocol for Optimism Fractal. It raises questions about whether Hats Protocol can gate pages or teamspaces and set permissions for visibility, commenting, and editing.
Parent-task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created time: March 18, 2024 7:16 PM
Last edited time: March 19, 2024 11:56 AM
Parent task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created by: Dan Singjoy

## Description

- 
- Can Hats Protocol token gate pages or teamspaces? Can it set permissions for visibility, commenting, and editing?