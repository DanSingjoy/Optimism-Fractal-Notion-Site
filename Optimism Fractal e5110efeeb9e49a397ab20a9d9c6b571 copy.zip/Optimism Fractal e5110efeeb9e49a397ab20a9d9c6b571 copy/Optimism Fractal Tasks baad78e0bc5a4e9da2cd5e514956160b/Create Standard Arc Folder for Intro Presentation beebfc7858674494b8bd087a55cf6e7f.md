# Create Standard Arc Folder for Intro Presentation

Assignee: Dan Singjoy
Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: In progress
Task Summary: This task aims to create a standard arc folder for the introductory presentation, which includes promoting Eden Fractal and Optimism, encouraging participants to record videos, introducing the topic of Town Hall, explaining the timing of the presentation, and including a starter guide or welcome guide. Additionally, the task involves creating a quick start guide or starter kit guide and incorporating it into the weekly presentation.
Summary: This document outlines the creation of a standard arc folder for an introductory presentation. It includes promoting Eden Fractal and Optimism, encouraging participants to record videos, introducing the topic of Town Hall, explaining the timing of the presentation, and including a starter guide or welcome guide. Additionally, there are plans to encourage recording breakout rooms and create a quick start guide or starter kit guide.
Created time: May 10, 2024 3:07 PM
Last edited time: June 5, 2024 8:46 PM
Created by: Dan Singjoy

- [ ]  

Include:

- Promote Eden Fractal
    - [EdenFractal.com](http://EdenFractal.com)
    
- Promote Optimism
    - [Optimism.io](http://Optimism.io)
    
- Encourage participants to record videos
    - Explain where videos are published
        - [Improve Weekly Contributions Page and Workflows](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Weekly%20Contributions%20Page%20and%20Workflows%2038634e026b854eedabd1ddd5cc273106.md)

- Introduce topic of Town Hall

- Explain the timing that we’ll end before the top of the hour
    - [Start finishing the breakout rooms sooner](Start%20finishing%20the%20breakout%20rooms%20sooner%209868be82e1984c60ade7d0c0f416c26f.md)

- Include starter guide or welcome guide
    - [Create Welcome Guide for Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md)

…

 so there's some other ideas that we added on there, and these are things that we can add to the checklist. So some of the things to add to the checklist was that, one, I can encourage everybody to record their breakout rooms. That's one of the value propositions that we're providing. And we have the weekly Contribution Notion database, so we have a great way that people can promote their work and have it recorded. So I need to remember to do that. That should be my checklist of my presentation, things to say. And that should also be in the guide to play to, we should basically make like an easy quick start guide or a starter kit guide.

we should basically make like an easy quick start guide or a starter kit guide. We'll figure out the best thing to call it that we can send to people. And I can also include that in my presentation every week to just say, and here's the website you can go, Rosemary can share the link in the Zoom chat while we do that.