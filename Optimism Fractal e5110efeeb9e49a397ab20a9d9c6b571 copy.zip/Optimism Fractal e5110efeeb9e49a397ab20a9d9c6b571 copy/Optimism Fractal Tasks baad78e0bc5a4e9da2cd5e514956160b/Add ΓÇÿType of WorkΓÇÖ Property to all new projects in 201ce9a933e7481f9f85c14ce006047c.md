# Add ‘Type of Work’ Property to all new projects in notion

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Improve Optimism Fractal Notion Site (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20Notion%20Site%20d2c9d9db20cf4635a1e9b86c653f8c19.md)
Status: Not started
Task Summary: This task aims to add a 'Type of Work' property to all new projects in Notion. The purpose of this addition is to categorize projects based on their nature or purpose, providing better organization and clarity. By implementing this property, it will be easier to filter, sort, and prioritize projects based on their assigned type of work.
Summary: No content
Created time: May 9, 2024 3:58 AM
Last edited time: July 23, 2024 12:08 PM
Created by: Dan Singjoy
Description: No content