# Watch the video about EAS from Optimism Fractal Event 20

Project: Explore and Create Integrations with Ethereum Attestation Service (EAS) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
Status: Not started
Task Summary: This task aims to watch the video about EAS from Optimism Fractal Event 20. The video discusses the integration of the Respect Game with the Ethereum Attestation Service (EAS) and explores the potential of this integration in shaping the future of public goods infrastructure. The video features presentations, discussions, and insights from various participants regarding the integration and its implications.
Summary: This document provides timestamps and links to a video about EAS from the Optimism Fractal Event 20. The video discusses integrating the Respect Game with the Ethereum Attestation Service (EAS) and explores potential collaborations and developments related to EAS and public goods infrastructure.
Created time: May 6, 2024 12:28 PM
Last edited time: May 6, 2024 12:36 PM
Created by: Dan Singjoy

[https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3420s](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3420s)

### **OF 20: Attestation Nation**

How can a community enhance interoperability? We joyfully evaluate impact, then discuss integrating the Respect Game with the Ethereum Attestation Service (EAS) to compose the future of public goods infrastructure 🎼🧾

[57:00](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3420s) - Nestor provides positive feedback on the integration of the Respect game and fractalgram tool, expressing curiosity about the potential integration with the Ethereum Attestation Service and contributing to its development on Optimism.
[58:48](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3528s) - Dan gives a presentation on the planning session and introduces EAS for clarity
[59:19](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3559s) - Dan talks about the open-source tools built by the Optimystics team to help play the respect game on the EVM. He shares thoughts on potential integrations with the EAS
[1:01:27](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3687s) - Zaal comments that he’s trying to implement something like respect game on weekly zooms, talks about creating new consensus games, interested in this or other ways to play this with musicians.
[1:01:35](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3695s) - Nester expresses interest in understanding how the data will be stored and wrapped in a schema to integrate with EAS.
[1:02:22](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=3742s) - Dan shares info on the Fractal app they are building, aiming for an all-in-one app to work alongside Zoom.
[1:07:56](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=4076s) - Dan discusses linking Optimism Fractal and respect more with RetroPGF and earning funding opportunities. Also working on OPF trees.
[1:10:08](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=4208s) - Nestor and Dan discuss the EAS integration and the unique token design for Respect, being both fungible and non-fungible design. Dan gives more details on respect token and shares an article on how it works
[1:17:18](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=4638s) - Zaal suggests to propose his topic for next week's event
[1:18:46](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=4726s) - Abraham expresses interest in helping with front-end or API work. Will take a look through the Notion list.
[1:19:05](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=4745s) - Dan is starting a development chat in the Discord to coordinate and potentially schedule a meeting with developers
[1:20:27](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=4827s) - Abraham respond to Dan on comment on his project, still trying to get funding.
[1:21:26](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=4886s) - Hodlon made a council proposal for next week, Zaal and Dan discuss the idea of creating "Robert's Rules of Web3 DAOs" as a standardization for governance. Dan also demonstrates how to create proposals and vote with respect using Snapshot.
[1:26:04](https://www.youtube.com/watch?v=Jdm9GKzFoiU&t=5164s) - Go Optimism Fractal!