# Create list of well-respected community members

Project: Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md), Integrate Optimism Fractal with ENS (Ethereum Name Service) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20with%20ENS%20(Ethereum%20Name%2003fc813cc6744f87807695748158eed5.md), Build Scoreboard for Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Scoreboard%20for%20Respect%20d7a8b49bef094d80b36d3f30749c033c.md)
Status: In progress
Task Summary: This task aims to create a list of well-respected community members, as well as provide a scoreboard with information on various accounts. The list includes names, Ethereum addresses, and scores. The page also contains an image titled "Untitled."
Summary: This document is a work in progress list of well-respected community members. It includes a scoreboard with account addresses and scores, as well as some unidentified accounts. The list is being created by Dan Singjoy.
Created time: May 20, 2024 4:17 PM
Last edited time: May 20, 2024 4:23 PM
Created by: Dan Singjoy

## Scoreboard

Here is the scoreboard copied and pasted from [blockscout](https://optimism.blockscout.com/token/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC?tab=holders) on May 20th, 2024. I added an extra column in an attempt to see who has which account.

There are 3 accounts in  that I’m not sure about here and I suspect that it may be:

- Zeugh
- Natalie
- Marc
- Nuno
- Jason
- Joe

| Dan | **0xC11C6f47fe090a706bA82964B8A98F1682b244Ff** | 966 |
| --- | --- | --- |
| Rosmari | **0xf6E9B8d1877Ea00F7b72F682Fa15906D6A9F4693** | 898 |
| Hodlon | **0xAED620c450911c38714E666cd84137767e3D6286** | 484 |
| Tadas | **0xfF8592A0e6acF8975b5b9B6643eB20aD2550CA89** | 445 |
| Zaal | **0x7234c36A71ec237c2Ae7698e8916e0735001E9Af** | 359 |
| Abraham | **0x7f985b1764f79faA42a4622bB605b23C8Eb5AbEA** | 309 |
| Vlad | **0xF34F5B88Ff9A65594C49ed9Fa8D0451C15Ce215B** | 162 |
|  | **0x1C9F765C579F94f6502aCd9fc356171d85a1F8D0** | 149 |
| Nuno? | **0xAe25E2E0e7F697d14B0B7ba6F73c7A2c50aEdF89** | 131 |
| Will | **0x461acd846B4cc249b96242F1AB7c72a39d94747c** | 128 |
|  | **0xB87b6ed5F0a0146be63A929b589075aA0683C383** | 102 |
|  | **0xf7253A0E87E39d2cD6365919D4a3D56D431D0041** | 94 |
|  | **0xca85460d23Bfb2e0079bAb5AAC84921D9D0762a4** | 76 |
|  | **0x3D92b8DFD192354a36720Bc57941bB006fc9ad3b** | 76 |
|  | **0xd05266DACd06a500f6a14fdA9D729CC033Ad9dE6** | 63 |
|  | **0xcbd4D0241481b49158077e8833AfdCAeC7d9d804** | 63 |
|  | **0xfE1552DA65FAcAaC5B50b73CEDa4C993e16d4694** | 55 |
|  | **0xfC9265A28f66CF4561D74A4E25D7Bbd3F482B8e6** | 55 |
|  | **0xeF2f8A260904051C33f88832c5fCF4D68e4F806e** | 55 |
|  | **0xc689c800a7121b186208ea3b182fAb2671B337E7** | 55 |
|  | **0x99DFcC1036f3f27Dfc6cB1E9490C128739C13a00** | 55 |
|  | **0x4786a8E293cc9c7020e10486741D2D20f7EC4DbC** | 50 |
|  | **0x4B7C0Da1C299Ce824f55A0190Efb13663442FA2c** | 42 |
|  | **0xD131F1BcDd547e067Af447dD3C36C99d6be9FdEB** | 34 |
|  | **0x7Fd4eD1b927E8ccBaF8174F66e20aAFDa99fdb61** | 34 |
|  | **0xe801DB5E2bEC91Db175f23a9E29C653Dd2a70993** | 21 |
|  | **0x66A51330b37938f414cBf09ebd2E1eB9c70051A1** | 21 |
|  | **0x54BABF466A61447f3ea64d0EE80207C9ae458a02** | 21 |
|  | **0x3b9F47629cD4D5903cF3eB897aaC4F6b41Dd2589** | 21 |
|  | **0x0820881c4c60Afc889025dA9a3784Bc00Bd700af** | 21 |
|  | **0xe68bc10cB855b108dedc1cFE6E77B089d46CD45A** | 13 |
|  | **0x87690be28b65F13394741C2C2BE5A6bdb0505039** | 13 |
|  | **0x7110D94153cCBf0a6F9D11527648549516b4C809** | 13 |
|  | **0x8A4ff766a5dFb16d9DBd6A31f950c48A0cAf0f54** | 8 |
|  | **0x7BC44Da100Abe004F070e3Ee3cEd7E31A9B73098** | 8 |
|  | **0xEF5A5968bB8dc7a28Eb66f2A5947b36131B2Cb72** | 5 |
|  | **0x82D7F4E5A06007fc5464D0d5f51b8c7f59b33391** | 5 |
|  | **0x0263E43c0dE253a0fe354b60d35D2855c514a887** | 5 |

![Untitled](Create%20list%20of%20well-respected%20community%20members%2046a399cd25c44333bb5adc4ab44f1500/Untitled.png)