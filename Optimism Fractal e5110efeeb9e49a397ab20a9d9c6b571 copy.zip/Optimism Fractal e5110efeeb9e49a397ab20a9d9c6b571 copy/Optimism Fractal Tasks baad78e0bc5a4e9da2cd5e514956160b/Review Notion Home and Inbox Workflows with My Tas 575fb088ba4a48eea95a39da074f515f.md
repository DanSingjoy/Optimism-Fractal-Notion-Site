# Review Notion Home and Inbox Workflows with My Tasks Database

Project: Develop Optimism Fractal Notion Workflow Resources (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%20Notion%20Workflow%20Resources%2000025cbe20b349dbac2a3983459ac1a5.md)
Status: Not started
Summary: Reviewing Notion Home and Inbox workflows with My Tasks Database provides insights on organizing tasks, using advanced filters, transferring tasks between databases, and utilizing the My Tasks feature. This guide explains how to set up My Tasks, when to use it, and how to navigate and customize the tasks view. Notion Home serves as a personalized launchpad, offering recently visited pages, suggested readings, trending topics, featured templates, and learning resources to enhance productivity and collaboration.
Created time: February 20, 2024 2:22 PM
Last edited time: May 2, 2024 3:24 AM
Created by: Dan Singjoy

- [x]  After reviewing, consider adding to Optimystics [Organizational Cooperating Manual](https://www.notion.so/Organizational-Cooperating-Manual-0dffb0f4e76440da823e45c8bc1da674?pvs=21) or if there’s some other place that’s better for this
    - It’s better to put it into Optimism Fractal so it’s public
    - What should it be called?
    - Project: Develop Optimism Fractal Notion Cooperating Manual
    - Add to the top: Notion Cooperating Manual
    - 

## Notion Home and My Tasks

[https://x.com/notionhq/status/1761096676775997479?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/notionhq/status/1761096676775997479?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://www.youtube.com/watch?v=X-hz2ResO1Q](https://www.youtube.com/watch?v=X-hz2ResO1Q)

## Advanced Filters

- Using an Advanced Filter allows you to view tasks in your own database without assigning yourself, which can be helpful for several reasons
    - One reason is that there may be occasions when you want to work on a task in your own private database, then move the task to a different database and assign it someone else. Of course you could remove your own assignment at that point, though it’s easier if you’re not assigned in the first place
    - Another reason is that default page templates don’t always work for assigning yourself in your home database. For example, when you create a new task by dragging text into the database, it does trigger the default database template or any template

- Example:

![Untitled](Review%20Notion%20Home%20and%20Inbox%20Workflows%20with%20My%20Tas%20575fb088ba4a48eea95a39da074f515f/Untitled.png)

## Workflow for Transferring Tasks Between Task Databases (and therefore people)

- It can be helpful to work on a task in your own private ‘inbox’ tasks database first, then move it to a different database when it’s ready for others to see it
- In this case, it works well to open the task that you want to move in the side panel by clicking the OPEN button, then from there moving the page with the … button or keyboard shortcut (cmd+shift+p)
    - This allows you to continue editing the page in the same window after you move it, which can be especially helpful if you want to set an assignee, project, parent task, subtask, due date, or other property

## More about Notion Home and My Tasks

[https://www.youtube.com/watch?v=X-hz2ResO1Q](https://www.youtube.com/watch?v=X-hz2ResO1Q)

[https://youtube.com/watch?v=2PjJ1ulQNSU&si=V591x9pce3zHkEvj](https://youtube.com/watch?v=2PjJ1ulQNSU&si=V591x9pce3zHkEvj)

[](Review%20Notion%20Home%20and%20Inbox%20Workflows%20with%20My%20Tas%20575fb088ba4a48eea95a39da074f515f/Untitled%20f51cbcf307aa4018ad00e749fa877451.md)

## Give your to-dos a Home with Task databases

[https://www.notion.so/help/guides/give-your-to-dos-a-home-with-task-databases](https://www.notion.so/help/guides/give-your-to-dos-a-home-with-task-databases)

![https://www.notion.so/cdn-cgi/image/format=webp,width=3840/https:/images.ctfassets.net/spoqsaf9291f/4PIFMsKBWupTCYlav4N9gi/91b7f43904a7ba8930130b606d859da7/Screenshot_2024-02-15_at_16.15.29.png](https://www.notion.so/cdn-cgi/image/format=webp,width=3840/https:/images.ctfassets.net/spoqsaf9291f/4PIFMsKBWupTCYlav4N9gi/91b7f43904a7ba8930130b606d859da7/Screenshot_2024-02-15_at_16.15.29.png)

My Tasks hero

In this guide

- All your tasks in one simple to-do list
- Setting up My Tasks
- When to use My Tasks
- How to use My Tasks
- A home page built for you

With Notion, you can track everything you have to do, and link individual tasks with projects in a connected system for managing your work.

But, what happens when tasks are assigned to you from several different sources? Things get confusing if you have to constantly check multiple places to keep up with your tasks.

Now, you have a dedicated Notion Home that’s tailor-made for you. Along with links to recently opened docs, suggested pages, and trending topics, you’ll find My tasks, a convenient place that groups together all tasks assigned to you, from any database in the workspace.

In this guide, we’ll show you how you can stay organized and up to date with everything that’s on your plate using My Tasks.

## **All your tasks in one simple to-do list**

When it’s time to power through your to-do list, the last thing you want is to waste time searching for tasks and relevant information. My tasks automatically brings all your assigned tasks into one manageable to-do list that’s built into Home.

### Setting up My Tasks

Tasks will show up in Home when they are assigned to you in a Task type database. If you’ve used Notion’s Projects & tasks databases previously, you may already have these.

If not, follow the steps below to convert any of your task trackers into a Task database.

1. Go to the database.
2. Open the Settings `…` menu.
3. Click `Turn into task database`.
4. Task databases must have a `Status` property, an `Assignee` property, and a `Due date`, so add these properties if they aren’t there already.

Now, when you navigate back to Home, you’ll see any tasks assigned to you from the Task database appear there.

Turn task trackers into Task databases so all your tasks appear in Home.

### When to use My Tasks

If you’re working on different teams and projects, colleagues might make requests or assign tasks to you from different places. For example, copywriters might get assigned tasks across several distinct campaigns, and engineers may have to triage requests from several different teams.

As long as those databases are turned into tasks databases, all tasks will show up in your Home where you can sort and filter through them according to your priorities.

You can also open My tasks as a page, and add it your favorites for easy access from your sidebar.

Open My tasks as a full page and add it to your favorites for easy access.

Because the My tasks widget is synced in real time to all Task databases, you’ll know right away when a new task is assigned to you or if the status of a task changes.

### How to use My Tasks

In your My tasks widget, you can:

- **See all tasks assigned to you** — Any items that have been assigned to you from any tasks database across the workspace will appear in the My tasks widget.
- **Open tasks to see more context** — Click on a task to open it as a page and read more information or add comments.
- **Customize the database view** — In the full page view of My tasks, select different layouts to view your tasks in a kanban board, gallery, timeline, calendar or list.

Change the layout of My Tasks to a board, list, calendar, and more.

- **Update properties instantly** — View and seamlessly update properties from within the My tasks widget, so you can mark a task as complete or assign it to someone else without navigating to the original database.

Update task properties instantly from the My tasks widget.

- **Filter and sort the tasks that appear** — By default, only tasks assigned to you that are not marked as completed will appear. You can customize these filters and add new ones, for example, if you only want to see tasks due in the next week or month.
- **Check on tasks for your team** — In addition to viewing tasks assigned to you, you can adjust the filter to look at tasks assigned to anyone in your workspace, like, for example, all the tasks for your team.

Adjust filters if you want to see tasks assigned to anyone else on your team.

- **Add new tasks directly** — Select `+` to add a new task. Some properties will automatically be filled in according to your database settings.

## **A home page built for you**

My tasks is just one widget in your Notion Home, a collection of resources adapted to you that serves as a launchpad to help you dive into your next task, catch up with what your colleagues are reading, or even brush up on your Notion skills.

Home gives you somewhere to start and a place you can always return to with one click. Here, you’ll find the pages that are most relevant to you, so you can jump straight into productive work.

In addition to My tasks, Home also contains other widgets of useful information.

- **Jump back into recent pages** — The `Recently visited` widget contains links to pages you last viewed.
- **Personalized reading suggestions** — The `Suggested for you` widget contains pages that may interest you, based on your recent activity in the workspace.
- **Check out trending topics** — See what pages are currently popular in your workspace. In the `Trending` tab, you can view popular topics from the whole company, and also filter to view popular pages by teamspace.
- **Get inspired by featured templates** — Browse the collection of `Featured templates` that can help you work more efficiently.
- **Boost your Notion skills** — In the `Learn` widget, you can develop your Notion skills. Each recommendation is a link to a useful guide from the Notion Help Center.

Show or hide Home widgets in the options menu.

Home unites all your work and relevant information, so it’s easy to stay connected with your colleagues and focus on what needs your attention.

Customize the page by opening the settings menu `…` at the top right. Here, decide which widgets to show or hide or change the default page to the `Last visited page` or the first page in your sidebar.