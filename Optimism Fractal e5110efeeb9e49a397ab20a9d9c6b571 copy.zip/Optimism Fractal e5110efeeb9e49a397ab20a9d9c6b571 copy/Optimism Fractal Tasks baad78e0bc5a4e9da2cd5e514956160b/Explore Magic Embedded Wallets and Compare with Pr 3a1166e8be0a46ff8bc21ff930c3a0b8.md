# Explore Magic Embedded Wallets and Compare with Privy

Status: Not started
Task Summary: This task aims to explore and compare Magic Embedded Wallets with Privy. The page provides an overview of both wallets, highlighting their pros and cons for developers and users. It also discusses the integration process, user experience, flexibility, and control offered by each wallet. The summary concludes by emphasizing that the choice between Magic and Privy depends on specific project needs, such as user authentication, privacy requirements, and the balance between ease of use and comprehensive data control.
Summary: Magic and Privy are compared as embedded wallets for web3 applications. Magic offers easy integration and user-friendly authentication, while Privy focuses on privacy and data control. The choice depends on project needs, considering factors like user authentication, privacy requirements, and the balance between ease of use and comprehensive data control. Magic, with its market leadership and features like fiat onramps and NFT support, appears to be a strong contender.
Parent-task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created time: March 18, 2024 5:59 PM
Last edited time: June 8, 2024 11:42 PM
Parent task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created by: Dan Singjoy

## Description

## magic vs privy

- [ ]  ask chatgpt to search bing for a better response, then organize this better

I can't provide real-time or the most up-to-date comparisons. However, based on my last training data, here's a high-level overview:

**Magic:**

- **Pros for Developers:** Easy integration, focusing on user-friendly, passwordless authentication. Simplifies blockchain interactions for apps not heavily reliant on complex blockchain functions.
- **Pros for Users:** Streamlined sign-up/login process without remembering passwords; improves overall user experience.
- **Cons for Developers:** May lack deep customization and control over blockchain-specific functionalities compared to more comprehensive solutions.
- **Cons for Users:** Less control over blockchain interactions; primarily relies on email for authentication.

**Privy:**

- **Pros for Developers:** Offers robust privacy controls and data management for Web3 applications, with a strong emphasis on user data sovereignty. Tailored for deeper blockchain integration.
- **Pros for Users:** Enhanced privacy and control over personal data; supports a wide range of authentication methods.
- **Cons for Developers:** Potentially more complex integration process due to its extensive features. May require more development time to fully leverage its capabilities.
- **Cons for Users:** The user experience might be slightly more complex due to the additional privacy features and options.

**Comparison and Contrast:**

- **Integration and Setup:** Magic is generally easier and quicker to integrate, focusing on simplicity. Privy offers more depth, suited for applications requiring extensive user data management and privacy controls, possibly requiring more setup time.
- **User Experience:** Magic excels in simplicity and ease of use for end-users. Privy, while still user-friendly, places more emphasis on privacy and data control, which might introduce additional steps or complexities in user interactions.
- **Flexibility and Control:** Privy provides developers with greater control over user data and privacy aspects, suitable for applications where these are critical. Magic's approach is more streamlined but might offer less flexibility in these areas.

Deciding between Magic and Privy would depend on the specific needs of your project, especially regarding user authentication, privacy requirements, and the balance between ease of use and comprehensive data control.

# Magic

Magic is a wallet-as-a-service provider that helps businesses onboard users into web3 with instant non-custodial wallet creation. It uses email or social logins, while removing the need for seed phrases and browser extensions - making it indistinguishable from standard web2 experiences that everyday users are accustomed to. Magic offers features for end-to-end web3 onboarding including authentication, fiat onramps, NFT Minting and NFT Checkout. Its solutions are trusted by top brands in web2 and web3, including 7-11, Macy’s, PayPal, Immutable, Magic Eden, Sound.xyz, and more. 

Magic raised 52 million dollars in May 2023 and at that time created 20M+ wallets and was used by 130K+ developers. So it seems like it may be more of a market leader than Privy.

![[https://magic.link/](https://magic.link/)](Explore%20Magic%20Embedded%20Wallets%20and%20Compare%20with%20Pr%203a1166e8be0a46ff8bc21ff930c3a0b8/Untitled.png)

[https://magic.link/](https://magic.link/)

[Magic's Strategic Funding](https://magic.link/posts/strategic-funding)

### Use Cases

- [Sound.xyz](http://Sound.xyz) is very popular and they use [Magic.link](http://Magic.link)
- The website shows integrations with many large brands like 7-11, Paypal, etc

[https://twitter.com/soundxyz_/status/1721936976973316246](https://twitter.com/soundxyz_/status/1721936976973316246)

[https://x.com/soundxyz_/status/1721936988650234043?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/soundxyz_/status/1721936988650234043?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[Magic Uploads on Sound: No Gas Fees & No Wallet Needed](https://sound.mirror.xyz/Z5fnJyTvTnHJs1Bb_CgzbL5eNFJu0D2BKHomBmrPYFU)

[Functional demo of magic ](Explore%20Magic%20Embedded%20Wallets%20and%20Compare%20with%20Pr%203a1166e8be0a46ff8bc21ff930c3a0b8/Functional%20demo%20of%20magic%20a960273b8182453bb2af0d281852b52c.md)