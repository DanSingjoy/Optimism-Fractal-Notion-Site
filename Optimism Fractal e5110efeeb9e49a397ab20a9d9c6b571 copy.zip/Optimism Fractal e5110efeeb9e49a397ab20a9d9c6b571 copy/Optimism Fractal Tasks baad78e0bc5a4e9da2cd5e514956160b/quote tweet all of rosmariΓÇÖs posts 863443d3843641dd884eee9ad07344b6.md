# quote tweet all of rosmari’s posts

Assignee: Dan Singjoy
Due: August 2, 2024
Status: Not started
Task Summary: This task aims to quote tweet all of Rosmari's posts. It was created by Dan Singjoy and is assigned to him as well. The task is due on August 2, 2024, and its status is currently marked as "Not started." The page also includes a checklist item to review and reshare all tweets and casts from the past couple of days.
Summary: Dan Singjoy has a task to quote tweet all of Rosmari's posts. The task is not started and the due date is August 2, 2024.
Created time: June 26, 2024 11:04 PM
Last edited time: July 23, 2024 12:07 PM
Created by: Dan Singjoy
Description: Dan Singjoy has a task to quote tweet all of Rosmari's posts. The task is not started and the due date is August 2, 2024. The task involves reviewing all tweets and casts from the past couple of days and sharing them again.

- [ ]  review all tweets and casts from past couple days then share them again