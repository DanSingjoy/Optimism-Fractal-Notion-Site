# Curate Retro Funding Opportunities on Base and Collaborations with Optimism

Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
Status: In progress
Task Summary: This task aims to curate retro funding opportunities on Base and explore collaborations with Optimism. The page provides links and resources related to earning RetroPGF and deploying on Base, highlighting its eligibility and the benefits of supporting the Superchain.
Summary: This document discusses curating retro funding opportunities on Base and collaborations with Optimism. Base, as part of the Optimism Superchain, offers RetroPGF for impact made on Base. Building on Base supports the Superchain in new ways, allowing for new forms of support. Videos and articles provide more information on earning from RetroPGF by deploying on Base.
Created time: May 27, 2024 7:43 PM
Last edited time: May 27, 2024 7:48 PM
Created by: Dan Singjoy

## Retro Funding

[https://www.youtube.com/watch?v=Co8lyviAn5c&list=PLa5URJF9l5lkkMtFEkWEKmlNw6CJKQsPB&index=4](https://www.youtube.com/watch?v=Co8lyviAn5c&list=PLa5URJF9l5lkkMtFEkWEKmlNw6CJKQsPB&index=4)

[https://twitter.com/base/status/1763649310208753962](https://twitter.com/base/status/1763649310208753962)

[https://twitter.com/base/status/1766195356843507910](https://twitter.com/base/status/1766195356843507910)

[Preparing Optimism for the Superchain future](https://optimism.mirror.xyz/9ZMwZjst9SQpzIgEd4gN42UDjATyK3ZRClPFx9oMPp8)

[Welcoming Base](https://optimism.mirror.xyz/Luegue9qIbTO_NZlNVOsj25O1k4NBNKkNadp2d0MsTI)

[Decentralizing Base with the OP Stack and Optimism](https://base.mirror.xyz/H_KPwV31M7OJT-THUnU7wYjOF16Sy7aWvaEr5cgHi8I)

[Base’s Commitment to Decentralization with the Superchain](https://base.mirror.xyz/aBwt4flT1WAKJGQTj2AXBpH_8Qd3umQ-ZECLAJoO_nE)

[Base's 2024 Mission, Strategy and Roadmap](https://base.mirror.xyz/Ouwm--AtTIVyz40He3FxI0fDAC05lOQwN6EzFMD_2UM)

[Preparing Optimism for the Superchain future](https://optimism.mirror.xyz/9ZMwZjst9SQpzIgEd4gN42UDjATyK3ZRClPFx9oMPp8)

Base is part of the Optimism Superchain and impact made on Base is eligible for earning RetroPGF. I think it makes more sense to post the results on Base because it’s just as eligible for RetroPGF as the OP Mainnet and building on Base would be supporting the Superchain in a new way, which allows the Superchain to support us in new ways as well. Plus it sounds cool to build on Base. You can see the following videos and related articles below for more info about earning from RetroPGF by deploying on Base:

[https://twitter.com/base/status/1763649310208753962](https://twitter.com/base/status/1763649310208753962)

[https://youtu.be/Co8lyviAn5c](https://youtu.be/Co8lyviAn5c)