# Research Gitcoin Retro Citizens RetroPGF and other funding Rounds

Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Not started
Summary: This document provides links to research Gitcoin's Retro Citizens RetroPGF and other funding rounds, including the Gitcoin Citizen Grants Program, retroactive funding round, and the DAO Citizen Resource Hub.
Parent-task: Curate Funding Opportunities aligned with the Optimism Collective (Curate%20Funding%20Opportunities%20aligned%20with%20the%20Opti%20699d5e6d354c40f1b428146c28ed47ae.md)
Created time: April 3, 2024 10:19 AM
Last edited time: April 8, 2024 11:52 AM
Parent task: Curate Funding Opportunities aligned with the Optimism Collective (Curate%20Funding%20Opportunities%20aligned%20with%20the%20Opti%20699d5e6d354c40f1b428146c28ed47ae.md)
Created by: Dan Singjoy

## Research Gitcoin Retro Citizens RetroPGF

[https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470)

[https://gov.gitcoin.co/t/gcp-017-gitcoin-citizens-retroactive-funding-round/17215](https://gov.gitcoin.co/t/gcp-017-gitcoin-citizens-retroactive-funding-round/17215)

[https://gitcoin.notion.site/DAO-Citizen-Resource-Hub-7b83f9b5ca06487f84e0142d0180970a](https://www.notion.so/7b83f9b5ca06487f84e0142d0180970a?pvs=21)

[https://checker.gitcoin.co/public/projects/list?search=kingfisher](https://checker.gitcoin.co/public/projects/list?search=kingfisher)

[https://checker.gitcoin.co/public/project/show/kingfishers-corner](https://checker.gitcoin.co/public/project/show/kingfishers-corner)

[https://twitter.com/GitcoinCitizens/status/1773405919923048625](https://twitter.com/GitcoinCitizens/status/1773405919923048625)

## Organize Funding Opportunities

- [ ]  consider how to best curate/organize this
    
    
    - [ ]  create a page in [Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)

- This should eventually be added to [Education Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Education%20Hub%20225efc918f9f4644a39448be1eb3c7f0.md)

- It might be a good idea to add it to [Create webpages and educational resources for Optimism Fractal Funding Opportunities (OptimismFractal.com/funding or /earn)](Create%20webpages%20and%20educational%20resources%20for%20Opti%20c82abe9c5c8341d897c04f8eed3b924f.md) at some point, though we can just keep it here for now

- There are also many other opportunities like Octant etc that are aligned with Optimism that are good to include

- But it’s best to focus mostly on Optimism with RetroFunding

- So I think we should create a task, page, and database for funding opportunities

- @Dan Singjoy can also add [Monetization Opportunities Database](https://www.notion.so/Monetization-Opportunities-Database-f606e1d27fee445c80a926ec7e174f95?pvs=21) here as well
    - It just needs to be reviewed briefly first to see what’s there and if it all should be shared