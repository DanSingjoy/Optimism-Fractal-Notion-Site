# Review Inspiration and Market Need for Optimism Fractal Season 3, Cagendas, and Optimism Town Hall from Optimism Collective

Project: Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Submit Respect and Respect Votes as Impact Metrics for Open Source Observer(OSO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Submit%20Respect%20and%20Respect%20Votes%20as%20Impact%20Metrics%2012ebf87ca05b40379c0f6a4266ffb847.md), Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Research and Strategize to provide Optimism Collective with the most value possible (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20and%20Strategize%20to%20provide%20Optimism%20Collec%20ad36d53370ce43a18be5b0ff973a2052.md), Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md)
Status: In progress
Task Summary: This task aims to review the inspiration and market need for Optimism Fractal Season 3, Cagendas, and the Optimism Town Hall within the Optimism Collective. By examining these elements, we seek to understand the underlying rationale that drives our initiatives and to identify opportunities for enhancing community engagement and governance in future projects.
Summary: The document outlines the rationale, inspiration, and market need for Optimism Fractal Season 3, Cagendas, and Optimism Town Hall within the Optimism Collective. It includes a to-do list for organizing content, adding resources, and reviewing strategies related to open governance and RetroFunding. The document is a work in progress, indicating plans for better organization and the potential creation of a dedicated project for governance research.
Created time: May 1, 2024 2:54 AM
Last edited time: May 20, 2024 9:29 PM
Created by: Dan Singjoy
Description: The document outlines the rationale, inspiration, and market need for Optimism Fractal Season 3, Cagendas, and Optimism Town Hall within the Optimism Collective. It includes a to-do list for organizing resources, merging pages, and adding relevant content, as well as links to related articles on governance and RetroFunding. The document is a work in progress and aims to facilitate better organization and review of the collective's strategy and initiatives.

## Description

This task aims to provide an overview for the rationale, inspiration, and market need for Optimism Fractal Season 3, Cagendas, and Optimism Town Hall in the Optimism Collective. The page includes various resources including a review of the collective's strategy and articles about the path to open governance, and an opportunity to shape future rounds of RetroFunding. Please note that this article is an early work in progress and will be organized better as soon as possible.

**Table of Contents**

## To Do

- [ ]  add the video of OF 25 and OF 26 here
    - [ ]  give the transcript here and ask it to summarize and write blog post

- [ ]  organize the following sections into separate pages
    - Most of them already are synced into other pages though

- [ ]  consider if it makes sense to create a project about this
    - I think that’s a good idea to make it easier to organize, review, and add to over time
    - I could keep this task as is and just put it as a task in the project if that’s helpful
        - or perhaps i could put the synced parts in a toggle and make it easier to read this page
    - I created similar projects already that might be fitting for this
        - Hmmm I don’t see it… maybe there is a task about this but not a project?
            - It could be in [Create Educational and Community Resources for the Optimism Collective and Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md)…. but i think that educational project is very general and it’s helpful to have a more specific project for researching optimism collective governance in this season
        - See the toggle for list of projects and tasks where it may be helpful to include this
        
        - 
            
            
            [Untitled](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183/Untitled%201529410f58f9401189549d94ab42a996.csv)
            
            [Untitled](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183/Untitled%2074a99e343556460aa1ccbcc65da5917b.csv)
            
        

## Related Pages

- [ ]  organize and/or merge the following pages

[Curate Rationale and Benefits of Plan for Implementing Cagendas in Season 3 of Optimism Fractal](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c.md) 

[Explore the Optimism Collective's Experiments in Impact Juries and Deliberative Processes for Impact Evaluation ](Explore%20the%20Optimism%20Collective's%20Experiments%20in%20I%20e43c8c0159e44728b15daca5f6495ce9.md) 

[Explore the Optimism Collective’s Experiment in Metrics-based Evaluation](Explore%20the%20Optimism%20Collective%E2%80%99s%20Experiment%20in%20Me%2042f580862b8f4fe98e65c70e3327ac67.md) 

[Make Promotion about how Optimism Town Hall helps Data Scientists](Make%20Promotion%20about%20how%20Optimism%20Town%20Hall%20helps%20%2003ed0682f73f439dabbbe706e5b8e19d.md) 

## Prioritization

The faster we can build features to enable voting with Respect, the better we can position Optimism Fractal to play a leading role in Optimism Collective governance going into RetroFunding [RetroFunding Round 6](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861#retro-funding-6-governance-14) (which is focused on governance). The Optimism Collective is seeking the kinds of solutions that Optimism Fractal provides, as you can see in their recently released blog posts about [Experimenting with Deliberative Processes in the Collective](https://gov.optimism.io/t/experimenting-with-deliberative-processes-in-the-collective/8041), ****[The Path to Open Metagovernance](https://gov.optimism.io/t/the-path-to-open-metagovernance/7728)**,** and plans to experiment with [Impact Juries](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861#experiment-1-impact-juries-9). ****The tooling that enables voting with Respect in flexible environments like Notion could greatly help Optimism Fractal community members earn significant funding, propel the growth of Optimism Fractal, and provide a powerful catalyzing force to implement fractal consensus processes throughout society. 

## Review The Optimism Collective’s Strategy and Articles about Path to Open Open Governance

[The Path to Open Metagovernance](https://gov.optimism.io/t/the-path-to-open-metagovernance/7728)**,** and plans to experiment with [Impact Juries](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861#experiment-1-impact-juries-9).

- [ ]  Add video from recap of citizens house call in march/april 2024

- [ ]  Merge [Consider pioneering Impact Juries for the Optimism Collective](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Consider%20pioneering%20Impact%20Juries%20for%20the%20Optimism%2020e58c7a2c564548a148ece84b1ba470.md)
    - [ ]  [Review Plans to Build Impact Jury App and Move/Sync the Appropriate parts to the Optimism Fractal Tasks for App Development](https://www.notion.so/Review-Plans-to-Build-Impact-Jury-App-and-Move-Sync-the-Appropriate-parts-to-the-Optimism-Fractal-Ta-c15b7ef1d5ca43f1bced09c57693658a?pvs=21)

## Organize and Read Reviews of RetroFunding Design

- [ ]  merge where are they?
    - [ ]  [Prepare Strategy for Retro Funding Round 4-6 ](https://www.notion.so/Prepare-Strategy-for-Retro-Funding-Round-4-6-23ce4ed308de4e5ba9a5f7696a7150f4?pvs=21)?

- [ ]  ask chatgpt to summarize most important questions for us to discuss at  based on others feedback
    - [ ]  add to [Curate topics and questions for discussion related to the Optimism Collective for each week's Optimism Town Hall](https://www.notion.so/Curate-topics-and-questions-for-discussion-related-to-the-Optimism-Collective-for-each-week-s-Optimi-de20cbe9df5f4ce4bc3d337ddc33d1d8?pvs=21)

- [ ]  Watch Optimism Collective livestream about Round 4

### Launaumu Reply

[Upcoming Retro rounds and their design](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861/45?u=dansingjoy)

### Opportunity to Shape future Rounds

![Untitled](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183/Untitled.png)

## Read the Optimism Foundation’s Article: **Experimenting with Deliberative Processes in the Collective**

[Experimenting with Deliberative Processes in the Collective](https://gov.optimism.io/t/experimenting-with-deliberative-processes-in-the-collective/8041)

![Untitled](Read%20the%20Optimism%20Foundation%E2%80%99s%20Article%20Experimenti%2096db7df7bf044574a6c2fde99f00298b/Untitled.png)

- [ ]  see [Read Antoine Vergne’s Post(s) and Watch Videos about Citizen Assemblies, RetroPGF, and Governance](Read%20Antoine%20Vergne%E2%80%99s%20Post(s)%20and%20Watch%20Videos%20abo%20cdbe77d6cbd1453fa5a54e2724b34f41.md) for the community member post

- [ ]  click the links to learn more about the references

The community member’s post is Antoine’s post about citizen’s assemblies

![Untitled](Read%20the%20Optimism%20Foundation%E2%80%99s%20Article%20Experimenti%2096db7df7bf044574a6c2fde99f00298b/Untitled%201.png)

## Read about the Collective Feedback Commission

- [ ]  Consider joining as a delegate and/or badgeholder

[Introducing the Collective Feedback Commission](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863)

## Read Antoine Vergne’s Post(s) about Citizen Assemblies for RetroPGF and Research [Missions Publiques](https://missionspubliques.org/?lang=en)

- [ ]  First read [Read the Optimism Foundation’s Article: Experimenting with Deliberative Processes in the Collective](Read%20the%20Optimism%20Foundation%E2%80%99s%20Article%20Experimenti%2096db7df7bf044574a6c2fde99f00298b.md) for context

![Untitled](Read%20Antoine%20Vergne%E2%80%99s%20Post(s)%20and%20Watch%20Videos%20abo%20cdbe77d6cbd1453fa5a54e2724b34f41/Untitled.png)

[https://gov.optimism.io/t/seeking-mission-request-sponsorship/7130/21](https://gov.optimism.io/t/seeking-mission-request-sponsorship/7130/21)

[A Citizens' Assembly for RPGF4](https://mirror.xyz/antoinevergne.eth/3IiSj8FHtdDd13tLDi6Iq4EijlxihGxfPxlncG5jKGE)

- What did nuno recommend? I wrote a note about this in [Develop Optimism Fractal’s Consensus Processes](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md)
    - It was [Learn about Adaptive Quorum Biasing](Learn%20about%20Adaptive%20Quorum%20Biasing%20c943eadc37dd4eb1a4a499f81bbef09a.md), which sounds different but i should still learn about it
    - Has James Mart tweeted about citizens assemblies as well as deliberative democracy? I think so

### [Missions Publiques](https://missionspubliques.org/?lang=en)

### Read Other Articles from Antoine Vergne

[Decision Lego: A primitive on Governance for the 21st Century](https://mirror.xyz/antoinevergne.eth/6XIyqKcZo3pJOQuGG8NQkxzxSv2SQZkdo2tz-NL0LJU)

[Designing Equitable Airdrops:  A Path to Inclusive Web3 Communities through Citizens' Assemblies](https://mirror.xyz/antoinevergne.eth/3eqlNCnNsj-2ZeD9XsUdqe0_D5lnX-DZWuEh6IcUrzQ)

[Towards an intersubjective concept of sortition](https://mirror.xyz/antoinevergne.eth/EyBtmfIWdYsYxG-1U9gWnqk6TwtmMpEI_rcEL-R9RaI)

[Antoine Vergne (@AVAntoineVergne) on X](https://twitter.com/AVAntoineVergne)

### **International Perspective on Citizens’ Assemblies and other Democratic Innovations Governance at Yale University**

[https://www.youtube.com/watch?v=7vFr7Cr5nCw](https://www.youtube.com/watch?v=7vFr7Cr5nCw)

Antoine shares presentations at [12:40](https://youtu.be/7vFr7Cr5nCw?si=5bBYbpkmbbrlc-1t&t=760) and [1:01:30](https://youtu.be/7vFr7Cr5nCw?si=6efcAmcpGXPWzW-L&t=3687)

### Smart Contract Research Community Call

[https://www.youtube.com/watch?v=TdREkPpbEtg&pp=ygUOQW50b2luZSBWZXJnbmU=](https://www.youtube.com/watch?v=TdREkPpbEtg&pp=ygUOQW50b2luZSBWZXJnbmU=)

# Review Inspiration and Market Need for Optimism Fractal Season 3 and Town Hall from Optimism Collective

[Naturalisation councils — polynya](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183/Naturalisation%20councils%20%E2%80%94%20polynya%20114074f5adac81539ed0ef357186c568.md)

[Power distribution report ](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183/Power%20distribution%20report%20115074f5adac8176b55ee8326f509309.md)

[Measuring the Concentration of Power in the Collective - Governance Design 📐 - Optimism Collective](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183/Measuring%20the%20Concentration%20of%20Power%20in%20the%20Collec%20115074f5adac8102ac9af63bfdb4a04a.md)