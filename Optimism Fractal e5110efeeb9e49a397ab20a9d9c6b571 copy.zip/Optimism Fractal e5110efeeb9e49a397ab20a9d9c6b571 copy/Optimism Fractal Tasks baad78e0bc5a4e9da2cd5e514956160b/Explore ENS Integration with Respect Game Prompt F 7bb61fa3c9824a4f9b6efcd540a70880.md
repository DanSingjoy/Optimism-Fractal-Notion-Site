# Explore ENS Integration with Respect Game Prompt Field

Due: May 3, 2024
Project: Explore and Create Integrations with Ethereum Attestation Service (EAS) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md), Build Respect Game app (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md)
Status: Not started
Task Summary: This task aims to explore the integration of ENS (Ethereum Name Service) with the Respect Game Prompt Field. The goal is to investigate how ENS can be incorporated into the prompt field, providing users with enhanced functionality and convenience.
Summary: No content
Created time: May 9, 2024 6:35 AM
Last edited time: May 9, 2024 6:45 AM
Created by: Dan Singjoy

### EAS Integration for Respect Game Results of Game Prompt

- What if we integrate with EAS and we create a schema for the Respect Game?
    - If we integrate with an EAS schema for the Respect Game where each address is included along with their level, then would this make it easier to see the rankings of each game?
    - Schema Design:
        - The schema could include the addresses for level 1-6
        - It could also potentially include the question/prompt, community, and answer from each participant
    - More details:
        - [Explore and Create Integrations with Ethereum Attestation Service (EAS)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
        - [Follow up with Nestor about EAS](Follow%20up%20with%20Nestor%20about%20EAS%20c1659c98cbf6450185be4eb7e3f1aa69.md)
        - [Attest.sh](http://Attest.sh)

### Is it always good to have an option text field in Respect Games?

- One potential issue is that many respect games don’t require a box to answer any questions, but I think it’s almost always helpful to have one as an option but we just never have before.
    - For example, we could use that box to send to the optimism fractal weekly contributions database so people can easily share their work in one place without requiring someone to add it manually.
        - That would be great and always useful to have either for an answer to a question like what is the mission (as we did database in Eden fractal) or what did you do to help (in which case they could submit links to promote their work or text overview).
    - This could also improve upon the async version of Optimystics fractal respect game we’re playing. Rather than sharing our work in notion than linking in telegram, there could be one place in the app where you can submit what you did and then it goes to notion

- I think that it’s usually good to have this kind of textbox and never a really bad thing to have it. In some cases it’s super helpful and needed to unlock new gameplay styles. In some cases it’s helpful to enhance gameplay. In some cases it could be confusing, but I think that the confusion can be basically eliminated by communicating it well (ie do you want to add anything here (optional)). Eventually there could be a checkbox that game creators could click to show this field or not, but for now adding the field would be a big plus

For example during Optimism Fractal this field could say ‘do you want to share any links or contributions here? (optional). this will be added to [Weekly Contributions](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Weekly%20Contributions%201c90e50f1e23408080b41c562d0dcd0b.md) “