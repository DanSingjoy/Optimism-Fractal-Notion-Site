# Consider migrating to ERC-1155

Project: Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md), Build app component to make it easy for participants to give personal respect at the end of each game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md), Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md)
Status: Not started
Task Summary: This task aims to explore the potential migration to ERC-1155, a token standard, and the reasons behind it. It discusses the benefits of ERC-1155 in terms of developer accessibility, integration with roles and reputations, and the development of a Respect Game app. The page also compares ERC-1155 with the current system and mentions potential software options for the migration.
Summary: This document discusses the potential migration to ERC-1155, a token standard, and explores the benefits of developer accessibility, integration with roles and reputations, and the development of a Respect Game app. It also compares ERC-1155 with the current system and mentions potential software options for the migration.
Sub-task: Consider implementing ERC 404 Token Standard for Respect (Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18.md)
Created time: April 5, 2024 8:52 AM
Last edited time: May 7, 2024 11:19 AM
Upvoters: Dan Singjoy
Created by: Dan Singjoy

## Introduction

This task aims to consider migrating to ERC-1155, a token standard, and explores the reasons behind the potential migration. It discusses the benefits of ERC-1155 in terms of developer accessibility, integration with roles and reputations, and the development of a Respect Game app. The comparison between ERC-1155 and the current system is also evaluated, along with the potential software options for the migration.

**Table of Contents**

# Overview

### Current Status and Technical Implementation of Respect Token

- We’re currently considering if we should migrate the Optimism Fractal Respect token to an ERC 1155 token standard.

- The current implementation of Respect uses a unique combination of ERC721 and ERC20 token standards which allows you to see Respect in both ERC20 (fungible) and ERC 721 (nonfungible) token interfaces.
    - Here is the Github [repository](https://github.com/Optimystics/op-fractal-sc) with the current Optimism Fractal smart contracts.
    - Tadas (a developer on the Optimystics team who created the smart contracts) said that the best and most recent explanation of the contract’s design can be found on [this page](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md), where he wrote about the rationale and technical issues with this token implementation. Tadas wrote this page in February to explain the unique design of the contract and improve how Respect displays in block explorers. At the end of the page he also considered the possibility of migrating the Respect token to an ERC-1155 standard.
    - For more details and rationale, you can see Tadas explain how the smart contract implements interfaces of both ERC20 and NFT standard for the Respect token in this [video](https://youtu.be/dU7Whneo5yI?si=LS-MI-MJxiX_ykwl&t=640). If you’re interested in learning about the philosophy originally behind this design, you could also see this blog [post](https://hive.blog/dao/@sim31/fungibility-out-of-non-fungible-tokens) and video [clip](https://youtu.be/yr1NzIdezG8?si=rNJbTSEuRczlr2_X&t=4653) for more details.

- I’m wondering if implementing Roles and Respect could make it easier for us to migrate to ERC-1155 by adopting an open-source and well supported standard that includes many helpful integrations out of the box.
    - After Tadas wrote the explanations linked below, I did a lot of research wrote the following page: [Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md). This page includes reasons why I think that we should migrate Respect to a ERC1155 token standard and questions about doing so
    

### Questions about Roles and Reputation Token Standards

- Would Roles and Reputations work with the current implementation as well or only if we switched to ERC1155?
    - I do not believe so. R&R relies heavily on using the ERC1155 standard from smart contract implementation to Hats integration. These are not interchangeable with ERC721 components, but possibly ERC20.

- We’re currently using a non-standard implementation of token standards for Respect where Respect can be viewed as both ERC721 and ERC
- We’re thinking about migrating Respect to an ERC1155, as you can see in this task: [Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md)

- Can the ERC1155 implementation accomplish all the same benefits as the current implementation with ERC721 and ERC20?
    - Yes to all of those, except for maintaining the fungibility with the non-fungibility. As the R&R smart contracts stand, they are precisely an ERC1155. This means that they are fungible, there is no tokenId or “serial number” assigned to each newly minted token. The way that I view ERC1155s, are that they are like ERC20s, but with metadata. With the Redeemable and Lifetime tokens, I did not see a need to have non-fungibility features, as they mostly were not really a currency.
    
    ![Untitled](Ask%20and%20Answer%20Questions%20about%20Integrating%20with%20Ro%201d7979738a9f49bdb1deba384035553d/Untitled%202.png)
    
    - As you can see from above, I took inspiration from World of Warcraft’s Reputation system. Looking at Rustbolt Restistance, we can see that the player has 1650 reputation. We can ignore the “Friendly”, “Honored”, “Exalted”, and “3000” pieces of the picture as they do not immediately pertain to R&R (Someone may choose to build those systems on top of R&R. However, R&R simply tracks the total reputation of a user, I.E. the 1650 number). Also, note that there is no non-fungibility. Reputation is simply a tracked total number with respect to an entity.
    - I can imagine if you wished to uphold both fungibility and non-fungibility, then possibly two different collections (smart contracts) need to exist. The traditional ERC1155 (sub for ERC20 if need be), but then an accompanied ERC721. They are not tightly defined, other than by an outside source. The outside source, RespectMinter, may have minting authority for both collections. RespectMinter may also have a Mint() function, which when called, mints tokens from the ERC1155 (or ERC20) collection AND  the ERC721 collection. Maybe. Of course it costs more gas, but I think when we think about these concepts, we can’t be constrained by gas, or we truly can’t achieve the visions we’re looking at.

- Benefits of the current implementation include:
    - Ability to set roles and permissions on a time basis (ie set councilors as top 6 respect earners *over the past 12 weeks*)
        - This can also be flexibly used in other many ways too, such as sending awards or rewards to people who participated in OF Season 2 based upon the Respect earned in that season
    - Ability to see total amount of Respect in addition to visible NFT for each token
    - Fungibility out of non-fungibility, as explained in this toggle and the section about community gardens below
        
        
        You can see Tadas explain how the smart contract implements interfaces of both ERC 20 and NFT standard for the Respect token in this [video](https://youtu.be/dU7Whneo5yI?si=LS-MI-MJxiX_ykwl&t=640). If you’re interested in learning about the philosophy originally behind this design, you could also see this blog [post](https://hive.blog/dao/@sim31/fungibility-out-of-non-fungible-tokens) and video [clip](https://youtu.be/yr1NzIdezG8?si=rNJbTSEuRczlr2_X&t=4653) for more details.
        

- Would it make sense to use ERC 404 instead of ERC1155 or ERC721 and ERC20?

- I watched Jacob’s video about Trash NFT’s and learned about ERC 404. I organized details about ERC 404 in [Consider implementing ERC 404 Token Standard for Respect](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18.md).
- My intuition is that it’s probably better to use a more proven and supported standard like ERC1155 than ERC404, but the fact that ERC 404 uses a similar design to Tadas’ implementation is enticing….
    - This is my intuition as well. ERC404 *tries* to be both. On a certain level, it accomplishes that goal. However, once you look under the hood it has some wonky behavior that results in similar behavior from what is being seen with Respect.
- Does ERC404 token standard work with Roles and Reputations instead of ERC1155?
    - No. Not without extra development work in place. R&R specifically and strictly only supports ERC1155 at the moment.

### To Do

- [x]  Ask Jacob to share thoughts about the current implementation of Respect as ERC721 and ERC20 compared to ERC1155 or ERC 404

- [ ]  Consider asking Tadas about this and sharing this page or section with Tadas
    
    

## To Do

- [ ]  Listen to Optimystics Call on April 22nd again
    - April 24, 2024 Listen to Optimystics Call on April 22nd again
    - April 25, 2024 Listen to Optimystics Call on April 22nd again

- [ ]  organize this page better at the bottom to make tasks for manifold and other options for implementation

## Consider if we should make Respect ERC1155-similar like Hats Protocol who also uses non-transferrable tokens

- [ ]  review the following

[https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility](https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility)

![[https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility](https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility)](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602/Untitled%201.png)

[https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility](https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility)

# Reasons to Migrate to ERC-1155

## Developer Accessibility and Legibility

- I think this is currently a bottleneck in several projects and a barrier to entry for developers to get involved because they don’t know how to interact with it, whereas they’d have an easier time grasping it if it used just ERC1155 standard
    - For example, this may make it easier to integrate with EAS. I’m thinking about creating a schema See [Follow up with Nestor about EAS](Follow%20up%20with%20Nestor%20about%20EAS%20c1659c98cbf6450185be4eb7e3f1aa69.md) for an example and details
    - Several people have asked about the design and I’m not totally sure how to explain it without you being there
        - Is it actually two different tokens right now or just that it’s viewable in two different interfaces?

## Integration with Roles and Reputations

The Roles and Reputations front-end seems to use ERC 1155 as the reputation token. It seems quite well developed and useful for Optimism Fractal. It’s created by Jacob Homanics, who is supporting it’s further growth and joined Optimism Fractal in OF 24. You can learn more about this in [Research Roles and Reputations System (from Jacob Homanics with ATX DAO)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d.md) 

![[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Untitled%201.png)

[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)

- This seems like another reason why it may be best to migrate to ERC 1155. It could make Respect more compatible with Reputations and Roles from Jacob.
    - Related: [Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md)

![[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Untitled%202.png)

[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)

## Respect Game App where Each Players Can Give Each other Their Respect

- I’m thinking about building the Respect Game app where all players can easily give each other respect and it seems that a single token standard (ERC 1155) would be easier for many people to use than 2 token standards…
    - I’m not sure about this, but we could embed code for [Manifold.xyz](http://Manifold.xyz) or something else that already uses ERC 1155
        - I think this could also make the manual or automatic token distribution easier?
    - I want to make it as easy as possible for people to give each other respect right after playing and optionally provide a picture
        - I think this has a lot of similarities with what we discussed in [EdenFractal.com/61](http://EdenFractal.com/61)

- You can see the designs for this below
    - Full Figma design in progress: https://www.figma.com/file/3JuoT7WfxvPDj2Esom9hJP/Respect-Game-xyz?type=design&node-id=0-1&mode=design&t=kaPBpI7XGw6TAxXt-0
    - [ ]  share ideas and UI design for game where everyone can give respect

![Untitled](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602/Untitled.png)

- What would be the functionality for this feature?
    - Contract ownership…
    - [ ]  Add timestamps from April 5th meeting and share with optimystics chat, tagging tadas

- Each player gets the option to easily share their Respect with everyone who they play with

- Each player can quickly add a picture and text to their Respect if they want, which could be accomplished by using something like [Manifold.xyz](http://Manifold.xyz) widget for creating ERC 1155 (if such code is open source)
    - In the future it could also have in app art creation tool for quickly adding images, gifs, and stylized text

- So for example if you play with Mary, Todd, Joe, Kelly, and Anne… and you get level 5… then you can get 34 Respect for each of them….

# Comparison

## Comparison of Features between ERC-1155 and Current System

- It seems like ERC 1155 could accomplish what we are aiming to do with both non-fungibility and fungibility, while also being simpler and benefitting from standardization with the rest of the ecosystem.
- In what ways might ERC-1155 be inferior to the current design? Or put another way, why wouldn’t we switch to ERC-1155?
- If we did decide to migrate, how much time and work would this require?

## When will we decide?

- Should we make a decision about whether to stay with current configuration or move to ERC 1155?
    - Do you think it makes sense to migrate to ERC 1155 now or make any other changes?

# Software to potentially switch to ERC-1155

## Manifold Resources

- [ ]  consider testing and trying

[https://forum.manifold.xyz/](https://forum.manifold.xyz/)

[https://docs.manifold.xyz/v/manifold-studio/case-studies/overview#case-studies](https://docs.manifold.xyz/v/manifold-studio/case-studies/overview#case-studies)

[https://docs.manifold.xyz/](https://docs.manifold.xyz/)

[https://studio.manifold.xyz/829817072/tokens](https://studio.manifold.xyz/829817072/tokens)

[https://manifold.xyz/](https://manifold.xyz/)

Hey Tadas, here is video from Friday’s meeting. You can see us discuss more about Respect given by each player, giving Respect to people outside of event participants, and other exciting topics at this [timestamp](https://youtu.be/L4P8BSObqxE?si=RzJZEQsc2zmvjzOs&t=2053) starting right after you left.

I also realized that I accidentally shared the wrong screen when I tried to show you the Give Respect button before you left. Below is the draft mockup of how a button that says “Give Respect” could be presented to each player right after they complete a game. 

![Untitled](Organize%20Plans%20for%20Personal%20Respect,%20Distributing%20%20404d4123e7974215968180a9f01a8945/Untitled.png)

## Other Software for ERC 1155

BitBond?

MintNite?

Third Web?

What others?

## Related Pages

[Improve representation of Respect on block explorers](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md) 

[Improve Visibility for Optimism Fractal Respect](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md) 

## Ask for update about ERC-1155?

- Maybe it would be good to ask Tadas or other developers about Bitbond, Manifold, MintNite, or other options
    - [Organize Plans for Personal Respect, Distributing after Respect Games, Respect Networks, and Synergies with Optimism Fractal](Organize%20Plans%20for%20Personal%20Respect,%20Distributing%20%20404d4123e7974215968180a9f01a8945.md)
    - [Test out [Manifold.xyz](http://Manifold.xyz) to allow people to give each other Respect in [RespectGame.xyz](http://RespectGame.xyz) ](Test%20out%20Manifold%20xyz%20to%20allow%20people%20to%20give%20each%20d1bc16afaad241bdb570c9b092be8ee4.md)
    - [Consider Bitbond Token Creation and Distribution Tool to put Respect onchain in Optimism ](https://www.notion.so/Consider-Bitbond-Token-Creation-and-Distribution-Tool-to-put-Respect-onchain-in-Optimism-83fcb35255b74ab7882f6238d2bcd2a7?pvs=21)
    - [[mintnite
    - [ ]  Consider organizing these better
    - [ ]  Review how this can also help [Review Plan to migrate Eden Fractal Respect to EVM for Eden Fractal 2 year anniversary](https://www.notion.so/Review-Plan-to-migrate-Eden-Fractal-Respect-to-EVM-for-Eden-Fractal-2-year-anniversary-4c7dc157e98a4cfaa4c6b346d8d22679?pvs=21)

[https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility](https://docs.hatsprotocol.xyz/for-developers/hats-protocol-overview/erc1155-compatibility)