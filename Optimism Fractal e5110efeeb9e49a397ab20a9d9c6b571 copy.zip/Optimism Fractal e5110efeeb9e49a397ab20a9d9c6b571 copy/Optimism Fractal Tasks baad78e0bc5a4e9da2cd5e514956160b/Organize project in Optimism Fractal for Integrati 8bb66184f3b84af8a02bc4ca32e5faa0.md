# Organize project in Optimism Fractal for Integrating with Intersubjective Measurement Systems such as SourceCred (and Armitage)

Due: May 3, 2024
Project: Explore and consider integrating with Intersubjective, Pluralistic Measurement Systems (such as SourceCred, PlaceCred, Praise and Armitage) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20consider%20integrating%20with%20Intersubject%203469e1de3b1e4193bf6dae0c669093f8.md)
Status: Not started
Task Summary: This task aims to organize a project in Optimism Fractal for integrating with intersubjective measurement systems such as SourceCred. The project was created by Dan Singjoy and has a due date of May 3, 2024. The status of the project is currently marked as "Not started". The page includes a checklist of tasks to be completed and references to Seth's presentations at OF. Additionally, there is a link to research PlaceCred.
Summary: This project aims to organize the integration of Optimism Fractal with intersubjective measurement systems like SourceCred. The project status is not started, and tasks include adding timestamps to presentations, adding a video on YouTube, and researching PlaceCred.
Parent-task: Respond to the thread with Seth Benton, Spencer Graham, and SudoFerraz.eth about Quantitative Value Creation Measurement for Decentralized Work with sourcecred, optimism fractal, and armitage (Respond%20to%20the%20thread%20with%20Seth%20Benton,%20Spencer%20Gr%203631f0a5782d40bea7e190480f5391b7.md)
Sub-task: Respond to Tadas about Breakout Room 1 and Share Message wrapping up  Optimism Fractal Season 3 on discord (Respond%20to%20Tadas%20about%20Breakout%20Room%201%20and%20Share%20M%20e541af626a174466969bcfe5515a071a.md)
Created time: April 17, 2024 11:02 AM
Last edited time: May 1, 2024 11:50 AM
Parent task: Respond to the thread with Seth Benton, Spencer Graham, and SudoFerraz.eth about Quantitative Value Creation Measurement for Decentralized Work with sourcecred, optimism fractal, and armitage (Respond%20to%20the%20thread%20with%20Seth%20Benton,%20Spencer%20Gr%203631f0a5782d40bea7e190480f5391b7.md)
Created by: Dan Singjoy
Description: This project aims to organize the Optimism Fractal (OF) project for integration with intersubjective measurement systems like SourceCred and Armitage. The project is not started yet, and the tasks include adding timestamps to Seth's presentations at OF, adding a video on YouTube about this, and conducting research on PlaceCred.

- [ ]  [Explore and consider integrating with Intersubjective, Pluralistic Measurement Systems (such as SourceCred, PlaceCred, Praise and Armitage)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20consider%20integrating%20with%20Intersubject%203469e1de3b1e4193bf6dae0c669093f8.md)

- [ ]  [Retweet Seth Benton’s tweet about Optimism Fractal, SourceCred, and PlaceCred?](Retweet%20Seth%20Benton%E2%80%99s%20tweet%20about%20Optimism%20Fractal%20d7355a14b6574c099b1d1c35237634e0.md)

- [ ]  add [Review and explore synergies with Armitage.xyz](Review%20and%20explore%20synergies%20with%20Armitage%20xyz%20e4d788b696f6460994a73332862bcb9d.md)

- [ ]  add timestamps to seth’s presentations at OF

- [ ]  add [Research Sourcecred from Seth Benton and consider following up with him](Research%20Sourcecred%20from%20Seth%20Benton%20and%20consider%20%20d22d8594ba5d475f8cdd16ed61954ace.md)

- [ ]  add the video on youtube about this

- [ ]  [Research Seth Bentons’s work with Sourcecred and the Credsperiment](https://www.notion.so/Research-Seth-Bentons-s-work-with-Sourcecred-and-the-Credsperiment-366aa0dd17184dbf96c648f6acdc8680?pvs=21)

- [ ]  add [Respond to the thread with Seth Benton, Spencer Graham, and SudoFerraz.eth about Quantitative Value Creation Measurement for Decentralized Work with sourcecred, optimism fractal, and armitage](Respond%20to%20the%20thread%20with%20Seth%20Benton,%20Spencer%20Gr%203631f0a5782d40bea7e190480f5391b7.md)

[Research PlaceCred](Organize%20project%20in%20Optimism%20Fractal%20for%20Integrati%208bb66184f3b84af8a02bc4ca32e5faa0/Research%20PlaceCred%2013acc96478614baca4753cccc19922c5.md)