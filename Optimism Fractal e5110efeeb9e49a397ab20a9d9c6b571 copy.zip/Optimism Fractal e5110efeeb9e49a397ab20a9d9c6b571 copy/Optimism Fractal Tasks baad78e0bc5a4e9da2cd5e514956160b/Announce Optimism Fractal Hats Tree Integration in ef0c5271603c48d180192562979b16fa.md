# Announce Optimism Fractal Hats Tree Integration in Hats, EF, and OF Telegram Chats

Assignee: Dan Singjoy
Due: July 1, 2024
Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Done
Task Summary: This task aims to announce the integration of the Optimism Fractal Hats Tree within the Hats, EF, and OF Telegram chats. This exciting development allows participants to earn and claim hats based on their Respect earned at weekly events, fostering community engagement and networking opportunities among builders in the Optimism Fractal space.
Summary: The Optimism Fractal now features a Hats Tree, allowing participants who earn Respect at events to claim Rookie Hats for access to a new charmverse space and networking opportunities. Those with over 50 Respect and Fractalgram Certification can wear a Respect Game Leader hat. The initiative encourages participation in weekly events and claiming hats to support the Hatathon competition, which requires at least five claims to win a prize. Thanks are given to contributors, and further integrations between Optimism Fractal and Hats Protocol are anticipated.
Created time: September 3, 2024 3:33 PM
Last edited time: September 12, 2024 1:19 PM
Created by: Dan Singjoy
Description: The Optimism Fractal now features a Hats Tree that allows participants who have earned Respect at weekly events to claim a Rookie Hat, granting access to a new charmverse space and networking opportunities. Those with over 50 Respect can earn a Respect Game Leader hat. The initiative aims to enhance integrations between Optimism Fractal and Hats Protocol, with participants encouraged to claim their hats to support the project and potentially win the Mad Hatter prize in the ongoing Hatathon.

## Hats Telegram

Hey everyone, I’m excited to announce that Optimism Fractal now has a Hats Tree! 🌻🧢

The Optimism Fractal Hats Tree enables anyone who has earned Respect at our weekly events to claim a Rookie Hat, which grants access to the new Optimism Fractal charmverse space and a networking page for builders. The Hats Tree also enables participants who’ve earned over 50 Respect and complete a Fractalgram Certification to wear a Respect Game Leader hat.

Huge thanks to @JacobHomanics for all the amazing work building the Hats Tree and all the excellent support from the Haberdasher Labs team. This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. You can learn more about this at [OptimismFractal.com](http://optimismfractal.com/) and the ‘Hats Protocol + Optimism Fractal’ [telegram group](https://t.me/hatsprotocolandoptimismfractal). 

Everyone is welcome to join our [weekly events](https://lu.ma/optimystics) to earn Respect while networking with builders on the Superchain, raising awareness for your work, and playing onchain social games where you can get our stylish hats. I hope to see you wearing hats there and am looking forward to further growing our Hats Tree! 🤠

![hats tree v1.png](Announce%20Optimism%20Fractal%20Hats%20Tree%20Integration%20on%20b98fd5714cad4f5a9fab770fe8dfe6e3/hats_tree_v1.png)

- [ ]  share link to tweet or cast here?
    - [ ]  i think it has enough links in there already and it’s best to share the cast or tweet in the OF + Hats Telegram group

## Hats+OF Chat

Hey all, 

I just shared a [tweet](https://twitter.com/DanSingjoy/status/1831509179657273773) and [cast](https://warpcast.com/dansingjoy/0x17998e30) announcing the new Optimism Fractal Hats Tree. Your likes and shares are appreciated to help spread the word. I’ll also announce the Hats Tree during the introductory presentation at the Optimism Fractal event tomorrow and propose it as a topic of discussion for the Optimism Town Hall.

For anyone who has earned Respect at Optimism Fractal and hasn’t yet claimed a hat, I encourage you to [claim](https://app.hatsprotocol.xyz/trees/10/175?hatId=175.1.2) your hats to see how the tree works and gain the hats’ powers. By claiming this week, you can also help Jacob and I win the Mad Hatter prize (which is partially determined by the amount of people who claim the hats).

Thank you to everyone who has claimed a hat or otherwise helped support the initiative so far! 🤠🌻

## OF Discord

Hey all! I just shared a [tweet](https://twitter.com/DanSingjoy/status/1831509179657273773) and [cast](https://warpcast.com/dansingjoy/0x17998e30) announcing the new Optimism Fractal Hats Tree. Your likes and shares are appreciated to help spread the word. 

For anyone who has earned Respect at Optimism Fractal and hasn’t yet claimed a hat, I encourage you to [claim](https://app.hatsprotocol.xyz/trees/10/175?hatId=175.1.2) your hats see how the tree works and gain the hats’ powers. By claiming this week, you can also help Jacob and I win the Mad Hatter prize (which is partially determined by the amount of people who claim the hats).

Thank you to everyone who has claimed a hat or otherwise helped support the initiative so far! 🤠🌻

## Eden Fractal Telegram

Hey everyone, I’m excited to announce that Optimism Fractal now has a Hats Tree and Charmverse Space! 🌻🧢

The Optimism Fractal [Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) enables anyone who has earned Respect at our weekly events to claim a Rookie Hat, which grants access to the new Optimism Fractal [charmverse space](https://app.charmverse.io/optimismfractal/welcome-33440438705074915) and a networking page for builders. The Hats Tree also enables participants who’ve earned over 50 Respect and complete a Fractalgram Certification to wear a Respect Game Leader hat.

Huge thanks to @jacobhomanics for all the amazing work building the Hats Tree and all the excellent support from the Haberdasher Labs team. This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. You can learn more at [HatsProtocol.xyz](http://HatsProtocol.xyz), this [notion project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), and the ‘Hats Protocol + Optimism Fractal’ [telegram group](https://t.me/hatsprotocolandoptimismfractal) where we’re planning the next steps with the Hats founders.

I hope to see you at our [weekly events](https://lu.ma/optimystics) tomorrow where we’ll collaborate with builders on the Superchain and advance Eden Fractal’s mission of implementing fractal decision-making processes throughout society. Hope to see you there! 🤠

I also just shared a [tweet](https://twitter.com/DanSingjoy/status/1831509179657273773) and [cast](https://warpcast.com/dansingjoy/0x17998e30) announcing the new Optimism Fractal Hats Tree. Your likes and shares are appreciated to help spread the word. 

For anyone who has earned Respect at Optimism Fractal and hasn’t yet claimed a hat, I encourage you to claim to see how the tree works and gain the hats’ powers. By claiming this week, you’ll also help Jacob and I increase our odds of winning the Mad Hatter prize in the [Hatathon](https://t.me/hatsprotocolandoptimismfractal/151) (which is partially determined by the amount of people who claim the hats). 

Thank you to everyone who has claimed a hat or otherwise helped support the initiative so far! 🤠🌻

See the links below to see the Hats tree, explore the future of Hats + Optimism Fractal, and join the weekly events!

[https://app.hatsprotocol.xyz/trees/10/175](https://app.hatsprotocol.xyz/trees/10/175)

[https://t.me/hatsprotocolandoptimismfractal](https://t.me/hatsprotocolandoptimismfractal)

[https://lu.ma/optimystics](https://lu.ma/optimystics)

You can also join this [chat](https://t.me/hatsprotocolandoptimismfractal) to learn more and participate in our discussions with the founders of Hats Protocol. 

## Hats Telegram

- [x]  first read the chats and save anything important for later

## Hats  + OF Chat

Exciting news: Optimism Fractal now has a Hats Tree!

Me and @jacobhomanics are participating in the Hatathon and we've created a basic [Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) that enables anyone who has earned Respect at Optimism Fractal weekly events to claim a Rookie Hat, which grants access to the Optimism Fractal charmverse [space](https://app.charmverse.io/optimismfractal/welcome-33440438705074915) and a new networking page for builders. The Hats Tree also enables anyone who has earned over 50 Respect and read the tutorial article about fractalgram to claim a Respect Game Leader hat, which signifies that you can lead a breakout room at weekly events.

The Hatathon has a requirement that at least 5 people must mint the hats in order for us to win a prize and the competition is nearly over. If you have earned Respect at Optimism Fractal events then please claim the Rookie Hat to help us win the competition and enhance our integrations with Hats Protocol. You can claim the Rookie Hat by clicking [here](https://app.hatsprotocol.xyz/trees/10/175?hatId=175.1.2) then connecting your wallet and clicking the ‘claim hat’ button near the right side of the screen. If you’d like to signify that you’re ready to host a breakout room for the Respect Game then you can also claim the Rising Star, Fractalgram Certification, and Respect Game Leader hats as well.

This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. Huge thanks to Jacob for all the amazing work building the Hats Tree and all the support from the Haberdasher Labs team! 🙌🏽 🙏🏽

## **ORDAO candidate for Optimism Fractal**

Vote for this topic if you want to talk about a candidate for the version 2 of Optimism Fractal software, that Tadas has been developing and am now testing. You can read about it [here](https://github.com/sim31/frapps/blob/main/concepts/apps/of2/README.md).