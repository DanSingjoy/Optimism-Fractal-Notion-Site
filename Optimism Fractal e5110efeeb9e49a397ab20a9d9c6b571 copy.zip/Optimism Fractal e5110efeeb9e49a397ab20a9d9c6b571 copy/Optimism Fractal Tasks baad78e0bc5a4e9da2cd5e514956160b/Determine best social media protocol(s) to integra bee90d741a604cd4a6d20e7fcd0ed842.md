# Determine best social media protocol(s) to integrate or build the app on

Project: Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md)
Status: In progress
Task Summary: This task aims to determine the best social media protocol(s) to integrate or build the app on. The goal is to identify the most effective and suitable social media platforms to enhance the functionality and reach of the app. The page, created by Dan Singjoy, is currently in progress and seeks to find the optimal social media strategy for the app's success.
Summary: No content
Created time: July 5, 2024 2:29 PM
Last edited time: July 5, 2024 2:30 PM
Created by: Dan Singjoy
Description: No content

[Explore and Create Integrations between Farcaster and Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md) 

[Sign up for [Lens.xyz](http://Lens.xyz) and start posting there](Sign%20up%20for%20Lens%20xyz%20and%20start%20posting%20there%204a35e003d9aa4f37931f55024f1ed4f4.md)