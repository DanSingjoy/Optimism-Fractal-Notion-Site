# Write introduction to Optimism Fractal tools

Due: May 3, 2024
Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md), Create educational resources about the history of Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20about%20the%20history%20of%20%20fdcb0d490a9a41ce95992d8947236df6.md), Build Optimism Fractal Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md)
Status: In progress
Task Summary: This task aims to write an introduction to Optimism Fractal tools. The introduction will provide a concise overview of the tools and their purpose, highlighting their relevance in the wider EVM ecosystem. It will also include links to key resources and funding opportunities to support development.
Summary: To create concise overviews of Optimism Fractal tools, utilize the writing on http://optimystics.io/tools, http://edencreators.com/tools, http://optimystics.io/respectgame, and other resources with ChatGPT. Additionally, link to key resources such as funding opportunities, an introduction to Optimism Fractal tools, and developer resources in the wider EVM ecosystem to build the development hub.
Created time: May 10, 2024 11:50 AM
Last edited time: June 9, 2024 11:11 AM
Created by: Dan Singjoy

We can use the writing on [Optimystics.io/tools](http://Optimystics.io/tools), [EdenCreators.com/tools](http://EdenCreators.com/tools), [Optimystics.io/respectgame](http://Optimystics.io/respectgame) and other resources with ChatGPT to create more concise overviews of Optimism Fractal tools

 It’s also worth linking to other key resources in the project to build the development hub, such as funding opportunities, an introduction to Optimism Fractal tools, and developer resources in the wider EVM ecosystem.