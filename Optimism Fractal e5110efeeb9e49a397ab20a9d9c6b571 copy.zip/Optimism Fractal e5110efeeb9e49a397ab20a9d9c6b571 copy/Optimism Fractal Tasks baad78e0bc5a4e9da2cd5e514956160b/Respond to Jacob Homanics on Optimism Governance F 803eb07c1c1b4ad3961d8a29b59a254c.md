# Respond to Jacob Homanics on Optimism Governance Forum

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Explore integrations with Roles and Reputations System (from Jacob Homanics with ATX DAO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20with%20Roles%20and%20Reputations%20Sy%20c85bbe3e9a8548bfb3ccf6a4aea29fde.md)
Status: Not started
Task Summary: This task aims to respond to Jacob Homanics on the Optimism Governance Forum. The page provides an overview of the task, including the creator, assignee, due date, and current status.
Summary: No content
Created time: May 3, 2024 9:33 AM
Last edited time: July 16, 2024 9:40 AM
Created by: Dan Singjoy
Description: No content

# Respond in Optimism Gov Forum

[Reputation & Roles Milestone Tracking - ATX DAO](https://gov.optimism.io/t/reputation-roles-milestone-tracking-atx-dao/7953/6)

![Untitled](../../Dan%E2%80%99s%20Home%20cb3a418b96e747a1ad4f08e71594a285/Dans%20Tasks%200094ba116ff8456f98bdea75c9027df2/Respond%20to%20Jacob%20Homanics%20about%20R&R%20on%20Optimism%20Go%20e36cf7a25ccd4856bec216419ecf66e5/Untitled.png)

- [ ]  Consider including some of the same text as in the telegram response
    - this makes sense to provide a similar update in both places and re-use the text
    - write the telegram response first

# Respond in telegram

![Untitled](../../Dan%E2%80%99s%20Home%20cb3a418b96e747a1ad4f08e71594a285/Dans%20Tasks%200094ba116ff8456f98bdea75c9027df2/Respond%20to%20Jacob%20Homanics%20about%20R&R%20on%20Optimism%20Go%20e36cf7a25ccd4856bec216419ecf66e5/Untitled%201.png)

- [ ]  Consider forwarding his messages here for context so others can see it and it provides context to my responses
    - I think this is a great idea

Thanks for sharing the links and all the excellent work Jacob!

I’m glad you like the video and write up, and I appreciate the kind words. Feel free to let me know if you’d like anything added to the document, if access to edit the page yourself, or there’s anything else I can do to help.

I hope these resources will help more people understand the benefits of Reputation & Roles and am excited to see the next steps in the project!

I also added a project to explore integrations and started drafting rationale

Added videos from BuidlGuidl

I will keep the documentation at the current link as educational resource, and added questions and benefits pages to the project

[Describe how Roles and Reputations can benefit Optimism Fractal](Describe%20how%20Roles%20and%20Reputations%20can%20benefit%20Opt%2058f681b27cf341e2aefb9e9aac8354f3.md) 

[Write blog post about synergies between the Respect Game, Hats Protocol, and Optimism Fractal ](Write%20blog%20post%20about%20synergies%20between%20the%20Respec%202b90213bfa904dc8bd740d0af77138f1.md) 

[Explore integrations with Roles and Reputations System (from Jacob Homanics with ATX DAO)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20with%20Roles%20and%20Reputations%20Sy%20c85bbe3e9a8548bfb3ccf6a4aea29fde.md)