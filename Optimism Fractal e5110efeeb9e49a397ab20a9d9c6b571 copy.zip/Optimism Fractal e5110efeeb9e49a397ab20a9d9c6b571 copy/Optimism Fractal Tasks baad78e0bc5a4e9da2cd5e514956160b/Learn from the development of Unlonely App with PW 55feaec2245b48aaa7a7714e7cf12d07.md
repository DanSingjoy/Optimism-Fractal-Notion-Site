# Learn from the development of Unlonely.App with PWA and Privy

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: Not started
Summary: No content
Created time: February 23, 2024 9:49 AM
Last edited time: February 23, 2024 9:59 AM
Created by: Dan Singjoy

[https://twitter.com/bdguan/status/1694057515766387191?s=12&t=kwCarPNUD1CcGDdzTYKUzw](https://twitter.com/bdguan/status/1694057515766387191?s=12&t=kwCarPNUD1CcGDdzTYKUzw)