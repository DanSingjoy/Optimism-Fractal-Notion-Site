# Figure out how to set recurring tasks with alerts or due dates in notion (and specifically see if my reminder to back up Notion every day is working)

Assignee: Dan Singjoy
Due: April 21, 2024
Project: Develop Optimism Fractal Notion Workflow Resources (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%20Notion%20Workflow%20Resources%2000025cbe20b349dbac2a3983459ac1a5.md)
Status: Done
Task Summary: This task aims to explore how to set recurring tasks with alerts or due dates in Notion, specifically focusing on the reminder to back up Notion every day. The user shares their experience with setting up a recurring task template and discusses whether the due date for the task reflects the day it renews. They also provide an update on their findings and share screenshots showcasing how the recurring reminders work.
Summary: The document discusses setting up recurring tasks with alerts or due dates in Notion, specifically focusing on the reminder to back up Notion daily. The author sets up a recurring task template and explores whether the due date for the task will show up correctly. After checking five days later, they find that while the recurring reminders don't show up at the top of My Tasks, they do receive notifications, which is sufficient for their use case.
Sub-task: Double check to make sure that this notion reminder system is still working AND check to see if this new feature for setting the due date works better than setting an alert (Double%20check%20to%20make%20sure%20that%20this%20notion%20reminde%20d7e7dbab2b664025bfe4befcfe858756.md)
Created time: May 6, 2024 8:00 PM
Last edited time: May 14, 2024 3:55 PM
Sub-tasks: Double check to make sure that this notion reminder system is still working AND check to see if this new feature for setting the due date works better than setting an alert (Double%20check%20to%20make%20sure%20that%20this%20notion%20reminde%20d7e7dbab2b664025bfe4befcfe858756.md)
Created by: Dan Singjoy

- I set up a recurring task template to do this daily in optimism fractal tasks

- I set the Due property to Remind on Day of the Event in the template

- The task will now recur every day, but I’m not sure if the due date for the task will show up as the day that the task renews
    - [x]  check to see if this is how it works
    - If the task doesn’t show the current due date, then it wouldn’t show up in My Tasks as desired
    - If the task doesn’t show the current due date, then an appropriate solution could be to just set the recurring task template with an old date like January 1st 2024, since this would make it always show up at the top of the My Tasks list

## Update

- i just checked five days later to see how this worked and have good results
    - Setting the Due property to Remind on Day of the Event in the template does not set the Due Date for the property, but it does give me a notification every day
    - So these recurring reminders don’t show up at the top of My Tasks, but they do give me notifications which is sufficient for this use case
    - I’m moving the recurring task template from OF tasks to my tasks so it doesn’t clog up the OF Tasks
    - You can see screenshots below to see more about how this works

![Untitled](Figure%20out%20how%20to%20set%20recurring%20tasks%20with%20alerts%20%20a1ec8f3efc064a6f84b136aafc583df0/Untitled.png)

![Untitled](Figure%20out%20how%20to%20set%20recurring%20tasks%20with%20alerts%20%20a1ec8f3efc064a6f84b136aafc583df0/Untitled%201.png)

![Untitled](Figure%20out%20how%20to%20set%20recurring%20tasks%20with%20alerts%20%20a1ec8f3efc064a6f84b136aafc583df0/Untitled%202.png)

![Untitled](Figure%20out%20how%20to%20set%20recurring%20tasks%20with%20alerts%20%20a1ec8f3efc064a6f84b136aafc583df0/Untitled%203.png)