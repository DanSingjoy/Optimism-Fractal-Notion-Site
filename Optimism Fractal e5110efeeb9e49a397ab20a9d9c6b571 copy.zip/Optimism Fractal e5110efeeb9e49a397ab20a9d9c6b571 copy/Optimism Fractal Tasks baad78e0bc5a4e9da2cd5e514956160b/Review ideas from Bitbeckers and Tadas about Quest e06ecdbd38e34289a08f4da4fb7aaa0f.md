# Review ideas from Bitbeckers and Tadas about Quests

Project: Explore Integrations of Quests with the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Integrations%20of%20Quests%20with%20the%20Respect%20Ga%202a4d3601ec8c4f10b683a139862dd9e7.md)
Status: Not started
Summary: No content
Created time: February 18, 2024 9:38 AM
Last edited time: February 18, 2024 9:43 AM
Created by: Dan Singjoy

## Description

![[https://discord.com/channels/1164572177115398184/1186376309744619560/1192402585773158401](https://discord.com/channels/1164572177115398184/1186376309744619560/1192402585773158401)](Review%20ideas%20from%20Bitbeckers%20and%20Tadas%20about%20Quest%20e06ecdbd38e34289a08f4da4fb7aaa0f/Untitled.png)

[https://discord.com/channels/1164572177115398184/1186376309744619560/1192402585773158401](https://discord.com/channels/1164572177115398184/1186376309744619560/1192402585773158401)

![[https://discord.com/channels/1164572177115398184/1186376309744619560/1193205012319436810](https://discord.com/channels/1164572177115398184/1186376309744619560/1193205012319436810)](Review%20ideas%20from%20Bitbeckers%20and%20Tadas%20about%20Quest%20e06ecdbd38e34289a08f4da4fb7aaa0f/Untitled%201.png)

[https://discord.com/channels/1164572177115398184/1186376309744619560/1193205012319436810](https://discord.com/channels/1164572177115398184/1186376309744619560/1193205012319436810)

### Next

[Review Hodlon’s Threads about reputation based governance, Hats Protocol, and Optimism Fractal](Review%20Hodlon%E2%80%99s%20Threads%20about%20reputation%20based%20gov%201b7299d154d1439dbcb6061d2048fc1e.md)