# Watch presentation about smart account wallets from WalletConnect founder

Assignee: Dan Singjoy
Due: June 21, 2024
Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md), Create smooth onboarding experience for people to play the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20smooth%20onboarding%20experience%20for%20people%20to%20%20457af43bf13c4cb5b89919ac19c449cb.md), Build Respect Game app (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md), Research Account Abstraction Services for Gasless Transactions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Account%20Abstraction%20Services%20for%20Gasless%20%2066379e2fdde445b194a7eb797b74e96c.md)
Status: Done
URL: https://x.com/pedrouid/status/1787174156536009179?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to provide a brief overview and introduction to the presentation about smart account wallets by the founder of WalletConnect. The presentation covers the concept and functionality of smart account wallets, offering valuable insights into this innovative technology. The summary serves as a starting point for readers to understand the purpose and significance of the presentation.
Summary: No content
Created time: May 8, 2024 12:24 AM
Last edited time: June 17, 2024 1:51 PM
Created by: Dan Singjoy

[https://x.com/pedrouid/status/1787174156536009179?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/pedrouid/status/1787174156536009179?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)