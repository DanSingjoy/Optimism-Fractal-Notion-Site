# Read and Curate Articles about Optimism Collective Season 6

Assignee: Dan Singjoy
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Explore Mission Opportunities in Optimism Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md)
Status: In progress
Task Summary: This task aims to read and curate articles about Optimism Collective Season 6. The articles include a guide to Season 6, intents ratification, missions v2.5, mission application guide, mission request voting guide, and the vision of Optimism Collective.
Summary: This document provides a list of articles about Optimism Collective Season 6, including a guide to the season, intents ratification, missions v2.5, mission application guide, mission request voting guide, and the vision of Optimism Collective.
Created time: May 23, 2024 9:11 AM
Last edited time: June 1, 2024 10:05 PM
Created by: Dan Singjoy

Below are articles about Optimism Collective Season 6:

[Season 6: Guide to Season 6](https://gov.optimism.io/t/season-6-guide-to-season-6/8113)

[Season 6: Intents Ratification](https://gov.optimism.io/t/season-6-intents-ratification/8104)

[Season 6: Missions v2.5](https://gov.optimism.io/t/season-6-missions-v2-5/8106)

[Season 6: Mission Application Guide](https://gov.optimism.io/t/season-6-mission-application-guide/8114)

[Season 6: Mission Request Voting Guide](https://gov.optimism.io/t/season-6-mission-request-voting-guide/8122/2)

[Vision](https://www.optimism.io/vision)