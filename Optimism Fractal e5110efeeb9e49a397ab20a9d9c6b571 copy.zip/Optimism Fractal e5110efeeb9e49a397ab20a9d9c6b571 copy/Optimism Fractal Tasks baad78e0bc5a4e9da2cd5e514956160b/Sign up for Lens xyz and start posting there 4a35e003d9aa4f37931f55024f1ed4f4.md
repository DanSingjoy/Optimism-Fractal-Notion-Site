# Sign up for Lens.xyz and start posting there

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md), Improve Promotions for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Promotions%20for%20Optimism%20Fractal%20e937c2a5d1f1446ba73482490ea0b347.md), Create Optimism Fractal Promotional Strategy (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Promotional%20Strategy%2092bfd89b01294e988511fe6e4f03f526.md), Explore integrations between Lens Protocol and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20between%20Lens%20Protocol%20and%20Opt%20409f17eb3e0b42aebfd01cbe9cf81dea.md)
Status: In progress
Task Summary: This task aims to guide users in signing up for Lens.xyz, a platform for posting and sharing content. By exploring its unique features and benefits, users will understand how to leverage this permissionless network effectively.
Summary: Lens.xyz is a permissionless platform with around 35k daily users, supported by Aave's funds, offering unique benefits for distribution. It requires a $4 fee paid in MATIC on Polygon, and all posts are immutable and publicly available on-chain.
Created time: July 5, 2024 1:07 PM
Last edited time: July 31, 2024 4:11 PM
Created by: Dan Singjoy
Description: Lens.xyz is a permissionless platform with around 35k daily users, supported by Aave's funds, offering unique benefits for distribution. It requires a $4 fee paid in MATIC on Polygon, and all posts are immutable and publicly available on-chain.

- It has about 35k daily users, which is about half as much as farcaster

- It’s well supported by aave’s funds and totally onchain, which offers some unique benefits. It might also be easier to gain distribution there than farcaster

- it’s now permissionless and seems easy to get started. 4 dollar fee to be paid on polygon via MATIC token

 Note:

All posts are onchain, immutable, and publicly available forever.

![Untitled](Sign%20up%20for%20Lens%20xyz%20and%20start%20posting%20there%204a35e003d9aa4f37931f55024f1ed4f4/Untitled.png)

[https://www.lens.xyz/legal/lens.xyz-terms-and-conditions.pdf](https://www.lens.xyz/legal/lens.xyz-terms-and-conditions.pdf)

![Untitled](Sign%20up%20for%20Lens%20xyz%20and%20start%20posting%20there%204a35e003d9aa4f37931f55024f1ed4f4/Untitled%201.png)

![Untitled](Sign%20up%20for%20Lens%20xyz%20and%20start%20posting%20there%204a35e003d9aa4f37931f55024f1ed4f4/Untitled%202.png)

[ORB PRIVACY POLICY](Sign%20up%20for%20Lens%20xyz%20and%20start%20posting%20there%204a35e003d9aa4f37931f55024f1ed4f4/ORB%20PRIVACY%20POLICY%20f8c1f2e216be41b0bae27e6bc3fdd090.md)

[ORB TERMS & CONDITIONS](Sign%20up%20for%20Lens%20xyz%20and%20start%20posting%20there%204a35e003d9aa4f37931f55024f1ed4f4/ORB%20TERMS%20&%20CONDITIONS%204109548e479a47a0b0c551c3f106111d.md)

[ORB EULA](Sign%20up%20for%20Lens%20xyz%20and%20start%20posting%20there%204a35e003d9aa4f37931f55024f1ed4f4/ORB%20EULA%20941cef9e5a0e41909f423932b169c3d5.md)