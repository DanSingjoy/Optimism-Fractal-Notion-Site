# Respond to blairforce in optimism governance forum about OF

Assignee: Dan Singjoy, Rosmari
Due: July 11, 2024
Status: Done
Task Summary: This task aims to respond to Blairforce in the Optimism Governance Forum about the topic of Optimism Fractal and its weekly events. The response provides information about joining the events, learning about technology, and trying out protocols with on-chain games. It also includes links to the Optimism Fractal website and event RSVP page.
Summary: This document is a response to blairforce in the optimism governance forum about OF. It provides information about joining Optimism Fractal weekly events, learning about tech, and trying out protocols with onchain games. More details can be found on the Optimism Fractal website and event page.
Created time: February 12, 2024 11:02 AM
Last edited time: July 3, 2024 10:27 PM
Created by: Dan Singjoy
Description: In response to blairforce.eth in the optimism governance forum, Dan Singjoy invites them to join Optimism Fractal weekly events to learn about tech, have conversations, and try out protocols with onchain games. More information can be found on the Optimism Fractal website and RSVP can be done at the event page.
Review: March 3, 2024

## Description

- [ ]  first wait until we have a tweet with the correct date before sending

![[https://gov.optimism.io/t/ideas-for-meetups-hangouts-etc/4449](https://gov.optimism.io/t/ideas-for-meetups-hangouts-etc/4449)](Respond%20to%20blairforce%20in%20optimism%20governance%20forum%20a253c3aac813436c8e10b7379a6c8ba6/Untitled.png)

[https://gov.optimism.io/t/ideas-for-meetups-hangouts-etc/4449](https://gov.optimism.io/t/ideas-for-meetups-hangouts-etc/4449)

Hey @blairforce.eth, thanks for introducing yourself and sharing your thoughts. You’re welcome to join Optimism Fractal weekly events, which provide a great place to learn about tech, have conversations with all kinds of optimists, and try out our protocols with fun onchain games. I think it can provide exactly what you’re seeking.

You can find more information at the Optimism Fractal [website](https://optimismfractal.com/) and you're welcome to [RSVP](https://lu.ma/optimismfractal) at the event page. Let me know if there are any questions. Hope to see you there :)

### Response

[https://gov.optimism.io/t/ideas-for-meetups-hangouts-etc/4449/5](https://gov.optimism.io/t/ideas-for-meetups-hangouts-etc/4449/5)

[https://twitter.com/optimystics_/status/1759570531689333242](https://twitter.com/optimystics_/status/1759570531689333242)

[https://gov.optimism.io/t/optimism-fractal-weekly-events/7378/5](https://gov.optimism.io/t/optimism-fractal-weekly-events/7378/5)

[optimismfractal.com](http://optimismfractal.com) 

[lu.ma/optimismfractal](http://lu.ma/optimismfractal) 

include embed to recent tweet