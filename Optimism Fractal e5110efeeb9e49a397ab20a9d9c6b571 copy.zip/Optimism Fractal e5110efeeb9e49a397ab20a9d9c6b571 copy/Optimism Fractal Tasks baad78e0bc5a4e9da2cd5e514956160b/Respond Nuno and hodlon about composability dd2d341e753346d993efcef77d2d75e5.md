# Respond Nuno and hodlon about composability

Assignee: Dan Singjoy
Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Done
Summary: No content
Created time: December 17, 2023 9:14 AM
Last edited time: February 15, 2024 8:06 PM
Created by: Dan Singjoy

By the way, thank you Nuno and @hodlon for asking these great questions a couple weeks ago. I wrote some responses to your questions at the time but didn’t share them here because I think Tadas already answered them well and was quite busy. You can see my draft responses to your questions [here](https://www.notion.so/Respond-Nuno-and-Hodlon-about-Respect-Composability-and-Interoperability-784cc369337a40869b1d1d65d415c979?pvs=21) if you’re still curious about this and want to see a slightly different perspective. As always, feel free to reach out with any follow up questions or comments :)

[Respond Nuno and Hodlon about Respect Composability and Interoperability](https://www.notion.so/Respond-Nuno-and-Hodlon-about-Respect-Composability-and-Interoperability-784cc369337a40869b1d1d65d415c979?pvs=21)