# Curate Research about Developer Tooling

Status: Not started
Summary: This document suggests curating developer tooling and considers the possibility of turning it into a project.
Created time: April 5, 2024 3:33 PM
Last edited time: April 5, 2024 3:36 PM
Created by: Dan Singjoy

## Description

- It may generally be helpful to curate developer tooling here
- Consider if this should be a project instead