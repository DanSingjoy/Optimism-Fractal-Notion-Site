# Listen to onchain summer opening ceremony

Assignee: Dan Singjoy
Due: June 11, 2024
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Done
URL: https://x.com/base/status/1796587985263264245?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to provide information about the opening ceremony of the Onchain Summer event. The page includes details such as the creator, assignee, due date, status, and relevant URLs. It serves as a central reference point for accessing the event's opening ceremony information.
Summary: No content
Created time: May 31, 2024 3:20 PM
Last edited time: June 11, 2024 11:29 PM
Created by: Dan Singjoy

[https://x.com/base/status/1796587985263264245?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/base/status/1796587985263264245?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)