# Learn about Adaptive Quorum Biasing

Project: Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md)
Status: Not started
Summary: Learn about Adaptive Quorum Biasing, a concept suggested by Nuno. For more information, refer to the provided links: https://polkassembly.medium.com/adaptive-quorum-biasing-9b7e6d2a2261 and https://docs.substrate.io/reference/glossary/.
Created time: February 4, 2024 5:36 PM
Last edited time: February 4, 2024 5:38 PM
Created by: Dan Singjoy

## Description

This was suggested by Nuno, in relation to [OREC](https://www.notion.so/OREC-14acfb1d475f4c6ea40c8fb2bd022d9a?pvs=21)  [Review and Refine Orpolls](Review%20and%20Refine%20Orpolls%205a81092f8f504d1dbde02cbdb2ad4b30.md) 

Nuno Amiar (Jan 22, 2024, 1:28 PM)
[https://polkassembly.medium.com/adaptive-quorum-biasing-9b7e6d2a2261](https://polkassembly.medium.com/adaptive-quorum-biasing-9b7e6d2a2261)

[https://polkassembly.medium.com/adaptive-quorum-biasing-9b7e6d2a2261](https://polkassembly.medium.com/adaptive-quorum-biasing-9b7e6d2a2261)

Nuno Amiar (Jan 22, 2024, 1:30 PM)
[https://docs.substrate.io/reference/glossary/](https://docs.substrate.io/reference/glossary/)