# Research alchemy embedded accounts and turnkey

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: In progress
Summary: No content
Created time: March 23, 2024 4:44 PM
Last edited time: March 31, 2024 12:22 PM
Created by: Dan Singjoy

[https://x.com/alchemyplatform/status/1763282544710365211?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/alchemyplatform/status/1763282544710365211?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/alchemyplatform/status/1763282544710365211?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/alchemyplatform/status/1763282544710365211?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)