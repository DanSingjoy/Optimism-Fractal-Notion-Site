# Ask Questions to Snapshot about Improving Front-end and Back-end for OPTOPICS and Cagendas. Consider making a mission proposal to fund this. Also organize notes about DAOHaus, Tally, and JokeRace

Assignee: Dan Singjoy
Due: July 28, 2024
Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md), Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md)
Status: Not started
Task Summary: This task aims to explore the potential improvements for the front-end and back-end functionalities of OPTOPICS and Cagendas through user research. It includes considering a mission proposal for funding and organizing relevant notes about DAOHaus, Tally, and JokeRace to inform decision-making.
Summary: The document discusses improvements for the front-end and back-end of OPTOPICS and Cagendas, suggesting a mission proposal for funding. It outlines various customizations needed, including a tagging system, archiving old proposals, vote expiration, and partial voting power usage, with estimated time and costs for development. It compares Snapshot, DAOhaus, Tally, and JokeRace regarding their features and capabilities, noting that JokeRace has introduced monetization for contests and submissions, while Snapshot remains flexible for off-chain governance with ERC1155 tokens. Recommendations are provided based on specific use cases.
Created time: September 26, 2024 12:18 PM
Last edited time: September 29, 2024 9:54 PM
Created by: Dan Singjoy
Description: The document discusses improving front-end and back-end features for Snapshot and Cagendas, proposing a mission for funding. It outlines various customizations needed, including a tagging system, vote expiration, and partial voting power usage, with estimated costs ranging from $13,000 to $26,000. It compares Snapshot, DAOhaus, Tally, and JokeRace regarding features like sorting proposals, archiving, and monetization, concluding that Snapshot offers the most flexibility for governance, while JokeRace is better suited for gamified contests but involves fees for usage.

are there open source alternative front ends for [snapshot.org](http://snapshot.org/)?

I like [https://decentraland.org/governance/proposals/](https://decentraland.org/governance/proposals/) and would like some of these features. is the front end open source? is it using snapshot as the backend?

These are the features that i want:

- ability to sort proposals/polls by date,
- ability to sort by the proposals/polls by the amount of upvotes,
- ability to add category tags and easily filter to show categories
- the ability to archive old proposals or set them to a different tag after creating them

In addition, there are also some other changes that i'd like that may require backend changes rather than front end changes:

- ability to see make votes expire over time,
- the ability to upvote a poll/proposal with just some of your voting power but not all of your voting power

These features would allow me to better use snapshot for a topic selection game at events.

Please advise on what is possible and easiest to do to gain these features. Should i ask snapshot about these or is there any other software that may work better for this while allowing people to vote with onchain reputation tokens (ERC1155)?

### ChatGPT said:

ChatGPT

Memory updated

The Decentraland Governance page, which you referenced, is indeed built with Snapshot as its backend for managing proposals and voting. Snapshot is an off-chain voting platform used by many DAOs for governance, and its front-end is open-source, allowing customization.

You can find the open-source repository for Snapshot's front end [here](https://github.com/snapshot-labs/snapshot). This means you could potentially fork it and add the features you're interested in.

### Features You Want:

**Front-end Customizations** (Likely possible with the open-source Snapshot front end):

- **Sorting Proposals by Date**: This should be relatively straightforward to implement by adjusting how the front-end fetches and displays proposals.
- **Sorting Proposals by Upvotes**: You can modify the sorting functionality in the front end to accommodate this.
- **Category Tags and Filtering**: You could add this to the UI for filtering and display purposes. It would require a tagging system, which could be handled with metadata stored alongside proposals.
- **Archiving or Tagging Old Proposals**: This could be handled via an additional status flag (like "archived") in the front end, and the corresponding UI to sort/filter based on this status.

**Backend Customizations** (May require deeper changes):

- **Vote Expiration**: This would likely require modifications to how Snapshot stores votes, adding a condition to expire or hide votes after a certain time. Snapshot doesn't support this natively but could be customized.
- **Partial Voting Power Usage**: Snapshot allows users to vote with their full voting power, but supporting partial voting would require changes in how voting power is distributed or how the interface handles voting.

### Next Steps:

1. **Fork Snapshot**: You can fork the Snapshot front-end repository and begin experimenting with the UI changes. Sorting and categorization could be straightforward, while vote expiration and partial voting power may need backend changes or workarounds.
2. **Engage with the Snapshot Team**: It would be useful to open an issue or discussion with Snapshot Labs, especially for the backend changes like vote expiration or partial voting power. They may have plans or suggestions that align with your needs.
3. **Other Software**: If Snapshot doesn't fully meet your requirements, you could explore platforms like **Tally** or **DAOhaus**, which are also popular for DAO governance. However, for onchain voting with ERC1155 tokens, Snapshot is still one of the most flexible options.

These steps would help you move toward creating a tailored governance system with your desired features.

4o

### You said:

I'm not a technical developer who interacts directly with the code and am considering making a funding proposal to pay a developer to do this. Can you please advise on how much work these would be and what would be the appropriate funding compensation?

### ChatGPT said:

ChatGPT

For a non-technical person looking to make a funding proposal to hire a developer, it's important to have a clear understanding of how much work is involved in each of the features you want. Here’s a breakdown of the different features and the potential scope of work involved:

### **Front-End Customizations**:

1. **Sorting Proposals by Date**:
    - **Complexity**: Low.
    - **Time Estimate**: 5–10 hours.
    - **Explanation**: Sorting by date is a relatively simple feature that can be implemented by adjusting the data fetching and display logic.
2. **Sorting Proposals by Upvotes**:
    - **Complexity**: Low to Medium.
    - **Time Estimate**: 10–20 hours.
    - **Explanation**: Similar to sorting by date, but may involve retrieving additional data to rank proposals by the number of votes. This will depend on how the existing Snapshot API or backend provides this data.
3. **Category Tags and Filtering**:
    - **Complexity**: Medium.
    - **Time Estimate**: 15–30 hours.
    - **Explanation**: This would require implementing a tagging system where categories are defined, stored, and displayed, along with filters that users can interact with.
4. **Archiving or Tagging Old Proposals**:
    - **Complexity**: Medium.
    - **Time Estimate**: 10–20 hours.
    - **Explanation**: Implementing an archive flag or additional status options (e.g., "archived") should be manageable with the current data model. The front end will need some modifications to handle these new status tags and display them appropriately.

### **Backend Customizations** (More complex):

1. **Vote Expiration**:
    - **Complexity**: High.
    - **Time Estimate**: 40–80 hours.
    - **Explanation**: This feature would require changes in how the backend stores and manages votes, including adding logic for expiring or hiding them after a certain time. The complexity comes from ensuring that expired votes are handled correctly across the system.
2. **Partial Voting Power Usage**:
    - **Complexity**: High.
    - **Time Estimate**: 50–100 hours.
    - **Explanation**: This is more involved because it requires modifying the voting mechanics to allow users to allocate part of their voting power rather than all of it. This could mean changes to the UI and back-end, as well as handling cases where multiple votes from one user are submitted.

### **Overall Workload & Estimation**:

- **Front-End Features**: Total time estimate is around 40–80 hours.
- **Backend Features**: Total time estimate is around 90–180 hours.

### **Funding Compensation**:

Rates for developers vary, but for quality developers in the blockchain/DAO space, expect hourly rates ranging from **$75–$150 per hour**. This can be higher depending on experience and location (developers in North America or Europe may charge higher rates).

### Estimation Breakdown:

1. **Front-End Customizations** (40–80 hours):
    - At $100/hour: **$4,000–$8,000**.
2. **Backend Customizations** (90–180 hours):
    - At $100/hour: **$9,000–$18,000**.

**Total Estimated Cost**:

- **Low End**: $13,000.
- **High End**: $26,000.

### Proposal Structure:

- **Break down the project into phases**:
    - You could split the project into phases like "Phase 1: Front-End Features" and "Phase 2: Backend Features" so that you can secure initial funding for the simpler front-end work and then seek additional funding based on progress and feedback.
- **Start with Front-End**: The front-end customizations will give you a lot of flexibility early on and are easier to implement, which means faster results and lower costs upfront.

### Final Advice:

1. **Seek Developer Feedback**: Before submitting a funding proposal, it might be beneficial to get input from a few developers for more refined estimates.
2. **Reach out to Snapshot or DAO Developer Communities**: There may be developers already familiar with Snapshot who could complete the work more efficiently, lowering the cost and time required. Platforms like Gitcoin or a DAO dev agency could also help you find talent for this project.

This should give you a solid basis for structuring a proposal and understanding the associated costs.

4o

### You said:

is decentraland or other front-ends for snapshot open source?

### ChatGPT said:

ChatGPT

Yes, many projects that use Snapshot for governance, including **Decentraland**, build custom front-ends on top of Snapshot, but not all of these front-ends are necessarily open-source.

1. **Decentraland**:
    - As of now, Decentraland’s front end for their governance platform (https://governance.decentraland.org/) does **not** appear to be open-source. While their smart contracts and other components are open-source, there is no indication that the front-end for their governance site is.
    
    You could reach out to the Decentraland team to ask if they would consider open-sourcing it or whether they have plans to do so. Sometimes teams share code privately for specific collaborations or requests.
    
2. **Snapshot.org Front-End**:
    - **Snapshot's front end is open-source**. You can view and fork their repository [on GitHub](https://github.com/snapshot-labs/snapshot). This is a good starting point if you want to customize your own governance interface using Snapshot’s back-end.
    
    The Snapshot open-source repository will allow you to add the features you mentioned, such as sorting proposals, filtering by categories, and archiving old proposals.
    
3. **Other Projects Using Snapshot**:
    - **Open-source alternatives**: Projects like **Gnosis Safe**, **Gitcoin**, and other DAOs that integrate Snapshot sometimes open-source their front-end customizations, though it depends on the specific project. You can check their GitHub repositories or reach out to their teams if they have custom front-ends that are open-source.
    - **DAOhaus** and **Tally** are two platforms that offer governance and voting tools, often with open-source components, but these may not always use Snapshot as a back-end.

### Key Takeaways:

- **Decentraland’s front end** for governance is likely **not open-source**.
- **Snapshot’s front end** is open-source and can be customized.
- There are **other open-source projects** you can look into, but it may require checking each project’s GitHub repositories for availability.

If you want to replicate Decentraland’s features, Snapshot's own open-source front-end would be the easiest and most flexible solution to build on.

4o

### You said:

compare DAOhaus and tally with snapshot for these features

### ChatGPT said:

ChatGPT

Let’s compare **DAOhaus**, **Tally**, and **Snapshot** based on the features you're looking for. Each platform is designed to facilitate DAO governance but differs in how customizable or feature-rich they are. Here’s how they stack up:

### 1. **Sorting Proposals by Date**

- **Snapshot**: Yes, this can be done by customizing the front-end. By default, proposals appear in chronological order (from newest to oldest).
- **DAOhaus**: Yes, proposals are generally organized by date, and the platform includes built-in filters to sort and view proposals.
- **Tally**: Yes, Tally also supports sorting proposals by date, with a simple and intuitive interface to view the latest proposals.

### 2. **Sorting Proposals by Upvotes**

- **Snapshot**: No default support for sorting by upvotes, but you can modify the front-end to include this feature. Snapshot has an open-source front-end that can be customized to display proposals by the number of votes.
- **DAOhaus**: Not natively supported. You’d need to add custom sorting functionality if you wanted to rank proposals by the number of upvotes.
- **Tally**: Yes, Tally supports ranking proposals by vote weight, as it emphasizes governance for DAOs like Compound and Uniswap, which involve token-weighted voting.

### 3. **Adding Category Tags & Filtering by Categories**

- **Snapshot**: Not available out of the box, but it can be implemented via customization in the front end. You would need to add metadata for proposals and a filtering mechanism.
- **DAOhaus**: No native category tagging system, but DAOhaus has a robust governance structure that can be extended to support this feature. Adding it would require some development work.
- **Tally**: Does not support category tagging by default. However, it's possible to add this by customizing the front end (if you're using their open-source version) or integrating tags with the backend.

### 4. **Archiving or Tagging Old Proposals**

- **Snapshot**: Archiving proposals isn’t a built-in feature but could be added through custom flags or tags to mark old proposals and then filter them accordingly.
- **DAOhaus**: This would need custom development. Currently, DAOhaus doesn’t have a built-in archiving feature for proposals but supports filtering in various ways.
- **Tally**: No native archiving feature. It’s possible to filter through proposals in the front end, but archiving would likely need to be custom-built.

### 5. **Vote Expiration (Backend Change)**

- **Snapshot**: Not natively supported. Votes are persistent and final. You would need to implement custom logic to make votes expire or hide after a certain period.
- **DAOhaus**: Does not support expiring votes. Since DAOhaus focuses on formal governance processes like proposals and DAO operations, implementing expiring votes would require significant customization.
- **Tally**: No vote expiration feature by default. Since Tally handles on-chain governance, vote expiration may be more complicated to implement, especially on the blockchain.

### 6. **Partial Voting Power Usage (Backend Change)**

- **Snapshot**: Not natively supported, but possible to customize. Snapshot lets users vote with their full voting power, but allowing partial voting power usage would require modifications to how voting is handled and distributed.
- **DAOhaus**: Voting mechanisms in DAOhaus are designed for 1 vote per token system, similar to Snapshot. Customization would be necessary to enable partial voting power distribution.
- **Tally**: Partial voting power isn’t supported out of the box, but Tally’s focus on token-weighted voting may make it easier to customize and implement a partial voting power system.

### Additional Notes:

- **Snapshot** is an off-chain voting solution that is flexible and lightweight, making it easier to customize and build on for your specific needs (front-end and back-end modifications). It integrates well with ERC1155 tokens, making it a good candidate for your use case of on-chain reputation voting.
- **DAOhaus** is highly customizable, focusing on DAO management with on-chain interactions, but it may require more backend work to meet your requirements, especially for vote expiration and partial voting power.
- **Tally** is designed primarily for on-chain governance, often for larger DAOs like Uniswap or Compound. It has strong support for token-weighted voting but is less flexible for customizations like vote expiration or partial voting power.

### Recommendation:

For your specific needs, **Snapshot** remains the most flexible platform. While it lacks some features out of the box, it has an open-source front-end that can be tailored to include sorting by upvotes, categories, archiving, and even vote expiration with backend changes. It's also well-suited for your use case of using ERC1155 tokens.

Both **DAOhaus** and **Tally** are more rigid and may require more extensive modifications to meet your requirements. However, they can still be explored if you prefer an alternative to Snapshot, particularly if you are working with on-chain governance models that involve token-weighted voting.

4o

### You said:

compare with jokerace

### ChatGPT said:

ChatGPT

Here’s a comparison of **Snapshot**, **DAOhaus**, **Tally**, and **JokeRace** based on the features you're interested in for governance and voting:

### 1. **Sorting Proposals by Date**

- **Snapshot**: Yes, this can be customized in the front end, though not a default feature. Proposals typically display in chronological order by default.
- **DAOhaus**: Yes, proposals are generally organized by date, with filters to sort and view them easily.
- **Tally**: Yes, supports sorting proposals by date natively.
- **JokeRace**: Yes, JokeRace is designed to create contests or challenges and rank entries. It supports sorting proposals based on time, and you can set up ranking mechanisms in contests to display submissions by date.

### 2. **Sorting Proposals by Upvotes**

- **Snapshot**: No built-in feature but can be implemented through front-end customization.
- **DAOhaus**: No native support, but sorting based on votes would require customization.
- **Tally**: Yes, Tally allows proposals to be sorted by token-weighted votes, which is similar to sorting by upvotes.
- **JokeRace**: Yes, JokeRace is designed around upvoting and ranking submissions, so sorting proposals by upvotes is a core feature of the platform. It's tailored for contests and ranks entries based on votes, making this a native feature.

### 3. **Adding Category Tags & Filtering by Categories**

- **Snapshot**: Not available by default but can be customized with tags or categories to filter proposals.
- **DAOhaus**: Does not have native category tagging but could be extended with development.
- **Tally**: Tally does not offer this feature natively. You would need custom front-end development to add category tagging and filtering.
- **JokeRace**: Limited. JokeRace is more focused on contests and ranking entries. It does not natively support categories or filtering by categories, but you might be able to customize how contests are categorized.

### 4. **Archiving or Tagging Old Proposals**

- **Snapshot**: Not a built-in feature but can be achieved by tagging or filtering old proposals.
- **DAOhaus**: No native archiving, but old proposals could be manually tagged or archived through additional custom development.
- **Tally**: No native archiving function, though you could build this feature on top.
- **JokeRace**: No native archiving feature, as it’s focused on active contests. However, finished contests could potentially be tagged or moved manually to an “archive” section.

### 5. **Vote Expiration (Backend Change)**

- **Snapshot**: Not supported by default but could be custom-built with significant back-end changes.
- **DAOhaus**: No vote expiration feature. Requires custom development to add this feature.
- **Tally**: No vote expiration feature. As it’s focused on on-chain voting, this would require significant customization.
- **JokeRace**: Somewhat supported. JokeRace revolves around running time-bound contests. You can set specific time limits for voting, and after the contest ends, votes are no longer counted. It doesn’t "expire" votes per se but has time-sensitive voting windows.

### 6. **Partial Voting Power Usage (Backend Change)**

- **Snapshot**: Not supported by default. Allowing users to vote with partial voting power would require backend modifications.
- **DAOhaus**: No native support for partial voting power usage. Custom backend development would be needed.
- **Tally**: Not supported by default, but as Tally uses token-weighted voting, it might be easier to customize partial voting power through on-chain mechanics.
- **JokeRace**: No support for partial voting power. JokeRace voting is generally winner-takes-all per contest. This feature would need significant changes to the way voting is handled on the platform.

### **Key Differences of JokeRace**:

- **Focus on Contests**: Unlike Snapshot, DAOhaus, and Tally, JokeRace is built around creating contests or challenges rather than pure governance. Proposals (or entries) are ranked, voted on, and rewarded based on community input. It’s more suited for gamified decision-making rather than traditional governance voting.
- **Ease of Use for Ranking & Voting**: JokeRace is designed for ranking proposals based on upvotes, making it naturally aligned with your requirement for ranking by votes. However, it lacks some advanced governance features like vote expiration and partial voting power distribution.
- **Best for Topic Selection Games**: JokeRace could work well for your **topic selection game at events**. Its contest-based structure could be used to let participants submit and upvote different topics. Since it’s designed for ranked voting and contests, it could fit well with a gamified event.

### Recommendation:

1. **Snapshot**: If you’re focusing on traditional governance with deep customization options, Snapshot is still the most flexible option. It will allow you to integrate on-chain reputation tokens (ERC1155) and modify the front-end to meet your needs.
2. **JokeRace**: If your primary focus is on **topic selection games** with ranked voting, JokeRace could be a great fit. It’s designed around ranking entries, which aligns with your use case. However, it may lack some advanced governance features like partial voting power and vote expiration, but its simplicity could make it easier to implement quickly.
3. **DAOhaus/Tally**: These platforms are more rigid and focused on formal DAO governance, and while they support token-weighted voting, they would likely require more extensive modifications to implement your desired features, especially the gamified aspects you want for events.

**Final Thoughts**: For a **gamified topic selection** at events, **JokeRace** might be your best starting point due to its focus on contests, ranked voting, and ease of use. For a more **governance-oriented system** with on-chain reputation tokens and flexibility in voting, **Snapshot** remains the better option, especially if you're willing to fund some custom development.

4o

### You said:

can you use jokerace without paying fees for proposal/poll/option creation and voting?

### ChatGPT said:

ChatGPT

JokeRace does not charge direct fees for creating proposals or voting within the platform itself. However, there may be indirect costs depending on how you deploy and use it, especially if you are interacting with blockchains that have transaction fees (gas fees).

- **Off-chain Use**: If JokeRace is being used off-chain (e.g., without recording votes or proposals on a blockchain), there are typically no fees involved.
- **On-chain Use**: If you’re using a blockchain for voting (e.g., Ethereum), users may incur **gas fees** when interacting with smart contracts, including when creating proposals or casting votes. These fees are dependent on the network you’re using and can vary.

If you're planning to use JokeRace in a way that requires voting or proposal creation to be recorded on a blockchain like Ethereum, the gas fees would apply. However, for off-chain contests and interactions, you can generally use the platform without paying fees.

4o

### You said:

I thought that jokerace introduced a monetization feature that requires payment for each contest and contest submission. is that not true? Is it open source or capable to be used offchain (but still with ERC 1155 voting power) like snapshot? If so then it would be free?

### ChatGPT said:

ChatGPT

Yes, JokeRace introduced a **monetization feature** in 2023, which allows the platform to collect fees for each contest and contest submission. This is a key part of their business model, where organizers pay to create contests and participants may also need to pay to submit their entries. The specific fees can vary depending on how the contest is structured.

### Monetization & Fees:

- **Contest Creation Fees**: When you create a contest, there may be a fee associated with setting up the contest on the platform.
- **Submission Fees**: Participants submitting proposals or options for the contest may also need to pay a fee.

These fees help support the development of the platform and the team behind it.

### Open Source & Offchain Use:

As of now, **JokeRace is not fully open-source**. This limits the ability to run your own version of the platform or customize it as freely as you could with an open-source project like Snapshot.

However, using **ERC1155 voting power off-chain** (like Snapshot) would require some custom development, and JokeRace doesn't natively support off-chain voting with ERC1155 tokens. Snapshot is much more flexible for off-chain governance using on-chain reputation tokens (ERC1155) and would allow you to avoid fees if you're only working off-chain.

### Summary:

- **Monetization**: JokeRace does require payment for contest creation and submissions, making it different from Snapshot, which is free for off-chain use.
- **Open Source**: Not fully open-source, meaning you can't easily run a custom instance without relying on their platform.
- **Offchain with ERC1155**: Currently, JokeRace does not offer this functionality like Snapshot, which can be used off-chain for free governance operations.

If you're aiming for a free solution with ERC1155 token voting off-chain, **Snapshot** is likely the better fit.