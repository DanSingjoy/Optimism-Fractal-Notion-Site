# Consider proposing KPIs for Optimism Fractal’s core intents

Assignee: Dan Singjoy
Project: Plan Optimism Fractal Season 4 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%204%2042304244bc404fceb0b2c1279508ed7e.md), Create systems, goals, and metrics to measure the success of Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20systems,%20goals,%20and%20metrics%20to%20measure%20the%20%2013e1391306f94511bf83c98ff58ecca8.md), Create tools and processes to track and prioritize projects and tasks for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20tools%20and%20processes%20to%20track%20and%20prioritize%20104241e49716490eb641cd12529159b9.md)
Status: Not started
Task Summary: This task aims to propose key performance indicators (KPIs) for Optimism Fractal's core intents. The page provides an overview of the task, including the creator, assignee, status, and creation/editing times. It also includes a checklist for reviewing a discussion with Eric and transcribing/summarizing it.
Summary: This document discusses the proposal of Key Performance Indicators (KPIs) for Optimism Fractal's core intents. The assigned task is to review a discussion with Eric and transcribe and summarize it.
Created time: June 13, 2024 9:32 PM
Last edited time: June 13, 2024 9:37 PM
Created by: Dan Singjoy

- [ ]  review discussion with Eric towards the end of EF 30
    - [ ]  transcribe and summarize