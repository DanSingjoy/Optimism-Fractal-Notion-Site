# Research Snapshot formatting and integration with IPFS

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to discuss the formatting and integration of Research Snapshots with IPFS. The page provides an overview of the topic, including markdown and image support, as well as links to IPFS resources. It also raises questions about the display of off-chain content on IPFS and the associated costs.
Summary: This document discusses the formatting and integration of research snapshots with IPFS. It mentions the support for full markdown and images, as well as provides an IPFS link for a snapshot. It also raises a question about the display of a block and the payment for IPFS.
Created time: June 3, 2024 9:11 AM
Last edited time: June 3, 2024 9:11 AM
Created by: Dan Singjoy

## Markdown and Image support

Full markdown support looks nice

![Untitled](Research%20Snapshot%20formatting%20and%20integration%20with%20%2024c9b5cf3f744d3e9733673eb757d20e/Untitled.png)

ipfs - [https://snapshot.4everland.link/ipfs/bafkreid4u77qav7oyvrny73faj5ciehtkrr7gb5h4ykfr2dmaey6onxere](https://snapshot.4everland.link/ipfs/bafkreid4u77qav7oyvrny73faj5ciehtkrr7gb5h4ykfr2dmaey6onxere)

For some reason it shows block even though it’s off chain. Maybe this was when ipfs submitted, but who pays? [https://optimistic.etherscan.io/block/115138341](https://optimistic.etherscan.io/block/115138341)