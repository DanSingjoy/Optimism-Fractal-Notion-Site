# Consider ENS Synergies with Privy?

Project: Integrate Optimism Fractal with ENS (Ethereum Name Service) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20with%20ENS%20(Ethereum%20Name%2003fc813cc6744f87807695748158eed5.md)
Status: On Pause
Summary: Privy's integration with Ethereum Name Service (ENS) is not clear. While Privy offers various integrations, specific details on ENS integration were not readily available. It is recommended to explore developer forums or contact Privy's support for more information on potential integrations with ENS or other blockchain-related services.
Created time: April 4, 2024 9:41 PM
Last edited time: April 4, 2024 9:48 PM
Created by: Dan Singjoy

During OF 21 I mentioned that Vlad is building an app for the Respect Game with Privy, though I don’t think it interacts much with ENS…

Does Privy or Vlad’s design for accounts in the new app synergize well with ENS? Or does Privy operate on a different dimension than ENS?

Related:  [Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md) 

Does [privy.io](http://privy.io) work with ENS?

I wasn't able to find direct information on Privy's integration with Ethereum Name Service (ENS). Privy offers a variety of integrations to enhance its platform, primarily focusing on email marketing, ecommerce support, and customer engagement tools. While Privy supports various integrations to improve user experiences, specific details on ENS integration were not readily available from the sources I checked.

If you're interested in integrating ENS with Privy or another platform, it might be worth exploring developer forums or contacting Privy's support directly for more detailed information on potential integrations and support for blockchain-related services.