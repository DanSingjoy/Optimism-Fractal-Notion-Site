# Research and Curate Tools in the Optimism Collective

Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md)
Status: Not started
Task Summary: This task aims to research and curate tools within the Optimism Collective. The page provides a list of various resources and projects related to the collective, offering potential value for organization and collaboration. The document is currently in need of further organization and exploration of its contents.
Summary: This document is a collection of resources related to the Optimism Collective project. It includes tasks, links to platforms like Rarible and Coordinape, and various marketing examples and proposals.
Created time: January 5, 2024 1:30 AM
Last edited time: May 4, 2024 3:37 AM
Created by: Rosmari

## About this project

This document was started in late 2023 and isn’t very well organized. I’m not sure if it’s worth organizing it further, but am moving it here into to the development hub project in case some of the resources are helpful and others are interested in organizing it

## Project tasks

[Tasks](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Tasks%2088323247d3f841b8b4a1526666d491c5.csv)

[Rarible NFT platform](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Rarible%20NFT%20platform%2000cdb2c063004f249c5776ab17079884.md)

[Kevin Owocki talks about teaching people how to run QF rounds in their local community at around 8th minute. Watch on YouTube](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Kevin%20Owocki%20talks%20about%20teaching%20people%20how%20to%20ru%209c12b1144f414997856fd424a47e370f.md)

[coordinape (@coordinape) / X](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/coordinape%20(@coordinape)%20X%2072e8fe1110e14ddd9f5df2819c4b9563.md)

[QF rounds/funding - DAO Drops (@dao_drops) / X](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/QF%20rounds%20funding%20-%20DAO%20Drops%20(@dao_drops)%20X%20a65957cd2756465daf339ded46312277.md)

[Speed Run Ethereum](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Speed%20Run%20Ethereum%203ccd666ee55e4c8fb781e006111662e3.md)

[MetaGame Twitter](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/MetaGame%20Twitter%20b4b3ce67695c45b6add209c523ac53ac.md)

[Coordinape Website and How It Works | Reimagining Collaboration](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Coordinape%20Website%20and%20How%20It%20Works%20Reimagining%20Co%209302323720c74231a81e40e6e1a2080c.md)

[Frequently Asked Questions | Coordinape](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Frequently%20Asked%20Questions%20Coordinape%205f32690c5e3443e9a54b0b24e4c4ce4d.md)

[Coordinape at Bankless DAO part 2 - YouTube](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Coordinape%20at%20Bankless%20DAO%20part%202%20-%20YouTube%20921d979658ce42e48a8b93825c635700.md)

[Coordinape at Bankless DAO Part 1 - YouTube](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Coordinape%20at%20Bankless%20DAO%20Part%201%20-%20YouTube%20160cf43742fe444ba616a9f4d6acbaa0.md)

[Treasure (@Treasure_DAO) / X - The interconnected network of games. Bringing games and players together through the magic of play](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Treasure%20(@Treasure_DAO)%20X%20-%20The%20interconnected%20ne%2063a3a237143244c3bd4c0e965f5bd383.md)

[Proposal by Ben Jones for Treasure to join the Optimism Superchain – Treasure on the Superchain](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Proposal%20by%20Ben%20Jones%20for%20Treasure%20to%20join%20the%20Opt%203e1e490051554c85b2240e4ffb20f199.md)

[Game cropxyz marketing example](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Game%20cropxyz%20marketing%20example%20b6b6fca06f4c4b2bbca6490f9df69793.md)

[Game cropxyz marketing example](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Game%20cropxyz%20marketing%20example%209fbea48f24bc4ab5a8772deb168953c0.md)

[Game cropxyz marketing example](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Game%20cropxyz%20marketing%20example%205d47b1062a1548689dd6762a0b3bf0f7.md)

[Lemonade Social (@_lemonadesocial) / X](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Lemonade%20Social%20(@_lemonadesocial)%20X%20622f98653a6f433182b657fd1ed36478.md)

[Warpcast - Fqbric Promotion tool](Research%20and%20Curate%20Tools%20in%20the%20Optimism%20Collecti%209d9350bf5f4a41228971ad495e839085/Warpcast%20-%20Fqbric%20Promotion%20tool%20cddb951a592a42f39648c0868c17ab30.md)