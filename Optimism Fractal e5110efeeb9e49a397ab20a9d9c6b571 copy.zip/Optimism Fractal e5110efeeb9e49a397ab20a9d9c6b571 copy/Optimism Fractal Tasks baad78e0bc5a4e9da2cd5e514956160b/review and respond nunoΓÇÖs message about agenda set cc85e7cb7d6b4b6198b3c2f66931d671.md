# review and respond nuno’s message about agenda setting in of discord

Assignee: Dan Singjoy
Due: June 25, 2024
Project: Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md), Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md), Create branding and educational resources for decision-making consensus games (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20branding%20and%20educational%20resources%20for%20deci%20188c45e0a1dc4773bd8202133ced6eb7.md)
Status: Done
Task Summary: This task aims to review and respond to Nuno's message about agenda setting in Discord. It was created by Dan Singjoy and is assigned to Dan Singjoy. The task is marked as done and was due on June 25, 2024. The page includes additional details and can be found under the "See" section.
Summary: No content
Created time: June 20, 2024 12:45 PM
Last edited time: June 28, 2024 2:18 PM
Created by: Dan Singjoy

See [Respond to Nuno about Fractal Democracy ](Respond%20to%20Nuno%20about%20Fractal%20Democracy%207de670285f2c4c298939bdd6b88980df.md) 

![Untitled](Respond%20to%20Nuno%20about%20Fractal%20Democracy%207de670285f2c4c298939bdd6b88980df/Untitled%206.png)

Thanks for sharing, it looks interesting and I’m looking forward to seeing it develops

Wonderful, thank you for linking to Optimism Fractal’s Respect Game page. Here is an interesting [post](https://x.com/bytemaster7/status/1648694633868718080) with a video about the importance of setting agendas. This is one of the reasons why playing Cagendas and voting on topics with Respect can be so helpful