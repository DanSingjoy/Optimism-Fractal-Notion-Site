# Retweet Seth Benton’s tweet about Optimism Fractal, SourceCred, and PlaceCred?

Project: Explore and consider integrating with Intersubjective, Pluralistic Measurement Systems (such as SourceCred, PlaceCred, Praise and Armitage) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20consider%20integrating%20with%20Intersubject%203469e1de3b1e4193bf6dae0c669093f8.md), Create Promotions for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Promotions%20for%20Optimism%20Fractal%20fccca47c97dd47df8ffe81b9b5e60c01.md)
Status: Not started
Summary: No content
Parent-task: Respond to the thread with Seth Benton, Spencer Graham, and SudoFerraz.eth about Quantitative Value Creation Measurement for Decentralized Work with sourcecred, optimism fractal, and armitage (Respond%20to%20the%20thread%20with%20Seth%20Benton,%20Spencer%20Gr%203631f0a5782d40bea7e190480f5391b7.md)
Created time: April 18, 2024 9:49 AM
Last edited time: May 1, 2024 11:52 AM
Parent task: Respond to the thread with Seth Benton, Spencer Graham, and SudoFerraz.eth about Quantitative Value Creation Measurement for Decentralized Work with sourcecred, optimism fractal, and armitage (Respond%20to%20the%20thread%20with%20Seth%20Benton,%20Spencer%20Gr%203631f0a5782d40bea7e190480f5391b7.md)
Created by: Dan Singjoy

## Retweet Seth Benton’s tweet about Optimism Fractal, SourceCred, and PlaceCred?

- I just retweeted it from Dan
- I think it’s good to retweet it from OF too. How about other accounts?

- Consider also linking to the new project: [Explore and consider integrating with Intersubjective, Pluralistic Measurement Systems (such as SourceCred, PlaceCred, Praise and Armitage)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20consider%20integrating%20with%20Intersubject%203469e1de3b1e4193bf6dae0c669093f8.md)

[https://twitter.com/zen_bacon/status/1780666839120646285](https://twitter.com/zen_bacon/status/1780666839120646285)

[Respond to Seth about placecred and optimism fractal and retweet?](Retweet%20Seth%20Benton%E2%80%99s%20tweet%20about%20Optimism%20Fractal%20d7355a14b6574c099b1d1c35237634e0/Respond%20to%20Seth%20about%20placecred%20and%20optimism%20fract%204c6e15474c8546c9bdd0b6d66c8624ca.md)