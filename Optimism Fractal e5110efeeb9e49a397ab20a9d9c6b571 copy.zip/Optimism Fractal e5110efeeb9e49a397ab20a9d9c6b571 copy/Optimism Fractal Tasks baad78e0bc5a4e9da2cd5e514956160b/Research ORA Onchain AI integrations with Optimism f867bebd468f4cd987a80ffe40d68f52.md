# Research ORA Onchain AI integrations with Optimism Fractal and Respect Game app

Assignee: Dan Singjoy
Due: August 9, 2024
Project: Create Optimism Fractal Listening List (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Listening%20List%20c12fe484ec6e49fbae98e702a39747b4.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md), Build Respect Game app (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md), Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Build app component to make it easy for participants to give personal respect at the end of each game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md)
Status: Not started
Task Summary: This task aims to research and explore the integration possibilities of ORA Onchain AI with Optimism Fractal and Respect Game app. The goal is to investigate how ORA Onchain AI can be utilized to enhance the Personal Respect concept and potentially contribute to the development of community gardens. The page includes a podcast discussing the idea of using AI to automatically generate artwork for NFTs, which could be relevant to the integration exploration.
Summary: Research project on integrating ORA Onchain AI with Optimism Fractal and Respect Game app. The project involves listening to a podcast about creating AI-generated artwork for NFTs and exploring its integration with the concept of Personal Respect and community gardens. The project status is not started.
Created time: May 16, 2024 10:59 AM
Last edited time: July 7, 2024 10:13 AM
Created by: Dan Singjoy
Description: Research project on integrating ORA Onchain AI with Optimism Fractal and Respect Game app. The project involves listening to a podcast discussing the idea of using AI to create artwork for NFTs and exploring its integration with the concept of Personal Respect and community gardens. Links to relevant resources are provided.

- [ ]  listen to the podcast
    - I started listening to the first 10 minutes and there was an interesting idea about creating artwork for NFTs automatically with AI. Perhaps this can be integrated into the idea of Personal Respect and/or community gardens
        - [Organize ideas about Community Gardens, Planting Seeds, and Redeemable Community Tokens](Organize%20ideas%20about%20Community%20Gardens,%20Planting%20S%2038fc77413f284a3bbdd82bb1957fe064.md)
        - [Organize Plans for Personal Respect, Distributing after Respect Games, Respect Networks, and Synergies with Optimism Fractal](Organize%20Plans%20for%20Personal%20Respect,%20Distributing%20%20404d4123e7974215968180a9f01a8945.md)

![[https://mirror.xyz/orablog.eth/WhcZyqKeFjcvkKskedBbv8Jrzt5WEmL5JYuUte3NO3w](https://mirror.xyz/orablog.eth/WhcZyqKeFjcvkKskedBbv8Jrzt5WEmL5JYuUte3NO3w)](Research%20ORA%20Onchain%20AI%20integrations%20with%20Optimism%20f867bebd468f4cd987a80ffe40d68f52/Untitled.png)

[https://mirror.xyz/orablog.eth/WhcZyqKeFjcvkKskedBbv8Jrzt5WEmL5JYuUte3NO3w](https://mirror.xyz/orablog.eth/WhcZyqKeFjcvkKskedBbv8Jrzt5WEmL5JYuUte3NO3w)

[So You Wanna Build with Onchain AI?](https://mirror.xyz/orablog.eth/WhcZyqKeFjcvkKskedBbv8Jrzt5WEmL5JYuUte3NO3w)

[https://mirror.xyz/orablog.eth/WhcZyqKeFjcvkKskedBbv8Jrzt5WEmL5JYuUte3NO3w](https://mirror.xyz/orablog.eth/WhcZyqKeFjcvkKskedBbv8Jrzt5WEmL5JYuUte3NO3w)

[https://docs.ora.io/doc/oao-onchain-ai-oracle/introduction](https://docs.ora.io/doc/oao-onchain-ai-oracle/introduction)

[https://www.youtube.com/watch?v=UrDxwwN34y8](https://www.youtube.com/watch?v=UrDxwwN34y8)