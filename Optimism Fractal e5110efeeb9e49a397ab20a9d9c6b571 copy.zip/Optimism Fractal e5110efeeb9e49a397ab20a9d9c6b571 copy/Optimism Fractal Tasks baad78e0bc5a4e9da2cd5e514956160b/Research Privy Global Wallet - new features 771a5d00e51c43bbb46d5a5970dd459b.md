# Research Privy Global Wallet - new features

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: Not started
URL: https://x.com/privy_io/status/1787577991834607983?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to explore and discuss new features for the Research Privy Global Wallet. The goal is to identify and propose enhancements that will improve the functionality and user experience of the wallet. Stay tuned for updates on the progress and status of this project.
Summary: No content
Created time: May 7, 2024 3:40 AM
Last edited time: May 7, 2024 3:41 AM
Created by: Dan Singjoy

[https://x.com/privy_io/status/1787577991834607983?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/privy_io/status/1787577991834607983?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)