# Set up Snapshot Subspaces

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to set up Snapshot Subspaces. It is created by Dan Singjoy and is currently in the "Not started" status. The page provides instructions on exploring http://snapshot.org/ for Cagendas and Copinions, along with a link to the relevant documentation. Additionally, it suggests looking into how decentraland creates their custom categories.
Summary: The document provides instructions to set up snapshot subspaces and suggests exploring http://snapshot.org/ for Cagendas and Copinions. It also mentions decentraland's custom categories as a reference.
Created time: June 3, 2024 9:08 AM
Last edited time: June 3, 2024 9:08 AM
Created by: Dan Singjoy

## Explore [Snapshot.org](http://Snapshot.org) for Cagendas and Copinions

[https://docs.snapshot.org/spaces/sub-spaces](https://docs.snapshot.org/spaces/sub-spaces)

Is this necessary? See how decentraland creates their custom categories

![Untitled](Set%20up%20Snapshot%20Subspaces%202d35024c893c4d74ad2223efc8643a81/Untitled.png)