# Research Smart Wallet from Coinbase Developer Platform

Project: Research Account Abstraction Services for Gasless Transactions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Account%20Abstraction%20Services%20for%20Gasless%20%2066379e2fdde445b194a7eb797b74e96c.md), Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: Not started
Task Summary: This task aims to research the Smart Wallet feature provided by the Coinbase Developer Platform. The page contains information about the Smart Wallet, including an introductory presentation by Jesse Pollack and key links for further exploration. The page also mentions funding opportunities and contact information for Base Developer Relations for assistance.
Summary: This document provides information about researching the Smart Wallet from the Coinbase Developer Platform. It includes links to presentations, key links, funding opportunities, and contact information for help. The Smart Wallet offers additional gas credits and the chance to be featured on the official Onchain Summer page for builders who integrate it.
Created time: June 8, 2024 9:52 PM
Last edited time: June 9, 2024 11:55 AM
Parent task: Research Coinbase Developer Platform (Research%20Coinbase%20Developer%20Platform%2060c4fa44c72f48a5a60a2d3cb11ba1f0.md)
Created by: Dan Singjoy

# Research Smart Wallet from Coinbase Developer Platform

[https://twitter.com/base/status/1798370085020828028](https://twitter.com/base/status/1798370085020828028)

## Presentation

[https://youtu.be/yNG9iFhD_ME?si=QdIz4iMRG5mwtsr3&t=530](https://youtu.be/yNG9iFhD_ME?si=QdIz4iMRG5mwtsr3&t=530)

Jesse Pollack, the creator of Base, provides an excellent introductory presentation to the Smart Wallet built by Coinbase at [9:30](https://youtu.be/yNG9iFhD_ME?si=QdIz4iMRG5mwtsr3&t=530) in the above video. You can learn more about the Smart Wallet at [wallet.coinbase.com/smart-wallet](https://wallet.coinbase.com/smart-wallet) and [smartwallet.dev](http://smartwallet.dev).

## Key Links

[Smart Wallet](http://smartwallet.dev/)

[Coinbase Wallet: All your crypto, all in one place](https://wallet.coinbase.com/smart-wallet)

[https://x.com/nassyweazy/status/1799080902078689663?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/nassyweazy/status/1799080902078689663?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

### Funding Opportunities for Integrating Coinbase Developer Platform Tooling

In addition to the track rewards in the Onchain Summer Buildathon, Base is adding a bonus pool of 40 ETH for builders using the following tools to superpower their onchain apps: [Coinbase Smart Wallet](https://www.coinbase.com/wallet/smart-wallet), [Coinbase Verifications](https://www.coinbase.com/onchain-verify), [Coinbase Paymaster](https://docs.cloud.coinbase.com/base-node/docs/paymaster-bundler-api), and [OnchainKit](https://onchainkit.xyz/).

For builders who integrate Smart Wallet, we’ll offer up to $15k in additional gas credits to eligible recipients through the [Base Gasless Campaign](https://www.smartwallet.dev/base-gasless-campaign) and the chance to be featured on the official Onchain Summer page in July.

## Contacting Base Developer Relations for Help

During the Onchain Summer Buildathon Launch Stream on X, the creator Wilson Cusack and Jesse Pollack invite builders to reach out to them on the Base and Coinbase Developer Discord if they need any help.

[Contact developer relations team at base ](Contact%20developer%20relations%20team%20at%20base%200259a96f5fad431e9b16df32a0d9a62b.md) 

[Find Coinbase Developer Platform Discord and Base Builders Telegram chat](Find%20Coinbase%20Developer%20Platform%20Discord%20and%20Base%20%207545304d46df443d850ebf82226051eb.md) 

### Integrations and Synergies with Onchain Kit

[Research OnchainKit from Coinbase Developer Platform](Research%20OnchainKit%20from%20Coinbase%20Developer%20Platfo%209828b1780cbe497699060bac1714ff3f.md) 

## More Resources

[https://x.com/jessepollak/status/1787134151902343397?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/jessepollak/status/1787134151902343397?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/jessepollak/status/1788018602324775306?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/jessepollak/status/1788018602324775306?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/jessepollak/status/1786816407956824358?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/jessepollak/status/1786816407956824358?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/bloomberg_seth/status/1770426199296160214?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/bloomberg_seth/status/1770426199296160214?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://youtube.com/watch?v=5PBUtgO-3P8&si=uPMPbg17nPP3I4XA](https://youtube.com/watch?v=5PBUtgO-3P8&si=uPMPbg17nPP3I4XA)

Smart wallets 101 video with timestamps in description

## Details about Coinbase Developer Platform

[Research Coinbase Developer Platform](Research%20Coinbase%20Developer%20Platform%2060c4fa44c72f48a5a60a2d3cb11ba1f0.md)