# Review message to Hodlon with notes about governance and social media, then add some of them here

Project: Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Create Documentation for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Documentation%20for%20Optimism%20Fractal%203ddb136554ea454b875ca8ec00d3900d.md), Improve Documentation for Optimism Fractal Tools (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Documentation%20for%20Optimism%20Fractal%20Tools%205e64d804bdda4f75aea849c05124ed55.md)
Status: Not started
Task Summary: This task aims to provide a review message to Hodlon, including notes about governance and social media. The review message will offer insights and suggestions regarding these topics. It was created by Dan Singjoy and is currently in the "Not started" status.
Summary: This document is a review message to Hodlon regarding governance and social media. It includes notes that will be added later.
Created time: June 23, 2024 10:50 AM
Last edited time: June 23, 2024 10:52 AM
Created by: Dan Singjoy

See [Respond to Hodlon about Bundl and iDunno DAO](https://www.notion.so/Respond-to-Hodlon-about-Bundl-and-iDunno-DAO-99bbf08e2b4441e6ba8226067101634a?pvs=21) 

- [ ]  consider also adding some of my writing here to [Improve [OptimismFractal.com](http://OptimismFractal.com) Website (and Create Educational Resources)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md) and/or [Create Documentation for Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Documentation%20for%20Optimism%20Fractal%203ddb136554ea454b875ca8ec00d3900d.md)
    - [ ]  then consider adding adding tasks and/or pages for resiliency, decentralization, pseudonymity, social media, and autonomy
        - [ ]  also consider adding other things i wrote on these subjects, like the EC articles about autonomy
        - [ ]  consider if some of these should be added to a larger article instead of as a separate task or documentation
            - for example: resiliency, decentralization, and autonomy could all be added to the governance page/task