# Post about Optimism Fractal Hats Tree, Hatathon, ORDAO Office Hours, and technical development in Optimism Governance Forum

Due: July 2, 2024
Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Done
Task Summary: This task aims to provide an update on various initiatives related to the Optimism Fractal Hats Tree, including the recent Hatathon, ORDAO office hours, and ongoing technical developments. It highlights the collaborative efforts and future steps in enhancing the Optimism Fractal community through innovative integrations with Hats Protocol.
Summary: The Optimism Fractal Hats Tree won a co-grand prize at the Hats Protocol Hatathon, providing utilities for the Optimism Fractal community. Participants can claim hats based on earned Respect, enabling access to new features and networking opportunities. Upcoming events will discuss technical updates and further integrations with Hats Protocol, enhancing community collaboration and governance.
Created time: September 13, 2024 9:10 PM
Last edited time: September 19, 2024 10:12 AM
Created by: Dan Singjoy
Description: The Optimism Fractal Hats Tree was co-winner of the Mad Hatter grand prize at the Hats Protocol Hatathon, providing utilities for the Optimism Fractal community. Users can claim hats for earned Respect, enhancing integrations with Hats Protocol. The update includes technical developments, upcoming events, and a focus on collaboration within the community. The initiative aims to improve autonomy and decentralization in governance.

Hey all! I’m writing here to provide an update about the new Optimism Fractal Hats Tree and other exciting technical developments:

# Optimism Fractal Hats Tree

I’m pleased to announce that the [Optimism Fractal Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) was selected a co-winner of the Mad Hatter grand prize in the first Hats Protocol Hatathon! 🌻🧢

A couple weeks ago I teamed up with @JacobHomanics to participate in the Hats Protocol [Hatathon](https://t.me/hatsprotocolandoptimismfractal/151) and we launched a great MVP, which provides valuable utilities for Optimism Fractal Respect and helps organize the Optimism Fractal community. You can explore the features of the Hats Tree below: 

[https://x.com/hatsprotocol/status/1833864343714513247](https://x.com/hatsprotocol/status/1833864343714513247)

### Next Steps and Thanks

This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. Huge thanks to Jacob for the amazing work building the Hats Tree and all the great support from the Haberdasher Labs team. You can learn more at [HatsProtocol.xyz](http://hatsprotocol.xyz/) and the ‘Hats Protocol + Optimism Fractal’ [telegram group](https://telegram.me/hatsprotocolandoptimismfractal) where we’re planning the next steps with the Hats founders.

[https://twitter.com/JacobHomanics/status/1831774911767203931](https://twitter.com/JacobHomanics/status/1831774911767203931)

### How to Claim Optimism Fractal Hats

If you have earned Optimism Fractal Respect then you claim your hats now to gain unique powers and help enhance our integrations with Hats Protocol!

You can claim the Rookie Hat by clicking [here](https://app.hatsprotocol.xyz/trees/10/175?hatId=175.1.2), then connecting your wallet and clicking the ‘claim hat’ button near the right side of the screen. If you’d like to signify that you’re ready to host a breakout room for the Respect Game then you can also claim the Rising Star, Fractalgram Certification, and Respect Game Leader hats as well.

[https://x.com/DanSingjoy/status/1831509179657273773](https://x.com/DanSingjoy/status/1831509179657273773)

### Hats at Optimism Town Hall

We commemorated the momentous win at last week’s Optimism Town Hall event by exploring the Optimism Fractal Hats Tree and the new Optimism Fractal charmverse space, which features a Respect-Gated networking page for builders. We also provided an introduction to Hats Protocol and explored [Let’s GROW](https://www.letsgrow.network/) and the [Let’s GROW DAO Hats Tree](https://app.hatsprotocol.xyz/trees/10/102), which was the other co-winner of the Hatathon Mad Hatter Grand Prize.

This event provided a great overview of the Hats Protocol and the new Hats Trees.  You can watch the episode on the Eden Creators [youtube channel](https://www.youtube.com/@EdenCreators) and explore detailed show notes at [OptimismFractal.com/41](http://OptimismFractal.com/41). You can also learn more exciting details about the Optimism Fractal Hats Tree and Hats Protocol by watching this [interview](https://www.youtube.com/watch?v=vVQbuUUn5pc) with Jacob Homanics, which was hosted by an Optimism Fractal community member named Patrick and released on his youtube channel this week.

[https://x.com/optimystics_/status/1833953500285600250](https://x.com/optimystics_/status/1833953500285600250)

# More Technical Updates

The rate of Optimism Fractal technical developments is increasing rapidly and there are many other great updates that we’re stoked to share with you. Stay tuned for exciting details about the next generation of Respect Game apps and Optimism Fractal onchain governance protocols. These also compose nicely with the Hats Tree above to increase Optimism Fractal’s autonomy, coordination, and decentralization!

# This Week’s Events

This week I proposed a new version of the [OPTOPICS](https://snapshot.org/#/optimismtownhall.eth/proposal/0xc524f83646c7bdb8116568577b0b4c398e374fbb368913c13bf2fa3a42541532) Cagendas game for the Optimism Town Hall and it was approved as the scheduled topic, so we can discuss more about technical updates or other topics at this week’s town hall event according to the community’s consensus and the game rules linked above.

As always, everyone is welcome to join our [weekly events](https://lu.ma/optimystics) to learn more, get involved, and collaborate with Superchain Builders. Hope to see you there! 🤠

[Optimystics.io/ordao](http://Optimystics.io/ordao) and [Optimystics.io/orec](http://Optimystics.io/orec) 

## Interviews about Hats Protocol

I’ll ask Wasabi to share a brief presentation about the [Let’s GROW DAO Hats Tree](https://app.hatsprotocol.xyz/trees/10/102) and provide an introduction to [Let’s GROW](https://www.letsgrow.network/), then we can also have an open discussion about various ways to collaborate and integrate with Hats on Optimism.

 Looking forward to hearing your thoughts and seeing you at the event!

So far they’ve created a basic [Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) that enables anyone who has earned Respect at Optimism Fractal weekly events to claim a Rookie Hat, which grants access to the Optimism Fractal charmverse [space](https://app.charmverse.io/optimismfractal) and a new networking page for builders. The Hats Tree also enables anyone who has earned over 50 Respect and read the tutorial article about fractalgram to claim a Respect Game Leader hat, which signifies that you can lead a breakout room at weekly events.

The Optimism Fractal [Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) enables anyone who has earned Respect at our weekly events to claim a Rookie Hat, which grants access to the new Optimism Fractal [charmverse space](https://app.charmverse.io/optimismfractal/welcome-33440438705074915) and a networking page for builders. The Hats Tree also enables participants who’ve earned over 50 Respect and complete a Fractalgram Certification to wear a Respect Game Leader hat.

Huge thanks to @jacobhomanics for all the amazing work building the Hats Tree and all the excellent support from the Haberdasher Labs team. This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. You can learn more at [HatsProtocol.xyz](http://hatsprotocol.xyz/), this [notion project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), and the ‘Hats Protocol + Optimism Fractal’ [telegram group](https://telegram.me/hatsprotocolandoptimismfractal) where we’re planning the next steps with the Hats founders.

I hope to see you at our [weekly events](https://lu.ma/optimystics) tomorrow where we’ll collaborate with builders on the Superchain and advance Eden Fractal’s mission of implementing fractal decision-making processes throughout society. Hope to see you there! 🤠

We participated in the Hats Protocol [Hatathon](https://t.me/hatsprotocolandoptimismfractal/151) and they've launched a great MVP! So far they’ve created a basic [Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) that enables anyone who has earned Respect at Optimism Fractal weekly events to claim a Rookie Hat, which grants access to the Optimism Fractal charmverse [space](https://app.charmverse.io/optimismfractal) and a new networking page for builders. The Hats Tree also enables anyone who has earned over 50 Respect and read the tutorial article about fractalgram to claim a Respect Game Leader hat, which signifies that you can lead a breakout room at weekly events.

If you have earned Optimism Fractal Respect then please claim your hats to help enhance our integrations with Hats Protocol. You can claim the Rookie Hat by clicking [here](https://app.hatsprotocol.xyz/trees/10/175?hatId=175.1.2), then connecting your wallet and clicking the ‘claim hat’ button near the right side of the screen. If you’d like to signify that you’re ready to host a breakout room for the Respect Game then you can also claim the Rising Star, Fractalgram Certification, and Respect Game Leader hats as well. You can also join this [chat](https://t.me/hatsprotocolandoptimismfractal) to learn more and participate in our discussions with the founders of Hats Protocol. 

This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. Huge thanks to Jacob for all the amazing work building the Hats Tree and all the support from the Haberdasher Labs team!