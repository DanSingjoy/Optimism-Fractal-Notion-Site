# Research Mel.eth’s work with Oxcart voting method

Assignee: Dan Singjoy
Due: August 7, 2024
Status: Not started
Task Summary: This task aims to research and analyze Mel.eth's work with the Oxcart voting method. The goal is to understand the implementation and effectiveness of the Oxcart method as a voting mechanism. The research will provide insights into the potential benefits and limitations of using Oxcart for voting systems.
Summary: Research Mel.eth's work with the Oxcart voting method. The task was created by Dan Singjoy and is due on August 7, 2024. The status is currently not started. The GitHub repository for Oxcart can be found at https://github.com/emjicy/Oxcart.
Created time: July 24, 2024 12:53 PM
Last edited time: July 24, 2024 12:57 PM
Created by: Dan Singjoy
Description: Research Mel.eth's work with the Oxcart voting method. The task was created by Dan Singjoy and is due on August 7, 2024. The status is currently not started. The GitHub link for the project is https://github.com/emjicy/Oxcart.

[https://github.com/emjicy/Oxcart](https://github.com/emjicy/Oxcart)