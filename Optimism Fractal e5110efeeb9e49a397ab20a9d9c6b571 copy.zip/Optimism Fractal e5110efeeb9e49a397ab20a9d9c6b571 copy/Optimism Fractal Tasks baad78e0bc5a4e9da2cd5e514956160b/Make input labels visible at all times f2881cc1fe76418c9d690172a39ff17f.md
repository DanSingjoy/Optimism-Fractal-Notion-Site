# Make input labels visible at all times

Status: Not started
Summary: To improve clarity, ensure that input labels are always visible. Currently, when pre-filled rows containing public keys are displayed in the UI, the top row does not indicate its purpose, causing confusion for new users.
Parent-task: Review Rosmari’s Message with Optimism Fractal app feedback from Hodlon, Bitbeckers, and Seth (Review%20Rosmari%E2%80%99s%20Message%20with%20Optimism%20Fractal%20app%20ebc983716281450682f56931412592a9.md)
Created time: March 7, 2024 10:57 AM
Last edited time: April 23, 2024 5:39 AM
Parent task: Review Rosmari’s Message with Optimism Fractal app feedback from Hodlon, Bitbeckers, and Seth (Review%20Rosmari%E2%80%99s%20Message%20with%20Optimism%20Fractal%20app%20ebc983716281450682f56931412592a9.md)
Created by: Tadas Vaitiekunas

## Description

After inputs are filled it’s not clear what they represent

- “When we look at the UI where we get pre-filled rows containing the public keys showing the consensus results, the top row doesn't say what it's for. It usually gets filled in subsequently either with a room number '1' or '2' but for a new person when they double-check the public keys, it can be confusing because it doesn't say that it's representing the breakout room number.”