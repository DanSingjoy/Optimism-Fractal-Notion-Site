# Review Optimism Fractal Videos about Hats Protocol

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: This document provides an overview of Optimism Fractal videos discussing Hats Protocol integration. The videos include discussions on privacy tools, DAO governance, community coordination, composability potentials, and integrations with the Respect Game. Discord conversations about Hats Protocol are also mentioned.
Created time: February 15, 2024 6:42 PM
Last edited time: March 17, 2024 9:33 PM
Parent task: Review status, plans, and history of collaborations between Optimism Fractal and Hats Protocol (Review%20status,%20plans,%20and%20history%20of%20collaboration%2002671444172e45cf93be73e5b2359e5a.md)
Created by: Dan Singjoy

## Introduction

We’ve discussed Hats Protocol in several Optimism Fractal events so far. You can see the videos, timestamps, and overviews of discussions from a few of these events below:

### OF 10

[24:42](https://www.youtube.com/watch?v=ood7Rzgb2Bw&t=1482s) Hodlon shares screen about working on privacy tools and DAO governance. He published casts on Farcaster about reputation-based governance and Optimism Fractal. Hodlon shares about using Quests to track contributions, for example integrating Optimism Fractal with Hats Protocol. Also shared a book he’s reading on DAO governance

[1:12:38](https://www.youtube.com/watch?v=ood7Rzgb2Bw&t=4358s) Dan and Hodlon discuss to continue the discussion offline about Hats Protocol integration.

[https://www.youtube.com/watch?v=ood7Rzgb2Bw&t=1482s](https://www.youtube.com/watch?v=ood7Rzgb2Bw&t=1482s)

### OF 9

[17:41](https://youtu.be/2x4xU2J8Jak?si=ggScJlKxPKqPrNgY&t=1061) Dan researched Hats Protocol for community coordination, in-depth on composability potentials with the OP fractal respect system and tools. 

[https://www.youtube.com/watch?v=2x4xU2J8Jak&t=860s](https://www.youtube.com/watch?v=2x4xU2J8Jak&t=860s)

### OF 8

[10:56](https://youtu.be/bQpiTD3kbmA?si=S6ESPB8Es33LggH-&t=655) - Nuno is exploring Hats Protocol integrations with the Respect Game

[34:26](https://youtu.be/bQpiTD3kbmA?si=nrRx03XaOiUKOdBn&t=2066) - Dan shares his interest about Hats Protocol and their meet ups and demo day coming up

[1:25:47](https://youtu.be/bQpiTD3kbmA?si=YjkP6p6G86v06dE_&t=5147) - Dan shares thoughts about composing Respect with Hats Protocol

[https://youtu.be/bQpiTD3kbmA?si=S6ESPB8Es33LggH-&t=655](https://youtu.be/bQpiTD3kbmA?si=S6ESPB8Es33LggH-&t=655)

### **Discord Conversations**

After the 8th Optimism Fractal event, then discussions started about Hats Protocol in the Optimism Fractal Discord. You can see these in [Review Posts about Hats Protocol in Optimism Fractal Discord ](Review%20Posts%20about%20Hats%20Protocol%20in%20Optimism%20Fract%20414959d259014507896f2894d27a054a.md)