# Post about Eden Fractal in OF chat

Project: Prepare for Optimism Fractal 37 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20Optimism%20Fractal%2037%2021c5f2f7dfe14e57ab1fe2e1bfec7978.md)
Status: Done
Task Summary: This task aims to provide an overview of the upcoming discussion and activities related to the Eden Fractal community as it transitions into Epoch 2. It outlines key topics for discussion, including updates on software development, community input, and the significance of collective decision-making processes in shaping the future of Eden Fractal.
Summary: Eden Fractal is entering Epoch 2 on August 14th, featuring a recap of the Epoch 2 proposal, software development updates, and an open discussion on goals and plans. Community members are encouraged to share their progress and ideas to shape the future of fractal decision-making. Registration for events is available on the events calendar, and past videos can be accessed on related websites. The focus is on collaboration and optimizing collective decision-making processes.
Created time: August 12, 2024 7:22 PM
Last edited time: August 12, 2024 10:13 PM
Created by: Dan Singjoy
Description: Eden Fractal is entering Epoch 2 on August 14th, featuring a recap of the Epoch 2 proposal, software development updates, and an open discussion on goals and plans. Community members are encouraged to share their work and ideas to shape the future of fractal decision-making. Registration for events is available on the events calendar, and resources from past seasons can be found on related websites. The importance of focusing on larger missions was noted, suggesting that promotion of Eden Fractal should not distract from Optimism Fractal.

![EF 104 promotional image.png](Post%20about%20Eden%20Fractal%20in%20OF%20chat%205dd685a1fb1b428585288110bcbe9d5c/EF_104_promotional_image.png)

You’re also welcome to join as we step into Epoch 2 of Eden Fractal on Wednesday, August 14th!

We’ll start with a recap of the [Epoch 2 proposal](https://www.notion.so/Introducing-Eden-Fractal-Epoch-2-4eaaf4268f5a4dd79e58aa4d70451fae?pvs=21), provide updates on software development, and have an open discussion on our goals and plans for this epoch. Eden Fractal is transitioning into it’s next phase to help Optimism Fractal as much as possible and you can find more details about this week’s event in this post. We invite community members to share what they’ve been working on, help shape the future of fractal consensus processes, and participate to optimize collective decision-making throughout society.

You can register to join all three events on our [events calendar](https://lu.ma/optimystics). As always, you can learn more and watch all the videos from past seasons at [Optimystics.io](http://Optimystics.io). Looking forward to seeing you at the events!

![fractal events presented by Optimystics2.png](Post%20about%20Eden%20Fractal%20in%20OF%20chat%205dd685a1fb1b428585288110bcbe9d5c/fractal_events_presented_by_Optimystics2.png)

Hey friends,

I hope you've all enjoyed the summer break! I’m excited to reconvene this Wednesday as we step into Epoch 2 of Eden Fractal. This marks an important transition in our journey and we'd love your input on shaping our path forward. For our first session back, I suggest that we have a discussion about planning our second epoch. Here's what you can expect:

- **A recap of the [Epoch 2 proposal](https://www.notion.so/Introducing-Eden-Fractal-Epoch-2-4eaaf4268f5a4dd79e58aa4d70451fae?pvs=21)**: We'll briefly revisit the original Epoch 2 proposal to refresh our collective memory, set the stage for our next steps, and explore any new feedback or ideas that have since emerged.

- **Updates on software development**: While I hoped to start playing Respect Games on Base at the start of Epoch 2, the tools aren't yet fully ready. I can provide updates on the progress and we can discuss potential interim activities.

- **Open discussion on our goals and plans:** This is your chance to share thoughts, ideas, and aspirations for Epoch 2. What do you hope to achieve? What challenges do you foresee? How can we best actualize our vision?

- **Updates from community members:** Each participant can share what they’ve been up to over the break and how Eden Fractal can help achieve their goals. What can Eden Fractal do to help you in this epoch?

I'm excited to hear your thoughts and share some exciting updates. This is a crucial time for Eden Fractal and your input is appreciated. Join us on Wednesday to reconnect, plan our second Epoch, and help shape the future of fractal decision-making processes!

![EF 104 promotional image.png](Post%20about%20Eden%20Fractal%20in%20OF%20chat%205dd685a1fb1b428585288110bcbe9d5c/EF_104_promotional_image.png)

**Eden Fractal**

This Wednesday we step into Epoch 2 of Eden Fractal. We’ll start with a recap of the [Epoch 2 proposal](https://www.notion.so/Introducing-Eden-Fractal-Epoch-2-4eaaf4268f5a4dd79e58aa4d70451fae?pvs=21), provide updates on software development, and have an open discussion on our goals and plans for this epoch. We invite community members to share what they’ve been working on, help shape the future of fractal consensus processes, and optimize collective decision-making throughout society.

You’re welcome to join both events whether you have big ideas, small suggestions, or just want to connect. You can register on our [events calendar](https://lu.ma/optimystics) and find more details in this post. As always, you can learn more and watch all the videos from past seasons at [OptimismFractal.com](http://OptimismFractal.com), [EdenFractal.com](http://EdenFractal.com), and [Optimystics.io](http://Optimystics.io). Looking forward to seeing you at the events!

![fractal events presented by Optimystics2.png](Post%20about%20Eden%20Fractal%20in%20OF%20chat%205dd685a1fb1b428585288110bcbe9d5c/fractal_events_presented_by_Optimystics2.png)

I think it’s not a high priority for me to do this right now bc the missions are larger priority, Rosmari will share the promotion for eden fractal any way, and we don’t need to promote eden fractal twice in OF chat bc that would distract from Optimism Fractal