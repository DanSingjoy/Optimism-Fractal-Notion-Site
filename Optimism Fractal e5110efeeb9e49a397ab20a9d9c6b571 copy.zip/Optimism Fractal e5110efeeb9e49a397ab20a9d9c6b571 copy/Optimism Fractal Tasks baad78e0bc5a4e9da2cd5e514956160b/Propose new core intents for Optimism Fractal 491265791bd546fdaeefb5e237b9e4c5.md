# Propose new core intents for Optimism Fractal

Assignee: Dan Singjoy
Due: June 18, 2024
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Define and refine Optimism Fractal's Core Intents (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Define%20and%20refine%20Optimism%20Fractal's%20Core%20Intents%205cfde79be1bd4396ba06b298876221f7.md), Plan Optimism Fractal Season 4 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%204%2042304244bc404fceb0b2c1279508ed7e.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md), Network and collaborate with governance enthusiasts in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Network%20and%20collaborate%20with%20governance%20enthusiast%20d5efbbcde39e4bf9a7a16aec51786709.md)
Status: Done
Task Summary: This task aims to propose new core intents for Optimism Fractal, focusing on optimizing collective governance in the Optimism Superchain and the Optimism Collective. The draft proposal outlines the suggested changes and provides rationale for updating the core intents. The goal is to foster collaboration, award public good creators, and enhance governance processes within the Optimism Fractal community.
Summary: This document proposes new core intents for Optimism Fractal, focusing on optimizing collective governance in the Optimism Superchain. The proposal suggests updating the core intents to include this focus and provides rationale for the changes. The document also includes questions and answers, as well as alternate versions and additional rationale for the proposed core intents.
Sub-task: Create proposal to update core intent of Optimism Fractal (Create%20proposal%20to%20update%20core%20intent%20of%20Optimism%20%20e2c93b9a89494965a628fae508b424ce.md)
Created time: May 30, 2024 12:24 PM
Last edited time: June 28, 2024 2:09 PM
Sub-tasks: Create proposal to update core intent of Optimism Fractal (Create%20proposal%20to%20update%20core%20intent%20of%20Optimism%20%20e2c93b9a89494965a628fae508b424ce.md)
Created by: Dan Singjoy

## Introduction

This page introduces a draft proposal to update the core intents for Optimism Fractal. The potential changes are about optimizing collective governance in the Optimism Superchain and the Optimism Collective. This page shows all the thought processes that went into creating this draft proposal and it is here for reference if you are interested.

**Table of Contents**

## Draft Proposal for Updating Optimism Fractal’s Core Intents

If this proposal is approved, the core intents of Optimism Fractal will be updated to include ‘optimize collective governance’. This intent will be updated on OptimismFractal.com and on social media. Everything else would remain the same in the intent as published on [OptimismFractal.com/details](http://OptimismFractal.com/details) except for the following change:

### Current Core Intents

**Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.**

### Proposed Core Intents

**Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.**

**~~Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance in the Optimism Collective and Superchain.~~**

### What are the Proposed Changes?

The two changes in this draft proposal are:

1. The inclusion of ‘optimizing governance’ 
2. The specifying of Optimism as the Optimism Collective and Superchain

![image.png](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5/image.png)

### Update

After thinking this over, I think it’s better to specify Optimism as the either the Optimism Superchain or just Superchain. It makes it longer to state the ‘Collective’ and I think this is already mostly implied by stating Optimism Superchain. So the updated proposal that I’m now thinking about is: 

**Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.**

**~~Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Superchain.~~**

- I think this is the best version because its good to mention the Superchain and it’s repetitive to mention the word Optimism twice.
    - Actually I think on the Optimism Superchain is better because some people might not know what is the Superchain

**~~Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.~~**

**~~Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance in the Optimism Superchain.~~**

### Rationale

I believe that it’s helpful to change the core intents in this way for the following reasons:

1. Optimism Fractal is now pioneering collective decision-making in various ways, including our  [Council](https://optimismfractal.com/council), advanced software for granular decision-making like [Respect Trees](https://optimystics.io/respect-trees), and topic discussion games at [Optimism Town Hall](https://lu.ma/optimismtownhall). When the Optimystics initially set the current core intents last October, Optimism Fractal was just beginning and had less to offer in terms of collective governance. Now, it has grown significantly and can make a substantial impact on Optimism Collective governance.

2. Optimism Fractal is rooted in [fractal democracy](https://fractally.com/blog/what-is-fractal-democracy), a governance process designed to truly empower people throughout society. This [article](https://optimystics.io/blog/fractalhistory) about the History of Fractals explains how the goal of improving collective governance is deeply ingrained in the fabric of Optimism Fractal. You can explore the article to understand how Optimism Fractal evolved from Eden Fractal, More Equal Animals, ƒractally, and the efforts of hundreds of dedicated builders optimizing governance processes.

1. The Optimism Collective aims to improve governance and the first intent ratified by the Collective in [Season 6](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md) is to move towards decentralization. As stated in the intent ratification [article](https://gov.optimism.io/t/season-6-intents-ratification/8104), “This includes both technical and organizational decentralization – including work to improve upgrade processes, governance execution, the development ecosystem, and governance processes of the Collective.” Optimism Fractal can play an increasingly important role on the Collective’s Path to Open MetaGovernance of the community leadership, which you can learn more about on this [page](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20and%20Strategize%20to%20provide%20Optimism%20Collec%20ad36d53370ce43a18be5b0ff973a2052.md).

2. The [6th round of Retro Funding](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861#retro-funding-6-governance-14) focuses on governance and setting this as a core intent can help Optimism Fractal community members to earn funding by providing a positive impact on Optimism Collective governance. You can learn more about how Optimism Fractal can help you earn Retro Funding in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md) and how we’re preparing for a successful RetroFunding round this season of Optimism Fractal [here](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md).

3. By incorporating a focus on optimizing collective governance into our core intent and consistently highlighting it in our messaging, we can more clearly convey the value that the Optimism Fractal community provides to the Collective and attract others interested in improving collective decision-making.

You can see more rationale at the bottom of the page in the section about alternate versions and some questions that were considered while making this draft proposal for those who are interested.

# Questions and Answers

## What is Optimism, anyway?

One thing that’s important to note is exactly what is Optimism. Some people might ask… what do you mean by on Optimism? You can see this [article](https://optimism.mirror.xyz/9ZMwZjst9SQpzIgEd4gN42UDjATyK3ZRClPFx9oMPp8) for an overview of Optimism that is really about the Superchain: including Base, OP Mainnet, Worldchain, Zora, Farcaster, and many others.

## Where are the Core Intents featured?

Optimism Fractal’s core intents are currently at the top of the website, social media, our agreed upon intents at [OptimismFractal.com/details](http://OptimismFractal.com/details). If this proposal is approved then the core intents would be updated in each of these places. 

## Is ‘Core Intents’ the best way to say this?

We haven’t formally defined these as Core Intents or given them any name yet, but I think it makes sense to call them this. Feel free to let me know if you have better suggestions for the nomenclature.

## Why should this be decided by the Council?

I think that this potential change should be decided by the Council because these core intents are part of the [OptimismFractal.com/details](http://OptimismFractal.com/details) page that were approved with our prior consensus processes and are central to the purpose, essence, and intentions of the Optimism Fractal community. The [Optimism Fractal Sages Council](https://optimismfractal.com/council) is the governance body in our consensus process to make these kinds of community decisions.

I also think it makes sense to evolve this details page to a community agreement in simple terms and it makes sense for the Council to approve such an agreement, though this could be decided in the future and isn’t needed for this proposal.

## Alternative Versions and More Rationale

In the page below you can find several alternate versions of the core intents that were under consideration and more rationale about why the draft proposal above created. This page is included for reference and may be interesting for anyone who wants to dive deeper into the logic behind the core intents.

[Alternate Versions of Optimism Fractal Core Intent Proposal and More Rationale](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5/Alternate%20Versions%20of%20Optimism%20Fractal%20Core%20Intent%2026a91975868b4c67a048884b51cd3a90.md)

---