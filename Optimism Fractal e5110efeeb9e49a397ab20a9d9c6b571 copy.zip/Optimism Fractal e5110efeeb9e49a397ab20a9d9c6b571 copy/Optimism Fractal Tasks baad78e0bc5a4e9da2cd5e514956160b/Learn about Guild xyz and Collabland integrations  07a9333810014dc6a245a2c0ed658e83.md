# Learn about Guild.xyz and Collabland integrations with Hats Protocol

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), Develop integrations with Guild.xyz (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20integrations%20with%20Guild%20xyz%206ee0c22c2a79405b82b280bef5e2a3ca.md)
Status: In progress
Task Summary: This task aims to explore the integrations of Guild.xyz and Collabland with Hats Protocol. By understanding these integrations, we can enhance our collaboration and optimize the use of these platforms within our projects.
Summary: Research is needed on Guild.xyz and Collabland integrations with Hats Protocol, as they are considered easy to use according to Spencer.
Parent-task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created time: March 18, 2024 7:16 PM
Last edited time: September 26, 2024 5:04 PM
Parent task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created by: Dan Singjoy
Description: Research is needed on Guild.xyz and Collabland integrations with Hats Protocol, as they are considered easy to use according to Spencer.

- Spencer said it is pretty trivial to use Guidxyz and collabland

- [ ]  research guild and collabland

[https://youtu.be/dFY48Au9aaM?si=nCa0TFBrwFbPU2NN](https://youtu.be/dFY48Au9aaM?si=nCa0TFBrwFbPU2NN)