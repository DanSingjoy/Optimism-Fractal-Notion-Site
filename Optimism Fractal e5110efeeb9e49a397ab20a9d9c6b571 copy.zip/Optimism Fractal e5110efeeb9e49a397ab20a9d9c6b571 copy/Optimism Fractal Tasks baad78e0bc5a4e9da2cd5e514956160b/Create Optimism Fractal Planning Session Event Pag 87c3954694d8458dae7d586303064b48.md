# Create Optimism Fractal Planning Session Event Page

Project: Create Optimism Fractal Planning Session (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Planning%20Session%20608f1e091e394765aaad1e2cd7a84666.md)
Status: Done
Summary: Optimism Fractal is a community dedicated to collaboration and supporting public goods creators on Optimism. This planning session provides a space for brainstorming and coordinating the future of Optimism Fractal. It takes place after the weekly Respect Game event and the video recordings are shared publicly. Learn more at http://optimismfractal.com/ and join the main weekly event at http://lu.ma/OptimismFractal.
Created time: January 18, 2024 11:09 AM
Last edited time: January 18, 2024 11:10 AM
Created by: Dan Singjoy

## Description

- 

Optimism Fractal is a community dedicated to fostering collaboration and awarding public goods creators on Optimism. This planning session provides a place where we can brainstorm, coordinate, and create the future of Optimism Fractal.

Optimism Fractal planning sessions happen right after our weekly event where we play the Respect Game. You're welcome to join either or both events and they're in the same zoom room, so you don't need to register or join each event separately. The video recordings from the planning sessions are shared publicly as part of Optimism Fractal [videos](https://optimismfractal.com/media), so please only join if you're comfortable with this.

You can learn more at [OptimismFractal.com](http://optimismfractal.com/) and can join our main weekly event an hour earlier at [lu.ma/OptimismFractal](http://lu.ma/OptimismFractal).  Hope to see you there :)

[https://lu.ma/optimismfractalplanning](https://lu.ma/optimismfractalplanning)

- Drafts
    
    Optimism Fractal is a community dedicated to fostering collaboration and awarding public goods creators on Optimism.
    
    This brainstorming session provides a place where we can brainstorm, coordinate, and create the future of Optimism Fractal. It happens right after our weekly event where we play the Respect Game. Both events are in the same zoom room and you don't need to register or join each event separately. You're welcome to join either or both events. The video recordings from the brainstorming session are published publicly along with the rest of Optimism Fractal videos, so please only join if you're comfortable with this.
    
    You can learn more at [OptimismFractal.com](http://optimismfractal.com/) and can join our main weekly event an hour earlier at [lu.ma/OptimismFractal](http://lu.ma/OptimismFractal).  Hope to see you there :)