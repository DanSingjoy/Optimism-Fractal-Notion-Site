# Test Claude API Access with MacWhisper to improve transcription and summarization workflow

Assignee: Dan Singjoy
Project: Refine Process for Creating Optimism Fractal Show Notes and Complementary Materials for Videos (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Refine%20Process%20for%20Creating%20Optimism%20Fractal%20Show%20%20c45abeadcb3d4a0fa61cfc0ca4017471.md), Improve Optimism Fractal video production processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20video%20production%20processe%201ddaaa3c112a4449ab121ec9df944d9e.md)
Status: On Pause
Task Summary: This task aims to test the integration of Claude API Access with MacWhisper in order to enhance the transcription and summarization workflow. However, it has been discovered that MacWhisper does not support custom prompts with the Claude API, rendering this setup ineffective. The document also includes a research section on obtaining Claude API keys and comparing its cost and features with Claude Plus Pro and ChatGPT.
Summary: The document discusses testing Claude API access with MacWhisper for transcription and summarization workflow improvement. However, it is discovered that MacWhisper does not support custom prompts with the Claude API. The document also includes plans for claiming free credits, obtaining API keys, and researching the Claude API. The limitations of processing words at once with Claude Pro on the browser are mentioned, and the need for reformatting is questioned.
Parent-task: Try doing a batch transcription/summarization of all audio notes in tasks AND first set up ChatGPT API with MacWhisper then compare with Claude to refine this process (Try%20doing%20a%20batch%20transcription%20summarization%20of%20a%20c27c9712ea1b44ff850b4e6a2dc19fe9.md)
Created time: June 17, 2024 4:46 PM
Last edited time: June 17, 2024 4:59 PM
Parent task: Try doing a batch transcription/summarization of all audio notes in tasks AND first set up ChatGPT API with MacWhisper then compare with Claude to refine this process (Try%20doing%20a%20batch%20transcription%20summarization%20of%20a%20c27c9712ea1b44ff850b4e6a2dc19fe9.md)
Created by: Dan Singjoy

# Test Claude API Access with MacWhisper

UPDATE: I just realized that MacWhisper does NOT have functionality to do custom prompts with the Claude API. It only has this ability to do it with the ChatGPT API. So I should not try to set this up with Claude API because this was the intended use case and it doesn’t work.

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled.png)

## New Plan

See [Try doing a batch transcription/summarization of all audio notes in tasks AND first set up ChatGPT API with MacWhisper then compare with Claude to refine this process](Try%20doing%20a%20batch%20transcription%20summarization%20of%20a%20c27c9712ea1b44ff850b4e6a2dc19fe9.md) 

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%201.png)

## Old Plan

- [ ]  claim free credits with the build plan at [https://console.anthropic.com/dashboard](https://console.anthropic.com/dashboard), as shown below

- [ ]  click get API keys at [https://console.anthropic.com/dashboard](https://console.anthropic.com/dashboard), as shown below

- [ ]  add the API keys to macwhisper

# Research

## how can I get claude api key? how much does it cost? how does it compare/contrast with claude plus pro plan? how does it compare with chatgpt?

[https://www.anthropic.com/api](https://www.anthropic.com/api)

[https://console.anthropic.com/dashboard](https://console.anthropic.com/dashboard)

- [ ]  test the build plan
    - it is self-serve and what i need for right now

- [ ]  first test it with the 5 dollars of free credits, then if it works well then give it the boa mastercard for more credits and test this with macwhisper

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%202.png)

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%203.png)

[https://www.anthropic.com/api](https://www.anthropic.com/api)

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%204.png)

In general, 1 token corresponds to approximately 3-4 characters in English text, so 1 million tokens could theoretically process on the order of 3-4 million characters of text. However, this is a very rough estimate and actual mileage may vary significantly depending on the specifics of the use case.

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%205.png)

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%206.png)

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%207.png)

![Untitled](Test%20Claude%20API%20Access%20with%20MacWhisper%20to%20improve%20%2052e4df608cc3427ba4b4735dccb47f9d/Untitled%208.png)

one feature that is time consuming with claude pro using claude on the browser is that claude can only process so many words at once. for example, when I am asking claude to reformat a long transcript it asks me to write continue several times. does the api have this limitation as well?

- or i can just skip the reformatting - the main purpose for this was to make sure that some parts weren’t removed from the conversation but claude seems to be quite thorough so idk if this is needed and it may be cheaper to do it without reformating. As it is i only really look at the summaries