# @Promote OTH 1 in Base Farcaster Channel?

Project: Promote OTH 1 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Promote%20OTH%201%203de5089a487a4e3ba2aba5d2fa5c8115.md)
Status: Not started
Task Summary: This task aims to create an untitled page in the Base Farcaster Channel. The page, created by Rosmari, is currently in the "Not started" status. The goal of this task is to provide a 2-4 sentence summary or introduction for the page.
Summary: This document is titled "@Untitled in Base Farcaster Channel?" and was created by Rosmari. It is in the "Not started" status and belongs to the "Citizen's House" category.
Created time: May 15, 2024 6:44 PM
Last edited time: May 15, 2024 6:44 PM
Created by: Rosmari

- In Citizen’s House Category?