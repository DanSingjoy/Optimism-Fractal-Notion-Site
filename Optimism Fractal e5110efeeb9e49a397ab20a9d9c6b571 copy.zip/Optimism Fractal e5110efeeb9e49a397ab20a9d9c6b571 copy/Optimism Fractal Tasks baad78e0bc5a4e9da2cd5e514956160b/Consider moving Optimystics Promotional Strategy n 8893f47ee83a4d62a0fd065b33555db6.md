# Consider moving Optimystics Promotional Strategy notes about Base into OF public site

Assignee: Dan Singjoy
Due: September 30, 2024
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
Status: On Pause
Task Summary: This task aims to consider the relocation of Optimystics Promotional Strategy notes about Base to the OF public site. It was created by Dan Singjoy and is currently on pause. The task is scheduled to be completed by September 30, 2024.
Summary: No content
Created time: May 27, 2024 7:48 PM
Last edited time: May 27, 2024 7:55 PM
Created by: Dan Singjoy

[Strategy for Engaging with Base and Posting on Base Farcaster](https://www.notion.so/Strategy-for-Engaging-with-Base-and-Posting-on-Base-Farcaster-549d6f4b909649689d77edb03acefa79?pvs=21)