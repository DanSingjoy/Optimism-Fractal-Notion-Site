# Research community size limits in More Equal Animals

Project: Research Community Limit Size (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Community%20Limit%20Size%2047629842db294dfbada49b38b739d858.md)
Status: Not started
Summary: No content
Created time: March 19, 2024 8:35 PM
Last edited time: March 20, 2024 8:35 PM
Created by: Dan Singjoy

## Description

![[https://moreequalanimals.com/posts/book-launch](https://moreequalanimals.com/posts/book-launch)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Community%20Limit%20Size%2047629842db294dfbada49b38b739d858/Untitled.png)

[https://moreequalanimals.com/posts/book-launch](https://moreequalanimals.com/posts/book-launch)

[More Equal Animals Book Released](https://moreequalanimals.com/posts/book-launch)

![Untitled](Research%20community%20size%20limits%20in%20More%20Equal%20Anima%20724c16b669044ecab39a32febb188f1f/Untitled.png)

## Context

![Untitled](Research%20community%20size%20limits%20in%20More%20Equal%20Anima%20724c16b669044ecab39a32febb188f1f/Untitled%201.png)

![Untitled](Research%20community%20size%20limits%20in%20More%20Equal%20Anima%20724c16b669044ecab39a32febb188f1f/Untitled%202.png)

![Untitled](Research%20community%20size%20limits%20in%20More%20Equal%20Anima%20724c16b669044ecab39a32febb188f1f/Untitled%203.png)

![Untitled](Research%20community%20size%20limits%20in%20More%20Equal%20Anima%20724c16b669044ecab39a32febb188f1f/Untitled%204.png)

![Untitled](Research%20community%20size%20limits%20in%20More%20Equal%20Anima%20724c16b669044ecab39a32febb188f1f/Untitled%205.png)

![[https://moreequalanimals.com/posts/book-launch](https://moreequalanimals.com/posts/book-launch)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Community%20Limit%20Size%2047629842db294dfbada49b38b739d858/Untitled.png)

[https://moreequalanimals.com/posts/book-launch](https://moreequalanimals.com/posts/book-launch)