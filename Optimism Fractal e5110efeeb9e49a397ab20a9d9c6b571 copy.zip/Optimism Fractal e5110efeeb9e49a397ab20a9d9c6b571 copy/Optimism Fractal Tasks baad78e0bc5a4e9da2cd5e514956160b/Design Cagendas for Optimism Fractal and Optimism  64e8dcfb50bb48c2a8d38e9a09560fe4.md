# Design Cagendas for Optimism Fractal and Optimism Town Hall

Project: Improve event structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20event%20structure%20for%20Optimism%20Fractal%201e2afc98737f4bf58af066788f956622.md), Create branding and educational resources for decision-making consensus games (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20branding%20and%20educational%20resources%20for%20deci%20188c45e0a1dc4773bd8202133ced6eb7.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)
Status: Not started
Task Summary: This task aims to create design cagendas for Optimism Fractal and Optimism Town Hall. The cagendas will be used to propose and prioritize topics for discussion in a scalable and dynamic manner, utilizing ranked choice voting. The goal is to provide a structured and transparent approach to determine the weekly topics for these meetings.
Summary: Design cagendas for Optimism Fractal and Optimism Town Hall. The top topics are proposed and ranked each week using Snapshot or Jokerace. The priority of topics is established at a specific time. This approach is more scalable and dynamic than voting in Notion, and ensures that everyone knows the topic in advance.
Created time: March 25, 2024 3:47 PM
Last edited time: May 10, 2024 3:22 AM
Created by: Dan Singjoy

![cagendas of1.png](Create%20Cagendas%20artwork%2020b9d034994048c9bd5ed744a417f537/cagendas_of1.png)

- [ ]  consider: could change or merge the background image to include the original spiral time at [edencreators.com/cagendas](http://edencreators.com/cagendas) or [Cagendas](https://www.notion.so/Cagendas-5d4173b9b0ea4ba28e491b1d01476f80?pvs=21)

## Optimism Fractal Agenda Game (Cagendas)

1. The top topics are proposed each week on Snapshot with ranked choice voting. Alternatively, Jokerace can be used instead of snapshot for this purpose.

1. The priority of topics is established at 17 or 18 UTC. Alternatively, voting can be open throughout the whole meeting if the software supports this ability.

### To Do

could curate early notes about cagendas and agendas here to as there might be some good ideas from a while ago- link old sites so others can see them

### Benefits

- This is more scalable and dynamic than voting in notion. Another issue with notion voting is the pages/upvotes don’t have an end time like snapshot
- The topic will determined by rank choice voting and the topic would be chosen each week at a set time so everyone knows what we’ll discuss in advance.