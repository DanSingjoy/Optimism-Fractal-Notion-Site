# Create Proposal to Implement Cagendas in Optimism Fractal Season 3

Project: Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Done
Task Summary: This task aims to create a proposal to implement Cagendas in Optimism Fractal Season 3. The proposal introduces Cagendas, a social coordination game for collaborative agenda setting, and Optimism Town Hall, a new collaborative space for structured discussions. The implementation proposal outlines the rules of Cagendas and invites community members to vote on the proposal.
Summary: A proposal has been created to implement Cagendas in Optimism Fractal Season 3. Cagendas is a social coordination game for collaborative agenda setting, allowing community members to propose, discuss, and vote on topics. The proposal also introduces Optimism Town Hall as a new collaborative space for structured discussions. The implementation proposal includes rules for proposing and voting on topics. The goal is to provide a platform for meaningful discussions and positive impact for Optimism Collective governance.
Created time: April 24, 2024 3:37 AM
Last edited time: May 10, 2024 9:12 AM
Sub-tasks: Propose Cagendas and Make Promotional Post for OF 25 (Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b.md)
Created by: Dan Singjoy

## Reminder

As a reminder, there are currently about x hours left to register for next week’s council. If you’d like to participate in the next week’s council, please [register here](https://snapshot.org/#/optimismfractal.eth/proposal/0x19936a78d2ea6e60c3bb2105f5d5cd230815f2121c73bdcabb30b2b3ab7bf010) before the upcoming event at 17 UTC.  Looking forward to seeing you soon!

- save this for future messages- it’s not needed to encourage people too much right now since it’ll be easier to approve the proposal with just 3 councilors rather than more
    
    There are currently 3 community member who have registered and space for councilors and 3 more positions available…
    

## Promotional Message

Hey all, 

I’m thrilled to introduce a proposal to start playing Cagendas after each Optimism Fractal event at a new community forum called Optimism Town Hall. I’d like to present this proposal at today’s event to kick off a fantastic third season and am curious to hear your thoughts about it. You can vote on the proposal [here](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d) and see details below:

**Introducing Cagendas**

Cagendas is a social coordination game for collaborative agenda setting that empowers Optimism Fractal community members to propose, discuss, and vote on topics with Respect.  This community agenda game provides a simple, structured, and scalable way for everyone who has earned Respect at Optimism Fractal to propose topics or vote on topics they want to discuss at weekly events after the Respect Game. Cagendas can create profound benefits by helping us prioritize discussions and ensuring that the topics that matter most get the attention they deserve. We’ve been developing Cagendas for over a year at Eden Fractal and I’m stoked to share it with everyone at Optimism Fractal and the Optimism Collective. You can explore more details and contribute to the development of Cagendas in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md). 

**Introducing Optimism Town Hall**

The Optimism Town Hall is envisioned as a new collaborative space for structured discussions about the Optimism Collective, powered by Optimism Fractal Respect. The Town Hall is intended to be a weekly event that replaces the Optimism Fractal planning sessions with a more organized approach to selecting discussion topics by voting with Respect and a greater focus on facilitating conversations that provide a positive impact for Optimism Collective governance. The Optimism Town Hall can provide you with a platform to help lead the Optimism Collective and create a better world for everyone. We have very exciting plans for the Optimism Town Hall and I look forward to collaborating with everyone there to actualize the [Optimistic Vision](https://www.optimism.io/vision). You can explore more details and contribute to the development of Optimism Town Hall in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md). 

**Implementation Proposal**

The rules of Cagendas are explained below. Please vote yes on this proposal if you agree to implement the following:

1. Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

2. Anyone who has earned Respect at Optimism Fractal can vote on polls with their Respect to help determine the discussion topic for each weekly event. 

3. Whichever poll has received the most votes in the Topic Poll by Monday at 17 UTC will be the topic discussed during the week’s event after the Respect Game.
    1. The poll for the topic proposal must end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event.

I believe that this proposal will position us well in our third season to provide the greatest impact for the Optimism Collective, help Optimism Fractal community members earn Retro Funding in Round 6, and catalyze exponential fractal growth to create profound benefits for all. You can see the proposal and Vote with Respect [here](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d). You can see more rationale about this proposal in this [introductory post](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md). Councilors, please review the proposal and let me know if you have any questions. I’m looking forward to hear everyone’s thoughts and would appreciate feedback!

![cagendas proposal image2.png](Create%20Proposal%20to%20Implement%20Cagendas%20in%20Optimism%20%200c32c54f1a5b4a949dc89363b0012ba5/cagendas_proposal_image2.png)

## Optimism Fractal Agenda Game (Cagendas)

1. The top topics are proposed each week on Snapshot with ranked choice voting. Alternatively, Jokerace can be used instead of snapshot for this purpose.

1. The priority of topics is established at 17 or 18 UTC. Alternatively, voting can be open throughout the whole meeting if the software supports this ability.

### To Do

could curate early notes about cagendas and agendas here to as there might be some good ideas from a while ago- link old sites so others can see them

### Benefits

- This is more scalable and dynamic than voting in notion. Another issue with notion voting is the pages/upvotes don’t have an end time like snapshot
- The topic will determined by rank choice voting and the topic would be chosen each week at a set time so everyone knows what we’ll discuss in advance.

![[https://www.notion.so/Plan-Optimism-Fractal-Season-3-a43df029ee964a3599c25be55d4387d4?d=f61cd40893a74c1795b5f35ec672924b&pvs=4](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md)](Research%20and%20Test%20Snapshot%20for%20Improvements%20to%20Cag%20e7906e1df6704fbb8de9f060f751ded9/Untitled.png)

[https://www.notion.so/Plan-Optimism-Fractal-Season-3-a43df029ee964a3599c25be55d4387d4?d=f61cd40893a74c1795b5f35ec672924b&pvs=4](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md)