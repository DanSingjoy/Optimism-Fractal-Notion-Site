# Curate top apps and benefits in the Optimism Collective

Assignee: Dan Singjoy
Project: Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md)
Status: Done
Summary: Curate top apps and benefits in the Optimism Collective. Collaborative process with OF, voting on apps subjectively with OPC.
Parent-task: Respond to Martin B from Pinax about Optimism (Respond%20to%20Martin%20B%20from%20Pinax%20about%20Optimism%20f8b1a4895c604b69ae19f11fd9015a78.md)
Created time: April 30, 2024 9:38 AM
Last edited time: May 2, 2024 9:56 AM
Created by: Dan Singjoy

## Description

Hmm I think the top 5 selling points and dApps depends on personal preferences, but I can share my perspective :)

Top 5 Benefits of Optimism:

- [RetroPGF](https://app.optimism.io/retropgf): Optimism regularly holds rounds of RetroPGF, or Retroactive Public Goods Funding. The culture of Optimism is very focused on rewarding public goods and the Optimism Collective gives more funding to public goods than any other network that I know.
- [Bicameral Governance System](https://optimism.mirror.xyz/gQWKlrDqHzdKPsB1iUnI-cVN3v0NvsWnazK7ajlt1fI): The system with the token house and citizens house is very exciting. It reminds me of Eden and I see lots of opportunity for it to grow.
- [Superchain](https://app.optimism.io/superchain): Optimism is EVM equivalent and is leading the Superchain, along with Base, Zora, Worldcoin, and many other market leaders.
- [Grants Council](https://app.charmverse.io/op-grants/optimism-grants-council-8323028890716944): The governance system provides many interactive, community led opportunities for missions and other funding sources. It’s well organized and works well.
- [Optimistic Vision](https://www.optimism.io/vision): The vision is very compelling and there are many amazing people building on the network. Very good community, branding, and vibes!

Top 5 Apps on Optimism:

- [Respect Game](https://optimystics.io/respectgame): The core consensus game at Optimism Fractal, a community dedicated to fostering collaboration and awarding public good creators on Optimism.
- [Farcaster](https://www.farcaster.xyz/): A decentralized social network that is growing quickly and has many innovative features, such as Frames and channels
- [Agora](https://vote.optimism.io/): A voting portal for missions, RetroPGF, and other collective decisions
- [Gitcoin Grants](https://twitter.com/owocki/status/1745845126562201733): A platform for crowdfunding public goods
- [Hats Protocol](https://twitter.com/owocki/status/1745845126562201733): A powerful coordination tool for decentralized collaboration

[](https://x.com/binji_x/status/1786012945916342290?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

- Binji tweet - collaborative process with OF? We could vote on apps subjectively with OPC
    
    [https://x.com/binji_x/status/1786012945916342290?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/binji_x/status/1786012945916342290?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)