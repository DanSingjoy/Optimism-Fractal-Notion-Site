# Follow up with Nestor about EAS

Assignee: Dan Singjoy
Due: September 4, 2024
Project: Explore and Create Integrations with Ethereum Attestation Service (EAS) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
Status: In progress
Task Summary: This task aims to follow up with Nestor regarding the integration of Respect with EAS. The goal is to explore the potential benefits of making Respect more compatible with EAS, a widely adopted standard used by various platforms. The task includes discussing technical development and considering the integration's implications.
Summary: This document is a follow-up regarding integrating Respect with EAS. Nestor is interested in making the Respect token compatible with EAS, a standard for making attestations. It is recommended to check out the EAS website and videos for more information. There is no rush for a response, as the assignee is currently on break.
Created time: March 22, 2024 7:53 PM
Last edited time: July 15, 2024 8:03 PM
Created by: Dan Singjoy
Description: This document is a follow-up task for Dan Singjoy to discuss technical development with Nestor regarding integrating Respect with EAS. Nestor is interested in making the Respect token compatible with EAS, a widely adopted standard used by Coinbase, Optimism, and others. There is no rush for a response as Dan is aware that Nestor is on break.

## Description

- EF 20
    - We started talking with Nestor at 54:04 and discussed technical development until about 1:21:30.

I just responded to Vlad’s comment in the notion page about this, which you can see here. Here is a follow-up comment: 

Nestor is interested in integrating Respect with EAS, not implementing the Respect Game into EAS. EAS is a standard for making attestations that could make Respect more composable with other applications. EAS doesn’t know about Respect Game yet and I don’t think that Nestor is affiliated with EAS, he’s interested in making the Respect token compatible with EAS.

You can see the [website](https://attest.sh/), this project, and [videos](Watch%20videos%20about%20EAS%20(Ethereum%20Attestation%20Servi%20993a579c792f4b7f9b4a4b968e155af2.md) to learn about EAS. I think there’s a lot of potential benefits in integrating Respect with EAS and recommend checking it out. It’s a widely adopted and quickly growing standard that’s being used by Coinbase, Optimism, and many others

You mentioned that the next step would be to arrive at consensus on the fields for the schema in EAS. A couple obvious fields that come to mind is amount of Respect and event number. I also imagine that it could be helpful to have fields for the community or organization that is hosting the Respect Game and community or organization that is giving Respect. It could also be interesting to include fields for descriptions of contributions, links to contributions, and links to timestamped videos from the event. I’ve only actually made an attestation with EAS once and haven’t seen many schemas before outside of this [video](Follow%20up%20with%20Nestor%20about%20EAS%20c1659c98cbf6450185be4eb7e3f1aa69.md), so you might have a much better idea of what kinds of fields are best to include in the schema. 

The Optimystics team is building an independent Respect Game app that anyone can use to easily play the Respect Game with their friends, community, or organization. One of the things that we’ve been thinking about is how we can create a generalized app where anyone can play the respect game without needing to deploy software or learn how to use Fractalgram. The idea is that this app should have a field that enables people to write the community that is hosting the game, so an admin or council of that community could be able to filter all the game results on a block explorer then easily award Respect to people who played their games. I’m not exactly sure what role EAS would play in this but I imagine that it could be very helpful if players each make an onchain attestation when they post the game results and this attestation includes the community/organization’s name.

You also mentioned that a good next step would be to organize our schema planning in notion, so I just updated the EAS [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md) and created a [task](Consider%20and%20Form%20Consensus%20on%20the%20Fields%20for%20an%20E%20ddeee45ad46a43a4b0ebd352e1f15678.md) to form consensus about the schema.

@Tadas I know you said that you’re taking a break and there’s no rush, but when you get a chance…. Nestor mentioned that it might be more complex to integrate Respect with EAS if with the unique token design with both that you created. I shared the link to your most recent page Would you recommend integrating EAS with the ERC-20, ERC-721, or some combination of these token standards? Or are you still thinking about migrating Respect to a different token standard like ERC 1151 and in this case how would you recommend proceeding?

- 
    
    
    I messaged Tadas about this and he told me that a better explanation of the contract’s design can be found here. Tadas wrote this [page](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md) last month to explain the unique design of the contract and improve how Respect displays in block explorers. You can read the explanation in the ‘background’ section near the top of the page if you’re interested. At the end of the page he also considered the possibility of migrating the Respect token to an ERC-1155 standard.
    

- [ ]  update this project with the resources and rationale i sent to [Message Spencer with and Ido from Hats Protocol with Optimism Fractal github repository and links to respect game and details page](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Message%20Spencer%20with%20and%20Ido%20from%20Hats%20Protocol%20wi%202d95ace163e24221a234331c7b6716b0.md)
- ERC1151 (if you’re still thinking about migrating to the different token standard),
- Another field that might be interesting to explore is a field for Hats of each participant (from Hats Protocol) with a Respect Eligibility module. That could for example make it easy for anyone in the community to play respect games with others and the admin/council of a community could award respect only to sufficiently respected community members
- By the way, last week I created a public telegram group for exploring integrations and collaborations between Optimism Fractal and Hats Protocol. Everyone is welcome to join and there have already been some very interesting conversations with the founders of Hats Protocol happening there. You can see the group here and a project with much more about collaborations with Hats Protocol here. @nuno I think you might be interested in this :)
    - This could enable a kind of Respect for hosting respect games that Zaal mentioned

- [ ]  consider tagging vlad in message to nestor as well
- Let us know whenever you get a chance, I know you’re on break this week so there’s no rush