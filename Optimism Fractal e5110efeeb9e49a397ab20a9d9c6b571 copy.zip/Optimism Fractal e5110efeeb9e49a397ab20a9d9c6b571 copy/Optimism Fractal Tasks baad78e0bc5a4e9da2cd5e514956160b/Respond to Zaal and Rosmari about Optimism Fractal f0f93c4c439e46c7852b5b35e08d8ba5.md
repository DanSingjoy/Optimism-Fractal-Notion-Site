# Respond to Zaal and Rosmari about Optimism Fractal referral system

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Create a referral or recruitment system for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20a%20referral%20or%20recruitment%20system%20for%20Optimi%20438c19ca93fe49a69e0dd77a330708cf.md), Interact on Optimism Fractal Discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Interact%20on%20Optimism%20Fractal%20Discord%206db8fc968f104b6cadc39a71b8f1b843.md)
Status: Not started
Task Summary: This task aims to respond to Zaal and Rosmari regarding the Optimism Fractal referral system. It was created by Dan Singjoy and is assigned to Dan Singjoy. The task has a due date of August 2, 2024, and its status is currently marked as "Not started". The page contains additional details, including a question about the meaning of one sharing token and a shared idea for review and potential implementation. There are also checkboxes for linking the referral system project and adding a screenshot.
Summary: This document is a response to Zaal and Rosmari regarding the Optimism Fractal referral system. The assignee is Dan Singjoy and the due date is August 2, 2024. The document includes a question about the meaning of "one sharing token" and a suggestion to review and potentially summarize or link to a certain part of an idea shared. There are also tasks listed, including linking to the referral system project and potentially adding a screenshot.
Created time: May 10, 2024 4:21 AM
Last edited time: July 23, 2024 12:08 PM
Created by: Dan Singjoy
Description: This document is a response to Zaal and Rosmari regarding the Optimism Fractal referral system. The author, Dan Singjoy, is assigned to the task and it is due on August 2, 2024. The document includes a question about the meaning of "one sharing token" and a suggestion to review and summarize or link to a certain part of an idea shared. There are also tasks listed, such as linking to the referral system project and adding a screenshot.

![Untitled](Respond%20to%20Zaal%20and%20Rosmari%20about%20Optimism%20Fractal%20f0f93c4c439e46c7852b5b35e08d8ba5/Untitled.png)

What do you mean by one sharing token? 

You can see an idea that i shared here: [Review Ideas about Respect Network, Community Member Hosted Respect Games, and Optimism Fractal Referral System ](Review%20Ideas%20about%20Respect%20Network,%20Community%20Memb%2073be637ac62249248c0fbe00c66bfb35.md) - review first and see if i should summarize or link to a certain part

- [ ]  link to referral system project
    - [ ]  organize it first if needed [Create a referral or recruitment system for Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20a%20referral%20or%20recruitment%20system%20for%20Optimi%20438c19ca93fe49a69e0dd77a330708cf.md)

- [ ]  add screenshot to the project?