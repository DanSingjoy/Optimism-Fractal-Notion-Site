# Review Piñata cloud, Airstack, thirdweb, and Neynar for building with Farcaster

Project: Explore and Create Integrations between Farcaster and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md)
Status: Not started
Task Summary: This task aims to review the platforms Piñata cloud, Airstack, thirdweb, and Neynar in the context of building with Farcaster. The review will assess their compatibility, features, and usability to determine their suitability for integrating with Farcaster.
Summary: No content
Created time: March 4, 2024 7:37 PM
Last edited time: July 5, 2024 12:45 PM
Created by: Dan Singjoy
Description: No content

[https://x.com/dwr/status/1763714224944017428?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/dwr/status/1763714224944017428?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/dwr/status/1763714224944017428?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/dwr/status/1763714224944017428?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)