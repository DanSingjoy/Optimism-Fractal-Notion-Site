# Respond to Alex from Livepeer about Matthias app

Status: In progress
Summary: The sender is asking if Livepeer can assist with the video post-production processing and playback of recorded videos in the app's functionality. They explain that the app's archive page currently shows some videos, but others are not visible, indicating a processing issue. They mention Matthias' explanation of how the video post-production works and inquire if Livepeer can handle this aspect of the app's functionality.
Parent-task: In v2, Consider recording, encoding and livestreaming integrations with Livepeer (In%20v2,%20Consider%20recording,%20encoding%20and%20livestream%207f9e5aff39d94b6c9fee1ca9f0999e32.md)
Created time: March 15, 2024 4:01 PM
Last edited time: April 24, 2024 4:40 AM
Parent task: In v2, Consider recording, encoding and livestreaming integrations with Livepeer (In%20v2,%20Consider%20recording,%20encoding%20and%20livestream%207f9e5aff39d94b6c9fee1ca9f0999e32.md)
Created by: Dan Singjoy

## Description

- 

![Untitled](Respond%20to%20Alex%20from%20Livepeer%20about%20Matthias%20app%20f023bfae6cb544e3b64db7f19b9c26ba/Untitled.png)

You’re welcome and thank you for the advice, I’ll relay that to him and other developers in our community who are working on similar projects.

To be clear, I understand that Livepeer doesn’t support real time communication use cases but was wondering if Livepeer can help with the video post-production processing and playback of the recorded videos in this app’s functionality. For example, you can see the [archive](https://dao.zeos.one/archive) page of the app currently shows about 25 election meetings. The intention of this page is to automatically show the video of each meeting (which is called an election in this app). Some of the videos of the election meetings are now visible, such as the two breakout rooms in the [19th election](https://dao.zeos.one/archive/19). The rest of the election pages say “No video with supported format and MIME type found,” so it seems like they haven’t yet finished processing correctly or something messed up. 

You can learn more about this by watching a 3 minute portion of the video above where Matthias explains how this works. I asked Matthias about the video post-production that enables this video and archive process at 9:22 in the video above, then Matthias described details about this until 12:25. He explains how he set up scripts to automatically send the raw video recordings from each person’s webcam to a server, which then automatically encode, crop, stitch, and otherwise process the recorded videos so they show up on the website’s archive page and make the recordings look similar to a zoom recording. It seems like all of this work is independent of the real-time communication for the many-to-many video call and there’s several use cases here for one-to-many processing, streaming, and playback that fits within the scope of Livepeer.

I’d appreciate if you can clarify if Livepeer would be able to help with this aspect of the app and if it might make sense for him (and other people using this app in the future) to start using Livepeer to handle this portion of the app’s functionality