# Watch Videos and listen to podcasts about Privy. Consider Creating a Playlist

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: In progress
Summary: In progress. Consider creating a playlist of videos and podcasts about Privy, including a segment about Privy in Internet Explorers.
Created time: January 1, 2024 10:37 AM
Last edited time: March 8, 2024 3:09 PM
Created by: Dan Singjoy

- [ ]  Consider organizing videos here into a youtube playlist

[https://www.youtube.com/watch?v=Kyjw_6aXGjM&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=Kyjw_6aXGjM&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=QhUeovaVesk&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=QhUeovaVesk&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=tvyvv0TSKDw&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=tvyvv0TSKDw&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=mn8N6Ozr2uY&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=mn8N6Ozr2uY&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=LFDJMogUFWU&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=LFDJMogUFWU&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=cDfwGwsKnBo&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=cDfwGwsKnBo&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=wAZQyMJ3510&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=wAZQyMJ3510&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=N-z6tjflh3c&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=N-z6tjflh3c&pp=ygULcHJpdnkgIHdlYjM=)

[https://www.youtube.com/watch?v=cyU6lPrJVR0&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=cyU6lPrJVR0&pp=ygULcHJpdnkgIHdlYjM=)

[Watch this segment about Privy in internet explorers ](Watch%20Videos%20and%20listen%20to%20podcasts%20about%20Privy%20Co%20af675c3ad4564d66b7e0918cfcf32570/Watch%20this%20segment%20about%20Privy%20in%20internet%20explore%200937b51858ed411c823598557949bca5.md)