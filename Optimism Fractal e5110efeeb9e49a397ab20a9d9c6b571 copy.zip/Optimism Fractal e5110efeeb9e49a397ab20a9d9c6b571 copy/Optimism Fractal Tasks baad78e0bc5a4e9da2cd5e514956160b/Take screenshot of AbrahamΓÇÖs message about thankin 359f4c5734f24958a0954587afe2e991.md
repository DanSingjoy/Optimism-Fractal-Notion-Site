# Take screenshot of Abraham’s message about thanking me for making consensus fun - did I save that in feedback on Notion?

Due: October 30, 2024
Project: Improve Optimism Fractal Feedback and Collaborations Page (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20Feedback%20and%20Collaboratio%20ebf341effdfe4fe7a7cfc749b4f84a20.md)
Status: Not started
Task Summary: This task aims to capture a screenshot of Abraham's message expressing gratitude for making consensus fun. The objective is to determine whether the message was saved in the feedback section of Notion. The task was created by Dan Singjoy with a due date of October 30, 2024.
Summary: No content
Created time: July 19, 2024 10:46 PM
Last edited time: July 19, 2024 10:47 PM
Created by: Dan Singjoy
Description: No content