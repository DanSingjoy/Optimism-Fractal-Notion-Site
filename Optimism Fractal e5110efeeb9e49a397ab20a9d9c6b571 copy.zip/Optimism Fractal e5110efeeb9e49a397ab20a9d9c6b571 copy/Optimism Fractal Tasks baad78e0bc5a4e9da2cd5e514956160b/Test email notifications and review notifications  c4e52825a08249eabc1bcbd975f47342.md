# Test email notifications and review notifications menu in-app

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to test the functionality of email notifications and review notifications menu in-app. The page includes information about the creator, status, creation time, and last edit time. The notification menu is described as nice, and there are also email subscriptions mentioned in the content.
Summary: This document is about testing email notifications and reviewing the notifications menu in-app. The notification menu is described as nice, and there are images included. There is also a section about email subscriptions.
Created time: June 3, 2024 9:09 AM
Last edited time: June 3, 2024 9:10 AM
Created by: Dan Singjoy

## Notification

notification menu is nice

![Untitled](Test%20email%20notifications%20and%20review%20notifications%20%20c4e52825a08249eabc1bcbd975f47342/Untitled.png)

![Untitled](Test%20email%20notifications%20and%20review%20notifications%20%20c4e52825a08249eabc1bcbd975f47342/Untitled%201.png)

### Email Subscriptions

![Untitled](Test%20email%20notifications%20and%20review%20notifications%20%20c4e52825a08249eabc1bcbd975f47342/Untitled%202.png)