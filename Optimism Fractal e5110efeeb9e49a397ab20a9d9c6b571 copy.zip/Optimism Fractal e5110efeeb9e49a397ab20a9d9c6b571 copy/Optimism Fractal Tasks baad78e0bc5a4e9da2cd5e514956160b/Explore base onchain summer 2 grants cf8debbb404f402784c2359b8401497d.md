# Explore base onchain summer 2 grants

Assignee: Dan Singjoy
Due: June 24, 2024
Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md), Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Curate Optimism Fractal community reading list (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Optimism%20Fractal%20community%20reading%20list%20cc9fd290fdb84e359fd9654107562d5d.md)
Status: Done
URL: https://x.com/base/status/1786079119824019650?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to explore the base onchain summer 2 grants. It was created by Dan Singjoy and assigned to him as well. The task has been marked as done and has a due date of June 24, 2024. For more details, you can visit the https://x.com/base/status/1786079119824019650?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ.
Summary: No content
Created time: May 2, 2024 4:26 PM
Last edited time: June 28, 2024 2:02 PM
Created by: Dan Singjoy

[https://x.com/base/status/1786079119824019650?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/base/status/1786079119824019650?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)