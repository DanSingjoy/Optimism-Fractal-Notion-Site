# Curate notes about Flower Time and Garden Joy shows created from weekly presentations in the Respect Game

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Improve Weekly Contributions Page and Workflows (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Weekly%20Contributions%20Page%20and%20Workflows%2038634e026b854eedabd1ddd5cc273106.md), Refine Process for Creating Optimism Fractal Show Notes and Complementary Materials for Videos (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Refine%20Process%20for%20Creating%20Optimism%20Fractal%20Show%20%20c45abeadcb3d4a0fa61cfc0ca4017471.md), Create System for Recording and Publishing videos of breakout groups (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20System%20for%20Recording%20and%20Publishing%20videos%20%20cd0e4f5b11f94662867b711f1592f66c.md), Improve Optimism Fractal video production processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20video%20production%20processe%201ddaaa3c112a4449ab121ec9df944d9e.md)
Status: In progress
Task Summary: This task aims to curate comprehensive notes about the Flower Time and Garden Joy shows that were generated from weekly presentations in the Respect Game. The goal is to organize relevant information and resources to enhance understanding and enjoyment of these shows, ensuring easy access to key insights and links.
Summary: Curate notes on the Flower Time and Garden Joy shows from weekly presentations in the Respect Game, with a due date of August 2, 2024. The task is in progress, and related links need to be added from Notion.
Created time: June 4, 2024 2:38 PM
Last edited time: September 2, 2024 11:32 AM
Created by: Dan Singjoy
Description: Curate notes about the Flower Time and Garden Joy shows based on weekly presentations in the Respect Game, with a due date of August 2, 2024. The task is in progress, and related links need to be added from Notion.

Example Playlist: [https://www.youtube.com/watch?v=diXcFlDNw0Y&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny](https://www.youtube.com/watch?v=diXcFlDNw0Y&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny)

- [ ]  search notion and add the related links here

[https://www.youtube.com/watch?v=diXcFlDNw0Y&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny](https://www.youtube.com/watch?v=diXcFlDNw0Y&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny)

[https://www.youtube.com/watch?v=zwWt91UF9zE&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=4&pp=gAQBiAQB](https://www.youtube.com/watch?v=zwWt91UF9zE&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=4&pp=gAQBiAQB)

[https://www.youtube.com/watch?v=Am0vCObSsZU&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=6&pp=gAQBiAQB](https://www.youtube.com/watch?v=Am0vCObSsZU&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=6&pp=gAQBiAQB)

[https://www.youtube.com/watch?v=gTdQPbrpifI&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=2&pp=gAQBiAQB](https://www.youtube.com/watch?v=gTdQPbrpifI&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=2&pp=gAQBiAQB)

[https://www.youtube.com/watch?v=6qJjybPshv4&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=5&pp=gAQBiAQB](https://www.youtube.com/watch?v=6qJjybPshv4&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=5&pp=gAQBiAQB)

[https://www.youtube.com/watch?v=6LR2HIp2hME&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=3&pp=gAQBiAQB](https://www.youtube.com/watch?v=6LR2HIp2hME&list=PLa5URJF9l5lnuiou5WS-hT5LmOCrDfmny&index=3&pp=gAQBiAQB)