# Create Artwork for Optimism Town Hall

Assignee: Rosmari
Due: May 17, 2024
Project: Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md)
Status: In progress
Task Summary: This task aims to create artwork for the Optimism Town Hall project. The artwork will be designed by Dan Singjoy and assigned to Rosmari. The goal is to incorporate elements of optimism, such as sunny skies, sunflowers, and imagery from Optimism Fractal, to enhance the visual appeal of the town hall. The project is currently in progress and is expected to be completed by May 17, 2024.
Summary: The task is to create artwork for the Optimism Town Hall. The timing and prioritization of the artwork for Season 3 or Season 4 is being discussed. Ideas for the artwork include incorporating Optimism elements such as RetroPGF Sunny, blue sky, sunflowers, Optimism City, OP moon, Pheonix, Snapshot lightning bolt, and Sages Council. There is also a suggestion to include the town hall in the Optimism City.
Created time: May 1, 2024 2:58 AM
Last edited time: May 22, 2024 5:35 PM
Parent task: Create branding and marketing for Optimism Town Hall (Create%20branding%20and%20marketing%20for%20Optimism%20Town%20Ha%200b44e54f627143098124e0519af9ff37.md)
Created by: Dan Singjoy

## Description

## Timing and Prioritization

- Does it make more sense to prioritize the artwork for Season 3 or Season 4?

- We still have a lot of work to do on Optimism Fractal’s artwork and other matters so i think it makes sense to save most of the artwork for a future season, but we definitely should make some artwork in this season to be able to promote it well

## Artwork ideas

- This building is very nice for the Optimism Town Hall

- How can we best add to the picture to make it more about Optimism?
    - Consider adding:
        - RetroPGF Sunny in the sky
        - Some nice blue sky, clouds, or stars
        - Sunflowers and sunny flower around the building
            - Perhaps behind the building too
            - Mountains behind the building (like in OF 15-17)
        - The Optimism City
        - Other Optimism imagery like OP moon and Pheonix
        - Snapshot lightning bolt
        - Sages Council

![Optimism town hall 1.png](Create%20Artwork%20for%20Optimism%20Town%20Hall%20ab3cd5480c5141ef997f5d74b233b20d/Optimism_town_hall_1.png)

- Maybe it would make sense to include the town hall in the Optimism City?

![optimism city with town hall?.png](Create%20Artwork%20for%20Optimism%20Town%20Hall%20ab3cd5480c5141ef997f5d74b233b20d/optimism_city_with_town_hall.png)