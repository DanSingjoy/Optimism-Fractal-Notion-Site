# Explore and Consider Hosting Base Meetups

Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
Status: Not started
Task Summary: This task aims to explore and consider hosting base meetups. The goal is to gather like-minded individuals and create a platform for networking and knowledge sharing. By organizing these meetups, participants will have the opportunity to engage in meaningful discussions and build valuable connections within the community.
Summary: No content
Created time: May 26, 2024 8:27 AM
Last edited time: May 27, 2024 7:43 PM
Created by: Dan Singjoy

[https://x.com/base/status/1794129613079343374?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/base/status/1794129613079343374?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/base/status/1794129613079343374?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/base/status/1794129613079343374?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)