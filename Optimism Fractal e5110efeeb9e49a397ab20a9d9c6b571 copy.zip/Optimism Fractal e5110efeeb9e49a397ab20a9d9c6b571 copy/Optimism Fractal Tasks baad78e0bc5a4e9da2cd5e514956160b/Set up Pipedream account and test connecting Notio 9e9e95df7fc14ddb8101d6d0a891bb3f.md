# Set up Pipedream account and test connecting Notion with Slack, Discord, and Telegram

Project: Improve notification and provenance system for optimism fractal notion site via discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20notification%20and%20provenance%20system%20for%20opt%202bd6ce3108b64785a23f1bba8557407f.md), Integrate Optimism Fractal notion page with Notion API and Pipedream (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20notion%20page%20with%20Notion%2071c1311213394726983236991c25e999.md), Explore deeper integrations between Optimism Fractal and Discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Optimism%20Fract%20337d632e686e44e68cd899e6e12e05f3.md)
Status: Not started
Summary: Set up a Pipedream account and test connecting Notion with Slack, Discord, and Telegram. Review and add notes from unspecified sources.
Created time: February 18, 2024 4:40 PM
Last edited time: March 9, 2024 11:02 AM
Created by: Dan Singjoy

## Description

- [ ]  Review and add notes from:
    - [ ]  [Improve notification and provenance system for optimism fractal notion site via discord](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20notification%20and%20provenance%20system%20for%20opt%202bd6ce3108b64785a23f1bba8557407f.md)
    - [ ]  [Integrate Optimism Fractal notion page with Notion API and Pipedream](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20notion%20page%20with%20Notion%2071c1311213394726983236991c25e999.md)