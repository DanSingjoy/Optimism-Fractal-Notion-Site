# Share tweet about intents and post in telegram chats

Assignee: Dan Singjoy
Due: August 2, 2024
Status: Not started
Task Summary: This task aims to create a tweet and post it in Telegram chats regarding intents. The tweet will be about the importance of understanding and utilizing intents in various contexts. It will highlight the significance of intents in optimizing governance on the Superchain. The post will include a quote tweet video post.
Summary: Dan Singjoy has created a task to share a tweet about intents and post it in Telegram chats. The task is assigned to Dan Singjoy and is due on August 2, 2024. The task has not been started yet.
Created time: June 27, 2024 12:45 PM
Last edited time: July 23, 2024 12:06 PM
Created by: Dan Singjoy
Description: Dan Singjoy has created a task to share a tweet about intents and post it in Telegram chats. The task has not been started yet and is due on August 2, 2024. The tweet includes a link to an announcement about Optimism Fractal's intent to optimize governance on the superchain. There is also a checkbox to quote tweet a video post.

[https://gov.optimism.io/t/announcing-optimism-fractal-s-intent-to-optimize-governance-on-the-superchain/8399](https://gov.optimism.io/t/announcing-optimism-fractal-s-intent-to-optimize-governance-on-the-superchain/8399)

- [ ]  quote tweet video post