# Consider organizing two different subprojects for education about the optimism collective and optimism fractal

Project: Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md), Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Build Optimism Fractal Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md)
Status: Not started
Summary: Consider organizing two subprojects for education about the Optimism Collective and Optimism Fractal. Each subproject would focus on providing educational resources and there may be a need to merge or create additional projects to cover related topics. Review ideas for managing these projects in Notion.
Created time: April 6, 2024 10:07 PM
Last edited time: May 1, 2024 7:24 AM
Created by: Dan Singjoy

## Description

- [ ]  Consider: I think it makes sense to split this into two different sub-projects
    - One for educational resources about the Optimism Collective and another for educational resources about Optimism Fractal
        - There is a really large information about each and they probably both deserve their own projects
        
    - It may make sense to merge the project about Optimism Fractal with the educational components of [Improve [OptimismFractal.com](http://OptimismFractal.com) Website (and Create Educational Resources)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md)
    
    - It may also make sense to create another project specifically about fractal communities outside of Optimism Fractal, though this may be out of the scope of Optimism Fractal for a while
        - A similar project has been started at [Create educational resources about the history of Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20about%20the%20history%20of%20%20fdcb0d490a9a41ce95992d8947236df6.md), though this mostly features historical information and doesn’t include much of the current information. It may be worth refocusing this project or creating another
        
    
    ## Review Ideas for managing all these projects in notion
    
    - I created a project called [Create educational resources and webpages on OptimismFractal.com](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md), which was previously a task. So we could use this as the place to curate educational resources about Optimism Fractal
    
    - [ ]  consider if this should be merged with [Improve [OptimismFractal.com](http://OptimismFractal.com) Website (and Create Educational Resources)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md)
        - I think that i should just clarify the project above to have a broader focus, then add this and the technical improvements to the site as sub-projects
    - [ ]  consider if this should be merged with [Create Educational and Community Resources for the Optimism Collective and Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md)?
    - [ ]  consider if this should be merged with [Build Optimism Fractal Education Hub](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md)
        - I think it makes sense to have several different projects and sub-projects:
            - improving the website
                - technical improvements
                - creating/updating webpages
            - building the educational hub
            - creating educational resources
                - optimism fractal specific
                - optimism collective
        - They’ll work closely together and may share many of the same tasks, but the first step is generally to create resources the educational hub in notion then move them to the website when they’re ready. And it’s helpful to have projects specifically about the creation of the website and education hub as structures to house the content.
        
        - [ ]  Review the notes at the top of each to figure out how to best merge/organize them