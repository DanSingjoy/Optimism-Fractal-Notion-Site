# Consider if there are other ways we should integrate ENS with Optimism Fractal and the Respect Game

Project: Integrate Optimism Fractal with ENS (Ethereum Name Service) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20with%20ENS%20(Ethereum%20Name%2003fc813cc6744f87807695748158eed5.md)
Status: Not started
Summary: No content
Created time: April 4, 2024 9:39 PM
Last edited time: April 4, 2024 9:40 PM
Created by: Dan Singjoy

## Description

-