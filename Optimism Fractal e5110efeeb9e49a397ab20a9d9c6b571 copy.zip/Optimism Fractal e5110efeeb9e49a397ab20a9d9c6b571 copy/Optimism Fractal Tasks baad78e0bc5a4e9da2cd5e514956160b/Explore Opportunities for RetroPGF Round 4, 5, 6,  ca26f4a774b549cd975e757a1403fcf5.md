# Explore Opportunities for RetroPGF Round 4, 5, 6, and 7

Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Not started
Summary: Explore opportunities for future rounds of RetroPGF, a retroactive public goods funding mechanism. The Optimism Collective plans to distribute funding based on lifetime impact to Optimism, with contributions from Superchain members. More information can be found on the main page and the Round 4-7 announcement.
Created time: January 14, 2024 11:23 PM
Last edited time: April 8, 2024 11:41 AM
Parent task: Create OptimismFractal.com/funding to show how Optimism Fractal can help people earn RetroFunding and other funding (Create%20OptimismFractal%20com%20funding%20to%20show%20how%20Opt%2045915c303ab94868b62bc2124430da06.md)
Created by: Dan Singjoy

## Intro to RetroPGF

RetroPGF may be the largest retroactive public goods funding mechanism in the world. In the most recent round of RetroPGF the Optimism Collective distributed 30 million OP.

There is over 800 million more OP allocated for future rounds of RetroPGF and a seemingly sustainable growth strategy where members of the Superchain (such as Base, Worldcoin, Lisk, and Zora) contribute a portion of their fees to funding public goods. 

The collective plans to run RetroPGF rounds every few months and allocates funding on the basis of lifetime impact to Optimism, so contributions that make an ongoing impact on Optimism then it could earn perpetually from future rounds of RetroPGF. 

**Table of Contents**

- [ ]  add messages in discord and OF 22 timestamps

## Key links

Main page: [https://app.optimism.io/retropgf](https://app.optimism.io/retropgf)

Round 4-7 announcement:

[850M OP Dedicated to the Evolution of Retro Funding](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU)

[https://x.com/optimism/status/1772664299359707556?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/optimism/status/1772664299359707556?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ)

## Earlier Optimism Foundation Articles

[Announcing RetroPGF Round 3 Recipients](https://optimism.mirror.xyz/37Bgum6MfTJWDuE41CH9RXSH5KBm_RCL5zsSFeRZl4E)

[RetroPGF 3: Learnings & Reflections](https://optimism.mirror.xyz/Bbu5M1mTNV2Z637QxOiF7Qt7R9hy6nxghbZiFbtZOBA)

[Announcing RetroPGF Round 3](https://optimism.mirror.xyz/oVnEz7LrfeOTC7H6xCXb5dMZ8Rc4dSkD2KfgG5W9cCw)

There are also so many more articles that you can find. These are just a few to get started and help you understand how it works. We can add more here when we get the chance. 

## Optimystics Videos

[https://youtu.be/LVZMBaBt7Xw?si=XFuY1J63B8vLf2ED](https://youtu.be/LVZMBaBt7Xw?si=XFuY1J63B8vLf2ED)

## Optimystics Articles

You can find related articles from Optimystics about with an overview and our experience with RetroPGF at [Optimystics.io/funding](http://Optimystics.io/funding) 

- 
    
    [Untitled](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimism%20Funding%20cd4f4cdf041a4bc5b3ab579a2e049847/Untitled%207af1fdae350c47059aebba467cc93530.csv)
    

## Events

[Create Calendar of Events for Optimism Collective](Create%20Calendar%20of%20Events%20for%20Optimism%20Collective%206f142fcf13744f73bf57b2cf7d454160.md)