# Create and Organize Topic(s) for Optimism Fractal 38

Assignee: Dan Singjoy
Due: June 30, 2024
Project: Prepare for OF 38 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2038%20fbdbc38ebea44212ad0d3ac008f92b30.md), Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md), Integrate Optimism Fractal into the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20into%20the%20Optimism%20Colle%20b7f7b9296593434ab7f8a4fc1f4cd7b2.md), Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md)
Status: Done
Task Summary: This task aims to create and organize topics for Optimism Fractal 38. It involves proposing discussion points for the upcoming Optimism Town Hall, facilitating engagement among participants, and exploring ways to maximize the impact of the Optimism Collective through collaborative dialogues.
Summary: The document outlines proposed topics for the upcoming Optimism Town Hall, including discussions on Optimism Collective Governance, Unifying the Superchain, Optimism Collective Identity, and Optimism Fractal Discussions. Participants are encouraged to vote on these topics and propose new ones during the event, utilizing the OPTOPICS game format to facilitate open dialogue and maximize impact within the Optimism community.
Sub-task: Create discord post for OTH Hall Topics, August 22 (Create%20discord%20post%20for%20OTH%20Hall%20Topics,%20August%2022%209087612afde849a382aedea653f56cc9.md), Propose topic for Optimism Collective Governance after OF 38 (Propose%20topic%20for%20Optimism%20Collective%20Governance%20a%20f4c2983b3e0a47238606328ab3133045.md), Review topic, discussion, and resources about Optimism Collective Identity  (Review%20topic,%20discussion,%20and%20resources%20about%20Opti%20fa0957f81ecb48fbb3aefd2e0fe87c49.md), Propose topic about Unifying the Superchain  (Propose%20topic%20about%20Unifying%20the%20Superchain%206b3f9c1b852b4b92b830650624cb76b8.md), Propose topic about Optimism Fractal Discussions (Propose%20topic%20about%20Optimism%20Fractal%20Discussions%20227f09a47ba94c078ea3a92ce629e6de.md), Untitled (Untitled%205e4c29a2396b420485bca95e988f50d4.md)
Created time: August 17, 2024 9:26 PM
Last edited time: September 19, 2024 12:37 PM
Sub-tasks: Create discord post for OTH Hall Topics, August 22 (Create%20discord%20post%20for%20OTH%20Hall%20Topics,%20August%2022%209087612afde849a382aedea653f56cc9.md), Propose topic for Optimism Collective Governance after OF 38 (Propose%20topic%20for%20Optimism%20Collective%20Governance%20a%20f4c2983b3e0a47238606328ab3133045.md), Review topic, discussion, and resources about Optimism Collective Identity  (Review%20topic,%20discussion,%20and%20resources%20about%20Opti%20fa0957f81ecb48fbb3aefd2e0fe87c49.md), Propose topic about Unifying the Superchain  (Propose%20topic%20about%20Unifying%20the%20Superchain%206b3f9c1b852b4b92b830650624cb76b8.md), Propose topic about Optimism Fractal Discussions (Propose%20topic%20about%20Optimism%20Fractal%20Discussions%20227f09a47ba94c078ea3a92ce629e6de.md), Untitled (Untitled%205e4c29a2396b420485bca95e988f50d4.md)
Created by: Dan Singjoy
Description: Dan Singjoy proposed four discussion topics for the Optimism Town Hall: Optimism Collective Governance, Unifying the Superchain, Optimism Collective Identity, and Optimism Fractal Discussions. The event will include an OPTOPICS game for participants to vote on these topics and propose new ones, aiming to enhance understanding and impact within the Optimism community. Resources for each topic are provided for further exploration.

# Discord Post

Hey all, 

I just proposed the following four topics for today’s Optimism Town Hall:

🔴 [Optimism Collective Governance](https://snapshot.org/#/optimismfractal.eth/proposal/0x63b2730dc4fe96861c747e3a736c2444d0e7eb3967f4e26229d0d31c9b40d212)

🔻 [Unifying the Superchain](https://snapshot.org/#/optimismtownhall.eth/proposal/0x5bb378e36303a11b05f7822bc33faaad72a6f5015bae60431c1551d6988181c5)

👁️ [Optimism Collective Identity](https://snapshot.org/#/optimismtownhall.eth/proposal/0x115d860c1ff68cd4b0850b90163801b0c4e49c6a4c43f43205df58fe71e14c86)

🌻 [Optimism Fractal Discussions](https://snapshot.org/#/optimismtownhall.eth/proposal/0xd8e5995dcfda589df30edb1ad107504ea1100b067b037bdefe7a5183a73eacf2)

Each of these topics provide space for us to have open discussions and explore educational resources that can help Optimism Fractal maximize impact for the Collective. We’ll play OPTOPICS at today’s town hall, so you can vote on these topics or propose others throughout the event. On a related note, I'm having an issue with the Optimism Town Hall Snapshot Space (which is explained in the first topic), so if you'd like to propose a topic then you can do so in the Optimism Fractal snapshot space today.

I’m curious to hear your thoughts and looking forward to seeing you at the events in a couple hours! :)

In order to be able to maximize the impact that create for Optimism, it helps to be more informed about how Optimism works and how we can help.  

By the way, there is x hours remaining to register for the weekly council:

# OPTOPICS Proposals

## 🔴 Optimism Collective Governance

The Optimism Collective is a band of companies, communities, and citizens working together to reward public goods and build a sustainable future on Ethereum. 

At this week’s event we can explore the innovative governance structures of the Optimism Collective, including the Citizen’s House, Token House, and opportunities for optimizations with Optimism Fractal. I can share a brief overview of Optimism Collective governance and we can have an open discussion about it.

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can find related resources and learn more about governance in the Optimism Collective in these [tabs](https://arc.net/folder/C17785E4-FAB6-4CD1-9298-4436CCDCB1BD) and this [notion page](../%F0%9F%90%99%20Optimism%20Town%20Hall%20Topics%20and%20OPTOPICS%20Database%206415ae101d154bf8a3c1b25d218295d5/%F0%9F%94%B4%20Optimism%20Collective%20Governance%20f76a4bd176b047b1b71468d39ecb5344.md). 

## 👁️ Optimism Collective Identity

The Optimism Foundation is working to create a robust system for identity and reputation within the Optimism Collective, which can improve RetroFunding, the Citizen’s House, and many other systems.

At this week’s event we can explore the Optimism Foundation’s thinking on identity systems in the Collective and how Optimism Fractal can help. I can share a brief overview of identity systems on Optimism and we can have an open discussion about it.

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can find related resources and learn more about identity in the Optimism Collective in these [tabs](https://arc.net/folder/1A6CF438-10DE-4161-9851-F26018B96591) and this [notion page](../%F0%9F%90%99%20Optimism%20Town%20Hall%20Topics%20and%20OPTOPICS%20Database%206415ae101d154bf8a3c1b25d218295d5/%F0%9F%91%81%EF%B8%8F%20Optimism%20Collective%20Identity%2052fe94446c2645cab1aca7de0d67925c.md). 

## 🔻Unifying the Superchain

Optimism began with a single L2 chain called OP Mainnet and is evolving into an expansive Superchain of cooperative networks.

At this week’s event we can explore the Superchain, it’s technical development, and ways that Optimism Fractal can help. I can share a brief overview of of the Superchain and we can have an open discussion about it.

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can find related resources and learn more about the Superchain [here](https://arc.net/folder/BA8967A1-5AFD-43DB-83C8-B43C8A43A84F).

## 🌻 Optimism Fractal Discussion

At this week’s event we can have an open discussion about Optimism Fractal, the Respect Game, and/or other related topics. What would you like to discuss about Optimism Fractal?

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can learn more at [OptimismFractal.com](http://OptimismFractal.com) and by joining our weekly events!

# Discord Post

Hey all, I hope you had a nice weekend and am looking forward to seeing you at this week’s events! 

For this week’s Optimism Town Hall I created a [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x1d6467252c1e2054ea59dfb8ddd7c02b41ae3ec6c3de3aab7f0d2288fbd652aa) to play an OPTOPICS Cagendas game. This allows you to proposal any topics related to Optimism and vote on topics at any time, so feel free to suggest a topic on the Snapshot space if there’s something you’d like to discuss. I also plan to follow up with at least one topic suggestion in the coming days.

Looking forward to hearing your thoughts and seeing you at the event!

# Snapshot Poll

I propose that we play an OPTOPICS Cagendas game at this week’s Optimism Town Hall. The game rules are below and you can learn more at [Optimystics.io/OPTOPICS](http://Optimystics.io/OPTOPICS). There are three main actions that you can take while playing OPTOPICS: propose topics, vote on topics, and switch topics.

### Propose Topics

Create a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth) at any time to propose a topic. Feel free to suggest anything related to Optimism.

**Tip:** When creating a topic proposal you can set the Voting Type to **Weighted Voting**, then set two poll options to **Upvote** and **Abstain**. This isn’t necessary, but provides greater ability for everyone to weigh their preferences while voting for topics.

### Vote on Topics

Vote on topics with [Respect](https://optimystics.io/respect) to help set the agenda. The topic with the most votes will be discussed until the group decides to switch topics. Feel free to change your vote at any time.

### Switch Topics

OPTOPICS features an optimistic topic transition system that allows anyone to influence the discussion as the game progresses and help move the group to the next topic. Here’s how it works:

- **Next Topic:** Type ‘next topic’ in the zoom chat to propose moving to the next topic. This starts a one-minute countdown.
- **Same Topic:** Type ‘same topic’ within one minute to veto the change. If vetoed, neither person can propose to switch or veto again for the current topic.
- **New Topic:** If over half of well respected community members agree (each with at least 50 Respect), any topic can be introduced and discussed immediately.

Feel free to suggest any topics related to Optimism. I also plan to follow up with at least one topic suggestion in the coming days. Looking forward to hearing your thoughts and seeing you at the events!

![optopics 3.png](Create%20and%20Organize%20Topic(s)%20for%20Optimism%20Fractal%20%20cc66d864b0a6469d97fbcb3f22237580/optopics_3.png)

## Overview of Optimism Governance

by the way, here are a few resources where you can learn about the Citizens’ House, which plays a major role in Optimism Collective Governance and uses a one-person-one-vote system.

I’ve been thinking a lot about how Optimism Fractal can enhance both the Citizens’ House and Token House. There are wonderful synergies with immense potential here for profoundly helpful collaborations for the benefit of Optimism and fractal governance. The Collective provides a perfect place to grow fractal democracy and will greatly benefit by integrating fractal democracy. Perhaps this would be a good topic for an upcoming Town Hall…

[https://community.optimism.io/citizens-house](https://community.optimism.io/citizens-house)

[https://optimism.mirror.xyz/PLrAQgE1EGRo7GRrFoztplFChnUZda4DFGW3dkQayxY](https://optimism.mirror.xyz/PLrAQgE1EGRo7GRrFoztplFChnUZda4DFGW3dkQayxY)

[https://www.youtube.com/results?search_query=optimism+citizens+house](https://www.youtube.com/results?search_query=optimism+citizens+house)

As a starting point you may be interested in exploring the Optimism [docs](https://community.optimism.io/welcome/welcome-overview), which provide an overview of the Collective’s governance structure, the Citizens’ House, and how the Foundation is thinking about identity and sybil-resistance. 

Optimism Fractal’s core [intents](https://optimismfractal.com/details#block-130723a67adb4a8ea2eb78ddada84a0f) are to foster collaboration, award public good creators, and optimize governance on the Optimism Superchain**.** The Optimism Foundation and Collective are actively looking for ways to improve their governance, identity, and other core systems. 

Optimism Fractal can play an important role in improving these systems and providing many other benefits for the Collective, while also working to expand fractal governance processes throughout society.

You can find an introductory overview of Optimism Collective governance [here](https://community.optimism.io/welcome/welcome-overview) and learn more in these [resources](https://arc.net/folder/9CCA22B3-81C3-432C-B296-50B97090F556). You can also see this [article](https://community.optimism.io/identity/project-and-individual-identity-in-the-collective) for an overview of how the Optimism Foundation is working to building identity and prevent sybil attacks and explore more in these [links](https://arc.net/folder/1CAFCC3A-3E3F-42F1-8B7B-FEF4376961BA). The Optimism Foundation and the broader Collective are looking for the best ways to improve and scale up the Optimism Collective governance, as you can see in this [article](https://gov.optimism.io/t/the-path-to-open-metagovernance/7728).

Optimism Fractal can greatly help with this in many ways, including increasing sybil resistance, building reputation with Respect, and optimizing governance in both the Citizens’ House and Token House. For example, the Citizen’s House has mostly operated on a personal vouching system so far and Optimism Fractal can enable this to work at a much larger scale. 

[Integrate Optimism Fractal into the Optimism Collective](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20into%20the%20Optimism%20Colle%20b7f7b9296593434ab7f8a4fc1f4cd7b2.md) 

[Summarize vision of Optimism Fractal and Collective + Strategy](https://www.notion.so/Summarize-vision-of-Optimism-Fractal-and-Collective-Strategy-f795a49cabfe475aaef37df04ec077ed?pvs=21) 

[Summarize Articles about Optimism Collective Season 6](Summarize%20Articles%20about%20Optimism%20Collective%20Seaso%20429db5209cc9419d869ac72347b7fe90.md) 

## Integratij