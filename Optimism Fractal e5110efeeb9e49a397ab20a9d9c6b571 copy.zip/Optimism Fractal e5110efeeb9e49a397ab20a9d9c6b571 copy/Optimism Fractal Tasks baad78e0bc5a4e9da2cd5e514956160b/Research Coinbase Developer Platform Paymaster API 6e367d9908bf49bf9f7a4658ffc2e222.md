# Research Coinbase Developer Platform Paymaster API

Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md)
Status: Not started
Task Summary: This task aims to research the Coinbase Developer Platform Paymaster API. The page provides information about the API, including its purpose, functionality, and how it can be utilized by developers. The summary/intro will give an overview of the research objectives and highlight the significance of understanding and utilizing this API for developers working with Coinbase.
Summary: No content
Sub-task: Research tool that protects your @CoinbaseDev Paymaster API from abuse by ensuring that only calls to an allowed list of contracts  (Research%20tool%20that%20protects%20your%20@CoinbaseDev%20Paym%209fde838d73a7431b993ab206b3c15c6c.md)
Created time: June 1, 2024 7:52 PM
Last edited time: June 8, 2024 11:42 PM
Parent task: Research Coinbase Developer Platform (Research%20Coinbase%20Developer%20Platform%2060c4fa44c72f48a5a60a2d3cb11ba1f0.md)
Created by: Dan Singjoy

[Onchain kit ](Research%20Coinbase%20Developer%20Platform%20Paymaster%20API%206e367d9908bf49bf9f7a4658ffc2e222/Onchain%20kit%207444db6231ae438ba7a4c84a80aa4d5d.md)