# Respond to Polynya on Warpcast AMA

Assignee: Dan Singjoy
Project: Prepare for Optimism Fractal 44 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20Optimism%20Fractal%2044%20114074f5adac80f1b58afdd32fcefefd.md)
Status: Done
Task Summary: This task aims to respond to Polynya during the Warpcast AMA. The discussion will focus on the integration of the Optimism Fractal and its processes of fractal democracy within the Optimism Collective. Engaging with Polynya will also provide an opportunity to express gratitude for past support in the Optimism Grants Councilor elections.
Summary: The document discusses a response to a question about the integration of /optimismfractal and its fractal democracy processes within the Optimism Collective. It expresses gratitude for past support in voting for the author as an Optimism Grants Councilor and shows interest in the recipient's insights on DAOs and governance.
Created time: October 3, 2024 9:13 AM
Last edited time: October 3, 2024 11:31 AM
Created by: Dan Singjoy
Description: The document discusses a response to Polynya regarding the integration of /optimismfractal and its processes of fractal democracy within the Optimism Collective. It expresses gratitude for past support in voting for an Optimism Grants Councilor and invites further discussion on the topic.

![image.png](Respond%20to%20Polynya%20on%20Warpcast%20AMA%20114074f5adac807188e4c1d2a0e9f6d3/image.png)

![image.png](Respond%20to%20Polynya%20on%20Warpcast%20AMA%20114074f5adac807188e4c1d2a0e9f6d3/image%201.png)

# V2

What do you think about /optimismfractal and the potential for it’s processes of fractal democracy to be more deeply integrated within Optimism Collective?

By the way, thank you very much for your support in voting for me as an Optimism Grants Councilor in the past two seasons. I’ve appreciated reading your posts about DAOs and governance over the past year and am curious if you’ve had the chance to look into Optimism Fractal

> Just thought if he gives an opening you might be able to get his opinion on the idea. Your just asking what he thinks of optimism fractal but what if you asked what he thinks of optimism fractal and the potential for deeper integration within optimism collective
> 

# V1

What do you think about /optimismfractal and the processes of fractal democracy that it is pioneering?

By the way, thank you very much for your support in voting for me as an Optimism Grants Councilor in the past two seasons.  I’ve appreciated reading your posts about DAOs and governance over the past year and am curious if you’ve had the chance to look into Optimism Fractal

[Naturalisation councils — polynya](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183/Naturalisation%20councils%20%E2%80%94%20polynya%20114074f5adac81539ed0ef357186c568.md) 

[message polynya about the respect game -  Democratising tokenholder DAOs](https://www.notion.so/message-polynya-about-the-respect-game-Democratising-tokenholder-DAOs-e99c92f33c184d92b765ce272655658d?pvs=21)