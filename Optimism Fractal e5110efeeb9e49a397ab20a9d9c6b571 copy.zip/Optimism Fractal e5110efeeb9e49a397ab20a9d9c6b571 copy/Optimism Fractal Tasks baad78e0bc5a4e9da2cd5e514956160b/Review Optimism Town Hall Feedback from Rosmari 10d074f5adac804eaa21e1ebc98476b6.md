# Review Optimism Town Hall Feedback from Rosmari

Assignee: Dan Singjoy
Due: June 6, 2024
Project: Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md)
Status: Not started
Task Summary: This task aims to review the feedback collected during the Optimism Town Hall led by Rosmari. The insights gathered will help identify areas for improvement in the format and structure of future town hall meetings, ensuring that they are more engaging and effective for all participants.
Summary: Feedback from the Optimism Town Hall suggests implementing rules for speaking, reducing meeting length to 30 minutes, using polls for questions, and verifying the OPTOPICS Snapshot for topic proposals. Additionally, it recommends less in-depth discussions to allow broader participation and more structured engagement to encourage lively discussions among all attendees.
Created time: September 26, 2024 11:36 AM
Last edited time: September 26, 2024 11:37 AM
Created by: Dan Singjoy
Description: Feedback from the Optimism Town Hall suggests establishing speaking rules, reducing meeting length to 30 minutes, utilizing polls for questions, and improving engagement among participants. It emphasizes the need for structured discussions to allow more voices to be heard and proposes using the OPTOPICS Snapshot for topic proposals and feedback collection.

OTH Feedback to bring up to Dan

Are there rules about raising our hand when we want to speak? If so, Patrick doesn’t do that every time and sometimes he goes into a tangine

The past few OTH recently have gone for longer than 30 mins. Do you know why and how we can keep it shorter and stick to 30 mins as scheduled?

It might be useful to have a poll for questions that we want to ask each other after a topic gets presented. Also maybe putting some avg time for topic presentation will be useful since it’s only 30 mins. Otherwise it becomes a community chosen topic presented in front of a live audience.

Reminder about verifying the OPTOPICS Snapshot so more topics can be proposed at a time.

For example we can still use Snapshot but make proposals with a follow up questions and vote on which questions to go around everyone. For example, what do you think about the way the Round 6 was organised, is there any feedback for the organisers that we can provide as a group?

If we think about the most value we can provide in the Town Hall for 30 mins, that would be good.

Also the Town Hall might be better if there’s a less deep dive into the topics so we can have more time for everyone to discuss. I feel like right now there are 2-3 people that speak the most during town halls and there’s not enough time for everyone to express their opinion. There seems to lack structure after the topic is presented - how do we engage the participants after they choose the topic? There will be better to have more of a lively discussion amongst multiple participants, similarly to the way the Respect Game gives people a chance to say what’s on their mind.