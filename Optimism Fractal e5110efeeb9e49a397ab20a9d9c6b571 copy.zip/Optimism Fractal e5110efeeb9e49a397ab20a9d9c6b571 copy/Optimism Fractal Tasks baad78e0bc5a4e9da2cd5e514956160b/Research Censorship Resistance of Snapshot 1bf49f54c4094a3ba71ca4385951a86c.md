# Research Censorship Resistance of Snapshot

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to explore and research the censorship resistance of the Snapshot platform. It discusses the potential centralization and vulnerabilities in their current voting system, as well as the development of Snapshot X as a solution. While there may not be immediate incentives for censoring community votes, it is important to consider the long-term implications and keep this aspect in mind.
Summary: The document discusses the censorship resistance of Snapshot, highlighting its dependence on centralized servers for vote collection and distribution, which enables censorship. It suggests considering on-chain voting and mentions the development of Snapshot X. However, it concludes that there is currently no incentive to censor votes and recommends using the best available polling app, such as Snapshot.
Created time: June 3, 2024 9:08 AM
Last edited time: June 3, 2024 9:09 AM
Created by: Dan Singjoy

## Censorship-resistance

Last time I checked (not too long ago), they depend on centralized servers to collect votes and distribute to IPFS. This point of centralization enables censorship of votes. That’s why others do on-chain voting. That’s also probably why they are working on Snapshot X.

I don’t see anyone having any incentive to censor votes of our communities anytime soon, so for now I think we should simply use the best polling app available and if it is snapshot let’s use it. But just something to keep in mind for later.

## Respond to Tadas about Snapshot Censorship Resistance

- [ ]  timestamp podcast