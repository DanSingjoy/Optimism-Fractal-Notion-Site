# Share Optimism Grants Changelog

Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Done
Summary: This document provides information about the Share Optimism Grants Changelog. It includes a timeline for grants in the Optimism Ecosystem and curated resources. The document also includes a link to the forum post and two untitled images.
Created time: August 29, 2023 12:09 PM
Last edited time: March 20, 2024 8:59 AM
Created by: Dan Singjoy

You can see the timeline for grants in the Optimism Ecosystem at [OptimismGrants.io](https://optimismgrants.io/). I also curated some more resources about this notion page called [Optimism Grants Changelog](Share%20Optimism%20Grants%20Changelog%205376efc4de15475181b5edd06c7a6b6d.md).

[https://optimismgrants.io/](https://optimismgrants.io/)

## Forum Post

[https://gov.optimism.io/t/optimism-grants-changelog/6719](https://gov.optimism.io/t/optimism-grants-changelog/6719)

![Untitled](Share%20Optimism%20Grants%20Changelog%205376efc4de15475181b5edd06c7a6b6d/Untitled.png)

![Untitled](Share%20Optimism%20Grants%20Changelog%205376efc4de15475181b5edd06c7a6b6d/Untitled%201.png)