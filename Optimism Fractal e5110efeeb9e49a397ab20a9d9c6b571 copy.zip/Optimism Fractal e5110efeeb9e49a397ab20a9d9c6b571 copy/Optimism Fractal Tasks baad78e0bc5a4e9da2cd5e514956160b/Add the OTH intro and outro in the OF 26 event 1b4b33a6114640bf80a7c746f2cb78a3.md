# Add the OTH intro and outro in the OF 26 event

Due: May 3, 2024
Status: Not started
Task Summary: This task aims to add the OTH (On the House) intro and outro in the OF 26 event. It is created by Rosmari and is due on May 3, 2024. The task has not been started yet.
Summary: No content
Created time: May 17, 2024 11:42 AM
Last edited time: May 17, 2024 11:58 AM
Created by: Rosmari