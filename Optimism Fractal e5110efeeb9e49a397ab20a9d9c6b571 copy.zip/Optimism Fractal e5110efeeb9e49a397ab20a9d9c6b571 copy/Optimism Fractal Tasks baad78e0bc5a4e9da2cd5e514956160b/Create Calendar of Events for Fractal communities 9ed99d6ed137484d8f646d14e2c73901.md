# Create Calendar of Events for Fractal communities

Project: Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md)
Status: Not started
Summary: No content
Created time: March 25, 2024 6:41 PM
Last edited time: March 28, 2024 10:45 AM
Created by: Dan Singjoy

## Description

/linked