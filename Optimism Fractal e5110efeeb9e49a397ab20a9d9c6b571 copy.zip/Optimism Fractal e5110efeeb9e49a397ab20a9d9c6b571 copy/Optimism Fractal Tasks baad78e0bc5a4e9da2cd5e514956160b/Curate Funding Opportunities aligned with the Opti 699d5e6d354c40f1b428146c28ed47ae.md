# Curate Funding Opportunities aligned with the Optimism Collective

Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Not started
Summary: This task aims to curate funding opportunities aligned with the Optimism Collective and accessible for Optimism Fractal community members. The focus should be on Optimism with RetroFunding, but other opportunities like Octant can also be included. A task, page, and database for funding opportunities should be created, and @Dan Singjoy can review and add to it.
Sub-task: Research Gitcoin Retro Citizens RetroPGF and other funding Rounds (Research%20Gitcoin%20Retro%20Citizens%20RetroPGF%20and%20other%203f8c9045201f4ecfb5e3c5d72fe1b74a.md)
Created time: April 8, 2024 11:38 AM
Last edited time: April 8, 2024 11:52 AM
Sub-tasks: Research Gitcoin Retro Citizens RetroPGF and other funding Rounds (Research%20Gitcoin%20Retro%20Citizens%20RetroPGF%20and%20other%203f8c9045201f4ecfb5e3c5d72fe1b74a.md)
Created by: Dan Singjoy

## Description

This task aims to curate information about funding opportunities that are aligned with the Optimism Collective and accessible for Optimism Fractal community members.

## Organize Funding Opportunities

- [ ]  consider how to best curate/organize this
    
    
    - [ ]  create a page in [Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)

- This should eventually be added to [Education Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Education%20Hub%20225efc918f9f4644a39448be1eb3c7f0.md)

- It might be a good idea to add it to [Create webpages and educational resources for Optimism Fractal Funding Opportunities (OptimismFractal.com/funding or /earn)](Create%20webpages%20and%20educational%20resources%20for%20Opti%20c82abe9c5c8341d897c04f8eed3b924f.md) at some point, though we can just keep it here for now

- There are also many other opportunities like Octant etc that are aligned with Optimism that are good to include

- But it’s best to focus mostly on Optimism with RetroFunding

- So I think we should create a task, page, and database for funding opportunities

- @Dan Singjoy can also add [Monetization Opportunities Database](https://www.notion.so/Monetization-Opportunities-Database-f606e1d27fee445c80a926ec7e174f95?pvs=21) here as well
    - It just needs to be reviewed briefly first to see what’s there and if it all should be shared