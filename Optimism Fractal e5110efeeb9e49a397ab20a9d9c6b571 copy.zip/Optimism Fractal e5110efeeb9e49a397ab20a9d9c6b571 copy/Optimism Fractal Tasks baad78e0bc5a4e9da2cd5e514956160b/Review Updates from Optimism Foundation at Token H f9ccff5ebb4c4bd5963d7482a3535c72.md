# Review Updates from Optimism Foundation at Token House Call

Due: May 3, 2024
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md)
Status: Done
Task Summary: This task aims to provide an overview of the updates discussed during the Token House Call organized by the Optimism Foundation. It will summarize key points and decisions made regarding the Optimism community and its ongoing projects.
Summary: The document outlines a review of updates from the Optimism Foundation during a Token House call, created by Dan Singjoy, with a due date of May 3, 2024, and includes a link to community call recaps and recordings.
Created time: May 20, 2024 11:20 AM
Last edited time: August 30, 2024 9:06 AM
Created by: Dan Singjoy
Description: The document outlines a review of updates from the Optimism Foundation during a Token House Call, created by Dan Singjoy, with a due date of May 3, 2024, and includes a link to the Optimism Community Call recaps and recordings thread.

[Optimism Community Call Recaps & Recordings Thread](https://gov.optimism.io/t/optimism-community-call-recaps-recordings-thread/6937/37)

[Consider proposing inflation change for Optimism Collective](Consider%20proposing%20inflation%20change%20for%20Optimism%20C%20665732002e8d412a85ae6742b0b74add.md)