# Review and Respond to Hodlon about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer

Due: April 15, 2024
Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), Improve Processes for Impact Measurement and Evaluation in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Processes%20for%20Impact%20Measurement%20and%20Evalu%20538192791aa94cf4ac328c1571d17f40.md)
Status: Done
Task Summary: This task aims to review and respond to Hodlon about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer. The page provides a summary of the task, including its status, due date, and creator, Dan Singjoy.
Summary: This document is a review and response to Hodlon regarding Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer. The conversation may be moved to a public OF task, and it is mentioned that Hodlon likely wouldn't mind sharing it publicly.
Parent-task: Respond to Spencer Graham about his PRD for Quantitative Value Creation Measurement for Decentralized Work (Respond%20to%20Spencer%20Graham%20about%20his%20PRD%20for%20Quanti%2003636b4f9b514204aebb0d472a9799d8.md)
Created time: April 7, 2024 10:35 AM
Last edited time: June 23, 2024 10:54 AM
Parent task: Respond to Spencer Graham about his PRD for Quantitative Value Creation Measurement for Decentralized Work (Respond%20to%20Spencer%20Graham%20about%20his%20PRD%20for%20Quanti%2003636b4f9b514204aebb0d472a9799d8.md)
Created by: Dan Singjoy

## Description

- [ ]  Consider asking Hodlon if he minds if i move this conversation to public OF task: about about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer
    - [ ]  [Consider asking Hodlon if he minds if i move this conversation to public OF task: about about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer](https://www.notion.so/Consider-asking-Hodlon-if-he-minds-if-i-move-this-conversation-to-public-OF-task-about-about-Hats-C-f59441218eff4f1bbb45f00fbf76f2b4?pvs=21)
    - I don’t think that he’d mind at all if i shared it publicly here, but it’s good to make sure before sharing it publicly and so the conversation is currently set to private

Context: [Respond to Hodlon about OF 22 and Hats Protocol Contribution Submissions](Respond%20to%20Hodlon%20about%20OF%2022%20and%20Hats%20Protocol%20Co%208628edca8518499b8c50ac86c4bf0f00.md)