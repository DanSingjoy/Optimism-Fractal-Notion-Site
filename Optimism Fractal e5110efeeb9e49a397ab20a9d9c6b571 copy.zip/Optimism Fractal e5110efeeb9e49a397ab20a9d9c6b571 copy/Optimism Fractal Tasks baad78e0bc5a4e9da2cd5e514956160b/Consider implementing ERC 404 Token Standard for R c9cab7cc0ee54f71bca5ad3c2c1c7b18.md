# Consider implementing ERC 404 Token Standard for Respect

Due: May 3, 2024
Status: Not started
Task Summary: This task aims to explore the implementation of the ERC 404 Token Standard for the Respect project. The document discusses the benefits and functionalities of ERC-404, its compatibility with existing infrastructure, and its potential for becoming a widely adopted token standard. It also provides insights into ERC-404's burning mechanic, current development status, and future prospects.
Summary: This document discusses the implementation of the ERC 404 Token Standard for the Respect project. It explores the benefits and functionalities of ERC-404, its compatibility with existing infrastructure, and its potential for becoming a widely adopted token standard. The document also provides insights into the burning mechanic of ERC-404, its current development status, and future prospects. ERC-404 is a proposed token standard that aims to provide a unified interface for both ERC-20 and ERC-721 standards, allowing tokens to act as both fungible and non-fungible tokens simultaneously. However, it is still in the experimental stage and has not undergone the formal Ethereum Improvement Proposal (EIP) process. Adoption and support from major infrastructure providers would require significant updates to accommodate the hybrid nature of ERC-404 tokens.
Created time: May 2, 2024 1:41 PM
Last edited time: May 7, 2024 11:20 AM
Parent task: Consider migrating to ERC-1155 (Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md)
Created by: Dan Singjoy

## Introduction

This task aims to explore the implementation of the ERC 404 Token Standard for the Respect project. The document discusses the benefits and functionalities of ERC-404, its compatibility with existing infrastructure, and its potential for becoming a widely adopted token standard. It also provides insights into ERC-404's burning mechanic, current development status, and future prospects.

**Table of Contents**

## Overview

### Current Status of Respect Token

- We’re currently considering if we should migrate the Optimism Fractal Respect token to an ERC 1155 token standard.

- The current implementation of Respect uses a unique combination of ERC721 and ERC20 token standards which allows you to see Respect in both ERC20 (fungible) and ERC 721 (nonfungible) token interfaces.
    - Here is the Github [repository](https://github.com/Optimystics/op-fractal-sc) with the current Optimism Fractal smart contracts.
    - Tadas (a developer on the Optimystics team who created the smart contracts) said that the best and most recent explanation of the contract’s design can be found [here](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md). You can read the explanation in the ‘background’ section near the top of the page if you’re interested. Tadas wrote this page in February to explain the unique design of the contract and improve how Respect displays in block explorers. At the end of the page he also considered the possibility of migrating the Respect token to an ERC-1155 standard.
    - For more details and rationale, you can see Tadas explain how the smart contract implements interfaces of both ERC20 and NFT standard for the Respect token in this [video](https://youtu.be/dU7Whneo5yI?si=LS-MI-MJxiX_ykwl&t=640). If you’re interested in learning about the philosophy originally behind this design, you could also see this blog [post](https://hive.blog/dao/@sim31/fungibility-out-of-non-fungible-tokens) and video [clip](https://youtu.be/yr1NzIdezG8?si=rNJbTSEuRczlr2_X&t=4653) for more details.

- I’m wondering if implementing Roles and Respect could make it easier for us to migrate to ERC-1155 by adopting an open-source and well supported standard that includes many helpful integrations out of the box.
    - After Tadas wrote the explanations linked below, I did a lot of research wrote the following page: [Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md). This page includes reasons why I think that we should migrate Respect to a ERC1155 token standard and questions about doing so

- Would it make sense to use ERC 404 instead of ERC1155 or ERC721 and ERC20?
    - I watched Jacob’s video about Trash NFT’s and learned about ERC 404. I organized details about ERC 404 in [Consider implementing ERC 404 Token Standard for Respect](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18.md).
    - My intuition is that it’s probably better to use a more proven and supported standard like ERC1155 than ERC404, but the fact that ERC 404 uses a similar design to Tadas’ implementation is enticing….
    - Does ERC404 token standard work with Roles and Reputations instead of ERC1155?

**Table of Contents**

- [ ]  ask chatgpt and/or jake if it could be included in the Roles and Reputations or if ERC 1155 is much easier/better

# AI Conversations

### What is ERC 404? Does it require burning/redeeming a ERC20 tokens to get the equivalent ERC721 and visa versa, or could it work in a way in which a token displays in user interfaces for both ERC20 and ERC721 at the same time? Are popular pieces of infrastructure (such as etherscan, blockscout, Zora, and opensea) able to display ERC404 by default or does it require additional programming to be compatible with existing infrastructure?

ERC-404 is a proposed Ethereum token standard that aims to provide a unified token interface that can simultaneously represent both ERC-20 and ERC-721 standards. This means a single token could act both as a fungible token (like ERC-20) and as a non-fungible token (like ERC-721) without needing to burn or redeem tokens in one standard to acquire tokens in another. The goal is to simplify token interactions and improve liquidity and interoperability across different applications and use cases.

### **How ERC-404 Works**

ERC-404 tokens are designed to function in a way where they display the characteristics of both ERC-20 and ERC-721 tokens simultaneously. This dual nature allows them to be used as needed depending on the context:

- As an ERC-20 token, they can be used for operations that require divisibility and fungibility, such as payments and trading on decentralized exchanges.
- As an ERC-721 token, they can be used for operations that require uniqueness and individual token identification, such as in collectibles or asset tracking.

### **Compatibility with Existing Infrastructure**

For ERC-404 tokens to be fully functional and display correctly on existing infrastructure like Etherscan, Blockscout, Zora, and OpenSea, additional programming and updates to these platforms may be required. This is because current systems are typically designed to handle ERC-20 and ERC-721 tokens separately, and they might not automatically recognize or correctly interpret the hybrid nature of ERC-404 tokens without modifications:

- **User Interfaces:** Platforms would need to update their user interfaces to properly display and differentiate when a token is acting as an ERC-20 or an ERC-721, or when it's utilizing both functionalities simultaneously.
- **Smart Contracts and APIs:** Backend systems that interact with these tokens would also need to be updated to handle their dual functionalities correctly. This might involve updates to smart contracts that interface with tokens, as well as changes to APIs that fetch and display token data.

### **Conclusion**

As of now, since ERC-404 is a relatively new and experimental concept, most popular infrastructure platforms do not yet support it by default. Implementing ERC-404 compatibility would require a considered effort from developers maintaining these platforms to integrate new functionalities and ensure seamless operation across different token standards. If ERC-404 gains traction and widespread adoption, it's likely that these updates will be made to accommodate the new standard.

## So ERC404 could include a burning mechanic, but they do not need to do so? Is this correct?

Please search bing to provide an overview of the most recent development and forecast for potential developments in the coming months. Is it likely to become formalized as an official token standard, become widely adopted, and become supported by popular infrastructure providers?

Yes, ERC-404 can include a burning mechanic, but it doesn't necessarily need to. ERC-404 allows for both functionalities, depending on how the token is used or the specific implementation of the standard. In some cases, burning a fraction of a token might result in the minting of a new, complete NFT if enough fractions are combined, offering flexibility in how the tokens and linked NFTs are managed ([Ledger](https://www.ledger.com/academy/topics/nfts/erc-404-tokens-what-are-they-and-how-do-they-work)).

As for its current development and future, ERC-404 is an experimental token standard that has captured significant interest due to its ability to merge ERC-20 and ERC-721 functionalities into a single token. This has potential implications for improving liquidity and access in the NFT market. However, ERC-404 is still in the early stages of development and has not yet undergone the formal Ethereum Improvement Proposal (EIP) process necessary to become a recognized standard. The absence of formal auditing and standardization raises concerns about security and reliability ([Bitstamp](https://www.bitstamp.net/learn/blockchain/what-is-the-erc-404-semi-fungible-token-standard/)) ([Kitco](https://www.kitco.com/news/article/2024-02-23/erc-404-experts-weigh-risks-and-rewards-hybrid-nfts)) ([Netcoins](https://netcoins.ca/understanding-the-erc-404-standard-an-ethereum-blockchain-protocol/)).

Regarding adoption, a few early projects like Pandora and DeFrogs have begun experimenting with ERC-404, suggesting a nascent interest among developers and investors. These projects demonstrate the potential of ERC-404 to facilitate innovative uses such as fractional ownership of NFTs and integration into decentralized finance (DeFi) ecosystems ([The Coin Republic](https://www.thecoinrepublic.com/2024/03/25/a-comprehensive-guide-to-erc-404-a-hybrid-token-standard/)). However, the widespread support from major infrastructure providers like Etherscan, OpenSea, and others would require these platforms to undertake significant updates to accommodate the hybrid nature of ERC-404 tokens.

Overall, the success and formalization of ERC-404 as an official Ethereum token standard will likely depend on its ability to address current challenges, including security vulnerabilities and increased transaction costs due to the complexities of its operations. It will also need to pass through the rigorous EIP process, which could lead to broader adoption and support across the Ethereum ecosystem in the future ([KuCoin](https://www.kucoin.com/learn/web3/what-is-erc-404-token-standard)) ([Netcoins](https://netcoins.ca/understanding-the-erc-404-standard-an-ethereum-blockchain-protocol/)).

# Token Standard for Roles and Reputation and Respect

[Research Roles and Reputations System (from Jacob Homanics with ATX DAO)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d.md) 

### Current Status and Technical Implementation of Respect Token

- We’re currently considering if we should migrate the Optimism Fractal Respect token to an ERC 1155 token standard.

- The current implementation of Respect uses a unique combination of ERC721 and ERC20 token standards which allows you to see Respect in both ERC20 (fungible) and ERC 721 (nonfungible) token interfaces.
    - Here is the Github [repository](https://github.com/Optimystics/op-fractal-sc) with the current Optimism Fractal smart contracts.
    - Tadas (a developer on the Optimystics team who created the smart contracts) said that the best and most recent explanation of the contract’s design can be found on [this page](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md), where he wrote about the rationale and technical issues with this token implementation. Tadas wrote this page in February to explain the unique design of the contract and improve how Respect displays in block explorers. At the end of the page he also considered the possibility of migrating the Respect token to an ERC-1155 standard.
    - For more details and rationale, you can see Tadas explain how the smart contract implements interfaces of both ERC20 and NFT standard for the Respect token in this [video](https://youtu.be/dU7Whneo5yI?si=LS-MI-MJxiX_ykwl&t=640). If you’re interested in learning about the philosophy originally behind this design, you could also see this blog [post](https://hive.blog/dao/@sim31/fungibility-out-of-non-fungible-tokens) and video [clip](https://youtu.be/yr1NzIdezG8?si=rNJbTSEuRczlr2_X&t=4653) for more details.

- I’m wondering if implementing Roles and Respect could make it easier for us to migrate to ERC-1155 by adopting an open-source and well supported standard that includes many helpful integrations out of the box.
    - After Tadas wrote the explanations linked below, I did a lot of research wrote the following page: [Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md). This page includes reasons why I think that we should migrate Respect to a ERC1155 token standard and questions about doing so
    

### Questions about Roles and Reputation Token Standards

- Would Roles and Reputations work with the current implementation as well or only if we switched to ERC1155?
    - I do not believe so. R&R relies heavily on using the ERC1155 standard from smart contract implementation to Hats integration. These are not interchangeable with ERC721 components, but possibly ERC20.

- We’re currently using a non-standard implementation of token standards for Respect where Respect can be viewed as both ERC721 and ERC
- We’re thinking about migrating Respect to an ERC1155, as you can see in this task: [Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md)

- Can the ERC1155 implementation accomplish all the same benefits as the current implementation with ERC721 and ERC20?
    - Yes to all of those, except for maintaining the fungibility with the non-fungibility. As the R&R smart contracts stand, they are precisely an ERC1155. This means that they are fungible, there is no tokenId or “serial number” assigned to each newly minted token. The way that I view ERC1155s, are that they are like ERC20s, but with metadata. With the Redeemable and Lifetime tokens, I did not see a need to have non-fungibility features, as they mostly were not really a currency.
    
    ![Untitled](Ask%20and%20Answer%20Questions%20about%20Integrating%20with%20Ro%201d7979738a9f49bdb1deba384035553d/Untitled%202.png)
    
    - As you can see from above, I took inspiration from World of Warcraft’s Reputation system. Looking at Rustbolt Restistance, we can see that the player has 1650 reputation. We can ignore the “Friendly”, “Honored”, “Exalted”, and “3000” pieces of the picture as they do not immediately pertain to R&R (Someone may choose to build those systems on top of R&R. However, R&R simply tracks the total reputation of a user, I.E. the 1650 number). Also, note that there is no non-fungibility. Reputation is simply a tracked total number with respect to an entity.
    - I can imagine if you wished to uphold both fungibility and non-fungibility, then possibly two different collections (smart contracts) need to exist. The traditional ERC1155 (sub for ERC20 if need be), but then an accompanied ERC721. They are not tightly defined, other than by an outside source. The outside source, RespectMinter, may have minting authority for both collections. RespectMinter may also have a Mint() function, which when called, mints tokens from the ERC1155 (or ERC20) collection AND  the ERC721 collection. Maybe. Of course it costs more gas, but I think when we think about these concepts, we can’t be constrained by gas, or we truly can’t achieve the visions we’re looking at.

- Benefits of the current implementation include:
    - Ability to set roles and permissions on a time basis (ie set councilors as top 6 respect earners *over the past 12 weeks*)
        - This can also be flexibly used in other many ways too, such as sending awards or rewards to people who participated in OF Season 2 based upon the Respect earned in that season
    - Ability to see total amount of Respect in addition to visible NFT for each token
    - Fungibility out of non-fungibility, as explained in this toggle and the section about community gardens below
        
        
        You can see Tadas explain how the smart contract implements interfaces of both ERC 20 and NFT standard for the Respect token in this [video](https://youtu.be/dU7Whneo5yI?si=LS-MI-MJxiX_ykwl&t=640). If you’re interested in learning about the philosophy originally behind this design, you could also see this blog [post](https://hive.blog/dao/@sim31/fungibility-out-of-non-fungible-tokens) and video [clip](https://youtu.be/yr1NzIdezG8?si=rNJbTSEuRczlr2_X&t=4653) for more details.
        

- Would it make sense to use ERC 404 instead of ERC1155 or ERC721 and ERC20?

- I watched Jacob’s video about Trash NFT’s and learned about ERC 404. I organized details about ERC 404 in [Consider implementing ERC 404 Token Standard for Respect](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18.md).
- My intuition is that it’s probably better to use a more proven and supported standard like ERC1155 than ERC404, but the fact that ERC 404 uses a similar design to Tadas’ implementation is enticing….
    - This is my intuition as well. ERC404 *tries* to be both. On a certain level, it accomplishes that goal. However, once you look under the hood it has some wonky behavior that results in similar behavior from what is being seen with Respect.
- Does ERC404 token standard work with Roles and Reputations instead of ERC1155?
    - No. Not without extra development work in place. R&R specifically and strictly only supports ERC1155 at the moment.

### To Do

- [x]  Ask Jacob to share thoughts about the current implementation of Respect as ERC721 and ERC20 compared to ERC1155 or ERC 404

- [ ]  Consider asking Tadas about this and sharing this page or section with Tadas
    
    

## Pandora Build

![Untitled](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18/Untitled.png)

[pandora.build](http://pandora.build) 

![Untitled](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18/Untitled%201.png)

![Untitled](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18/Untitled%202.png)

[Pandora Labs](https://github.com/Pandora-Labs-Org)

![Untitled](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18/Untitled%203.png)

[https://github.com/Pandora-Labs-Org/erc404?tab=readme-ov-file](https://github.com/Pandora-Labs-Org/erc404?tab=readme-ov-file)

![Untitled](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18/Untitled%204.png)

[Pandora Labs](https://github.com/Pandora-Labs-Org)

[ERC-404 and Why It Matters on Bankless](https://www.bankless.com/erc-404-pandora)

![[https://twitter.com/Pandora_ERC404](https://twitter.com/Pandora_ERC404)](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18/Untitled%205.png)

[https://twitter.com/Pandora_ERC404](https://twitter.com/Pandora_ERC404)

![[https://twitter.com/Pandora_ERC404](https://twitter.com/Pandora_ERC404)](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18/Untitled%206.png)

[https://twitter.com/Pandora_ERC404](https://twitter.com/Pandora_ERC404)

[https://twitter.com/Pandora_ERC404/status/1776789941072367769](https://twitter.com/Pandora_ERC404/status/1776789941072367769)

[https://twitter.com/Pandora_ERC404/status/1777920395753951553](https://twitter.com/Pandora_ERC404/status/1777920395753951553)

[https://twitter.com/Pandora_ERC404/status/1777920395753951553](https://twitter.com/Pandora_ERC404/status/1777920395753951553)

[https://twitter.com/Pandora_ERC404/status/1777920395753951553](https://twitter.com/Pandora_ERC404/status/1777920395753951553)

[https://youtu.be/Ced555YbK2k?si=UGtlSmhWqN2-5l4p](https://youtu.be/Ced555YbK2k?si=UGtlSmhWqN2-5l4p)

**Mar 27, 2024, Trash NFTs: J**acob Homanics demonstrates an interesting implementation of ERC 404, a new token standard that combines mechanics of ERC20 and ERC721 

[https://www.youtube.com/watch?v=zqnmjRHjwY8&pp=ygUGZXJjNDA0](https://www.youtube.com/watch?v=zqnmjRHjwY8&pp=ygUGZXJjNDA0)

[https://www.youtube.com/watch?v=SiYqJ6QF39U&pp=ygUGZXJjNDA0](https://www.youtube.com/watch?v=SiYqJ6QF39U&pp=ygUGZXJjNDA0)

Watch this to learn about ERC 404 with trash nft , is this better for us than erc1155 or the current configuration? Does it work with roles and reputations? 

[https://youtube.com/watch?v=Ced555YbK2k&si=fjXACe2yEMyyWeVY](https://youtube.com/watch?v=Ced555YbK2k&si=fjXACe2yEMyyWeVY)