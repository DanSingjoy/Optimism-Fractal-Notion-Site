# In v2, Consider recording, encoding and livestreaming integrations with Livepeer

Project: Build Respect Game app (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: Not started
Summary: No content
Sub-task: Prepare for meeting with Alex from Livepeer (Prepare%20for%20meeting%20with%20Alex%20from%20Livepeer%202e70af1cf6cd44b6b4570b25b7c31d25.md), Respond to Alex from Livepeer about Matthias app (Respond%20to%20Alex%20from%20Livepeer%20about%20Matthias%20app%20f023bfae6cb544e3b64db7f19b9c26ba.md), Review and organize notes about Livepeer pricing and integrations (Review%20and%20organize%20notes%20about%20Livepeer%20pricing%20a%20eba5068451164476ade4a094a235202f.md), Respond to Eric Tang from Livepeer about Optimism Fractal (Respond%20to%20Eric%20Tang%20from%20Livepeer%20about%20Optimism%20%205a5db61774784900955ef085bab56fdc.md)
Created time: March 12, 2024 5:41 PM
Last edited time: April 24, 2024 4:40 AM
Sub-tasks: Prepare for meeting with Alex from Livepeer (Prepare%20for%20meeting%20with%20Alex%20from%20Livepeer%202e70af1cf6cd44b6b4570b25b7c31d25.md), Respond to Alex from Livepeer about Matthias app (Respond%20to%20Alex%20from%20Livepeer%20about%20Matthias%20app%20f023bfae6cb544e3b64db7f19b9c26ba.md), Review and organize notes about Livepeer pricing and integrations (Review%20and%20organize%20notes%20about%20Livepeer%20pricing%20a%20eba5068451164476ade4a094a235202f.md), Respond to Eric Tang from Livepeer about Optimism Fractal (Respond%20to%20Eric%20Tang%20from%20Livepeer%20about%20Optimism%20%205a5db61774784900955ef085bab56fdc.md)
Created by: Dan Singjoy

## Description

- 

![Untitled](In%20v2,%20Consider%20recording,%20encoding%20and%20livestream%207f9e5aff39d94b6c9fee1ca9f0999e32/Untitled.png)

Ok great, thanks! I saved the link to the show and am looking forward to listening. I’ve been very busy coordinating development for the other parts of our app and haven’t gotten a chance to sign up yet, but I really appreciate the offer and will keep it in mind. Hopefully I’ll be able to try it out and provide some initial estimates this week. I’ll let you know when I’m ready to take the next steps!

[](https://twitter.com/i/spaces/1PlJQDAvyaZGE)

[https://www.youtube.com/watch?v=Y0bWTVOVAKo&t=1s](https://www.youtube.com/watch?v=Y0bWTVOVAKo&t=1s)