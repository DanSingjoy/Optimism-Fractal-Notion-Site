# Announce Developers Hub and share Superchain Console in Optimism Fractal Development Chat

Due: May 8, 2024
Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md)
Status: Not started
Summary: Announce the introduction of the Optimism Fractal Developers Hub, which provides resources, projects, and tasks for developers working with Optimism Fractal. The hub includes filters to show relevant information and is a collaborative workspace. Builders are encouraged to contribute and earn funding from the Optimism Collective. Curate resources and share the Superchain Console in the development chat.
Parent-task: Announce Optimism Fractal Development Hub and share resources in the Development Channel (Announce%20Optimism%20Fractal%20Development%20Hub%20and%20shar%20bf2c80fdf56c4c769771e1ad62928639.md)
Created time: April 16, 2024 6:22 AM
Last edited time: May 1, 2024 10:57 AM
Parent task: Announce Optimism Fractal Development Hub and share resources in the Development Channel (Announce%20Optimism%20Fractal%20Development%20Hub%20and%20shar%20bf2c80fdf56c4c769771e1ad62928639.md)
Created by: Dan Singjoy

## Announce Developers Hub and share Superchain Console in Optimism Fractal Development Chat

- [ ]  Curate resources for Optimism Developers like the superchain console in the [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)
- [ ]  post in the dev chat
- [ ]  curate this announcement post in the [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)
- [ ]  curate this announcement post in the project [Build Optimism Fractal Development Hub and Create Educational Resources for Builders](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md)

Hey all, I’d like to introduce you to the Optimism Fractal [Developers Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)!

There’s been a lot of interest in building with Optimism Fractal and the Respect Game lately, which I greatly appreciate and is super exciting. To help organize our collective development and make it easier for builders to contribute, I created a new page in our notion site that’s dedicated to providing resources, projects, and tasks related to the technical development of Optimism Fractal.

This developer hub pulls data from the main Optimism Fractal notion site, but it includes filters to only show information that is most relevant for developers. I also updated a bunch of projects here over the past week and added tags to show the type of work for each project, so it’s now easier to filter or search to find development projects that interest you. Feel free to edit these notion pages as you see fit and keep in mind that this is an ongoing workspace that will evolve over time.

With the next four rounds of RetroFunding announced to happen this year and the first round dedicated to rewarding Onchain Builders starting in May, I’d love to help builders create a positive impact and earn funding from the Optimism Collective by helping develop Optimism Fractal. There is lots of ‘low hanging fruit’ kinds of relatively quick developments that could greatly benefit Optimism Fractal and a huge design space of profoundly helpful tools that will need many talented builders in the coming years… and we’d really appreciate your help!

I hope you enjoy exploring the new [development hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md). Please feel free to reach out with any questions and share any related thoughts in discord, notion, or at our weekly events :)

Below are a few exciting pieces of news related to development in the Superchain. I’ll follow up with more details in this week’s event and in the Optimism Fractal [notion page](../../Optimism%20Fractal%20e5110efeeb9e49a397ab20a9d9c6b571.md) soon.

## Curate resources for Optimism Developers like the superchain console in the [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)

- [ ]  Curate resources for Optimism Developers like the superchain console in the [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)
- [ ]  share developers console and retrofunding in development chat

![Untitled](Announce%20Developers%20Hub%20and%20share%20Superchain%20Conso%20ee7991abe3624708833839ffcc75a085/Untitled.png)

[https://vxtwitter.com/Optimism/status/1771197457793466761](https://vxtwitter.com/Optimism/status/1771197457793466761)

![Untitled](Announce%20Developers%20Hub%20and%20share%20Superchain%20Conso%20ee7991abe3624708833839ffcc75a085/Untitled%201.png)

[https://warpcast.com/optimism/0xf9cf14f7](https://warpcast.com/optimism/0xf9cf14f7)

![Untitled](Announce%20Developers%20Hub%20and%20share%20Superchain%20Conso%20ee7991abe3624708833839ffcc75a085/Untitled%202.png)

[https://vxtwitter.com/Optimism/status/1772664316996755566](https://twitter.com/Optimism/status/1772664316996755566)

[https://www.youtube.com/watch?v=3JWUNXdAkmM](https://www.youtube.com/watch?v=3JWUNXdAkmM)

[https://www.youtube.com/watch?v=IrMiOlqmnbU](https://www.youtube.com/watch?v=IrMiOlqmnbU)

[https://www.youtube.com/watch?v=0xz_gsGjlb8](https://www.youtube.com/watch?v=0xz_gsGjlb8)

- [x]  add link to the Superchain freebie with third web here as well

[https://x.com/amandatylerj/status/1771216711783436774?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/amandatylerj/status/1771216711783436774?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ)