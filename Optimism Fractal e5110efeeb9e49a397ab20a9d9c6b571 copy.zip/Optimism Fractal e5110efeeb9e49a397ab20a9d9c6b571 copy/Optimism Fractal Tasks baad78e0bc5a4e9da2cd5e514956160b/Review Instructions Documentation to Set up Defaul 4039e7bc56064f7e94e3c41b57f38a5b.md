# Review Instructions/Documentation to Set up Default Database Templates for Each Event in Notion

Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Done
Task Summary: This task aims to review the instructions and documentation for setting up default database templates for each event in Notion. The page provides information about the creator, status, and creation/editing times. It also includes links to relevant resources and a free course for beginners to learn about Notion databases.
Summary: This document provides instructions and documentation on setting up default database templates for each event in Notion. It includes links to the Notion Help Center and a free course for beginners on Notion databases.
Created time: June 27, 2023 9:31 AM
Last edited time: June 18, 2024 12:05 PM
Created by: Dan Singjoy

[https://www.youtube.com/watch?v=gMFaeZGGxsk](https://www.youtube.com/watch?v=gMFaeZGGxsk)

![Untitled](Review%20Instructions%20Documentation%20to%20Set%20up%20Defaul%204039e7bc56064f7e94e3c41b57f38a5b/Untitled.png)

[Database templates – Notion Help Center](https://www.notion.so/help/database-templates)

💾 LEARN NOTION DATABASES (Free course for beginners):

[ • Notion Databases ...](https://www.youtube.com/watch?v=mAJOpO73d8Y&t=0s)

![https://www.gstatic.com/youtube/img/watch/yt_favicon.png](https://www.gstatic.com/youtube/img/watch/yt_favicon.png)

![Untitled](Review%20Instructions%20Documentation%20to%20Set%20up%20Defaul%204039e7bc56064f7e94e3c41b57f38a5b/Untitled%201.png)

![Untitled](Review%20Instructions%20Documentation%20to%20Set%20up%20Defaul%204039e7bc56064f7e94e3c41b57f38a5b/Untitled%202.png)