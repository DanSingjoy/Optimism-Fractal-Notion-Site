# Review and Organize Ideas for Optimism Fractal Respect Networks and Mutual Respect Networks

Due: May 3, 2024
Project: Build Respect Game app (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md), Build app component to make it easy for participants to give personal respect at the end of each game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md), Create a referral or recruitment system for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20a%20referral%20or%20recruitment%20system%20for%20Optimi%20438c19ca93fe49a69e0dd77a330708cf.md)
Status: Not started
Task Summary: This task aims to review and organize ideas for Optimism Fractal Respect Networks and Mutual Respect Networks. It involves exploring concepts such as Respect Networks, Personal Respect, and a referral system to enhance community engagement and incentivization through a digital Respect Game app. The goal is to foster a cycle of positive reinforcement and mutual respect within the community, while also encouraging community growth and participation through the distribution of respect.
Summary: This task aims to review and organize ideas for Optimism Fractal Respect Networks and Mutual Respect Networks. The concepts of Respect Networks, Personal Respect, and a referral system are explored, with the goal of fostering positive reinforcement, mutual respect, and community growth through a digital Respect Game app. The app allows players to award personal respect, tied to the amount they have earned, and a referral system incentivizes community engagement. The distribution of respect becomes both a personal and communal activity.
Parent-task: Organize Plans for Personal Respect, Distributing after Respect Games, Respect Networks, and Synergies with Optimism Fractal (Organize%20Plans%20for%20Personal%20Respect,%20Distributing%20%20404d4123e7974215968180a9f01a8945.md)
Created time: May 6, 2024 11:19 AM
Last edited time: May 6, 2024 12:31 PM
Created by: Dan Singjoy

## Introduction

This task aims to review and organize ideas for Optimism Fractal Respect Networks and Mutual Respect Networks. It involves exploring concepts such as Respect Networks, Personal Respect, and a referral system to enhance community engagement and incentivization through the Respect Game app. The goal is to foster a cycle of positive reinforcement and mutual respect within the community, while also encouraging community growth and participation through the distribution of respect.

This task aims to review and organize ideas for Optimism Fractal Respect Networks and Mutual Respect Networks. It involves exploring concepts such as Respect Networks, Personal Respect, and a referral system to enhance community engagement and incentivization through a digital Respect Game app. The goal is to foster a cycle of positive reinforcement and mutual respect within the community, while also encouraging community growth and participation through the distribution of respect.

**Table of Contents**

## Overview

Respect Networks are a novel idea for ecosystems where participants can recognize each other's contributions with Respect to measure appreciation for collaborative efforts in a more expansive way across many communities and organizations. Mutual Respect Networks can include both Personal Respect, Community Respect, and any other kind of auxiliary Respect tokens that may be helpful to recognize appreciation for others. 

I think these kinds of Respect Networks can work in a somewhat similar way to Community Gardens, but the Respect Network would be based upon the lifetime Respect token and not on a redeemable token. It also doesn’t include the same incentives and rationale, but it could be coupled with a Respect Network of Community Gardens where communities recognize both the lifetime and redeemable tokens of other communities. You can see details about this idea here. You can see ideas about this idea [here](Review%20and%20Organize%20Ideas%20for%20Optimism%20Fractal%20Res%20cf8a8d3750ce4968a6cdeef1eed82e7d.md).

## To Do

- [ ]  Consider if/how this should be organized within it’s parent task:

See [Organize Plans for Personal Respect, Distributing after Respect Games, Respect Networks, and Synergies with Optimism Fractal](Organize%20Plans%20for%20Personal%20Respect,%20Distributing%20%20404d4123e7974215968180a9f01a8945.md) for related ideas about how Personal Respect could be used along with Community Respect to form Respect Networks

# Inspiration and Original Ideas

## Review Ideas about Respect Network, Community Member Hosted Respect Games, and Optimism Fractal Referral System

[1:01:27](https://youtu.be/Jdm9GKzFoiU?si=9uij7y9tekmqsaff&t=3679) Zaal comments that he’s trying to implement something like respect game on weekly zooms, talks about creating new consensus games, interested in this or other ways to play this with musicians. 

Last week @Zaal said that he’d like to discuss a topic at this week’s event related to creating new consensus games, giving new forms of awards, and implementing the Respect Game with musicians. Here is the video [clip](https://youtu.be/Jdm9GKzFoiU?si=9uij7y9tekmqsaff&t=3679). 

- I can see potential for Optimism Fractal to award Respect or some other token for people hosting their own respect games

- Similar to our prior discussions about referral systems, but also for people who play the respect game with their friends, community, or organization. I’m curious to hear your thoughts about this and explore how such a system could be designed.

## Idea for Referral System with Network of Respect

I had idea about how a hat could be given to people who have earned enough respect, then there could be a pool of respect each week to people who host respect games . 

Maybe a certain limit of how many games you can host or people you can invite per week. Maybe this somehow synergize with Optimystics respect game too and gives more incentive for us to reach consensus. It could synergize very nicely with the release of the new app and basically respect people who are playing it with their communities and spreading it. 

There could also be some fractal respecting happening, for example If zaal host a game in zao with attabotty then attabotty hosts game with another community then maybe it makes sense for zaal to get a portion of recruitment respect that attabotty earns from hosting a game with his other community

Maybe a certain limit of how many games you can host or people you can invite per week. Maybe this somehow synergize with Optimystics respect game too and gives more incentive for us to reach consensus. It could synergize very nicely with the release of the new app and basically respect people who are playing it with their communities and spreading it. 

There could also be some fractal respecting happening, for example If zaal host a game in zao with attabotty then attabotty hosts game with another community then maybe it makes sense for zaal to get a portion of recruitment respect that attabotty earns from hosting a game with his other community

I have idea about how a hat could be given to people who have earned enough respect, then there could be a pool of respect each week to people who host respect games. 

## Summary

The concepts of Respect Networks, Personal Respect, and a referral system center around enhancing community engagement and incentivization through a digital Respect Game app. This app would allow players to award personal respect to others, with the amount of respect a person can give tied directly to the amount they have earned. This fosters a cycle of positive reinforcement and mutual respect within the community. Additionally, a referral system could be implemented to further encourage community growth and engagement by rewarding those who host and participate in games. This system would not only encourage participation but also strengthen the bonds within the community by making the distribution of respect both a personal and communal activity.

## Create a blog post about Optimism Fractal Respect Networks, Personal Respect, and a referral system where fractal communities can respect other people and communities that play the respect game

### **Unveiling the Optimism Fractal Respect Networks: Fostering Community Through Personal Respect and Referral Systems**

In the evolving landscape of decentralized communities, the Optimism Fractal stands out with its innovative approach to building stronger bonds through the Respect Networks, Personal Respect, and a dynamic referral system. These mechanisms are not just tools; they are the foundation for cultivating a vibrant ecosystem where mutual respect and community engagement are paramount.

### **Optimism Fractal Respect Networks**

The Optimism Fractal Respect Networks introduce a structured way for members to acknowledge and reward each other's contributions within the community. By implementing a digital Respect Game app, participants can easily express their appreciation for fellow players by awarding "Personal Respect." This unique approach ensures that the value of respect within the network is quantifiable and significant, fostering a culture of acknowledgment and appreciation.

### **Personal Respect: Empowering Individuals**

At the heart of this system lies the concept of Personal Respect, where participants have the autonomy to give respect directly to others. The amount of respect one can award is directly proportional to the respect they have earned, creating a balanced and equitable distribution. This feature encourages individuals to actively contribute and engage with the community, knowing that their efforts will be reciprocally recognized and rewarded.

### **A Referral System that Enhances Community Growth**

The referral system is ingeniously designed to promote community growth and active participation. Members who host respect games can invite new players, expanding the community's reach and influence. As these games are hosted and attended, both hosts and participants earn respect points, which can further be used within the network to unlock new opportunities and rewards.

This system not only incentivizes members to bring in new participants but also ensures that those who contribute to the community's expansion are adequately rewarded. It creates a cycle of growth and reinforcement, where each new member adds value and sustains the network's vibrancy.

### **The Impact of Respect Networks on Community Dynamics**

The implementation of Respect Networks, coupled with Personal Respect and the referral system, revolutionizes how communities operate and interact. These mechanisms provide a concrete way to measure and reward participation and influence within the community. By aligning personal incentives with community goals, the Optimism Fractal ensures that every contribution is valued and that every member feels integral to the community's success.

In conclusion, the Optimism Fractal's approach to building community through respect networks offers a blueprint for other decentralized networks aiming to foster genuine engagement and sustainable growth. Through personal respect and a strategic referral system, the Optimism Fractal is not just creating a game; it's nurturing a community where everyone is valued and empowered to contribute to the collective vision.

# Implementation

## Roles and Reputations for Personal Respect Networks

Roles and Reputations may help enable this kind of decentralized graph of Respect and Trust by providing infrastructure for entities to trust each other’s opinions about who to Respect. 

*Explain how Roles and Reputations can benefit Optimism Fractal Respect Networks, Personal Respect, and a referral system where fractal communities can respect other people and communities that play the respect game*

Roles and Reputations, as a framework for managing and recognizing the contributions within a community, can significantly enhance the functionality and effectiveness of the Optimism Fractal Respect Networks, Personal Respect, and referral systems. Here’s how:

### **1. Structured Role Management**

Roles and Reputations can help define clear roles within the Optimism Fractal ecosystem. Each role can have specific responsibilities and permissions associated with it. For example, roles such as Game Hosts, Respect Validators, or Community Moderators can be created. Each of these roles would have different levels of authority and responsibility in organizing and validating respect games, ensuring that the rules are followed and that the distribution of respect is fair.

### **2. Dynamic Reputation Scoring**

In a system where personal respect and referrals play a crucial role, a dynamic reputation scoring mechanism can provide a transparent and trustable way to measure the value each participant brings to the community. Reputation scores can be influenced by various factors such as the quantity and quality of respect received, the successful hosting of respect games, or the active participation in community governance. This would encourage members to contribute positively to the community, knowing that their efforts increase their reputation, which in turn could unlock new privileges or roles.

### **3. Enhancing the Referral System**

Roles and Reputations can add depth to the referral system by allowing users to earn reputational scores or achieve roles based on their success in expanding the community. For instance, members could earn the role of "Community Ambassador" by successfully inviting new players who actively participate in games. These roles could come with benefits like increased voting power in community decisions or higher caps on the respect they can distribute, incentivizing members to not only invite others but ensure they are engaged and valued members of the community.

### **4. Trust and Accountability**

With a structured role and reputation system, trust and accountability become integral to the community. Members with higher reputations and significant roles would likely be more trusted, making their endorsements or respect distributions more impactful. This could also help in moderating the community, as those with higher stakes and reputations are less likely to engage in actions that could harm the community’s trust or integrity.

### **5. Rewarding Consistency and Loyalty**

Long-term contributions and consistent engagement can be systematically recognized through reputational improvements or role upgrades. This not only rewards loyalty but also encourages ongoing participation, which is crucial for the sustained growth and health of the community.

### **6. Integration with Existing Systems**

Roles and Reputations can be seamlessly integrated with existing blockchain and smart contract technologies to automate many of these processes. For example, smart contracts could automatically adjust reputation scores based on community-defined criteria or trigger role assignments without needing manual oversight.

By integrating Roles and Reputations into the Optimism Fractal Respect Networks and referral systems, the community can achieve a more organized, trustworthy, and engaging environment. This integration fosters a culture where contributions are visibly appreciated and rewarded, enhancing overall participation and growth within the community.

## Hats Protocol for Respect Networks

Hats Protocol can significantly benefit the Optimism Fractal Respect Networks, Personal Respect, and a referral system by providing a robust infrastructure for decentralized coordination and role management. Here's how:

1. **Role Management and Distribution**: Hats Protocol allows the creation of roles (hats), which are tokenized responsibilities, permissions, and incentives within an organizational graph. This structure can be integrated into the Optimism Fractal to manage personal respect and roles within the community efficiently. Each role can have specific permissions tied to actions in the Respect Networks, such as the ability to initiate or validate respect transactions, or manage referral system dynamics.

2. **Decentralized Coordination**: By leveraging Hats Protocol, the Optimism Fractal can enhance its referral system by allowing the creation of custom roles for members who bring new participants into the network or who significantly contribute to the network’s vibrancy and health. These roles can carry additional benefits, enhancing incentive alignment within the community.

3. **Automation and Accountability**: Hats Protocol supports automating the granting and revoking of roles based on specific criteria or outcomes. This feature can be used to automate aspects of the Personal Respect system, where members' roles and the respect they can earn or give can be adjusted dynamically based on their contributions and activities within the network.

4. **Secure and Transparent Governance**: With the accountability relationships enabled by Hats Protocol, Optimism Fractal can implement a transparent governance model for its Respect Networks. This ensures that roles and permissions are monitored and managed fairly, with the possibility of revoking or modifying roles if they are misused, thus maintaining integrity within the community.

5. **Enhanced Interoperability and Integration**: Hats Protocol's design as a credibly neutral infrastructure means it can seamlessly integrate with other tools and platforms used by the Optimism Fractal. This interoperability is crucial for expanding the Respect Networks across different ecosystems and platforms, ensuring that the system remains flexible and adaptable.

In summary, Hats Protocol can provide the structural and governance backbone for Optimism Fractal’s Respect Networks, enhancing the way roles are managed, respect is distributed, and referrals are incentivized. This integration would not only streamline operations but also reinforce the security and efficacy of the community’s efforts in fostering a respectful and collaborative environment.

## Technical Outline

Might be too specific, see toggle

- 
    
    Create a technical outline that can be used by developers to understand the specifications and create Optimism Fractal Respect Networks, Personal Respect, and a referral system where fractal communities can respect other people and communities that play the respect game
    
    ChatGPT
    
    Here's a technical outline designed to guide developers in creating the Optimism Fractal Respect Networks, Personal Respect, and a referral system for fractal communities. This outline includes the architecture, technologies, and key components necessary for development.
    
    ### **Technical Outline for Optimism Fractal Respect Networks**
    
    ### **1. **System**
    
    **Overview**
    
    - **Purpose**: Build a decentralized application (dApp) to facilitate Respect Networks within the Optimism Fractal community, enabling personal respect allocation and a referral system.
    - **Functionality**:
        - Users can give and receive respect points.
        - Implement a referral system to reward users for expanding the community.
        - Track and visualize respect and referrals within a network graph.
    
    ### **2. Architecture**
    
    - **Frontend**:
        - **Framework**: ReactJS for dynamic user interfaces.
        - **State Management**: Redux for managing global state related to user respect levels, referrals, and roles.
        - **Real-Time Interaction**: Socket.io for real-time updates of respect scores and network changes.
    - **Backend**:
        - **Node.js**: Serve the backend application.
        - **Express**: Handle routing.
        - **Smart Contracts**: Solidity for Ethereum-based smart contracts on the Optimism layer.
        - **Database**: MongoDB or a similar NoSQL database to store user data, roles, reputation scores, and referral links.
    - **Blockchain Integration**:
        - **Web3.js** or **Ethers.js**: Interface with Ethereum blockchain to manage smart contracts.
        - **Smart Contracts**: Implement contracts for handling respect transactions, role assignments, and referral validations.
        - **Token Standard**: ERC-1155 for issuing and managing respect tokens (fungible for respect points, non-fungible for unique recognitions).
    
    ### **3. Core Components**
    
    - **User Authentication**:
        - Integrate with MetaMask or similar wallets for blockchain-based authentication.
        - Handle user sessions and data associated with blockchain addresses.
    - **Respect Management**:
        - **Smart Contract Functions**:
            - **`giveRespect(receiver, amount)`**: Allocate respect points to other users.
            - **`redeemRespect(amount)`**: Use respect points for benefits within the community.
        - **Token Economics**: Define how respect points are generated, capped, or burned.
    - **Referral System**:
        - **Smart Contract Functions**:
            - **`createReferralLink()`**: Generate a unique referral link for each user.
            - **`validateReferral(referralId)`**: Validate referrals when a new user signs up using a referral link.
        - **Referral Tracking**: Monitor and attribute respect earnings from referrals, manage referral limits.
    - **Roles and Reputations**:
        - **Smart Contract Functions**:
            - **`assignRole(userId, role)`**: Assign roles based on reputation scores or admin selection.
            - **`updateReputation(userId, change)`**: Modify reputation scores based on community feedback and interactions.
        - **Role-Based Access Control (RBAC)**: Define permissions and visibility based on user roles.
    - **Networking and Visualization**:
        - Implement graphical representations of the respect networks using libraries like D3.js to visualize how respect flows between community members.
        - Include features to filter, search, and analyze the network graph dynamically.
    
    ### **4. Security Considerations**
    
    - **Smart Contract Security**: Conduct thorough audits of the smart contracts to prevent vulnerabilities related to respect transactions and role management.
    - **Sybil Attack Prevention**: Implement mechanisms to detect and mitigate fake accounts or manipulative behaviors in respect allocation and referrals.
    
    ### **5. Testing and Deployment**
    
    - **Unit Tests**: Write comprehensive unit tests for both smart contracts and application logic using frameworks like Mocha and Chai.
    - **Integration Tests**: Ensure components interact correctly using test environments like Ganache for blockchain simulations.
    - **Deployment**: Use platforms like Infura for deploying the application on the Optimism network.
    
    ### **6. Documentation and Community Feedback**
    
    - Provide detailed API documentation and developer guides.
    - Set up a feedback loop with the community to refine and enhance the features based on actual user experiences.
    
    This technical outline serves as a foundation for developers to understand, contribute to, and implement the functionalities of Optimism Fractal Respect Networks, ensuring that the system is robust, secure, and effectively meets the needs of the community.
    

## Specifications

Provide specifications for Optimism Fractal Respect Networks, Personal Respect, and a referral system where fractal communities can respect other people and communities that play the respect game. 

Don't make it too development centric as far as the implementation technologies but keep it more high level overview where it explains the dynamics of how it works. Also include a part about how this can be combined with community gardens and the ideas of redeemable respect as well

### **Specifications for Optimism Fractal Respect Networks, Personal Respect, and a Referral System**

### **Overview**

The Optimism Fractal Respect Networks, Personal Respect, and Referral System aim to foster community growth, enhance engagement, and incentivize collaboration within and between fractal communities. This system will integrate concepts from community gardens and implement mechanisms for earning and redeeming respect in a way that encourages positive community interactions and growth.

### **Key Components**

1. **Respect Networks**
    - **Purpose**: Enable members of the Optimism Fractal and other associated fractal communities to acknowledge and reward each other’s contributions.
    - **Mechanics**: Members earn respect points by participating in community activities, contributing to discussions, or providing valuable content.
    - **Visibility**: Respect points are publicly visible, allowing members to gain recognition within the community.
2. **Personal Respect**
    - **Definition**: Personal respect points are a direct measure of a community member's contributions and influence within the community.
    - **Allocation**: Each member has the ability to allocate a limited amount of respect to other members based on their interactions or perceived value of contributions.
    - **Usage**: Respect can be used to influence community decisions, access special privileges, or as a criterion for roles and responsibilities within the community.
3. **Referral System**
    - **Objective**: Expand the community by incentivizing members to invite new participants.
    - **Functionality**: Members generate personalized referral links to invite others. Successful referrals that result in active participation earn the referrer additional respect points.
    - **Tracking**: The system will keep detailed logs of referrals and rewards, ensuring transparency and fairness in the distribution of respect points.

### **Integration with Community Gardens and Redeemable Respect**

1. **Community Gardens Concept**
    - **Integration**: Respect points act as seeds within community gardens, where planting (allocating respect to others) fosters growth and development of the community ecosystem.
    - **Growth Tracking**: Members can track the growth of their planted seeds (allocated respect points) as the recipients of their respect grow and contribute to the community.
2. **Redeemable Respect**
    - **Redemption Options**: Members can redeem their respect for various benefits, such as access to exclusive content, participation in special events, or voting power in significant community decisions.
    - **Dynamic Value**: The value of respect points in terms of redemption options can vary based on community goals, available resources, and member needs.

### **System Dynamics**

- **Respect Flow**: Members earn respect by contributing positively to the community. They can allocate this respect to others, thereby influencing the community structure and dynamics.
- **Earning and Spending Cycles**: The system encourages a continuous cycle of earning and spending respect, promoting ongoing engagement and contribution.
- **Community Feedback and Adjustment**: Regular assessments and feedback from community members help adjust the mechanics of respect allocation and redemption to ensure the system remains fair and effective.

### **Benefits to the Community**

- **Enhanced Engagement**: By tying respect to valuable community contributions, members are motivated to engage more deeply and meaningfully.
- **Incentivized Growth**: The referral system expands the community while maintaining a quality of engagement, as members are likely to invite individuals who will contribute positively.
- **Community Empowerment**: Members feel more connected and empowered as they see the tangible impacts of their contributions and respect in the community.

### **Conclusion**

The integration of Optimism Fractal Respect Networks with the principles of community gardens and the functionality of redeemable respect creates a robust framework for community interaction and growth. This system not only incentivizes individual participation but also fosters a collaborative and supportive environment where collective goals can be achieved more effectively.

### **Definition of Respect Networks**

Respect Networks are community-driven frameworks where members allocate and receive recognition—termed "respect"—based on their contributions, collaborations, or influence within the group. These networks use a decentralized approach to validate and reward individual efforts, facilitating a transparent and equitable distribution of value among participants.

### **Blog Post: Exploring the Power of Respect Networks**

In an age where digital collaboration and community engagement are more crucial than ever, Respect Networks emerge as a transformative solution to recognize and reward contributions in various communities and organizations. These networks operate on the principle of decentralized recognition, where every member has the power to allocate "respect" to fellow participants, thereby influencing the community dynamics and decision-making processes directly.

At the heart of Respect Networks lies the idea of leveraging collective intelligence through a democratized respect system. Members earn respect by contributing positively—be it through sharing knowledge, participating in projects, or supporting others. This respect can then be used to shape the community, from influencing strategic decisions to accessing exclusive opportunities, creating a dynamic environment where contributions translate directly to influence and rewards.

The true innovation of Respect Networks, however, isn't just in rewarding participation; it's in how they cultivate a culture of mutual appreciation and accountability. In these networks, respect becomes a currency of trust and value, driving members to engage more deeply and meaningfully with the community. It shifts the focus from top-down authority structures to a more fluid, organic form of governance where every member's voice can be heard and valued.

Furthermore, Respect Networks are adaptable to a vast array of contexts—from corporate environments and educational institutions to decentralized autonomous organizations (DAOs) and beyond. In each setting, they foster a sense of ownership and belonging among participants, encouraging a proactive approach to collaboration and innovation.

As we navigate a world where digital interactions become increasingly predominant, the implementation of Respect Networks could revolutionize not just how we work together, but also how we recognize and value each individual's contributions. They hold the potential not only to enhance productivity and engagement but also to weave stronger, more cohesive community fabrics where everyone feels valued and empowered.

# Personal Respect

## Respect Game App where Each Players Can Give Each other Their Respect

- I’m thinking about building the Respect Game app where all players can easily give each other respect and it seems that a single token standard (ERC 1155) would be easier for many people to use than 2 token standards…
    - I’m not sure about this, but we could embed code for [Manifold.xyz](http://Manifold.xyz) or something else that already uses ERC 1155
        - I think this could also make the manual or automatic token distribution easier?
    - I want to make it as easy as possible for people to give each other respect right after playing and optionally provide a picture
        - I think this has a lot of similarities with what we discussed in [EdenFractal.com/61](http://EdenFractal.com/61)

- You can see the designs for this below
    - Full Figma design in progress: https://www.figma.com/file/3JuoT7WfxvPDj2Esom9hJP/Respect-Game-xyz?type=design&node-id=0-1&mode=design&t=kaPBpI7XGw6TAxXt-0
    - [ ]  share ideas and UI design for game where everyone can give respect

![Untitled](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602/Untitled.png)

- What would be the functionality for this feature?
    - Contract ownership…
    - [ ]  Add timestamps from April 5th meeting and share with optimystics chat, tagging tadas

- Each player gets the option to easily share their Respect with everyone who they play with

- Each player can quickly add a picture and text to their Respect if they want, which could be accomplished by using something like [Manifold.xyz](http://Manifold.xyz) widget for creating ERC 1155 (if such code is open source)
    - In the future it could also have in app art creation tool for quickly adding images, gifs, and stylized text

- So for example if you play with Mary, Todd, Joe, Kelly, and Anne… and you get level 5… then you can get 34 Respect for each of them….

## Aligning Personal Respect with OPF

- consider: the respect you get is equal to the respect you can give
    - ie u earn 55 opf, then you can give 55 opf
    - of course opf council could remove this if its being abused or misused

- the players can give respect in any amount
    - one option is to give their own respect like in shared consensus algorithm but no algorithm- just give according to their ranks
    - by default it should be the game consensus prob to make it simple, but its adjustable to different options or custom numbers