# Respond to Hodlon about Solutions to Improve Registration Poll process

Assignee: Dan Singjoy
Project: Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md)
Status: Done
Summary: The document discusses solutions to improve the registration poll process. It suggests automating the process and exploring existing solutions like ChatGPT and Snapshot. It also mentions the need for automatic Discord posts when a new poll is created. Temporary solutions include asking someone to create the poll during the event and setting up a reminder or assignment system. The document also mentions the Fractal Framework and potential collaboration opportunities with Shutter DAO. Finally, it reminds readers to register for the next council meeting.
Sub-task: Read Teams All The Way Down Article from Hodlon and Research Fractal app from Shutter (Read%20Teams%20All%20The%20Way%20Down%20Article%20from%20Hodlon%20an%20e7b6a93c42d64fb5a6ff9f9f50fd3f14.md)
Created time: April 6, 2024 12:46 PM
Last edited time: April 6, 2024 12:51 PM
Sub-tasks: Read Teams All The Way Down Article from Hodlon and Research Fractal app from Shutter (Read%20Teams%20All%20The%20Way%20Down%20Article%20from%20Hodlon%20an%20e7b6a93c42d64fb5a6ff9f9f50fd3f14.md)
Parent task: Improve Process for Creating Registration Polls (Improve%20Process%20for%20Creating%20Registration%20Polls%20f9d262227ae24e49adf82285d60d8773.md)
Created by: Dan Singjoy

## Description

- 

![Untitled](Respond%20to%20Hodlon%20about%20Solutions%20to%20Improve%20Regis%20ff592f28dcfc4f3cb719c85d4968ca07/Untitled%201.png)

Lol thank you, I appreciate whenever you make the poll and know how it feels to forget things! 😄

Yes it would be great to automate this and I think it’s definitely possible, though I’m not sure how to do it. Maybe we should try asking ChatGPT about this or dig into the docs for Snapshot to see if such a solution exists already. I just created a [task](Improve%20Process%20for%20Creating%20Registration%20Polls%20f9d262227ae24e49adf82285d60d8773.md) to improve this process for creating registration polls where we can coordinate a solution. 

It would also be nice if there was automatically a post in the discord when the new poll was created, so that people could easily see the poll when it’s created in discord even if the poll creator doesn’t share a link to the poll in discord. It’s helpful to post most Snapshot polls in discord to make them easier to see, so this integration would be useful for many other purposes as well. I asked ChatGPT about this a few weeks ago and just create a task that includes there conversation, which you can see [here](Figure%20out%20how%20to%20automatically%20post%20Snapshot%20poll%200f0cc903ef1d49248174678e2ebb2aca.md). It seems like it would be fairly easy to do, but might require some development work.

As a temporary solution I asked Rosmari if she could create the registration poll during the event if others haven’t already done it and she agreed. It might also be helpful to set up a bot reminder or some kind of assignment like you suggested and I’m happy to go with whatever solution works best. If anyone wants to volunteer to do this each week then please let us know, it’d be much appreciated and I’d give extra Respect to whoever creates registration polls :)

![Untitled](Respond%20to%20Hodlon%20about%20Solutions%20to%20Improve%20Regis%20ff592f28dcfc4f3cb719c85d4968ca07/Untitled.png)

Thanks for sharing, I read some of the article this morning and will read it more closely in the coming days. It seems like there’s a lot that we can learn from here and the Fractal Framework looks interesting. Shutter DAO has expressed interest in implementing the Respect Game as well and it looks like they’re involved with this Fractal project, so there may be some opportunities for collaboration here too.

Some parts of this article also reminded me of the [discussions](https://discord.com/channels/1164572177115398184/1186376309744619560/1192402585773158401) in the brainstorming chat from a few months ago about organizing Quests and sub-fractals with the Respect Game. I see a lot of potential for Optimism Fractal to branch off into many teams that each have more focused goals…

Hey everyone, I just realized that nobody made a registration poll for the council this week 😅

If you’d like to participate in the next week’s council, please [register here](https://snapshot.org/#/optimismfractal.eth/proposal/0xa3fb3e528320f49914fe592d182664c1e0a821d72ee25db449c9f08d85327750) before the upcoming event at 17 UTC. Looking forward to seeing you soon!

![Untitled](Respond%20to%20Hodlon%20about%20Solutions%20to%20Improve%20Regis%20ff592f28dcfc4f3cb719c85d4968ca07/Untitled%202.png)