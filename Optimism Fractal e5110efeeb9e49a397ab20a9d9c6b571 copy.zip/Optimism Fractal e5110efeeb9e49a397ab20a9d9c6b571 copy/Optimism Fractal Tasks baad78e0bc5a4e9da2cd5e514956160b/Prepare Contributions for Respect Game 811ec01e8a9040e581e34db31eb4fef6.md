# Prepare Contributions for Respect Game

Project: Prepare for OF 32 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2032%2041f1b4d97f4343048c130f12ee0f0588.md)
Status: Not started
Task Summary: This task aims to prepare contributions for the Respect Game. It provides a platform for participants to introduce themselves, share their contributions to Optimism, and receive reminders about inviting others to join and learn how to lead breakout groups. Created by Dan Singjoy, this page serves as a central hub for organizing and coordinating the Respect Game.
Summary: Prepare contributions for the Respect Game by introducing yourself and sharing links and descriptions of how you are contributing to Optimism. Remember to invite participants to join the Discord and share their contributions in the community database. If interested in leading breakout groups and hosting Respect Games, refer to the provided link.
Created time: June 27, 2024 11:28 AM
Last edited time: June 27, 2024 11:28 AM
Created by: Dan Singjoy

# Introduction

*Feel free to introduce yourself and share anything that you’d like participants in your group or viewers to know.* 

- 

- 

- 

# Contributions

*Share links and descriptions to help your group understand how are you contributing to Optimism.* 

- 

- 

- 

## Reminders

- Remember to invite fellow participants to join the [discord](https://discord.gg/dJgrP8ekYC) and share their contributions in the community [database](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Weekly%20Contributions%201c90e50f1e23408080b41c562d0dcd0b.md)

- If you’d like to learn how to lead breakout groups and host Respect Games in your community or organization, see [here](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Formalize%20and%20Request%20Leads%20in%20Optimism%20Fractal%201fb1919236b64800a839d21cbecfa306.md)