# Watch Hats Protocol Town Halls

Assignee: Dan Singjoy
Project: Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: In progress
Summary: No content
Parent-task: Respond to Spencer about Hats Protocol and Optimism Fractal Updates (Respond%20to%20Spencer%20about%20Hats%20Protocol%20and%20Optimis%20878c493ea73c4f7b859c45845ee9ad19.md)
Created time: April 23, 2024 2:28 PM
Last edited time: April 27, 2024 2:27 AM
Parent task: Respond to Spencer about Hats Protocol and Optimism Fractal Updates (Respond%20to%20Spencer%20about%20Hats%20Protocol%20and%20Optimis%20878c493ea73c4f7b859c45845ee9ad19.md)
Created by: Dan Singjoy

Only viewable for people who joined the community

[Watch Hats Protocol Town Hall, April 18th](https://www.notion.so/Watch-Hats-Protocol-Town-Hall-April-18th-187e4d27b7f24447b59bb4c07b6320e3?pvs=21)