# Respond to Tadas about Higher Order Fractals and Fractal Tournament Ideas

Assignee: Dan Singjoy
Project: Develop Systems for Fractal Communities to Collaborate and Interact with Each Other (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Systems%20for%20Fractal%20Communities%20to%20Collabo%20d9ca753ed03b4732a97bc6023c8d24ab.md)
Status: Done
Task Summary: This task aims to respond to Tadas regarding Higher Order Fractals and Fractal Tournament Ideas. The response discusses collaborative fractals, the implementation of ideas, and proposes alternative approaches for ranking and consensus within fractal tournaments. The author explores the potential of livestreamed events and the excitement of shorter consensus processes, while considering the advantages and challenges of different timeframes for higher order fractals.
Summary: The document discusses ideas for higher order fractals and proposes a consensus process for ranking and presenting contributions. It suggests options such as livestreaming the respect game and involving representatives from each fractal. The document also explores the analogy of baseball and basketball to explain the roles and dynamics within the fractal game. The author considers the pros and cons of a week-long consensus process and suggests that both weekly and monthly timeframes could work depending on the size and goals of the fractals.
Created time: December 26, 2023 1:27 PM
Last edited time: May 6, 2024 3:59 AM
Parent task: Synthesize Higher Order Fractals ideas (Synthesize%20Higher%20Order%20Fractals%20ideas%20fcb52e0fc73b4e5f8edf02522e67ba3d.md)
Created by: Dan Singjoy

## About this project

[An idea for how different fractals could collaborate](https://www.notion.so/1bf8fe7ed74d4cdaaa1f0cfb0a256515?pvs=21).

[Potential path for EdenFractal to implement the idea above.](https://www.notion.so/b831968892554853a312dedfdc6b8204?pvs=21)

Looking forward to your thoughts about this. You should be able to comment in notion on the links above.

For the second, I think representative is not enough because, while you can prepare a presentation that presents the work of the whole fractal, you can’t really prepare for a consensus process on rankings where you would represent your whole fractal (its opinion on the rankings). Therefore, I think that after all participant DAOs present their contributions, they should be given at least a week to build consensus on their rankings.

Another option is to livestream the respect game amongst contributors of other fractals and allow the other contributors to vote in real time.

I’m not sure if the week long delay might decrease some of the natural excitement of fractals. The fact that you can reach consensus in an hour and the game isn’t stretched out for very long is a big advantage of the Respect Game. People might not be as motivated to play it if takes a week to deliberate and feels more like work than play.

Imagine a game where the representatives are like team members of each fractal who are ‘going up to bat’ for the fractal. That’s a reference to baseball where the other players are in the dugout and cheering on the batter. The other fractal members are rooting them on and playing a less active role by participating just in consensus, while the representative is participating in both consensus and presentation. 

This is similar to baseball. In a baseball game, each team spends half of the time in the dugout cheering on one batter for their team and the other half of the time in the field. In the higher order fractal game, everyone in the fractal would watch a livestream of the higher order fractal game and participate in consensus to rank the other fractals. The consensus process for the sub-fractals could be a vote of recent respect like we tested with cignals games and the consensus process for the higher order fractal could be the respect game as you wrote. 

Alternatively, the consensus process of the subfractal could be an eden+fractal council or a council of top contributors where 4/6 agree how to rank other fractals during the livestream. This might have a closer analogy to a sport like basketball where there are five players on the court, but only one player with the ball. Playing offense is comparable to giving a presentation in that only one player can have a ball (or have the mic) to be able to present. Playing defense is comparable to reaching consensus in that everyone on the team plays a more active role during this part of the game. Obviously the analogy only goes so far here and the other connotations for offense and defense don’t really apply here. 

There could even be an analogy for ‘passing the ball’ where participants in the higher order fractal could call up their team members to give part of the presentation or answer a question which requires their specialized knowledge. This reminds me of how big companies like Apple or Github give annual keynotes where they have different employees give different presentations for various products. These presentations are very well produced and it would be awesome for fractals to do something like this in a higher order fractal respect game 

I can see a week long consensus process working in some contexts, but I really like the potential of fractals as discrete events that are fun for participants and I think that this idea of a livestreamed event could be very interesting. I’d be curious to hear your thoughts about this…

I could see higher order fractals work well on a weekly basis for two reasons:

1. Teams can do a lot in a short amount of time, much more than individuals. Especially with advances in AI and other tools. The amount of output of final products from a team of 10 or 100 or 1000 people in a week could be vastly greater than an individual over months.

2. With so much contributions from larger teams, it could put a lot of pressure into trying to convey so much in a small amount of time. This might reduce the accuracy of the measurement of success and put undue pressure on a lesser amount of meetings.

It depends on the design, circumstances, and awards or rewards for the winners. I think either timeframe could work. Maybe monthly is better for a nearer term scenario where fractals are relatively smaller and more meetings is more suited for larger fractals in the future