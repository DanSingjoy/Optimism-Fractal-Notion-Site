# Curate resources for Optimism Developers like the superchain console in the @Development Hub

Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Not started
Summary: No content
Parent-task: Announce Optimism Fractal Development Hub and share resources in the Development Channel (Announce%20Optimism%20Fractal%20Development%20Hub%20and%20shar%20bf2c80fdf56c4c769771e1ad62928639.md)
Created time: April 16, 2024 6:22 AM
Last edited time: May 1, 2024 10:57 AM
Parent task: Announce Optimism Fractal Development Hub and share resources in the Development Channel (Announce%20Optimism%20Fractal%20Development%20Hub%20and%20shar%20bf2c80fdf56c4c769771e1ad62928639.md)
Created by: Dan Singjoy

## Curate resources for Optimism Developers like the superchain console in the [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)

- [ ]  Curate resources for Optimism Developers like the superchain console in the [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)
- [ ]  share developers console and retrofunding in development chat

![Untitled](Announce%20Developers%20Hub%20and%20share%20Superchain%20Conso%20ee7991abe3624708833839ffcc75a085/Untitled.png)

[https://vxtwitter.com/Optimism/status/1771197457793466761](https://vxtwitter.com/Optimism/status/1771197457793466761)

![Untitled](Announce%20Developers%20Hub%20and%20share%20Superchain%20Conso%20ee7991abe3624708833839ffcc75a085/Untitled%201.png)

[https://warpcast.com/optimism/0xf9cf14f7](https://warpcast.com/optimism/0xf9cf14f7)

![Untitled](Announce%20Developers%20Hub%20and%20share%20Superchain%20Conso%20ee7991abe3624708833839ffcc75a085/Untitled%202.png)

[https://vxtwitter.com/Optimism/status/1772664316996755566](https://twitter.com/Optimism/status/1772664316996755566)

[https://www.youtube.com/watch?v=3JWUNXdAkmM](https://www.youtube.com/watch?v=3JWUNXdAkmM)

[https://www.youtube.com/watch?v=IrMiOlqmnbU](https://www.youtube.com/watch?v=IrMiOlqmnbU)

[https://www.youtube.com/watch?v=0xz_gsGjlb8](https://www.youtube.com/watch?v=0xz_gsGjlb8)

- [x]  add link to the Superchain freebie with third web here as well

[https://x.com/amandatylerj/status/1771216711783436774?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/amandatylerj/status/1771216711783436774?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ)