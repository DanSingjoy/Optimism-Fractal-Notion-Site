# Curate Fractally Whitepaper section, video, and context/history about fractal social media

Project: Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md)
Status: Not started
Task Summary: This task aims to curate the Fractally Whitepaper section, video, and context/history about fractal social media. It involves gathering information about the history of fractal social media and Dan Larimer's experience, as well as providing a brief summary and introduction to the page's content.
Summary: The document is about curating a whitepaper, video, and context/history about fractal social media. It mentions the initial concept of fractal democracy created by Daniel Larimer, his experience with Satoshi Nakamoto, and his innovations in decentralized exchange, stablecoin, Web3 social media, and ICO design. The document also includes links to download the whitepaper and learn more about http://fractally.com/.
Created time: July 5, 2024 12:46 PM
Last edited time: July 15, 2024 9:44 PM
Created by: Dan Singjoy
Description: This document is a request to curate a whitepaper, video, and context/history about fractal social media. It mentions the concept of fractal democracy created by Daniel Larimer, his experience with Satoshi Nakamoto, and his previous successful blockchain projects. The document provides links to the whitepaper, the Fractally website, and additional resources for more information.

- [ ]  curate context about the history of fractal social media and dan larimer’s experience

- [ ]  [Organize timestamps of video discussions about building social media apps from optimism fractal events ](Organize%20timestamps%20of%20video%20discussions%20about%20bui%2031552c884773452f9eb904508a64876a.md)

You can download the whitepaper [here](Curate%20the%20fractally%20whitepaper%206aee337b145a4f059e445882bc0c7163.md) and learn more at [fractally.com](http://fractally.com).

[Curate the fractally whitepaper](Curate%20the%20fractally%20whitepaper%206aee337b145a4f059e445882bc0c7163.md) 

## Context

[Review and curate related history about steem and hive](Review%20and%20curate%20related%20history%20about%20steem%20and%20%2007ba8ba98b32480bb6f8948a332aec9b.md) 

The initial concept for [fractal democracy](https://fractally.com/blog/what-is-fractal-democracy) was created by [Daniel Larimer](https://fractally.com/bio/daniel-larimer), a visionary innovator who interacted with Satoshi Nakamoto in 2009 and invented the concept of [DACs](https://blog.ethereum.org/2014/05/06/daos-dacs-das-and-more-an-incomplete-terminology-guide) (aka DAOs) as Decentralized Autonomous Companies in 2013. Daniel is a prolific founder who created the world’s first decentralized exchange (Bitshares), the first stablecoin (BitUSD), the first Web3 social media app (steemit/hive), and designed the software for the largest ICO of all time (EOS). 

Each of these projects were among the world’s most successful blockchain projects for a period of time and continue to grow today with decentralized, autonomous communities of countless talented builders. These innovations provided immense inspiration for industry leaders and paved the path for the largest sectors of Web3 today. You can learn more about each of these projects and Daniel’s outstanding track record in this [infographic](https://cdn.discordapp.com/attachments/974165882311946320/1153705492955271209/Meet-Fracallys-Founder-Daniel-Larimer-01312022-B.png).

![curating_more_equal_animals_122.png](Curate%20Fractally%20Whitepaper%20section,%20video,%20and%20co%200c22757a0f5c4393bb06009842ffc7fc/curating_more_equal_animals_122.png)

![Untitled](Curate%20Fractally%20Whitepaper%20section,%20video,%20and%20co%200c22757a0f5c4393bb06009842ffc7fc/Untitled.png)

![Untitled](Curate%20Fractally%20Whitepaper%20section,%20video,%20and%20co%200c22757a0f5c4393bb06009842ffc7fc/Untitled%201.png)

![Untitled](Curate%20Fractally%20Whitepaper%20section,%20video,%20and%20co%200c22757a0f5c4393bb06009842ffc7fc/Untitled%202.png)

![Untitled](Curate%20Fractally%20Whitepaper%20section,%20video,%20and%20co%200c22757a0f5c4393bb06009842ffc7fc/Untitled%203.png)

[Review and curate related work with EdenTalk.com](Review%20and%20curate%20related%20work%20with%20EdenTalk%20com%2088bcaf31b568498ebb6d58398c099763.md)