# Ask questions and Provide feedback and  about Tadas’ Optimism Fractal 2

Assignee: Dan Singjoy
Due: July 31, 2024
Status: Not started
Task Summary: This task aims to gather questions and feedback regarding Tadas’ Optimism Fractal 2, focusing on its potential implementation and the necessary adjustments for community engagement. The page serves as a collaborative space for discussing insights and challenges associated with the second iteration of Optimism Fractal’s software development.
Summary: The document outlines feedback and questions regarding Tadas' Optimism Fractal 2 software, highlighting key topics such as the impact of the bubble economy, the Plaza Accord, and changes in Japanese economic policy. It includes a to-do list for resource curation, discussions on funding distribution via OREC, and the need for educational materials to aid community understanding. Additionally, it addresses technical aspects of the software's deployment, potential attack vectors, and the integration of roles and reputations, while emphasizing the importance of clarity and accessibility for non-technical users.
Created time: May 30, 2024 12:25 PM
Last edited time: September 16, 2024 11:24 AM
Created by: Dan Singjoy
Description: The document outlines feedback and questions regarding Tadas' Optimism Fractal 2 software, focusing on its implementation, the impact of the Plaza Agreement, and the readiness for securing funds. Key topics include the need for educational materials, the structure of OREC and its interaction with the council, potential attack vectors, and the visibility of proposals. It also discusses the deployment of the software, beta testing, and participation in the Onchain Summer Buildathon for funding opportunities.

## Introduction

This page provides feedback and questions about Tadas’ candidate for the second iteration of Optimism Fractal’s software. The concept and implementation details of the candidate can be found below: 

https://github.com/sim31/fractal/tree/concept-for-of28-1/concepts/apps/of2

**Table of Contents**

## Questions for ORDAO Office Hours 1

- More details in the recent episodes of Optimism Town Hall and Eden Fractal

- I just fellow jitser

- Curious what Abraham and Howard think as they are

- Curious what Joshua thinks as someone who’s planning to launch fractal communities

## To Do

- [x]  Curate resources about Base Onchain Summer for Optimystics

- [ ]  Provide links to [Build app component to make it easy for participants to give personal respect at the end of each game](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md)

- [ ]  [Review Jacob Homanics and ask questions about Responses with Roles and Reputations](https://www.notion.so/Review-Jacob-Homanics-and-ask-questions-about-Responses-with-Roles-and-Reputations-ed76b3367f8e449eaff71f8c0bcea99c?pvs=21)
    - [x]  Highlight Jacob’s responses to make it easier to read, and put something at the top that clearly explains this
    - [x]  add superchain demo day

- [ ]  Add related articles from tadas here
    - [ ]  legislative executive
        - [ ]  
    - [ ]  immutable seasons
        - [ ]  [https://www.notion.so/edencreators/Immutable-upgrades-for-a-fractal-bd613b2a1bce4e9ea7701026da3e7b39](https://www.notion.so/Immutable-upgrades-for-a-fractal-bd613b2a1bce4e9ea7701026da3e7b39?pvs=21)

- [ ]  Transcribe, summarize, and organize the discussion about this to provide more clarity about the topics that we discussed on the Optimystics call
    - [ ]  Consider if it would be helpful to share the video with the Optimism Fractal community on this page and/or somewhere else so others can have a better understanding of this as well
    - [ ]  Consider asking team about this

- [ ]  Consider if this document should be repurposed, moved, and/or re-organized
    - It’s currently in the public Optimism Fractal notion site which I generally think is good…
    - [ ]  Consider adding it to the appropriate projects:
        - [Build Optimism Fractal App](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
        - [Build Respect Game app](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md)
        - [Improve Visibility for Optimism Fractal Respect](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md)
        - [Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md)
        - [Build app component to make it easy for participants to give personal respect at the end of each game](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md)

## Testing and Timing

See [Ask Tadas about how much he thinks the frapps software needs to be tested now and what he thinks of a 10 week season with a 3 week break](https://www.notion.so/Ask-Tadas-about-how-much-he-thinks-the-frapps-software-needs-to-be-tested-now-and-what-he-thinks-of--c0846b914f21469bad5625cddfc61337?pvs=21) 

See newer notes in [Propose 4 week summer break from Eden fractal, Eden Fractal Epoch 2, biweekly optimystics office hours events, and two week break from optimism fractal](https://www.notion.so/Propose-4-week-summer-break-from-Eden-fractal-Eden-Fractal-Epoch-2-biweekly-optimystics-office-hou-e7bdb4a20b5047a6943e8043e0e94f3d?pvs=21) 

Add notes to [Plan Optimism Fractal Season 4](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%204%2042304244bc404fceb0b2c1279508ed7e.md)?

## Readiness for Securing Funds via Optimism Missions

What do you think of allowing OREC controlled accounts to distribute funding? 

- This could/should be facilitated by legal entity like Optimism Foundation or FractalJoy

Will it be ready enough for us to make mission request proposal before July 8th?

- I think the software will not be fully ready then, but it will be ready enough to make the proposal

Will it be ready enough to receive some funding in contracts governed by OREC?

- I think the software will be ready enough by the time that missions are approved to secure a reasonable amount of funding, though i’d appreciate some clarity on how much funding would be appropriate

[Review Notes about Optimism Missions And Organize Plans in this task](https://www.notion.so/Review-Notes-about-Optimism-Missions-And-Organize-Plans-in-this-task-aebd4a1f3ed14515bb857c0c64a45d8e?pvs=21) 

[Create Missions to Start FractalJoy, FractalJoy Grants, and Fractal Fellowship](https://www.notion.so/Create-Missions-to-Start-FractalJoy-FractalJoy-Grants-and-Fractal-Fellowship-5e8579640a5c4f568bf3c444085b4b05?pvs=21) 

[Organize ideas to Create Mission Request Proposals to enable compliant funding and distribution powers for Optimism Fractal participants (and eden fractal)](https://www.notion.so/Organize-ideas-to-Create-Mission-Request-Proposals-to-enable-compliant-funding-and-distribution-powe-930e7779eb294ce6b417dda37e5dbf82?pvs=21) 

## Respect Configuration

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled.png)

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled%201.png)

## How to Deploy Software?

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled%202.png)

# Tadas’ Optimism Fractal 2

## Introduction

- Anything else you’d like to introduce or share?

- Feedback and questions

- Zaal voted for OF2 to be discussed during yesterday event and we discussed it for 15-20 minutes, most of which was me giving presentation.
    - If it’s helpful we can also publish it as separate video clip. I gave decent overview but wasn’t well versed in it yet

## OREC

### OREC and Council

How do OREC and Council work together?

- OREC makes decisions related to onchain actions and council makes all other decisions?
    - Will there be likelihood of disagreement between council and OREC?
    - What is the best way to explain the consensus process if there are two?

### Education, Explanation, and Accessibility

- It would be helpful to define nomenclature to explain who is the governing body that uses OREC as it’s consensus process. OREC is a good technical name that describes the process, but it doesn’t describe the people who use the process and a name for this group would be helpful for explanations.
    - Perhaps it makes sense to call it ‘the board’?
    - Or perhaps ‘the house of respect’, parliament, congress….
    - I think it would be good to keep it simple and casual to reflect the playful nature, similar to the naming of the Sages Council.
    - What would be the best name for this body?
        - [ ]  Consider asking AI about this

- The current document is written from a development perspective and we should create educational materials in the coming weeks that will enable the wider community and other nontechnical leaders of communities deploying the software to understand it more easily without needing to parse the technical overview on github.
    - For example, many people may be confused by the idea of the old Respect Distribution as Rosmari explains here (which followed a detailed discussion to help her understand it):

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled%203.png)

### Attack Vectors

- Possibility of spamming or making continual proposals to OREC
- [ ]  Add timestamp/summary of this part of discussion here

### OREC UI and Proposal Flow

- Would OREC have it’s own UI for voting or would it use a voting app like Snapshot or [Tally.xyz](http://Tally.xyz)?
    - How would the parameters of OREC be determined? I imagine that it’s voted by OREC, but how would non-technical users make proposals and ?
    - Would there be a commit on Github that would be forked into the main branch of an Optimism Fractal organization on Github?
        - This could potentially be configured with Hats Protocol and [Guild.xyz](http://Guild.xyz), or perhaps there is a onchain alternative to Github for this
        - I suppose that a simpler method for now could be that the OREC approves an offchain proposal to use a candidate such as Tadas’ from his repo in the deployment

### Visibility of OREC Proposals

- How would we ensure that Respected community members can see proposals created via OREC?

- With only a 4 day period, then this is extra important that people can see proposals easily

- Could we use some API to make these go in the discord chat
    - Can we use [XMTP.org](http://XMTP.org) to send messages directly to people’s onchain accounts in a more decentralized, resilient, and open-source manner?
    - Another option could be to automatically post the results into the Optimism Fractal farcaster channel.
        - Farcaster introduced plan to make channels decentralized as part of the protocol (and recently raised $150m), so we could potentially give ownership of the channel to the OREC board.should be complete in the coming months. Hats Protocol is building a component for decentralized channel ownership and moderation. So we could integrate
        - This could potentially be facilitated with [neynar.xyz](http://neynar.xyz) or [airstack.xyz](http://airstack.xyz)
            - 
                
                [https://twitter.com/betashop/status/1793714023386562929](https://twitter.com/betashop/status/1793714023386562929)
                

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled%204.png)

## Parent Respect and Transition Plan

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled%205.png)

### Prior Respect

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled%206.png)

- At first glance, this doesn’t seem optimal because it could confuse people and make it difficult to vote with. After considering it more I see the benefits in this approach, but still think it will likely result in confusion unless we make it really clear in the front-end(s) and explain it well.

- Can we port/migrate/mint the existing Respect distribution for Optimism Fractal from first few seasons as well?
    
    
- Does snapshot or other voting apps allow voting with both deployments of respect?
    
    
- Can we also mint the prior respect as ERC1155 so we can mint the thumbnail and publish the episodes 1-35 while we make posts on Paragraph?

![Untitled](Ask%20questions%20and%20Provide%20feedback%20and%20about%20Tadas%2023e3b1e82044464baeefe0e853288a0c/Untitled%207.png)

## Respect1155

[Respect1155](https://github.com/sim31/fractal/blob/concept-for-of28-1/impl/respect/sc) fixes [main headaches](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md) with the current Respect contract of Optimism Fractal. It is ERC1155 contract with a fungible token representing fungible Respect and NTTs with value attribute that sums to balance of a fungible token.

- Does ERC1155 achieve fungibility and nonfungibility as well as original intention?
    - What, if any, disadvantages are there in this implementation compared to the original implementation?
    - Can you still see the total amount of Respect in a ERC20 interface like Blockscout or Etherscan?
    - Can we still count past 12 weeks and create flexible
        - [Consider creating Respect Eligibility Module with Hats Protocol](Consider%20creating%20Respect%20Eligibility%20Module%20with%20%20bcd68cac7cc04f04a2c9bf1bdae9b646.md)

- Is it a standard ERC-1155 contract or are there any modifications?
    - Tadas said that it is a standard ERC1155 contract that should work in any ERC1155 interfaces and it has some additional features.
    - What additional features does this ERC-1155 have?
        - Does it have the non-transferability feature implemented in the same way as [Hats ERC1155](https://docs.hatsprotocol.xyz/for-developers/hats-protocol-for-developers/erc1155-compatibility)?
            - If so maybe we should explain it the same way in our documentation?

- Are you planning to make any additional documentation for Respect1155?

- How will the ERC1155 be implemented?
    - Will each event have a collection? Or will each season be a collection? Or will each deployment/fractal be a collection?
    - What will be the attributes of the collection?

- Can the attributes of the ERC1155 be used to create onchain EAS attestations?
    - I started drafting some attributes that could work for a EAS Schema and ERC1155 properties here: [Consider and Form Consensus on the Fields for an EAS Schema](Consider%20and%20Form%20Consensus%20on%20the%20Fields%20for%20an%20E%20ddeee45ad46a43a4b0ebd352e1f15678.md)

- How easy or difficult would it be to modify the ERC1155 implementation?
    - For example, if we decided to add another attribute/property, then could we do this easily?

### Roles and Reputations

- Can this integrate smoothly and easily with Roles and Reputations?
    - [Review Jacob Homanics and ask questions about Responses with Roles and Reputations](https://www.notion.so/Review-Jacob-Homanics-and-ask-questions-about-Responses-with-Roles-and-Reputations-ed76b3367f8e449eaff71f8c0bcea99c?pvs=21)
    - [Ask and Answer Questions about Integrating with Roles and Reputations](Ask%20and%20Answer%20Questions%20about%20Integrating%20with%20Ro%201d7979738a9f49bdb1deba384035553d.md)
    
    ([Research Roles and Reputations System (from Jacob Homanics with ATX DAO)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d.md) 
    

### Respect Visibility

- Will this allow us to add a picture for the Respect each week?

### Personal Respect

- Can RESPECT1155 enable people to mint their own Respect?
- Can RESPECT1155 this be integrated with Zora smart contracts to use their creator tools and enable people to earn a portion of ?
    - [Research Crossmint + Zora as solution for respect game and fractal app](Research%20Crossmint%20+%20Zora%20as%20solution%20for%20respect%20%20d4ad4dcaffce4fb3a964524926d8e7c7.md)

## OrNode and OrClient

Other componets currently being worked on:

- [OrNode](https://github.com/sim31/fractal/blob/concept-for-of28-1/impl/ornode) - nodejs component that stores OREC proposal metadata;
- [OrClient](https://github.com/sim31/fractal/blob/concept-for-of28-1/impl/orclient) - client to interact with smart contracts and OrNode;

- Can you provide more information about these?
    - Who will run the Node and Client?
    - What will be the requirements and needs for the nodes and clients?
    - Are these difficult to run? Are they a point of vulnerability?

## Upgrade Paths

Another differentiator from the current app could be ‘upgrade compatibility’ with the next generation fractal app that you’re building. The old app has a form of upgrade compatibility that you explained [here](https://github.com/sim31/fractal/blob/main/concepts/apps/of2/UPGRADE_PATH.md), but the upgrade path is less straightforward because it uses a different token standard. I think it would be ideal if people can easily play the Respect Game in a really simple app to just have fun with friends, then when ready they can start using advanced fractal features like OREC using the existing personal Respect that they’ve given out to bootstrap a community account with community Respect. I wonder if OREC can be added in a modular way for an existing Respect distribution like this…

## Front End

- Will it use the existing front-end or a new front-end?

- I don’t know what is Vipe. Is there some important differences between this and the current implementation?

- Does it make sense for Vlad and Lennar to help with any of this?

- There will be front-end place for disbursement of Respect

- Will there be front-end UI to manage contract proposals via OREC?

## Next Steps

- What are the biggest priorities?

- Is there anything we should emphasize for other developers that needs to be done or should be considered?

### Documentation

- Are you planning to write more documentation?

- Would it be helpful to publish or transcribe parts of this video to provide additional information?

## How can we help?

- Is there anything you’d like from me, vlad, and/or rosmari?

### Beta Testing

- A few weeks ago Zaal and Deeze volunteered to beta test the software, so I could ask them to test it out if it’d be helpful for any purposes
- Of course I’d also be happy to help with any testing as well

# Eden Fractal Deployment

- Can we deploy this software on Base? When?

- Should/can we fully deploy it for Eden Fractal immediately when it’s available (while Optimism Fractal tests it for 6 weeks alongside the current app)?
    - What are the risks or worst that can happen?
    - It seems that the software will be much better than not using anything like we’re doing now and it could provide big opportunities for Eden Fractal, so I think it’s probably best to start using it immediately once it is ready

- Eventually we could port/migrate previous respect, but not a big deal for now

- Related notes:
    - [Review Plan to migrate Eden Fractal Respect to EVM for Eden Fractal 2 year anniversary](https://www.notion.so/Review-Plan-to-migrate-Eden-Fractal-Respect-to-EVM-for-Eden-Fractal-2-year-anniversary-4c7dc157e98a4cfaa4c6b346d8d22679?pvs=21)
    - [Deploy Software, Create Documentation, and Start posting consensus results for Eden Fractal on Base](https://www.notion.so/Deploy-Software-Create-Documentation-and-Start-posting-consensus-results-for-Eden-Fractal-on-Base-e0a87af5a51f478dbbca911740dee78a?pvs=21)
    - [Propose topics about Base in Eden Fractal Events](Propose%20topics%20about%20Base%20in%20Eden%20Fractal%20Events%20d78a077c922544d8a2961212a8029c22.md)

# Onchain Summer

Join the Base Onchain Summer Buildathon in June and compete for a share of 200 ETH in prizes across eight sponsored tracks. Backed by major sponsors like Stripe, Shopify, and Farcaster, this global online hackathon encourages builders to create innovative onchain solutions in payments, commerce, gaming, social, and more. Key dates include the kickoff on May 31st, application deadline on June 17th, and submission deadline on June 30th. 

- You can find details here: [Research and Apply for Onchain Summer](Research%20and%20Apply%20for%20Onchain%20Summer%2040d95d67b7d341e0b570363154a6083b.md)

- This could be a big opportunity to earn funding, attract community, and grow fractals
    - It would be great to participate with the Fractal App in some way

- Is there any way that we’d like to apply as a team?
    - If so, how?
    - Alternatively we could also apply as individuals.
        - Let me know if you think that’s better and would like any help or support
        - Rosmari and I are considering to apply with Base Play. I’ll check the rules about participating on multiple teams
        

[Respond in Optimystics Chat about deploying Eden Fractal on Base for the anniversary and Tadas’ Competition Article](https://www.notion.so/Respond-in-Optimystics-Chat-about-deploying-Eden-Fractal-on-Base-for-the-anniversary-and-Tadas-Comp-4a0001aa36a34028b810a7d2ec7f034e?pvs=21)