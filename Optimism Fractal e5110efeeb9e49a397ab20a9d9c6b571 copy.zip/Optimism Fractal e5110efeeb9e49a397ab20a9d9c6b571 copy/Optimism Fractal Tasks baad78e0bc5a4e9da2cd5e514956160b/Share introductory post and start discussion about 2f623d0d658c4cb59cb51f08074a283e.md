# Share introductory post and start discussion about Optimism Fractal Seasons in planning session

Assignee: Dan Singjoy
Due: April 8, 2024
Project: Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md)
Status: Done
Summary: In the planning session, Dan Singjoy shares an introductory post about Optimism Fractal and proposes a seasonal structure for it. The plan includes aligning seasons with RetroFunding rounds, having breaks between seasons, and focusing on different aspects of Optimism. Feedback and discussion are encouraged.
Created time: April 10, 2024 9:23 PM
Last edited time: April 11, 2024 12:25 PM
Created by: Dan Singjoy

## Description

- [ ]  review OF 16 text
    - [ ]  Update Respect Trees article
    

![Untitled](Share%20introductory%20post%20and%20start%20discussion%20about%202f623d0d658c4cb59cb51f08074a283e/Untitled.png)

![Untitled](Share%20introductory%20post%20and%20start%20discussion%20about%202f623d0d658c4cb59cb51f08074a283e/Untitled%201.png)

Following up on this… during last week’s planning session we discussed how Optimism Fractal can help public goods creators earn RetroFunding and how community members can earn RetroFunding by contributing to Optimism Fractal. For anyone who missed last week’s meeting, you can listen to this discussion [here](https://youtu.be/5FeRMLjw0yY?si=KFlMCc2ZbeopO_Is&t=3413).

- 
    
    We talked about how RetroFunding rewards public goods creators who make a positive impact in the Optimism Collective.
    

Hey everyone, I’d like to introduce a seasonal structure to Optimism Fractal and discuss this during our upcoming planning session. I’m curious to hear your thoughts and would appreciate feedback. Here’s the plan: 

I think that we should complete the second season of Optimism Fractal next week, then take a week off for spring break and align our seasons with RetroFunding rounds for the remainder of the year. The first two seasons would each be 12 weeks long, then there’d be three more seasons this year that each last about 9-12 weeks (depending on the exact dates of RetroFunding) and a 1-2 week break at the end of each season to give everyone time to relax.

![Untitled](Share%20introductory%20post%20and%20start%20discussion%20about%202f623d0d658c4cb59cb51f08074a283e/Untitled%202.png)

As we discussed last week (and you can see in the [article](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU) linked above), I think that contributions to Optimism Fractal could qualify for RetroFunding in the Onchain Builders, Governance, and Dev Tooling rounds. In addition Optimism Fractal can also play a very helpful role in promoting, evaluating, connecting, and otherwise providing value for public goods creators and citizens assessing impact in the Optimism Collective. 

The third season of Optimism Fractal would focus on Onchain Builders who contribute to the success of Optimism and it’d start on May 2nd. The fourth season of Optimism Fractal would focus on Governance and it would start around July or August. The fifth season of Optimism Fractal would focus on Dev Tooling and it would start around September or October. Each round of RetroFunding is expected to last approximately two and a half months, as you can see [here](https://gov.optimism.io/t/optimism-community-call-recaps-recordings-thread/6937/33?u=dansingjoy).

![Untitled](Share%20introductory%20post%20and%20start%20discussion%20about%202f623d0d658c4cb59cb51f08074a283e/Untitled%203.png)

Each season of Optimism Fractal could feature special initiatives to complement the scope of RetroFunding rounds, such as focused [RetroPitches](https://optimystics.io/retropitches) and [Respect Trees](https://optimystics.io/respect-trees)/[OPF Trees](Develop%20OPF%20Tree%20V1%20and%20V1%201%2074f99e1fb0d341499816c3e8ddb38669/OPF%20Tree%20V1%201%202af841e0096d4493b33695a2d1b9f04b.md) to promote public goods creators, coordinate priorities, and evaluate impact in the Collective. We could also create exciting new kinds of Respect Games and seasonal [shows](https://optimismfractal.com/media) that go along with each category. Of course, everyone will still be welcome to join our weekly events and earn Respect by contributing to Optimism in any way that they’d like.

I started writing more about the seasonal structure in this [notion project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md) and am curious to hear everyone’s thoughts. I know it’s rather short notice to end this season next week then take a break and jump into the third season, but I think we’ll make the most positive impact by moving quickly to align Optimism Fractal with RetroFunding. Taking short breaks at the end of each season will also help us grow in a more dynamic and sustainable manner, while also giving everyone more time to prepare before the next round of RetroFunding starts.

Please let us know what you think and if you have any objections to this plan or other ideas about how the seasonal structure could best work. It would be great to discuss this at today’s event and then create a proposal to initiate this seasonal structure on Snapshot after hearing feedback. Thanks! :)

- 
    
    Hey everyone, I’d like to discuss the seasons of Optimism Fractal during this week’s planning session and suggest that we adopt the following seasonal structure:
    
    Bre
    
    8-12 week seasons for Optimism Fractal seasons (subject to change based upon the schedule of Retrofunding)
    
    1-2 week breaks following each season
    

I just created a poll where everyone can signal their opinion about this plan as well and would appreciate hearing your thoughts.