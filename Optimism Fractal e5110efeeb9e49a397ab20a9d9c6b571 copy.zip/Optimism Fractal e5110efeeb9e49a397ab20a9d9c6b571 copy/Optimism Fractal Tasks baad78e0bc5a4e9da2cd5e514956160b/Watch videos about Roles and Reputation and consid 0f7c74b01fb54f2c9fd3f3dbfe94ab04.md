# Watch videos about Roles and Reputation and consider curating information

Due: May 3, 2024
Status: Not started
Task Summary: This task aims to watch videos about Roles and Reputation and consider curating the information. The page provides a collection of videos and presentations by Jacob, discussing his work on Roles and Reputations, Scaffold ETH, and other related projects. It also mentions the opportunity to curate the learnings from the BuidlGuild videos, highlighting interesting features such as the automatic updates in the UI header based on Reputation holdings and the various views for displaying Respect.
Summary: This document contains information about videos related to Roles and Reputation. Jacob's presentation at Optimism Fractal event introduces his work with Roles and Reputations, Scaffold ETH, and other projects. There are also Quick Deployment Demonstrations and BuidlGuidl videos showcasing Reputation Starter Kit, Scaffold NFT, ATX REP, Hats Demo, and ERC404 NFTs. The document also mentions the intention to curate information from the videos, highlighting interesting features such as the dynamic UI header, different views for displaying Respect, configurable front-end components, and potential websites to explore.
Created time: May 3, 2024 11:14 AM
Last edited time: May 4, 2024 3:09 AM
Parent task: Research Roles and Reputations System (from Jacob Homanics with ATX DAO) (Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d.md)
Created by: Dan Singjoy

# Videos

## Presentation at Optimism Fractal 24

Here is a video clip of Jacob’s [presentation](https://youtu.be/pjQH394S4zc?si=jP9mbFiWm-UmGl9o&t=1546) during Optimism Fractal event 24 where he introduces his work with Roles and Reputations, Scaffold ETH, and other exciting projects. You can hear a brief overview of Roles and Reputations at [26:30](https://youtu.be/pjQH394S4zc?si=vCJCwA2TGJTSOXlT&t=1590) in the following video.

[https://youtu.be/pjQH394S4zc?si=jP9mbFiWm-UmGl9o&t=1546](https://youtu.be/pjQH394S4zc?si=jP9mbFiWm-UmGl9o&t=1546)

Starting at [25:33](https://www.youtube.com/watch?v=pjQH394S4zc&t=1533s) Jake discusses his contributions to the Scaffold ETH 2 repository for web3 dapp development. He talks about his Rep and Roles project for tracking onchain trust, which received an Optimism grant. Jake discusses his work on an NFT project focused on supporting creators, explaining its vision of properly onboarding artists into web3 and providing the benefits of smart contracts and NFTs.

## Quick Deployment Demonstrations from Jacob

[https://youtu.be/-XbTq4sp37Q?si=zKsgFpb2uCrfWw1k](https://youtu.be/-XbTq4sp37Q?si=zKsgFpb2uCrfWw1k)

[https://youtu.be/2iJAzDnvnNY?si=dK3z5Gk2uD_szwlb](https://youtu.be/2iJAzDnvnNY?si=dK3z5Gk2uD_szwlb)

## BuidlGuidl Videos

[https://www.youtube.com/watch?v=1p0KQlVTFow&list=PLnVqcyNGbH01OAruHVSgTmOsykvmQdb3z&index=7&pp=iAQB](https://www.youtube.com/watch?v=1p0KQlVTFow&list=PLnVqcyNGbH01OAruHVSgTmOsykvmQdb3z&index=7&pp=iAQB)

### **Reputation Starter Kit**

April 26th, **Reputation Starter Kit: Jacob Homanics demonstrates the kit that developers can use to implement Reputation Tokens**

[https://youtu.be/peH2eFKvDxc?si=bcTEpV6TNhQDHtLV](https://youtu.be/peH2eFKvDxc?si=bcTEpV6TNhQDHtLV)

### **Scaffold NFT**

April 26th, **Scaffold NFT:** Jacob demonstrates Scaffold NFT, a flexible development tool for deploying NFT applications

[https://youtu.be/fQjn7B47FAM?si=kn3DQk5hhThYJqRd](https://youtu.be/fQjn7B47FAM?si=kn3DQk5hhThYJqRd)

### **ATX REP**

**Mar 27, 2024, ATX REP:** A method to track trust onchain, using ERC1155s, with decentralized distribution & management and permissionless authorities/responsibilities, using Hats Protocol.

[https://youtu.be/1TG_8Z1ctz8?si=7JwMVbXkERM0DA6t](https://youtu.be/1TG_8Z1ctz8?si=7JwMVbXkERM0DA6t)

### **Hats Demo**

**Mar 27, 2024, Hats Demo:** A method to track trust onchain, using ERC1155s, with decentralized distribution & management and permissionless authorities/responsibilities, using Hats Protocol.

[https://youtu.be/Ced555YbK2k?si=UGtlSmhWqN2-5l4p](https://youtu.be/Ced555YbK2k?si=UGtlSmhWqN2-5l4p)

### ERC404 NFTs

**Mar 27, 2024, Trash NFTs: J**acob Homanics demonstrates an interesting implementation of ERC 404, a new token standard that combines mechanics of ERC20 and ERC721 

### Curate Videos

- I learned a lot about Roles and Reputations from the BuidlGuild videos and would like to document some of the learnings to make them more easily absorbable. Here are some interesting features:
    - The UI header automatically updates with new items based upon the Reputation holdings
    - The card, multi-card, mini, and other views are very interesting.
        - It’s inspiring to think about how Respect can be displayed in each of these views
        - The view of Respect as a card is also quite interesting. The Respect Game can become like a card game, which has been proven quite well in pokemon, magic the gathering, and many other card games
    - There are some websites that may be good to screenshot or explore
    - Each component of the front-end seems high configurable
    - [Consider implementing ERC 404 Token Standard for Respect](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18.md)
    - [Research and consider developing with scaffold.eth to build features and experiences for Optimism Fractal](Research%20and%20consider%20developing%20with%20scaffold%20eth%20fcb9e730ac514ca79e0db426c40dc3df.md)