# Message Tadas in Public OF Chat about Respect in OSO , newest thoughts on voting with Respect, and  @Abraham exploring API integrations with Notion

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Integrate Optimism Fractal and the Respect Game with RetroFunding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md), Create Notion API integration that allows upvoting with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Notion%20API%20integration%20that%20allows%20upvoting%201bba7e8a0bda4237854946b51a32c98e.md)
Status: In progress
Task Summary: This task aims to provide an overview of the latest thoughts and discussions related to respect in the Optimism Foundation's Open Source Organization (OSO). It covers topics such as voting with respect, API integrations with Notion by Abraham, and the exploration of deliberative processes in the Retro Funding 4 project.
Summary: This document discusses the Optimism Foundation's experimentation with deliberative processes in the Collective's governance system. The document outlines the use of sortition and balanced information to facilitate deliberations among a subset of voters. The goal is to test whether a deliberative process can increase agreement on contested topics and lead to greater satisfaction and clarity in the Retro Funding process. The document also highlights the benefits of deliberative processes, such as more informed decision-making and greater social cohesion. The outcome of the deliberative process will be incorporated into the Retro Funding 4 voting mechanism.
Created time: April 29, 2024 11:21 AM
Last edited time: July 16, 2024 9:39 AM
Created by: Dan Singjoy
Description: This document discusses the use of deliberative processes in the Optimism Foundation's governance system, specifically in the context of Retro Funding Round 4. The document explains the purpose of deliberative processes, their benefits, and how they will be implemented in the Retro Funding 4 voting mechanism. The document also mentions the recent blog posts released by the Optimism Foundation and outlines the next steps for the research and experimentation in the Collective.

- [x]  create slightly different version intended for OF and not just Abraham
    - [x]  Perhaps use headers more, ie integrating with Graph
    - [ ]  linking to [Organize Project to Submit Respect and Respect Voting as Impact Metric for Open Source Observer(OSO)](Organize%20Project%20to%20Submit%20Respect%20and%20Respect%20Vot%208097d7a2b8114247859cb30ad8b174cf.md)
    - [x]  idea for how we might want to also integrate with easyretropgf [Create RetroPGF UI to sort applicants by Respect](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20RetroPGF%20UI%20to%20sort%20applicants%20by%20Respect%2064ea936bf8714afbb84382bafe857662.md)
    - [x]  Also share [Read the Optimism Foundation’s Article: Experimenting with Deliberative Processes in the Collective](Read%20the%20Optimism%20Foundation%E2%80%99s%20Article%20Experimenti%2096db7df7bf044574a6c2fde99f00298b.md)

The Optimism Foundation recently released blog posts about [**Experimenting with Deliberative Processes in the Collective](https://gov.optimism.io/t/experimenting-with-deliberative-processes-in-the-collective/8041) and [The Path to Open Metagovernance](https://gov.optimism.io/t/the-path-to-open-metagovernance/7728)**

[](https://gov.optimism.io/t/experimenting-with-deliberative-processes-in-the-collective/8041)

Experimenting with Deliberative Processes in the Collective - 🏛️ Citizens’ House Governance - Optimism Collective- Retro Funding 4 Deliberation. This is how metrics in round 4 will be decided 

A subset of 50 Round 4 voters will be randomly selected to participate in the deliberative experiment. Randomly sampling individuals to make governance decisions (also called sortition) is common practice in deliberative democracy as higher quality discussion can be had with a smaller, but still representative, sample of the population. We will also experiment with sortition in Round 6.
This subset of voters will deliberate on a topic of relevance to Retro Funding Round 4, facilitated by a team specialized in designing and running such processes (from Missions Publiques 2 and RnDAO 1). This subset will be provided with balanced information on the topic to be debated in advance of the deliberations. Participants will work in a combination of plenary and subgroup settings across 2 sessions:

Thursday, May 30 from 16:30-18:00 UTC time (12:30-14:00 Eastern // 9:30-11:00 Pacific)
Thursday, June 6 from 16:30-18:00 UTC time (12:30-14:00 Eastern // 9:30-11:00 Pacific)

Between the two sessions, the community will be able to comment on the draft output of the deliberation. Also, the plenary moments of the sessions will be opened to the full set of voters in Round 4. This allows for the broader community to better understand and trust the decision-making process. The full Citizens’ House will ratify the output of the deliberative process before Round 4 voting begins.

The ratified outcome will be incorporated directly into the Retro Funding 4 voting mechanism.

As outlined in the [Path to Open Metagovernance 1](https://gov.optimism.io/t/the-path-to-open-metagovernance/7728), Optimism takes an experimental approach to the development of the Collective’s governance system. One of our [goals](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861) for Retro Funding in 2024, is to test a few clear hypotheses in each round, the results of which will inform the design of future rounds and/or other parts of the governance system.

![https://global.discourse-cdn.com/business7/uploads/bc41dd/optimized/2X/d/d08cdf34724b709f0a1c74f61959ff2bfc029cf3_2_1190x1000.png](https://global.discourse-cdn.com/business7/uploads/bc41dd/optimized/2X/d/d08cdf34724b709f0a1c74f61959ff2bfc029cf3_2_1190x1000.png)

While the Foundation facilitates this iterative process, with the help of the [Collective Feedback Commission 1](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863), any member of the community may contribute to this process. Inspired by a community member’s [post 1](https://gov.optimism.io/t/seeking-mission-request-sponsorship/7130/22), we will test the below hypothesis, among others, during Retro Funding 4:

> 
> 
> 
> A deliberative process can allow voters to come to consensus on a subject that would otherwise be difficult to come to consensus on.
> 

> 
> 
> 
> More specifically, we want to understand whether voter participation in a deliberative process increases agreement on a contested topic, and whether the resulting decision leads to broader satisfaction and clarity in the Retro Funding process.
> 

We will run this initial experiment as a pilot that could later be scaled to a larger sample size, applied to other parts of the Optimism governance system, and/or expanded to include an in-person assembly, if the preliminary findings are promising. Specifically, we think a deliberative process could be useful in the setting of collective definitions and/or shared values, preventing gridlock between Houses, coming to collective consensus on complex topics, and/or the future creation of critical governance documents, similar to the [Law of Chains.](https://github.com/ethereum-optimism/OPerating-manual/blob/main/Law%20of%20Chains.md)

## **What are Deliberative Processes?**

In its modern meaning, deliberation refers to a collective decision making process which aims to reduce the impact of power structures in discussion. In practice, it generally involves a set of three principles:

1. Informed, structured, and facilitated discussion of pros and cons about a topic.
2. A process that progresses from individual opinions towards collective judgement.
3. A recruitment of a representative group to have the discussion. This is mostly achieved through “sortition” (random selection of participants).

Deliberative democracy has roots all the way back to Aristotle but deliberative processes have been flourishing over the past 20 years in local and global discussions (see [here](https://participedia.net/) for many use cases). This method is currently utilized by the likes of the European Commission (to shape the directive on Food Waste, or the strategy on Virtual Worlds: [European Citizens’ Panels - European Commission](https://citizens.ec.europa.eu/european-citizens-panels_en)), national governments (more than 20+ such discussions have been held on Climate policy), or local governments (1000+ participatory budgeting discussions allowing citizens to allocate public funds to projects from the community).

Tech platforms such as [Meta](https://about.fb.com/news/2024/04/leading-the-way-in-governance-innovation-with-community-forums-on-ai/) and [OpenAI](https://openai.com/blog/democratic-inputs-to-ai-grant-program-update) have explored deliberative processes among their users to discuss topics related to governing AI. In web3, Cosmos has [experimented 1](https://forum.cosmos.network/t/discussion-onboarding-managing-offboarding-the-aez-a-set-of-draft-propositions/12054) with deliberative processes to determine the process and principles for adding or removing chains to the Atom Economic Zone (AEZ).

## What are Deliberative Processes Useful For?

- **More Informed Decision-Making**: A deliberative process can aid a diverse group of voters with different perspectives and expertise in navigating complex topics without relying on popular opinions, resorting to groupthink, being pressured into conformity, or being driven towards partisanship.
- **Greater Chance for Social Cohesion:** Deliberative processes can incorporate varied viewpoints in the process of coming to a shared consensus and promote greater social cohesion between people from different backgrounds. We’ve seen the opposite play out when the community has attempted to come to consensus in the absence of a structured deliberative process.
- **Credibly Neutral Consensus:** Structured deliberation gives participants an equal opportunity to discuss and debate the merits and drawbacks of multiple options among a representative sample rather than letting the loudest voices prevail in an unstructured social media debate. This process, facilitated by an expert external third party, can also reduce the influence of special interests (and the Foundation) in the formation of policy.
- **Buy-In:** Deliberative processes can increase the legitimacy of decision making via participation in the policymaking process. Voters may be more likely to commit to and/or abide by policies that have been proposed and agreed-upon amongst themselves.

## Retro Funding 4 Deliberation

1. A subset of 50 Round 4 voters will be randomly selected to participate in the deliberative experiment. Randomly sampling individuals to make governance decisions (also called sortition) is common practice in deliberative democracy as higher quality discussion can be had with a smaller, but still representative, sample of the population. We will also experiment with sortition in Round 6.
2. This subset of voters will deliberate on a topic of relevance to Retro Funding Round 4, facilitated by a team specialized in designing and running such processes (from [Missions Publiques 2](https://missionspubliques.org/?lang=en) and [RnDAO 1](https://www.rndao.io/)). This subset will be provided with balanced information on the topic to be debated in advance of the deliberations. Participants will work in a combination of plenary and subgroup settings across 2 sessions: 
    1. Thursday, May 30 from 16:30-18:00 UTC time (12:30-14:00 Eastern // 9:30-11:00 Pacific)
    2. Thursday, June 6 from 16:30-18:00 UTC time (12:30-14:00 Eastern // 9:30-11:00 Pacific)
3. Between the two sessions, the community will be able to comment on the draft output of the deliberation. Also, the plenary moments of the sessions will be opened to the full set of voters in Round 4. This allows for the broader community to better understand and trust the decision-making process. The full Citizens’ House will ratify the output of the deliberative process before Round 4 voting begins.
4. The ratified outcome will be incorporated directly into the Retro Funding 4 voting mechanism.

## Next Steps

In 2024, you can expect to see a more scientific and interdisciplinary approach to research and experimentation in the Collective (thanks to our new Research and Experiments Lead, [@elizaoak](https://gov.optimism.io/u/elizaoak).) We’re excited to begin by testing a hypothesis that originated from a community member on the forums, and to experiment with an approach that empowers voters to address contested topics without interference from the Foundation.

The Foundation will share additional details on the specifics of the deliberation on the forum before reaching out to the 50 randomly selected Round 4 voters via telegram.