# Decide the best way to explain Cagendas

Due: May 3, 2024
Project: Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)
Status: In progress
Task Summary: This task aims to determine the best approach for explaining Cagendas, a social coordination game that helps communities create agendas, choose discussion topics, and make collective decisions together. Created by Dan Singjoy, the game empowers Optimism Fractal community members to propose, discuss, and vote on topics with Respect, ensuring that the most important topics receive the attention they deserve.
Summary: Cagendas is a social coordination game that helps communities create agendas, choose discussion topics, and make decisions together. It has been continuously improved since its creation in late 2022 and offers a fair, fast, and fun way to prioritize discussions. The game involves proposing topics, voting on them, and discussing them during weekly events. Eden Fractal community has been actively engaged in playing Cagendas and more developments are coming soon.
Created time: May 9, 2024 8:33 AM
Last edited time: July 15, 2024 1:16 PM
Created by: Dan Singjoy
Description: Cagendas is a social coordination game that helps communities create agendas, choose discussion topics, and make decisions together. It has been continuously improved since its creation in late 2022 and offers a fair, fast, and fun way for community members to propose, vote, and discuss topics during weekly events. The game is being developed by Eden Fractal and aims to prioritize discussions and ensure that important topics receive attention. More information can be found at http://edencreators.com/cagendas.

- [ ]  Review related tasks in [Develop Cagendas at Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)

Cagendas is a social coordination game for collaborative agenda setting that empowers Optimism Fractal community members to propose, discuss, and vote on topics with Respect.  This community agenda game provides a simple, structured, and scalable way for everyone who has earned Respect at Optimism Fractal to propose topics or vote on topics they want to discuss at weekly events after the Respect Game. Cagendas can create profound benefits by prioritizing discussions and ensuring that the topics that matter most to our community get the attention they deserve. We’ve been developing Cagendas for over a year at Eden Fractal and I’m stoked to share it with the Optimism Collective. You can explore more details and contribute to the development of Cagendas in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md). 

Cagendas is A social coordination game that helps communities create agendas, choose discussion topics, and make collective decisions together

creative collaboration

collective decision making

allocate time

Learn more at [EdenCreators.com/cagendas](http://EdenCreators.com/cagendas) 

A social coordination game that helps communities create agendas, choose discussion topics, and make decisions together

Cagendas is designed to be fair, fast, and fun.

Cagendas is a social coordination game that helps communities create agendas, choose discussion topics, and make decisions together. It has been continuously improved since its creation in late 2022. The game involves proposing topics, voting on them, and discussing them during weekly events. Eden Fractal community has been actively engaged in playing Cagendas and producing videos about it. There are different game modes, such as Vlalendas. More articles and developments are coming soon.

Cagendas is a social coordination game that helps communities create agendas, choose discussion topics, and make decisions together. It’s a portmanteau of community and agendas. The basic idea is that anyone can propose a topic to discuss at weekly events (after the Respect Game), then community members vote on their favorite topics with Respect. We’ve been pioneering Cagendas at Eden Fractal weekly events for over a year and you can learn more about it below.

Cagendas is an exciting new game where communities can have fun while allocating time more effectively!

The Eden community has been deliberating to find the best ways to set [agendas](https://www.notion.so/Agendas-072f40a6460149d0b6c0d469eaad9f73?pvs=21) for discussions and proposals during weekly meetings. I propose that we play a game of Cagendas to help the community cooperate during the hour after breakout rooms. Cagendas can provide structure for Eden and other communities to guide discussions, process proposals, and coordinate all sorts of group activities in real-time.

Please note that this idea is a work in progress in an early stage of development and will be updated soon. Thanks for reading. Enjoy :)