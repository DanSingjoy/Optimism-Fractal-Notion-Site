# Create topics for discussion to propose for Cagendas at Optimism Town Hall

Due: May 3, 2024
Project: Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Create Topics for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Topics%20for%20Optimism%20Town%20Hall%2069e19236e45d4dd8b0a4b7c6fc12ae19.md), Create Promotions for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Promotions%20for%20Optimism%20Town%20Hall%20f0d644b3dbb8453e9413b33e03b0228b.md)
Status: In progress
Task Summary: This task aims to create topics for discussion that are relevant for the Optimism Town Hall. The goal is to propose comprehensive and engaging topics that align with the goals and objectives of the Optimism Collective. These topics will foster meaningful conversations and collaboration among participants, contributing to the overall success of the event.
Summary: This task aims to create topics for discussion relevant to the Optimism Collective and propose them at the Optimism Town Hall. The goal is to foster meaningful conversations and collaboration by preparing comprehensive overviews and resources for each topic. The topics will cover Optimism Collective governance decisions, Optimism Fractal, and other relevant areas. The task also includes creating an organizational structure for the topics and considering adding them to a database view for easier organization and potential voting. Future designs for Cagendas include creating a larger pool of topics that can be ranked using ranked choice voting.
Created time: May 9, 2024 5:07 AM
Last edited time: July 7, 2024 10:15 AM
Created by: Dan Singjoy
Description: This task aims to create topics for discussion relevant to the Optimism Collective and propose them at the Optimism Town Hall. The goal is to foster meaningful conversations and collaboration among participants by preparing comprehensive overviews and resources for each topic. The topics will cover Optimism Collective governance decisions, Optimism Fractal, and other related areas. The strategy includes proposing topics every Friday, sharing them in the Discord, and providing materials for review before the event. The document also discusses creating an organizational structure for topics and future designs for Cagendas.

## Introduction

This task aims to create topics for discussion that are relevant for the Optimism Collective and propose them at the Optimism Town Hall. These topics will be relevant to the collective's goals and objectives, fostering meaningful conversations and collaboration among participants.  The goal is to prepare comprehensive overviews and resources for each topic to facilitate informed and engaging conversations during the event. 

***Table of Contents***

## To Do

- [x]  Create 10-20 different drafts topics or questions to answer
    - The topics will be related to Optimism Collective governance decisions and Optimism Fractal
    - Anyone else can also propose a topic of course, but i should start by seeding it with enough good topics so that nobody else needs to propose a topic and we’ll have great discussions

- [ ]  Put the questions up on [](../Optimism%20Town%20Hall%20Topics,%20v1%20cf5421ca0469466bbb57f9d5793cd773.md)

- [ ]  Refine and add more draft questions over time

- [ ]  Propose 1-4 topics every Friday and share the message in the discord
    
    

## Strategy

- [ ]  Propose 1-4 topics every Friday and share the message in the discord

- For each question, I should take extra time and care to prepare a great overview of materials for review
    - I should share this before the event as part of the promotional event as well so people can read up on it and have very informed opinions during the event
    - I should also prepare a nice presentation for each topic that includes all the best resources
    - For example, we can include relevant forum posts, blog posts, metrics garden, tweets, etc to give people a good overview of the discussion and set the stage for a great conversation

- If a topic includes polls where people can vote during the event to help answer a question, then this can be a big value add

# Create Organizational Structure for Topics

- [ ]  consider adding these to a database view
    - I could use the existing [](../Optimism%20Town%20Hall%20Topics,%20v1%20cf5421ca0469466bbb57f9d5793cd773.md) database
        - I think this is a good idea. It would be easy to do and make the homepage better. Then we could also experiment with voting in notion along the way and generally organizing it in a database makes the topics much easier to organize

- [ ]  add the topics below to a database view

# Create topics for discussion at Optimism Town Hall about the Optimism Collective

based on the writing above and below 

- Prompt details
    
    
    - [ ]  Create 10-20 different topics or questions to answer, then put them up on  Snapshot for ranked choice voting before the end of the season
        - The topics will be related to Optimism Collective governance decisions and Optimism Fractal
        - Anyone else can also propose a topic of course, but i should start by seeding it with enough good topics so that nobody else needs to propose a topic and we’ll have great discussions
        - See [Curate questions for discussion related to the Optimism Collective for each week's Optimism Town Hall](https://www.notion.so/Curate-questions-for-discussion-related-to-the-Optimism-Collective-for-each-week-s-Optimism-Town-Hal-de20cbe9df5f4ce4bc3d337ddc33d1d8?pvs=21)
        
    
    ## Questions for Discussion
    
    - For each question, I should take extra time and care to prepare a great overview of materials for review
        - I should share this before the event as part of the promotional event as well so people can read up on it and have very informed opinions during the event
        - I should also prepare a nice presentation for each topic that includes all the best resources
        - For example, we can include relevant forum posts, blog posts, metrics garden, tweets, etc to give people a good overview of the discussion and set the stage for a great conversation
    
    How to reward educators
    
    - how can optimism fractal best help the collective
        
        
        ![Untitled](https://prod-files-secure.s3.us-west-2.amazonaws.com/b19e2783-0c6c-4152-8875-b7f9819a558f/23882f04-fd7e-4fd7-b9d7-605fd82dd443/Untitled.png)
        
    
    what is best design for juror 
    
    how can the respect game help organize impact juries
    
    what are the best metrics to measure impact of onchain builders
    
    what are the best metrics to measure impact of governance
    
    How can support optimism auooort  musicians
    
    [Upcoming Retro rounds and their design](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861/42?u=dansingjoy)
    
    [Regarding tokenized art, local cultural impact and RPGF4](https://gov.optimism.io/t/regarding-tokenized-art-local-cultural-impact-and-rpgf4/8003)
    
    - In each post, we ask a question related to Optimism Governance
        
        
        - [ ]  Draft out top questions:
            - What is the best way to create impact in the Optimism Collective?
            - What are the best metrics to evaluate the impact of onchain builders?
            - How can Optimism Fractal help evaluate impact in the Optimism Collective?
        
    
    ### Questions Suggested by Carl
    
    the ensuing debate around what forms of impact should be rewarded most.
    
    “what forms of impact should be rewarded most”. 
    
    These questions include everything from “what’s the right ratio of upstream to downstream funding” to “do we care more about newer teams or ones that stuck it out through the bear market”. These are inherently political questions because the answers reveal where people thing the OP should flow. 
    
    There are good debates to be had about the quality of new users, the elasticity of blockspace demand, the attribution of various network effects, how far downstream / upstream you want to ring fence impact, and so on.
    
    Let’s talk about those things ... with relevant data in the loop.
    
    To be fair, things are certainly moving in that direction, but more could be done to force these hard conversations before rounds are announced.
    
    https://twitter.com/carl_cervone/status/1772862669168468132
    
    [](https://x.com/jonassft/status/1787409167856161217?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)
    
    - Jonas open source question
        
        https://x.com/jonassft/status/1787409167856161217?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
        
        Do you believe Retro Funding should only reward projects that use an open source license?
        
        Optimism Citizens shall decide!
        
        Quick summary of popular opinions in the replies:
        
        1. Retro Funding should reward things that we want to see more of. The Collective wants to see more OS projects and so it should reward them more heavily or exclusively
        2. RF should reward impact, and closed source projects can have impact.
        3. Innovation should be protected via closed source licenses; Copy pasta behavior should not be incentivised.
        4. Implementation questions: How is OS defined? How are licenses detected? etc
    
    ChatGPT
    

# **Proposed Discussion Topics for Optimism Town Hall**

As we seek to deepen community involvement and refine our governance processes within the Optimism Collective, here are carefully curated topics and questions for our upcoming Optimism Town Hall sessions. These topics are designed to spark meaningful conversations, solicit informed opinions, and guide actionable outcomes for the betterment of the collective.

### **Governance and Impact Measurement**

1. **Evaluating the Impact of Onchain Builders**: What metrics and methodologies should we implement to measure the tangible impact of onchain builders within the Optimism ecosystem?

2. **Optimizing Impact Juries**: How can the Respect Game be integrated to organize and enhance the efficiency of impact juries?

3. **Governance Impact Metrics**: What are the most effective metrics for assessing the impact of governance actions within Optimism Collective?

### **Funding and Support Strategies**

1. **Support Structures for Educators**: How can the Optimism Fractal framework be tailored to better support educators within the collective?

2. **Supporting Cultural Leaders**: What is the role of cultural leaders in driving community engagement for the Collective and how should artists be rewarded with Retro Funding?

3. **Funding Allocation Debate**: What is the right balance between upstream and downstream funding, and how should priorities be adjusted to support both new and enduring projects through market cycles?

### **Technical and Operational Enhancements**

1. **Designing Effective Juror Systems**: What design principles should guide the development of juror systems to ensure fairness and effectiveness?
2. **Role of Open Source in Retro Funding**: Should Retro Funding prioritize open-source projects, and what criteria should define such preferences?

### **Community Engagement and Policy**

1. **Rewarding Diverse Forms of Impact**: What forms of impact should be prioritized for rewards, and how do we quantify diverse contributions to the collective?
2. **Promoting New User Onboarding**: How can we enhance the onboarding process for new users to ensure they contribute positively to the Optimism ecosystem?

### **Forward-Looking Governance Strategies**

1. **Future of Optimism Collective Governance**: How can Cagendas be further integrated to improve collective decision-making processes?
2. **Long-Term Vision for Optimism Fractal**: Discuss the strategic goals for Optimism Fractal and how it can lead governance innovations in decentralized networks.

### **Miscellaneous**

1. **Using Data in Governance Decisions**: How can we better incorporate data and analytics to inform governance decisions and policy formulations within the collective?
2. **Enhancing Community Participation**: What strategies can be employed to increase active participation in governance and decision-making processes among all members of the Optimism Collective?

These topics, available for ranked choice voting on the Snapshot platform, will help ensure that our discussions are comprehensive and focused on areas of highest priority and impact. By preparing an overview of materials, including relevant forum posts, blog posts, metrics, and tweets, we aim to facilitate well-informed discussions that can lead to effective outcomes for the collective.

We encourage every member of the Optimism Collective to participate in these discussions, whether by voting, proposing additional topics, or contributing to the debates during the Town Hall meetings. This collective effort is essential as we strive to embody the principles of transparency, inclusivity, and impactful governance that define our community.

# Create topics for discussion at Optimism Town Hall about Optimism Fractal

## OF 25 Topic Proposal

Just make one topic proposal

- I think i should just make one topic proposal: Exploring Optimism Town Hall and Cagendas
    - Then i can share more details about these initiatives and future plans
    - It would be good to discuss this in more detail and hear more feedback
    - This will provide everyone with a chance to hear and engage with the topic after learning about it last week
    

## Other Ideas for OF 25

- Ideas for future proposals
    - Fractal app development
        - We’ll probably be discussing this at Eden Fractal, so i can propose this early at EF and recommend OF people to join if they’re interested in this
        - The projects are more developed but not very ready yet for this at OF, so it’s better to save this topic proposal about this at OF for later and focus on this at EF

- Understanding/Exploring the Optimism Collective
    - RetroFunding and Round 6
    - Path to open metagovernance, etc
    - This is a good topic to discuss at some point, but it’s better to focus on town hall and cagendas first

## Inspiration for Topics

- I shared the following text with ChatGPT and asked it to ask questions based upon these, which led to the creation of about 12 topics in [](../Optimism%20Town%20Hall%20Topics,%20v1%20cf5421ca0469466bbb57f9d5793cd773.md).
    - 
        
        
        How to reward educators
        
        - how can optimism fractal best help the collective
            
            
            ![Untitled](Create%20topics%20for%20discussion%20to%20propose%20for%20Cagend%206ae17a37abe741d79914a64d0aca6ff5/Untitled.png)
            
        
        what is best design for juror 
        
        how can the respect game help organize impact juries
        
        what are the best metrics to measure impact of onchain builders
        
        what are the best metrics to measure impact of governance
        
        How can support optimism auooort  musicians
        
        [Upcoming Retro rounds and their design](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861/42?u=dansingjoy)
        
        [Regarding tokenized art, local cultural impact and RPGF4](https://gov.optimism.io/t/regarding-tokenized-art-local-cultural-impact-and-rpgf4/8003)
        
        - In each post, we ask a question related to Optimism Governance
            
            
            - [ ]  Draft out top questions:
                - What is the best way to create impact in the Optimism Collective?
                - What are the best metrics to evaluate the impact of onchain builders?
                - How can Optimism Fractal help evaluate impact in the Optimism Collective?
            
        
        ### Questions Suggested by Carl
        
        the ensuing debate around what forms of impact should be rewarded most.
        
        “what forms of impact should be rewarded most”. 
        
        These questions include everything from “what’s the right ratio of upstream to downstream funding” to “do we care more about newer teams or ones that stuck it out through the bear market”. These are inherently political questions because the answers reveal where people thing the OP should flow. 
        
        There are good debates to be had about the quality of new users, the elasticity of blockspace demand, the attribution of various network effects, how far downstream / upstream you want to ring fence impact, and so on.
        
        Let’s talk about those things ... with relevant data in the loop.
        
        To be fair, things are certainly moving in that direction, but more could be done to force these hard conversations before rounds are announced.
        
        [https://twitter.com/carl_cervone/status/1772862669168468132](https://twitter.com/carl_cervone/status/1772862669168468132)
        
        [](https://x.com/jonassft/status/1787409167856161217?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)
        
        - Jonas open source question
            
            [https://x.com/jonassft/status/1787409167856161217?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/jonassft/status/1787409167856161217?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)
            
            Do you believe Retro Funding should only reward projects that use an open source license?
            
            Optimism Citizens shall decide!
            
            Quick summary of popular opinions in the replies:
            
            1. Retro Funding should reward things that we want to see more of. The Collective wants to see more OS projects and so it should reward them more heavily or exclusively
            2. RF should reward impact, and closed source projects can have impact.
            3. Innovation should be protected via closed source licenses; Copy pasta behavior should not be incentivised.
            4. Implementation questions: How is OS defined? How are licenses detected? etc
            
        

- You can see more inspiration here:
    - [Review Inspiration and Market Need for Optimism Fractal Season 3, Cagendas, and Optimism Town Hall from Optimism Collective](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183.md)

## Future Designs for Cagendas

- In the future i/we can create many more topics (ie 10 or 100) that stay throughout the season and use ranked choice voting on the topics depending on the top topic at a certain time without needing to post topics each week.
    - You can see technical development related to this feature here: [Research and Test Snapshot for Improvements to Cagendas](Research%20and%20Test%20Snapshot%20for%20Improvements%20to%20Cag%20e7906e1df6704fbb8de9f060f751ded9.md)

## Related Notes

See [Explore the Optimism Collective's Experiments in Impact Juries and Deliberative Processes for Impact Evaluation ](Explore%20the%20Optimism%20Collective's%20Experiments%20in%20I%20e43c8c0159e44728b15daca5f6495ce9.md) 

See [Organize Project to Submit Respect and Respect Voting as Impact Metric for Open Source Observer(OSO)](Organize%20Project%20to%20Submit%20Respect%20and%20Respect%20Vot%208097d7a2b8114247859cb30ad8b174cf.md) 

See [Review Inspiration and Market Need for Optimism Fractal Season 3, Cagendas, and Optimism Town Hall from Optimism Collective](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183.md)