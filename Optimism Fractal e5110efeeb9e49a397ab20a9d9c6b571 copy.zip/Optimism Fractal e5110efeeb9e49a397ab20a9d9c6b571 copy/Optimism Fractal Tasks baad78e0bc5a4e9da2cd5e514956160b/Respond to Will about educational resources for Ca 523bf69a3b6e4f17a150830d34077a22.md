# Respond to Will about educational resources for Cagendas

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)
Status: In progress
Task Summary: This task aims to respond to Will regarding educational resources for Cagendas. The response includes a recommendation for the best resource to learn about Cagendas, which is a page at http://optimystics.io/cagendas. The page provides game rules, videos of events, a notion project, and more resources about Cagendas.
Summary: In response to Will's inquiry about educational resources for Cagendas, Dan Singjoy suggests visiting http://optimystics.io/cagendas for game rules, videos, a notion project, and more information about Cagendas. Dan is also open to discussing Cagendas with the Let's Grow community.
Created time: July 15, 2024 11:38 AM
Last edited time: July 16, 2024 9:40 AM
Created by: Dan Singjoy
Description: In response to Will's inquiry about educational resources for Cagendas, Dan Singjoy suggests visiting http://optimystics.io/cagendas for game rules, videos, a notion project, and more information about Cagendas. Dan expresses excitement for experimentation with fractals and supporting unique niche communities.

- [x]  update cagendas article

![Untitled](Respond%20to%20Will%20about%20educational%20resources%20for%20Ca%20523bf69a3b6e4f17a150830d34077a22/Untitled.png)

Sounds good. Yes I’m usually available at that time, though this week I might be busy reaching out to Optimism delegates requesting support for the Mission Requests. Would next Wednesday work?

 if it’s not a rush for you then I think next Wednesday would be better than this Wednesday

![Untitled](Respond%20to%20Will%20about%20educational%20resources%20for%20Ca%20523bf69a3b6e4f17a150830d34077a22/Untitled%201.png)

Hey Will, thanks for asking. I think the best resource for someone to look at Cagendas explained is at [Optimystics.io/cagendas](http://optimystics.io/cagendas). This page includes the game rules, videos of events, links to a notion project, and more resources about Cagendas. I hope the Let’s Grow community likes it and would be happy to speak with them about it as we discussed last week

- 
    
    Hey Will, I think the best resource for someone to look at Cagendas explained is at [Optimystics.io/cagendas](http://Optimystics.io/cagendas). This page includes the game rules, videos of events, links to a community notion project with more details, and more about Cagendas. I hope the members of Let’s Grow like it and would be happy to speak about it with them as we discussed last week
    

![Untitled](Respond%20to%20Will%20about%20educational%20resources%20for%20Ca%20523bf69a3b6e4f17a150830d34077a22/Untitled%202.png)

You’re welcome Pascal, thank you! You make a lot of good points and I always appreciate hearing your perspectives. I’m excited for all kinds of experimentation with fractals and am aiming to support this as much as possible with Eden Fractal. As in nature, there is room and need for a wide variety of designs for fractal communities that serve unique niches.

[https://optimystics.io/cagendas](https://optimystics.io/cagendas)