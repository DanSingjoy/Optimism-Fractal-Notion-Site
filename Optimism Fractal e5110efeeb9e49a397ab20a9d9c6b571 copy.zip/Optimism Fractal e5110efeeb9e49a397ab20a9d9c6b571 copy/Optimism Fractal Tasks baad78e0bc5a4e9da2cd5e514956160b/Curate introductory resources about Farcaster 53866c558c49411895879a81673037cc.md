# Curate introductory resources about Farcaster

Project: Explore and Create Integrations between Farcaster and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md), Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md)
Status: Not started
Task Summary: This task aims to curate introductory resources about Farcaster, a platform frequently used by industry leaders like Vitalik Buterin and Balaji Srinivasan. The resources provided include the official website https://www.farcaster.xyz/, the Warpcast platform https://warpcast.com/, and metrics available at https://dune.com/pixelhack/farcaster.
Summary: Curate introductory resources about Farcaster, a platform used by industry leaders like Vitalik Buterin and Balaji Srinivasan. Resources include the official website https://www.farcaster.xyz/, https://warpcast.com/, and metrics available at https://dune.com/pixelhack/farcaster.
Created time: July 5, 2024 2:32 PM
Last edited time: July 5, 2024 2:33 PM
Created by: Dan Singjoy
Description: Curate introductory resources about Farcaster, a platform used by industry leaders like Vitalik Buterin and Balaji Srinivasan. Resources include the official website https://www.farcaster.xyz/, https://warpcast.com/, and metrics at https://dune.com/pixelhack/farcaster.

Used frequently by industry leaders like Vitalik Buterin and Balaji Srinivasan.

[https://www.farcaster.xyz](https://www.farcaster.xyz/)

[https://warpcast.com/](https://warpcast.com/)

Metrics: [https://dune.com/pixelhack/farcaster](https://dune.com/pixelhack/farcaster)