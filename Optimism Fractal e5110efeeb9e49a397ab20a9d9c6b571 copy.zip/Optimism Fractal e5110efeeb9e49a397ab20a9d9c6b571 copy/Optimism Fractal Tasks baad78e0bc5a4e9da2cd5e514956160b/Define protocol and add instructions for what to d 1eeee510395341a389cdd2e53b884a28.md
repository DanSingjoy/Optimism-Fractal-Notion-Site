# Define protocol and add instructions for what to do when someone doesn’t have an evm account

Due: June 16, 2024
Project: Create Welcome Guide for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md)
Status: In progress
Task Summary: This task aims to define a protocol and provide instructions for individuals who do not have an EVM (Ethereum Virtual Machine) account. The protocol explores potential solutions such as using the Coinbase wallet or Alchemy. The goal is to add this information to the welcome guide and ensure seamless onboarding for users without EVM accounts.
Summary: In this document, Dan Singjoy is defining a protocol and providing instructions for what to do when someone doesn't have an EVM account. The document suggests using solutions like Coinbase Wallet or Alchemy and mentions adding the information to the welcome guide. There is also a mention of the OREC system and its impact on onchain consensus in the rules.
Created time: June 13, 2024 3:25 PM
Last edited time: June 18, 2024 11:45 AM
Created by: Dan Singjoy

- what is the best solution?
    - coinbase wallet?
        - [ ]  test coinbase wallet
    - alchemy?

- [ ]  add it to the welcome guide
    - [ ]  refer them to the welcome guide
    - with the OREC system it wont’ need 4/6 onchain consensus in the rules

- [ ]  [Research Smart Wallet from Coinbase Developer Platform](Research%20Smart%20Wallet%20from%20Coinbase%20Developer%20Plat%20d699b048ee4e4c328f4f8f3948204de8.md)