# Consider Games at Optimism Town Hall with JokeRace

Project: Research JokeRace for Cagendas and OPTOPICS  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20JokeRace%20for%20Cagendas%20and%20OPTOPICS%2062b9e52fb4994fd2902dc10fb082e592.md)
Status: Not started
Task Summary: This task aims to explore the consideration of games during the Optimism Town Hall with JokeRace. Led by Dan Singjoy, the goal is to discuss and potentially introduce games that can enhance the overall experience and engagement of the event. The current status of this task is not started, with the initial creation timestamp on July 22, 2024, at 5:05 PM, and the last edit made at the same time.
Summary: No content
Created time: July 22, 2024 1:05 PM
Last edited time: July 22, 2024 1:05 PM
Created by: Dan Singjoy
Description: No content

## Joke Race Competition

We could do some sort of game competition on JokeRace. I could set the entry charge and vote charge to .0001 eth, which is 35 cents. Half of the funds could go to a wallet i own and I could say that i intend to deploy any funds raised in this game to any purpose decided by the council

However, in jokerace it costs funds to add submit options to the competition. So i could do it or ask rosmari to do it during the event, though it would cost a bit and we’d need to do multiple transactions live. so that might be too much and it might be better to just have a conversation rather than trying to play too many games.

If we want to have multiple polls/games, then we’d need to make multiple polls on jokerace and each one would increase the cost for submitters and voters. so we’d need to just pick one topic like most inspiring speech or perhaps most optimistic speech

![Untitled](Propose%20topic%20for%20Optimism%20Fractal%2036%205f2a0e2203da4bb6a6180fbcfc308b88/Untitled.png)

![Untitled](Propose%20topic%20for%20Optimism%20Fractal%2036%205f2a0e2203da4bb6a6180fbcfc308b88/Untitled%201.png)