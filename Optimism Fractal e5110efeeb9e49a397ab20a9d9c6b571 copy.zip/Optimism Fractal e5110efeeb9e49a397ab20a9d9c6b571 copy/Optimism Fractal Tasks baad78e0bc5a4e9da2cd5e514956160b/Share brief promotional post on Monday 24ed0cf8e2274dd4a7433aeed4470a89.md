# Share brief promotional post on Monday

Due: May 25, 2024 5:28 PM (EDT)
Project: Prepare for OF 28 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2028%2055526595a95345fd888501f23774c254.md)
Status: Not started
Task Summary: This task aims to create a brief promotional post to be shared on Monday. The post will serve as a promotional tool for a specific purpose, product, or event. It will be created by Dan Singjoy and is due on May 25, 2024, at 5:28 PM (EDT).
Summary: This document is a brief promotional post created by Dan Singjoy. It is due on May 25, 2024, and the status is not started. The document includes information that can be seen by clicking on the "Info" link.
Created time: May 25, 2024 5:28 PM
Last edited time: May 25, 2024 5:28 PM
Created by: Dan Singjoy

See [Train Turquoise and create recurring tasks template for Opie to promote events and videos](https://www.notion.so/Train-Turquoise-and-create-recurring-tasks-template-for-Opie-to-promote-events-and-videos-b90101db1ec84f56ad05b6e28cfe3ac0?pvs=21) 

- Info
    
    
    - [ ]  Share 5-10 general nice promotional pictures with Turquiose
    
    - [ ]  Create notion task
        - [ ]  Add this to button in the project template to prepare for event
            - [ ]  Set Turqoise as the assignee along with a reminder alert to send it out on Monday
        - [ ]  Create draft message
            - [ ]  event reminder
            - [ ]  include topic proposal current and timeline
            - [ ]  recent video?
            - remember to keep it simple
                - I don’t think that the recent video is needed and this might make it more difficult for us to automate a message that turquoise can send out by copy/pasting
                - We could just share a link to the most recent videos on the media page instead. This would be good to promote this often without needing to
            - It’s probably good to make a few different versions that turquoise can copy and paste so that we mix it up a bit and promote different pages along with the event promotion each week
                - media page
                - optimystics blog
                - respect game article
                - council registration poll
                - town hall topic proposals
                - optimism fractal promotion
                - optimism town hall promotion
                
    - What is the next best step for this and how big of a priority is it to start doing this?
        - [ ]  consider asking rosmari what she thinks about this
            - maybe we should pick 3-5 of the messages from [Optimystics Promotional Messaging Templates and Audiences ](https://www.notion.so/Optimystics-Promotional-Messaging-Templates-and-Audiences-c3f6913edb4c496d882081f524b05ed0?pvs=21) and share them with Turquoise
        - [ ]  Once we pick a few of the messages and pictures that we want turquoise to post, we should add these to recurring notion task templates so that everything needed for turquoise is already in the task
            - We should include both the pre-written message and the picture in the recurring task along with the automatic reminder and assignment