# Create topic for OF 36

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Prepare for OF 36 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2036%204108e083e509475b88284ebc93ed38e8.md), Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md), Create different kinds of consensus games for seasonal celebrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20different%20kinds%20of%20consensus%20games%20for%20seas%20a62e1ceb57514af3ae9999b57973df4c.md)
Status: Done
Task Summary: This task aims to create a topic for the OF 36 town hall event, titled "Optimism Stories." The goal is for participants to share their experiences, hopes, and thoughts about Optimism Fractal and other communities on the Superchain. The page also includes other tasks related to creating a Snapshot Space and proposing topics for future town hall events.
Summary: The proposed topic for the Optimism Town Hall event is "Optimism Stories," where participants can share their experiences and hopes for the future related to Optimism Fractal and other communities on the Superchain. A special NFT mint will be given to all participants who share a story. There are also plans to create a Snapshot Space for OPTOPICS and discuss funding opportunities for Optimism Fractal.
Created time: July 13, 2024 1:11 PM
Last edited time: July 22, 2024 7:40 PM
Created by: Dan Singjoy
Description: The proposed topic for the Optimism Town Hall is "Optimism Stories," where participants can share their experiences and hopes for the future related to Optimism Fractal and other communities on the Superchain. A special NFT mint will be given to all participants who share a story. There are also plans to create a Snapshot Space for OPTOPICS and discuss funding opportunities in the upcoming Town Hall.

Hey all, I just proposed the following topic for this week’s town hall event:

## 🔴 Optimism Stories

To celebrate the end of Optimism Fractal’s third season and prepare for an epic fourth season, I propose that we share stories about Optimism during the Optimism Town Hall.

Each participant will have the opportunity to share a story about Optimism. The story can be about your past experiences, hopes for the future, or anything else related to Optimism. Feel free to share thoughts about Optimism Fractal, the Optimism Collective, and/or other communities on the Superchain. 

To commemorate the occasion and express thanks for the amazing season, l’ll give a special nft mint to all participants who share a story at the event. Looking forward to hearing from you and seeing you there!

- 
    
     Feel free to share your experiences or thoughts about Eden Fractal, another fractal community, or a fractal that you are interested in starting.
    
    invited to share your experiences and aspirations for fractal communities.
    
    I’d love to hear more of your thoughts, perspectives, and hopes for fractal governance
    

![optimism stories 1.png](Create%20topic%20for%20OF%2036%20ad48fe0dd5bc433c9c3fa0977ef57807/optimism_stories_1.png)

## Joke Race Competition

We could do some sort of game competition on JokeRace. I could set the entry charge and vote charge to .0001 eth, which is 35 cents. Half of the funds could go to a wallet i own and I could say that i intend to deploy any funds raised in this game to any purpose decided by the council

However, in jokerace it costs funds to add submit options to the competition. So i could do it or ask rosmari to do it during the event, though it would cost a bit and we’d need to do multiple transactions live. so that might be too much and it might be better to just have a conversation rather than trying to play too many games.

If we want to have multiple polls/games, then we’d need to make multiple polls on jokerace and each one would increase the cost for submitters and voters. so we’d need to just pick one topic like most inspiring speech or perhaps most optimistic speech

![Untitled](Propose%20topic%20for%20Optimism%20Fractal%2036%205f2a0e2203da4bb6a6180fbcfc308b88/Untitled.png)

![Untitled](Propose%20topic%20for%20Optimism%20Fractal%2036%205f2a0e2203da4bb6a6180fbcfc308b88/Untitled%201.png)

## Create OPTOPICS.eth Snapshot Space

- [ ]  add it as subspace in Town Hall
    - [ ]  if it’s not working, ask about this in snapshot discord
        - having these sub-spaces working will make it much easier for people to see the three spaces and have them make more sense

## Propose Topic for OF 35

- [ ]  propose for monday’s topic that we play OPTOPICS in the new Snapshot Space?

- [ ]  consider if this week’s topic should be funding opportunities or if it should be OPTOPICS
    - [ ]  should we promote the Respect Game or Funding Opportunities this week?

- [ ]  maybe this other version of OPTOPICS would be best to play and experiment with in the final event of the season
    - this would be a fitting ending to play this new kind of game and perhaps it’s better for OF 35 to be about funding and more so structure the next steps
        - public goods funding

### Draft for OPTOPICS Proposal

For this week’s Town Hall, I’d like to play OPTOPICS in a new way

I created a new Spapshot Space for OPTOPICS

This will make it easier for us to vote on topics in a more flexible and expressive way.

1. Propose a topic in OPTOPICS Snapshot Space. You can propose the topic at any time

1. Set the Voting Type to **Weighted Voting**, then set two poll options to **Upvote** and **Abstain**. This allows anyone to vote with just a portion of their Respect and provides greater ability for everyone to weigh their preferences with granularity.

1. Set the End Date for the proposal to Thursday at 19 UTC. This allows us to vote on the proposal at any time during the Town Hall. Is this necessary? I don’t think so. If people set it to go longer that’s ok and people can always remove their votes for this topic on the fly.

Whichever topic has the most votes will be the topic that is discussed.

We can move onto the next topic by saying ‘next topic’ on the call or in the zoom chat. By default everyone’s vote counts for next topic, but a majority of participants with at least 100 respect can overrule the every vote counts if they want. Alternatively, when a topic has more votes on snapshot then that will start a 1 minute timer automatically.

- [ ]  review OPTOPICS rules and see what should be added here

If this works well thenoing forward I’d like to play OPTOPICS to facilitate these kinds of more flexible, real time conversations more often. Perhaps every other Town Hall or whenever there isn’t a topic that we really need to focus on.

### Draft to Discuss Optimism Fractal Funding

I have an idea to discuss funding opportunities with updates in Retro Funding, Missions, and other opportunities.

Public Goods Funding or 

## OPTOPICS Game

At this week’s Optimism Town Hall, I’d like to play a new type of OPTOPICS game where participants can propose and vote on several exciting topics!

OPTOPICS is a Cagendas game that allows participants to suggest, vote, and dynamically choose discussion topics during our events. This allows us to create *Community Agendas.* We played OPTOPICS twice earlier in the season and you can learn about our experiences with this innovative community agenda game at [Optimystics.io/optopics](http://Optimystics.io/optopics).

This new type of OPTOPICS game will work in the same way as the previous versions, except for a slight tweak to the rules that make the game simpler, easier to play, and more interactive. The main new feature of this version is that you can suggest a topic simply by making a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth) at any time, including during the event.

## Game Rules

There are three main actions that you can take while playing OPTOPICS: suggest topics, vote on topics, and switch topics.

### Suggest Topics

Create a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth) at any time to suggest a topic. 

**Tip:** When creating a topic proposal you can set the Voting Type to **Weighted Voting**, then set two poll options to **Upvote** and **Abstain**. This allows anyone to vote with just a portion of their Respect and provides greater ability for everyone to weigh their preferences in their votes.

### Vote on Topics

Vote on topics with [Respect](https://optimystics.io/respect) to help set the agenda. Feel free to change your vote at any time.

### Switch Topics

OPTOPICS features an optimistic topic transition system that allows anyone to influence the discussion as the game progresses and help move the group to the next topic. Here’s how it works:

- **Next Topic:** Type ‘next topic’ in the zoom chat to propose moving to the next topic. This starts a one-minute countdown.

- **Same Topic:** Type ‘same topic’ within one minute to veto the change. If vetoed, neither person can propose to switch or veto again for the current topic.

- **New Topic:** If over half of well respected community members agree (each with at least 50 Respect), any topic can be introduced and discussed immediately.

The Optimism Town Hall is a collaborative forum that provides a platform for everyone in the community to share their thoughts, so feel free to suggest anything on your mind related to Optimism. Any feedback is welcome and I hope you enjoy the game!

![Untitled](Propose%20Topic%20for%20OF%2035%20about%20OPTOPICS%20f615f92f16bc44c982948b7b75cf77f7/Untitled.png)

- 
    
    
    1. **Initiate Change:** You can propose to switch topics by typing ‘next topic’ in the chat, triggering a one-minute countdown. A one-minute countdown will also start immediately once another topic has more votes on Snapshot.
    
    1. **Veto Option:** You can veto this by typing ‘same topic’ within the minute. If vetoed, neither
    person can make the same motion for the current topic.
    
    1. **Consensus Transition:** If there’s no veto, the discussion moves to the next highest-ranked topic on Snapshot.
    - **Proposing New Topics:** If at least 51% of well-respected members agree, a new topic can be introduced and discussed immediately. Approval can be indicated by thumbs-up from
    respected members in the chat.
    

A one-minute countdown will also start immediately once another topic has more votes on Snapshot.

We can move onto the next topic by saying ‘next topic’ on the call or in the zoom chat. By default everyone’s vote counts for next topic, but a majority of participants with at least 100 respect can overrule the every vote counts if they want. Alternatively, when a topic has more votes on snapshot then that will start a 1 minute timer automatically.

This will make it easier for us to vote on topics in a more flexible and expressive way.

- 
    
    a topic proposal Optimism Town Hall channel in the Optimism Fractal discord. The topic can be very simple, like a quick question or just a few words. The topic could also be more complex with detailed information and links. Feel free to suggest any topic related to Optimism Fractal or the Optimism Collective.
    
    During the event, respected participants can adjust their topic preferences in real-time to influence the discussion as the game progresses and move the group to the next topic with an optimistic topic transition system.