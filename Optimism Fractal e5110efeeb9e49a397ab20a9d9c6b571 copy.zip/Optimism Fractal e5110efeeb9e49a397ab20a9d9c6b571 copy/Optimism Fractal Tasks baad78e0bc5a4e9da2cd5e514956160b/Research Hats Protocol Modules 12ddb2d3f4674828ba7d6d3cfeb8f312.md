# Research Hats Protocol Modules

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: In progress
Task Summary: This task aims to provide an introduction and summary for the "Research Hats Protocol Modules" page. It discusses the ongoing development and progress of the Hats Protocol Modules, highlighting their significance in enabling automated granting and revocation of hats within the Hats protocol stack. The page also includes links to a video and article that provide more details about the Hats Modules and their role in advancing open source composability at the application layer.
Summary: The Hats team has published a video and article about Hats Modules, which offer a way to automate the granting and revocation of hats in your tree. This represents a significant advancement in open source composability at the application layer.
Created time: January 12, 2024 10:10 PM
Last edited time: May 12, 2024 12:50 PM
Parent task: Consider creating Respect Eligibility Module with Hats Protocol (Consider%20creating%20Respect%20Eligibility%20Module%20with%20%20bcd68cac7cc04f04a2c9bf1bdae9b646.md)
Created by: Dan Singjoy

## Description

See [Consider creating Respect Eligibility Module with Hats Protocol](Consider%20creating%20Respect%20Eligibility%20Module%20with%20%20bcd68cac7cc04f04a2c9bf1bdae9b646.md) 

[https://youtube.com/watch?v=8-qRpypY83U&si=g4IR3X9-C87bWVMX](https://youtube.com/watch?v=8-qRpypY83U&si=g4IR3X9-C87bWVMX)

## Hats Modules

The Hats team also recently published another great new video and article with more details about Hats Modules. 

“I just want to reiterate that this is a huge moment for the evolution of hats and the hats protocol stack. We're pushing the cutting edge of open source composability, especially at the application layer. Hats modules represents an amazing way to automate the granting and revocation of hats in your tree.” 

Video: [https://youtu.be/8-qRpypY83U](https://youtu.be/8-qRpypY83U)

Article: [https://hats.mirror.xyz/xAk_yb7dDL1OLBx8nq47Ni7V1SuiC6L6B-49u7vz520](https://hats.mirror.xyz/xAk_yb7dDL1OLBx8nq47Ni7V1SuiC6L6B-49u7vz520)

[https://www.youtube.com/watch?v=8-qRpypY83U](https://www.youtube.com/watch?v=8-qRpypY83U)

[https://twitter.com/hatsprotocol/status/1717194429843566898](https://twitter.com/hatsprotocol/status/1717194429843566898)

[https://twitter.com/hatsprotocol/status/1717194435631673469](https://twitter.com/hatsprotocol/status/1717194435631673469)

[https://twitter.com/hatsprotocol/status/1717194438638969006](https://twitter.com/hatsprotocol/status/1717194438638969006)

[https://twitter.com/hatsprotocol/status/1717194441713406068](https://twitter.com/hatsprotocol/status/1717194441713406068)

[https://twitter.com/hatsprotocol/status/1717194445001789756](https://twitter.com/hatsprotocol/status/1717194445001789756)