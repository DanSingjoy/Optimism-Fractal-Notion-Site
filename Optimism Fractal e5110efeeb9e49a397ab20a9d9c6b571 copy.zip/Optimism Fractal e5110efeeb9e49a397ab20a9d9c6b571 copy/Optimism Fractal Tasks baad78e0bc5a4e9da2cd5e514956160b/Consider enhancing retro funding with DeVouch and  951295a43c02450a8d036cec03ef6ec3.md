# Consider enhancing retro funding with DeVouch and Respect : Leveraging Trust Networks for better Capital Allocation | Jun, 2024 | Giveth

Assignee: Dan Singjoy
Project: Create RetroPGF UI to sort applicants by Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20RetroPGF%20UI%20to%20sort%20applicants%20by%20Respect%2064ea936bf8714afbb84382bafe857662.md), Integrate Optimism Fractal and the Respect Game with RetroFunding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md), Create Auxiliary Respect Tokens for Optimism Collective (ie OPC) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Auxiliary%20Respect%20Tokens%20for%20Optimism%20Colle%20b78abde1bff54c499c648628e459c689.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Plan Optimism Fractal Season 4 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%204%2042304244bc404fceb0b2c1279508ed7e.md)
Status: Not started
URL: https://blog.giveth.io/devouch-leveraging-trust-networks-for-better-capital-allocation-ad134d130dd4
Task Summary: This task aims to enhance retro funding with DeVouch and Respect by leveraging trust networks for better capital allocation. It discusses the importance of understanding user needs and introduces DeVouch, a platform that uses attestations to allow reputable community members to vouch for or flag projects seeking funding in the Ethereum ecosystem. With DeVouch, decision-makers can filter through projects more effectively and make informed funding decisions based on collective knowledge and trust networks.
Summary: DeVouch is a new product by Giveth that leverages attestations from EAS to allow reputable community members to vouch for or flag projects seeking funding in the Ethereum space. It aims to streamline the review process for retro funding rounds and provide a database of vouches and flags for informed decision-making. Attester groups, representing trusted communities, can vouch for projects, while flags help prevent funding from going to untrustworthy projects. DeVouch offers potential applications throughout the Ethereum ecosystem and promotes open-source accessibility.
Created time: June 13, 2024 8:28 AM
Last edited time: June 13, 2024 8:29 AM
Created by: Dan Singjoy

![https://miro.medium.com/v2/resize:fit:1000/1*H04qs20Pvmf8rRp1-C11Ww.png](https://miro.medium.com/v2/resize:fit:1000/1*H04qs20Pvmf8rRp1-C11Ww.png)

Also consider using these as input data for OPC 

It’s been a busy month for Giveth! We [integrated Recurring Donations](https://blog.giveth.io/introducing-giveth-recurring-donations-set-it-forget-it-1d9047eb9e95) onto the platform, wrapped up an [EPIC QF round](https://forum.giveth.io/t/galactic-giving-round-results-may-2-16-2024/1445), and [integrated Base!](https://blog.giveth.io/base-chain-is-now-available-on-giveth-14bc2d3aa3e0)

Well we aren’t done shipping, we just launched a brand new product to help everyone make better funding decisions.

This is DeVouch!

DeVouch uses attestations from [EAS](https://attest.org/) to allow reputable community members to attest to the trustworthiness of projects seeking funding in the ecosystem. Attesting takes the form of either “vouching” for a project’s legitimacy or “flagging” a project as suspicious or untrustworthy.

## Why is Something like DeVouch Important?

Grants programs, retroactive funding and donations now make up a significant portion of the funding mechanisms available in the Ethereum space. Many projects sustain themselves through these mechanisms and it’s one of the best ways right now to bootstrap a project with funds without seeking investors or VCs.

With this flourishing of funding mechanisms there is a massive influx of projects looking to them as a source of revenue, putting a heavy burden on decision makers to have to sift through 100’s of projects. Sometimes objective data such as on-chain metrics or open source activity can help, but not always, so DeVouch takes an alternative approach with a powerful and familiar way to help decision makers filter through projects.

[https://miro.medium.com/v2/resize:fit:700/0*RNQOhRZHwCmR43Ui](https://miro.medium.com/v2/resize:fit:700/0*RNQOhRZHwCmR43Ui)

We can all relate to situations where we relied on the opinions of others to influence our decisions. This is a rational behaviour since this allows us to outsource the time it takes to gather all the context and knowledge that might be required to make a good decision to someone else, someone we trust. We can leverage the opinions of a few well informed trusted friends to make our own decisions faster and better.

DeVouch plays this all out on a grand scale with the massive ecosystem of funding platforms and projects, letting us get to funding what matters, using our collective knowledge of the web3 space.

## **DeVouch & Optimism Retro Funding**

Giveth won a [mission grant from Optimism](https://gov.optimism.io/t/devouch-decentralized-vouching-with-attestations-mission-grant-project-updates/8066/1) to build something to improve Optimism Governance and drive the use of Attestations. This grant provided us with the funds to make DeVouch a reality, we are extremely grateful! Given this, we built DeVouch with a special attention to Optimism Retro Funding rounds.

In RetroPGF3 we saw the experimentation with lists, allowing badgeholders to create a public list of projects they support, DeVouch takes it a step further allowing to vouch, flag and even leave comments on specific projects, all on-chain.

[https://miro.medium.com/v2/resize:fit:1000/0*IAUu5yrWbEmrO8r6](https://miro.medium.com/v2/resize:fit:1000/0*IAUu5yrWbEmrO8r6)

RetroPGF3 we saw thousands of applications, which led to a very intense review period from a select few badgeholders to filter out fraudulent and ineligible applications, with DeVouch the review process can be streamlined and integrated with ease.

The Retro Funding voting process can also benefit from a database of vouches and flags, allowing badgeholders to not only provide their unique insight into the web3 project ecosystem but allow voters to be informed at a quick glance on if projects can be trusted with funding.

## Who gets to Vouch for Projects?

An “attester group” is the way we handle bundling a bunch of attestation data together into a definable group of addresses that are associated with a given organization.

Attester Groups can represent groups like “Giveth Core Team”, “Gitcoin Passport Holders”, “Optimism Badgeholders” — groups that you might consider have some reputation behind them or at least can prove they meet some certain criteria (like being a human). However Attester groups can be formed from any addresses that have credentials that can be attested to on-chain.

By allowing members of attester groups to vouch for projects we in a way get to leverage the reputation of the underlying community to lend credibility to any project found through DeVouch.

## Attesting is a Double Edge Sword

In addition to vouching, a project can also be flagged! It’s obvious that when so much funding is available through certain programs, it attracts all types of people. This has led to numerous cases of projects failing expectations, impersonating others or straight up [stealing money with no intention of delivering](https://gov.optimism.io/t/nftearth-rpgf-appeal/7159)!

[https://miro.medium.com/v2/resize:fit:700/0*ZJ5tg3kIPkmEZVFO](https://miro.medium.com/v2/resize:fit:700/0*ZJ5tg3kIPkmEZVFO)

With DeVouch we can leverage our collective wisdom to flag projects that seem untrustworthy and prevent funding from falling into the wrong hands.

Be aware that all attestations, vouches or flags are public on-chain activity and your address will be associated with whatever action you take.

## A Bit of Backstory

At Giveth we currently have a verification system that projects on our platform must run through to get the coveted “Verification Badge” and be able to yield GIVbacks to their donors and be boosted with GIVpower. This Verification system relies on a few well-trained humans to go through a project’s verification application and rule on whether the project passes the criteria or not.

It’s a demanding job to constantly be in the know of a project’s existing reputation and impact they might have had. We sought a way to decentralize this process, allowing a wider group of trusted people to vouch for a project’s impact and legitimacy. With a tool like DeVouch our verification process would become a lot smoother, relying more on trust networks rather than projects needing to pass hard criteria.

Thus the idea for DeVouch was born, and while we considered the use case for Giveth a novel one, we soon realized it could have far reaching applications throughout the Ethereum ecosystem.

## Continuing Giveth’s Legacy of Open Source and Accessibility

There are a ton of unexplored ways for organizations and funding platforms to use DeVouch for the better. In this spirit we created DeVouch to be as open and accessible as possible.

Anyone can use our [standardized DeVouch schema](https://optimism.easscan.org/schema/view/0x97b0c9911936fad57e77857fac6eef6771f8d0bf025be9549214e32bf9e2415a) to add new attestation data to our indexer. We also have a [powerful graphQL API](https://optimism.backend.devouch.xyz/graphql) that anyone can query to get information about DeVouch attestations made on projects or from certain addresses.

Lastly all the code is published open-source on Github and there is a documented way for others to add their attester groups into the indexer. Anyone can submit a request to add their organization to DeVouch through our [github repository](https://github.com/Giveth/DeVouch-BE), you can find [instructions on that in our docs](https://docs.giveth.io/devouch/integrating-devouch).

# In Sum

DeVouch offers a way to greatly improve Optimism Retro Funding processes and improve badgeholder voting decisions.

In general it offers new ways for funding platforms to incorporate trust networks for their users. It is a tool with a massive amount of potential to help donors and voters to make faster and better decisions on funding projects throughout the ecosystem.

We invite you to explore this new product and let us know what you think!

[https://devouch.xyz/](https://devouch.xyz/)