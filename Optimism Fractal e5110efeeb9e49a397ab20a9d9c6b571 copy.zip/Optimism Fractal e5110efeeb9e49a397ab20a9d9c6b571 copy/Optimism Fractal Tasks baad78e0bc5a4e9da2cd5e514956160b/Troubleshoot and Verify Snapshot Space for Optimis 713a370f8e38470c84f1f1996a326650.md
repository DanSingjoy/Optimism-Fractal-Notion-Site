# Troubleshoot and Verify Snapshot Space for Optimism Town Hall

Assignee: Dan Singjoy
Due: July 1, 2024
Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)
Status: Done
Task Summary: This task aims to troubleshoot and verify the Snapshot Space for the Optimism Town Hall. The goal is to ensure that the community can efficiently propose and vote on discussion topics, ultimately enhancing participation and collaboration within the forum.
Summary: The Optimism Town Hall is a community forum where participants discuss topics using a Snapshot Space, which allows for proposal and voting with a token called Respect. Verification of the space is needed to increase proposal limits from three to twenty daily. The space has been successfully verified, and there are options for upgrading to a Turbo plan for enhanced features.
Created time: August 22, 2024 11:27 AM
Last edited time: August 31, 2024 9:58 AM
Created by: Dan Singjoy
Description: The document outlines the process for verifying the Snapshot Space for the Optimism Town Hall, which allows community members to propose and vote on discussion topics. The verification increases proposal limits and enhances the community's ability to engage. Key features include the use of a soulbound token called Respect, earned through a social game, and plans for collaborative agenda games. The space has been successfully verified, enabling more than three polls per day.

# Message on X

Hi, I'd like to get my Snapshot Space verified:

[https://snapshot.org/#/optimismtownhall.eth](https://snapshot.org/#/optimismtownhall.eth)

 I (@DanSingjoy) messaged with Rich in the Snapshot help center and he instructed me to reach out to get the space verified so that our community can post more than three polls per day. You can find an overview of the Optimism Town Hall event and how we use this Snapshot Space below if you’d like. Please feel free to let me know if you have any questions. Thank you!

**More Details**

The Optimism Town Hall is a collaborative forum dedicated to conversations about Optimism, featuring innovative community agenda games where participants choose the topics. It is a community event that anyone is welcome to join and we produce videos of each event to provide educational resources about Optimism. I’ve been hosting weekly Optimism Town Hall events since May and we’ve chosen all of our discussion topics on Snapshot since then.

The Snapshot Space allows participants to propose and vote on discussion topics with a soulbound token called Respect (aka OPF), which is earned by playing an onchain social game called the Respect Game at Optimism Fractal. Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain. We’re pioneering a collaborative agenda game called Cagendas at Optimism Town Hall and have exciting plans to build more elements of this game with Snapshot.

You can learn more at the following links:

[https://lu.ma/optimismtownhall](https://lu.ma/optimismtownhall)

[https://optimystics.io/optimismtownhall](https://optimystics.io/optimismtownhall)

[https://optimystics.io/cagendas](https://optimystics.io/cagendas)

[https://optimismfractal.com/](https://optimismfractal.com/)

[https://optimystics.io/respectgame](https://optimystics.io/respectgame)

[https://optimystics.io/respect](https://optimystics.io/respect)

[https://optimismfractal.com/videos](https://optimismfractal.com/videos)

# Message with Rich

You're welcome. Yes, of course!

The Optimism Town Hall is a collaborative forum dedicated to conversations about Optimism, featuring innovative community agenda games where participants choose the topics. It is a community event that anyone is welcome to join and we produce videos of each event to provide educational resources about Optimism. I’ve been hosting weekly Optimism Town Hall events since May and we’ve chosen all of our discussion topics on Snapshot since then.

The Snapshot Space allows participants to propose and vote on discussion topics with a soulbound token called Respect (aka OPF), which is earned by playing an onchain social game called the Respect Game at Optimism Fractal. Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain. We’re pioneering a collaborative agenda game called Cagendas at Optimism Town Hall and have exciting plans to build more elements of this game with Snapshot.

Feel free to let me know if you have any questions. You can learn more at the following links:

[https://lu.ma/optimismtownhall](https://lu.ma/optimismtownhall)

[https://optimystics.io/optimismtownhall](https://optimystics.io/optimismtownhall)

[https://optimystics.io/cagendas](https://optimystics.io/cagendas)

[https://optimismfractal.com/](https://optimismfractal.com/)

[https://optimystics.io/respectgame](https://optimystics.io/respectgame)

[https://optimystics.io/respect](https://optimystics.io/respect)

[https://optimismfractal.com/videos](https://optimismfractal.com/videos)

You're welcome. Yes, of course!

The Optimism Town Hall is a collaborative forum dedicated to conversations about Optimism, featuring innovative community agenda games where participants choose the topics. It is a community event that anyone is welcome to join and we produce videos of each event as educational resources about Optimism. I’ve been hosting weekly Optimism Town Hall events since May and we’ve chosen all of our discussion topics on Snapshot since then.

The Snapshot Space allows participants to propose and vote on discussion topics with a soulbound token called Respect (or OPF), which is earned by playing an onchain social game called the Respect Game at Optimism Fractal. Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain. We’re pioneering a collaborative agenda game called Cagendas and have exciting plans to build more elements of this game with Snapshot.

Feel free to let me know if you have any questions. You can learn more at the following links:

[https://lu.ma/optimismtownhall](https://lu.ma/optimismtownhall)

[https://optimystics.io/optimismtownhall](https://optimystics.io/optimismtownhall)

[https://optimystics.io/cagendas](https://optimystics.io/cagendas)

[https://optimismfractal.com/](https://optimismfractal.com/)

[https://optimystics.io/respectgame](https://optimystics.io/respectgame)

[https://optimystics.io/respect](https://optimystics.io/respectgame)

[https://optimismfractal.com/videos](https://optimismfractal.com/videos)

Hi there! This is a bot speaking. I’m here to answer your questions, but you’ll always have the option to talk to our team.

![https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png](https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png)

So what brings you here today?

Hi, is there a limit to how many proposals can be created on a snapshot space? What is this limit and is there any way to increase it?

I'm using a snapshot space to allow community members to propose discussion topics for weekly events and it's not allowing us to propose more than 3 topics today.

Yes, there are limits on proposal creation in Snapshot spaces. For unverified spaces, the limit is 3 proposals daily and 15 monthly. Verified spaces can create 20 daily and 100 monthly. To increase these limits, you can upgrade to the Turbo plan, which allows 40 proposals daily and 200 monthly.

### **Sources**

What are the limitations for creating proposals on Snapshot?

Create a proposal | snapshot

**Answer**

![https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png](https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png)

Is that what you were looking for?

Yes that helped. How do i verify the space? Provide more details about the turbo plan as well, how does that work?

To verify your space, ensure you have an avatar, proposal validation threshold, 5 closed proposals, and a link from an official source. Contact support via the Help Center to request verification.

The Turbo plan ($6,000/year) offers enhanced monitoring, increased proposal limits, customizable interface, extended voting strategies, and higher visibility. It includes dedicated support and an SLA for responsiveness.

To subscribe to Turbo, reach out through the Help Center, Discord, or Telegram.

### **Source**

snapshot

**Answer**

![https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png](https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png)

Was that helpful?

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Hi there! Rich here. Can you send us your space link?

Hi Rich! Thank you. Yes here is the link to the space:[https://snapshot.org/#/optimismtownhall.eth](https://snapshot.org/#/optimismtownhall.eth)

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Thank you. It seems that it is not an official Optimism space. Can you give more more context about your space?

Hi there! This is a bot speaking. I’m here to answer your questions, but you’ll always have the option to talk to our team.

11:19 am

![https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png](https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png)

So what brings you here today?

Hi, is there a limit to how many proposals can be created on a snapshot space? What is this limit and is there any way to increase it?

I'm using a snapshot space to allow community members to propose discussion topics for weekly events and it's not allowing us to propose more than 3 topics today.

Yes, there are limits on proposal creation in Snapshot spaces. For unverified spaces, the limit is 3 proposals daily and 15 monthly. Verified spaces can create 20 daily and 100 monthly. To increase these limits, you can upgrade to the Turbo plan, which allows 40 proposals daily and 200 monthly.

### **Sources**

What are the limitations for creating proposals on Snapshot?

Create a proposal | snapshot

**Answer**

![https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png](https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png)

Is that what you were looking for?

Yes that helped. How do i verify the space? Provide more details about the turbo plan as well, how does that work?

To verify your space, ensure you have an avatar, proposal validation threshold, 5 closed proposals, and a link from an official source. Contact support via the Help Center to request verification.

The Turbo plan ($6,000/year) offers enhanced monitoring, increased proposal limits, customizable interface, extended voting strategies, and higher visibility. It includes dedicated support and an SLA for responsiveness.

To subscribe to Turbo, reach out through the Help Center, Discord, or Telegram.

### **Source**

snapshot

**Answer**

![https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png](https://static.intercomassets.com/avatars/7164174/square_128/custom_avatar-1712629372.png)

Was that helpful?

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Hi there! Rich here. Can you send us your space link?

Hi Rich! Thank you. Yes here is the link to the space:[https://snapshot.org/#/optimismtownhall.eth](https://snapshot.org/#/optimismtownhall.eth)

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Thank you. It seems that it is not an official Optimism space. Can you give more more context about your space?

You're welcome. Yes, of course!

The Optimism Town Hall is a collaborative forum dedicated to conversations about Optimism, featuring innovative community agenda games where participants choose the topics. It is a community event that anyone is welcome to join and we produce videos of each event to provide educational resources about Optimism. I’ve been hosting weekly Optimism Town Hall events since May and we’ve chosen all of our discussion topics on Snapshot since then.

The Snapshot Space allows participants to propose and vote on discussion topics with a soulbound token called Respect (aka OPF), which is earned by playing an onchain social game called the Respect Game at Optimism Fractal. Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain. We’re pioneering a collaborative agenda game called Cagendas at Optimism Town Hall and have exciting plans to build more elements of this game with Snapshot.

Feel free to let me know if you have any questions. You can learn more at the following links:

[https://lu.ma/optimismtownhall](https://lu.ma/optimismtownhall)

[https://optimystics.io/optimismtownhall](https://optimystics.io/optimismtownhall)

[https://optimystics.io/cagendas](https://optimystics.io/cagendas)

[https://optimismfractal.com/](https://optimismfractal.com/)

[https://optimystics.io/respectgame](https://optimystics.io/respectgame)

[https://optimystics.io/respect](https://optimystics.io/respect)

[https://optimismfractal.com/videos](https://optimismfractal.com/videos)

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Thanks for sharing. For verification, you can DM using the linked X account of your space to our official X account: [https://x.com/SnapshotLabs](https://x.com/SnapshotLabs)State that you want your space to get verified and attach the space link. Our team will check regarding this.

You're welcome and thank you. I will send it now. Do you recommend that I send the details above as well or just share the link to the space?

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Yes you can. Let me know once you send it.

Thanks. I just sent it from @Optimystics_ on X

![https://static.intercomassets.com/avatars/7274823/square_128/bebop1-1713127992.jpg](https://static.intercomassets.com/avatars/7274823/square_128/bebop1-1713127992.jpg)

Hi there, Mark here. Let me confirm with the team

Hi Mark. Sounds good, thank you

Hi there, we've verified your space.

![https://static.intercomassets.com/avatars/7274823/square_128/bebop1-1713127992.jpg](https://static.intercomassets.com/avatars/7274823/square_128/bebop1-1713127992.jpg)

Please let us know if you are interested in the Turbo plan as well and if you have any other concern. Otherwise, we can close this chat

![https://static.intercomassets.com/avatars/7274822/square_128/23b78f24-6235-4a38-85b5-1ec9ab02011b_LE_auto_x2-1712629364.jpg](https://static.intercomassets.com/avatars/7274822/square_128/23b78f24-6235-4a38-85b5-1ec9ab02011b_LE_auto_x2-1712629364.jpg)

![https://downloads.intercomcdn.com/i/o/1155264513/9b107ded6dfe6b1e98d93a95/Screenshot+2024-08-23+081204.png?expires=1725114600&signature=0d1cba34c8d9c023d683e19ee7038667f3f527508f191b3dd6ae9bcc0b82030a&req=dSEiE8t4mYReWvMW1HO4zTQSKXw1mOuQ12AzfTA%2B3JwSkkxpdfgOCmfEPxrd%0A%2B9q%2F3QufdGOO7XOvUNs%3D%0A](https://downloads.intercomcdn.com/i/o/1155264513/9b107ded6dfe6b1e98d93a95/Screenshot+2024-08-23+081204.png?expires=1725114600&signature=0d1cba34c8d9c023d683e19ee7038667f3f527508f191b3dd6ae9bcc0b82030a&req=dSEiE8t4mYReWvMW1HO4zTQSKXw1mOuQ12AzfTA%2B3JwSkkxpdfgOCmfEPxrd%0A%2B9q%2F3QufdGOO7XOvUNs%3D%0A)

I can confirm that your space has now been verified by Mark. Please let us know if you need any further assistance.

August 23

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Let us know if you have other concern. Otherwise, we'll be closing this conversation for the meantime.

Ok sounds great, thank you all very much!

![https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png](https://static.intercomassets.com/avatars/7274833/square_128/PFP-1712629701.png)

Awesome.