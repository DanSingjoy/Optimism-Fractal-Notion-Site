# Consider places to Promote Optimism Town Hall #2

Assignee: Rosmari
Due: May 15, 2024
Project: Create and Execute Promotional Strategy for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20and%20Execute%20Promotional%20Strategy%20for%20Optimi%20ea86a4b0098f48da970a5a108ec02544.md)
Status: In progress
Task Summary: This task aims to consider various places to promote the Optimism Town Hall #2. The page provides updates and announcements regarding the event, including a Governance Forum answer regarding the merging of the Community Calls section.
Summary: In the Governance Forum, the Community Calls section has been merged under the 'Updates and announcements' category.
Created time: May 11, 2024 3:01 AM
Last edited time: May 22, 2024 5:53 PM
Created by: Dan Singjoy

## Governance Forum Answer

‘Updates and announcements’ category

The Community Calls section isn’t removed from the main page, it’s just merged under ‘Updates and announcements’

## **Determine where to post promotions about Optimism Town Hall**

### Governance Forum

- [ ]  consider posting in one of the other channels that are featured since they removed the community calls section from the main page

- [ ]  token house governance category?
    - [ ]  retropgf category?
    - [ ]  collective strategy?
    - [ ]  governance design?
    - [ ]  general discusisons?
    - [ ]  citizens?
    

![[https://gov.optimism.io/](https://gov.optimism.io/)](Create%20weekly%20promotional%20strategy%20for%20Optimism%20To%208959f9b7397f4e09a622b49c42e2f0a8/Untitled.png)

[https://gov.optimism.io/](https://gov.optimism.io/)