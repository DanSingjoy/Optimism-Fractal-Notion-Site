# Message Nestor about Optimism Fractal and Ethereum Attestation Service

Assignee: Dan Singjoy
Due: December 3, 2024
Project: Explore and Create Integrations with Ethereum Attestation Service (EAS) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
Status: In progress
Task Summary: This task aims to facilitate communication with Nestor regarding the integration of the Respect Game with the Ethereum Attestation Service (EAS). It outlines the necessary steps to achieve consensus on the attestation schema fields and encourages collaboration and feedback on the integration process.
Summary: Dan Singjoy is communicating with Nestor regarding the integration of the Respect Game with the Ethereum Attestation Service (EAS). They discussed reaching consensus on the attestation schema fields and Singjoy has added thoughts to a project for this purpose. He plans to create a Discord thread for organized discussions on EAS integrations and is eager to hear Nestor's and others' ideas.
Created time: March 24, 2024 3:07 PM
Last edited time: August 18, 2024 11:24 AM
Created by: Dan Singjoy
Description: Dan Singjoy is in progress on a task to message Nestor regarding the integration of the Respect Game with the Ethereum Attestation Service (EAS). Following a recent meeting, Dan appreciates Nestor's interest and contributions, and has initiated a discussion about reaching consensus on the attestation schema fields. Dan plans to share further thoughts in a Discord thread for organized discussion on EAS integrations.

# Development Channel

Hi @Nestor, 

It was such a pleasure meeting you last week and I really appreciate your interest in helping to integrate the Respect Game with the Ethereum Attestation Service (EAS). I also enjoyed reading your [article](https://mirror.xyz/0xnestor.eth/4Z3_LMc-ghb908FzGS7EsJ6gdRYDq1iz3fDOL1iVYEI) about ReFi and checking out your development videos on Celo channel, thank you for all the great work! 🙏🏽

In our [discussion](https://youtu.be/Jdm9GKzFoiU?si=xTTqqMVzrbH2socD&t=3423) at last week’s event, we were planning how we could integrate the Respect Game with EAS and you mentioned that the first step would be to arrive at consensus on the fields to be used in the attestation schema. I thought about this for a while after our conversation and was inspired to write quite a bit, which I added to the notion [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md) for integrating with EAS and a new [task](Consider%20and%20Form%20Consensus%20on%20the%20Fields%20for%20an%20E%20ddeee45ad46a43a4b0ebd352e1f15678.md) to form consensus about the schema.

I’ll also share my thoughts here in discord via a thread where we can discuss integrations with the Ethereum Attestation Service in an organized manner. Please check it out and let me know what you think. I’m curious to hear your thoughts and would be interested to hear if anyone else has ideas about integrating with EAS!

## Create Discord Thread about EAS Integrations

When we spoke at last week’s event 

- [ ]  welcome Nestor?
    - [ ]  Follow up with Nestor (in general, development, or PM?)
        - Thanks so much
        - Feel free to reach out with any questions or thoughts
        - I checked out your videos from Celo and article about ReFi, thanks for all the great work
    - I could start up another chat or channel with Optimystics if you’d like. Feel free to also start a thread here or let us know if you have any other organization in mind
    - Abraham as well
        - [ ]  arrive at consensus on the fields for the schema in EAS.
            - Respect amount
            - Event number
            - Links to work?
            - Description of contributions?
        - You mentioned that the next step would be to arrive at consensus on the fields for the schema in EAS. A couple obvious fields that come to mind is amount of Respect and event number. I also imagine that it could be helpful to have fields for the community or organization that is hosting the Respect Game and community or organization that is giving Respect. It could also be interesting to include fields for descriptions of contributions, links to contributions, and links to timestamped videos from the event. I’ve only actually made an attestation with EAS once and haven’t seen many schemas before, so you might have a much better idea of what kinds of fields are best to include in the schema.
        - The Optimystics team is building an independent Respect Game app that anyone can use to easily play the Respect Game with their friends, community, or organization. One of the things that we’ve been thinking about is how we can create a generalized app where anyone can play the respect game without needing to deploy software or learn how to use Fractalgram. The idea is that this app should have a field that enables people to write the community that is hosting the game, so an admin or council of that community could be able to filter all the game results on a block explorer then easily award Respect to people who played their games. I’m not exactly sure what role EAS would play in this but I imagine that it could be very helpful if players each make an onchain attestation when they post the game results and this attestation includes the community/organization’s name.
        - You also mentioned that a good next step would be to add these to notion, so I just updated the project and tasks
        - @Tadas, Nestor mentioned that it might be more complex to integrate Respect with EAS if with the unique token design with both  that you created. I shared the link to your most recent page Would you recommend integrating EAS with the ERC-20, ERC-721, or some combination of these token standards? Or are you still thinking about migrating Respect to a different token standard like ERC 1151 and in this case how would you recommend proceeding?
            
            
            I messaged Tadas about this and he told me that a better explanation of the contract’s design can be found here. Tadas wrote this [page](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md) last month to explain the unique design of the contract and improve how Respect displays in block explorers. You can read the explanation in the ‘background’ section near the top of the page if you’re interested. At the end of the page he also considered the possibility of migrating the Respect token to an ERC-1155 standard.
            
            - [ ]  update this project with the resources and rationale i sent to [Message Spencer with and Ido from Hats Protocol with Optimism Fractal github repository and links to respect game and details page](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Message%20Spencer%20with%20and%20Ido%20from%20Hats%20Protocol%20wi%202d95ace163e24221a234331c7b6716b0.md)
        - ERC1151 (if you’re still thinking about migrating to the different token standard),
        - Another field that might be interesting to explore is a field for Hats of each participant (from Hats Protocol) with a Respect Eligibility module. That could for example make it easy for anyone in the community to play respect games with others and the admin/council of a community could award respect only to sufficiently respected community members
        - By the way, last week I created a public telegram group for exploring integrations and collaborations between Optimism Fractal and Hats Protocol. Everyone is welcome to join and there have already been some very interesting conversations with the founders of Hats Protocol happening there. You can see the group here and a project with much more about collaborations with Hats Protocol here. @nuno I think you might be interested in this :)
            - This could enable a kind of Respect for hosting respect games that Zaal mentioned
        - Funding article
            - I created a new project called[Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)