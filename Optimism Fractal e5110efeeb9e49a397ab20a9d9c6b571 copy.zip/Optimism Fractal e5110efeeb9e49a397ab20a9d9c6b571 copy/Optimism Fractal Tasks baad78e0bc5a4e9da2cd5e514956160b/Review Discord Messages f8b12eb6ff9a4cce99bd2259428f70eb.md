# Review Discord Messages

Project: Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md)
Status: Done
Summary: No content
Created time: January 11, 2024 12:23 PM
Last edited time: February 15, 2024 8:32 PM
Created by: Dan Singjoy

![Untitled](Review%20Discord%20Messages%20f8b12eb6ff9a4cce99bd2259428f70eb/Untitled.png)

![Untitled](Review%20Discord%20Messages%20f8b12eb6ff9a4cce99bd2259428f70eb/Untitled%201.png)

![Untitled](Review%20Discord%20Messages%20f8b12eb6ff9a4cce99bd2259428f70eb/Untitled%202.png)

![Untitled](Review%20Discord%20Messages%20f8b12eb6ff9a4cce99bd2259428f70eb/Untitled%203.png)