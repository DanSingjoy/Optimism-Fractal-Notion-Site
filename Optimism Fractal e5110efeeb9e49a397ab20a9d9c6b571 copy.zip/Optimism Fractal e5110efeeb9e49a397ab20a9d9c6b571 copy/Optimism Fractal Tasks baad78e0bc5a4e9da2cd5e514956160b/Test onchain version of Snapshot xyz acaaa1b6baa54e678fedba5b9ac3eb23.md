# Test onchain version of Snapshot.xyz

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to test the onchain version of Snapshot.xyz, a platform created by Dan Singjoy. The status of the task is currently not started, and it was created on June 3, 2024, at 2:17 AM.
Summary: No content
Created time: June 2, 2024 10:17 PM
Last edited time: June 2, 2024 10:17 PM
Created by: Dan Singjoy