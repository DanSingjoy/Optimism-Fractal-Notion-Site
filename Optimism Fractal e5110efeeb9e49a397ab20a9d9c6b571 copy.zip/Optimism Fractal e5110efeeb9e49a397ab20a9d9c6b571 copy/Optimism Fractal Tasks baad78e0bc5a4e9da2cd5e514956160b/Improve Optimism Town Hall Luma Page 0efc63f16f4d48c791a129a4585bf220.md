# Improve Optimism Town Hall Luma Page

Project: Improve Luma Events Pages and Calendar (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Luma%20Events%20Pages%20and%20Calendar%2048f8957739b34030974879b011c83d3c.md)
Status: Not started
Task Summary: This task aims to improve the Optimism Town Hall Luma Page by enhancing its content and structure. The goal is to create a more engaging and informative platform for community discussions about the Superchain, ensuring that participants can easily access relevant information and actively contribute to the agenda.
Summary: The Optimism Town Hall is a collaborative forum for discussions about the Superchain, featuring a game called Cagendas where participants propose and vote on topics using onchain reputation tokens. Events occur after Optimism Fractal weekly meetings, and video recordings are publicly shared. Participants are encouraged to engage in well-organized and impactful discussions, with resources available for proposing topics and joining the Respect Game.
Created time: August 20, 2024 9:37 AM
Last edited time: August 20, 2024 11:31 AM
Created by: Dan Singjoy
Description: The Optimism Town Hall is a collaborative forum for discussions about the Superchain, featuring a Cagendas game for topic selection using onchain reputation tokens. Events follow the Optimism Fractal weekly meetings, allowing participants to earn Respect and influence agendas. Video recordings are publicly shared, and attendees are encouraged to join discussions and propose topics through various linked resources.

## Version 2

A collaborative forum dedicated to conversations about Optimism, featuring innovative Community Agenda games where participants choose the topics!

Optimism Town Hall provides a special place to learn about the latest developments on the Superchain, help lead the Collective, and explore opportunities with the Optimism Fractal community. At each event we play a *Cagendas* game where you can propose, vote, and choose topics with onchain reputation tokens, which provides a fun and fair way to participate in community discussions. You're welcome to join the event in the [zoom room](https://us06web.zoom.us/j/82510562614) and register above for email reminders.

These events occur immediately after [Optimism Fractal](http://optimismfractal.com/) weekly events, where you can play the Respect Game and earn Respect to influence the agenda of each meeting. You can learn how to propose topics [here](https://optimystics.io/cagendas#block-70e5a90cf2d54a18876eb8626a7d3a69), play the Respect Game an hour earlier at Optimism Fractal [weekly events](https://lu.ma/4ggdpzyp), and explore this [article](https://optimystics.io/optimismtownhall) to learn more about Optimism Town Hall. You can also visit the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth) to view, vote, or propose topics for upcoming events.

The video recordings from the Optimism Town Hall are shared publicly as part of Optimism Fractal [videos](https://optimismfractal.com/media), so please only join if you're comfortable with this.  Hope to see you there!

- What is impactful?
- How is it well organized? What if its not?

- Join the experiments we’re running with topics that are happening in the superchain

well-organized, welcoming, and impactful discussions about the Superchain.

## August 2024 Version 1

The Optimism Town Hall is a collaborative space for well-organized, welcoming, and impactful discussions about the Superchain.

This event is pioneering onchain social games that enable community members to propose, vote, and choose topics together. You're welcome to join the event in the [zoom room](https://us06web.zoom.us/j/82510562614) and register above for email reminders. Topics for each week are chosen in a community agenda game called Cagendas using Respect earned at [Optimism Fractal](http://optimismfractal.com/).

You can learn how to propose topics [here](https://optimystics.io/cagendas#block-70e5a90cf2d54a18876eb8626a7d3a69), join to play the Respect Game an hour earlier at Optimism Fractal [weekly events](https://lu.ma/4ggdpzyp), and explore this [article](https://optimystics.io/optimismtownhall) to learn more about Optimism Town Hall. You can also visit the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth) to view, vote, or propose topics for upcoming events.

The video recordings from the Optimism Town Hall are shared publicly as part of Optimism Fractal [videos](https://optimismfractal.com/media), so please only join if you're comfortable with this. Hope to see you there!