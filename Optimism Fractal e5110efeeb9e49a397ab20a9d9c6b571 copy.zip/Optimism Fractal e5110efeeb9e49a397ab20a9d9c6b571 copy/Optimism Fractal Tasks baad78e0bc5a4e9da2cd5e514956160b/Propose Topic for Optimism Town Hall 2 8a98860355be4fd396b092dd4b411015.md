# Propose Topic for Optimism Town Hall 2

Project: Prepare for OF 28 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2028%2055526595a95345fd888501f23774c254.md)
Status: Done
Task Summary: This task aims to propose a topic for the Optimism Town Hall 2. The page provides details about the topic, including its creator, status, and creation/editing timestamps. The "Topics" section is currently empty and awaiting further information.
Summary: No content
Created time: May 25, 2024 5:28 PM
Last edited time: June 2, 2024 4:06 PM
Created by: Dan Singjoy

See [Prepare for Optimism Town Hall 3](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Prepare%20for%20Optimism%20Town%20Hall%203%203a4cc50ac4224ba5bfd09468eaa7d253.md) 

## Topics

[Untitled](Propose%20Topic%20for%20Optimism%20Town%20Hall%202%208a98860355be4fd396b092dd4b411015/Untitled%20a6f747a0771949e0beb7c1ea30ee28d3.csv)

- [Create topics for discussion to propose for Cagendas at Optimism Town Hall](Create%20topics%20for%20discussion%20to%20propose%20for%20Cagend%206ae17a37abe741d79914a64d0aca6ff5.md)

## Strategy

- [ ]  Propose 1-4 topics every Friday and share the message in the discord

- For each question, I should take extra time and care to prepare a great overview of materials for review
    - I should share this before the event as part of the promotional event as well so people can read up on it and have very informed opinions during the event
    - I should also prepare a nice presentation for each topic that includes all the best resources
    - For example, we can include relevant forum posts, blog posts, metrics garden, tweets, etc to give people a good overview of the discussion and set the stage for a great conversation

- If a topic includes polls where people can vote during the event to help answer a question, then this can be a big value add