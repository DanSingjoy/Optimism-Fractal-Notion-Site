# Add to the welcome guide that participants are encouraged to say links out loud and share their links on discord+notion

Project: Create Welcome Guide for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md), Formalize and Request Leads in Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Formalize%20and%20Request%20Leads%20in%20Optimism%20Fractal%201fb1919236b64800a839d21cbecfa306.md), Create Resources for hosts to implement the Respect Game in their communities or organizations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Resources%20for%20hosts%20to%20implement%20the%20Respec%204b3a3aacea0647e8b1f527b2d1dadc23.md)
Status: Done
Task Summary: This task aims to enhance the welcome guide by encouraging participants to vocalize and share their links during discussions. By promoting the sharing of links on Discord and Notion, we aim to create a more inclusive and engaging environment that values self-promotion and collaboration among participants.
Summary: Participants are encouraged to say their links out loud and share them on Discord and Notion to promote their work, making it more welcoming and easier for others to find. This approach values self-promotion during the respect game, enhancing the overall experience.
Created time: June 6, 2024 2:33 PM
Last edited time: August 8, 2024 2:05 PM
Created by: Dan Singjoy
Description: Participants are encouraged to verbally share links and post them on Discord and Notion to promote their work, fostering a welcoming environment and enhancing visibility. This practice is also to be included in the welcome, lead, and host guides.

- [x]  also add this to the lead and host guide
    - [x]  [Formalize and Request Leads in Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Formalize%20and%20Request%20Leads%20in%20Optimism%20Fractal%201fb1919236b64800a839d21cbecfa306.md)
    - [x]  [Create Resources for hosts to implement the Respect Game in their communities or organizations](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Resources%20for%20hosts%20to%20implement%20the%20Respec%204b3a3aacea0647e8b1f527b2d1dadc23.md)

- Encourage participants to share links to their work on discord and notion (and say any links out loud for listeners)
    - You can share your contributions in the #contributions channel on discord and the [Weekly Contributions](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Weekly%20Contributions%201c90e50f1e23408080b41c562d0dcd0b.md) page on notion
    - This makes it more welcoming for people to promote their work and easier for viewers or other participants to find their work
    - This makes it clear that self-promotion is valued and appreciated during the respect game, which increases the value proposition of promoting your work