# Develop OPF Tree V1 and V1.1

Project: Create tools and processes to track and prioritize projects and tasks for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20tools%20and%20processes%20to%20track%20and%20prioritize%20104241e49716490eb641cd12529159b9.md), Integrate Optimism Fractal and the Respect Game with RetroFunding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md)
Status: Not started
Task Summary: This task aims to develop the OPF Tree V1 and V1.1, which are pages created by Tadas Vaitiekunas to design OPF Trees. The task includes subtasks such as considering initial project weight, finding ways to reach consensus on a list of projects, and generalizing to a new version of Respect trees. The goal is to evaluate the structure and contributions of fractals in order to create a comprehensive view of their impact.
Summary: This document outlines the development of OPF Tree V1 and V1.1. It includes subtasks such as considering project weight and rewards, reaching consensus on project lists, generalizing to a new version of Respect trees, and evaluating fractals from different perspectives.
Created time: February 7, 2024 3:42 AM
Last edited time: June 4, 2024 11:52 AM
Created by: Tadas Vaitiekunas

## Description

Here are pages that Tadas created to design OPF Trees. The most recent design can be found towards the bottom of this page.

[OPF Tree V1.1.](Develop%20OPF%20Tree%20V1%20and%20V1%201%2074f99e1fb0d341499816c3e8ddb38669/OPF%20Tree%20V1%201%202af841e0096d4493b33695a2d1b9f04b.md)

[OPF Tree V1](Develop%20OPF%20Tree%20V1%20and%20V1%201%2074f99e1fb0d341499816c3e8ddb38669/OPF%20Tree%20V1%203a1649985578464b92989a17c2176b3c.md)

## Subtasks

- [ ]  Need to take into account initial project weight and reward projects which contribute to more respected projects more. Need to figure out a formula for that. I think it should probably be simple multiplication but should not take into account projects for which there are no fractals
- [ ]  Ways to reach consensus on a list of projects;
- [ ]  Generalize to a new version of Respect trees?
- [ ]  There are couple of perspectives to evaluate a fractal. Might be good to separate
    - [ ]  How it works (maybe it produced innovative structure or maybe it treats its participants badly, is centralized)
    - [ ]  How good are its contributions to a particular project;
    - [ ]  Broad view that encompasses both of the above
    

## Proposal

This is a proposal for a plan for growing Optimism Fractal. If implemented this plan could initiate a process, that would be repeatable every season (albeit modifications to this algorithm are expected, especially at the beginning of every season). The intent of this plan is to achieve the following:

1. Help RetroPGF review process through the creation of lists curated by Optimism Fractal;
2. Creating an ecosystem of fractal experiments on Optimism, where the most successful experiments get recognized (awarded) and the best innovations get integrated into Optimism Fractal (and potentially many other fractals);
3. Get more developers contributing to Optimism Fractal by helping Optimism Fractal developers get rewarded through RetroPGF;
4. Reach consensus on a list of projects relevant to Optimism Fractal and their priority. Besides clearing up the direction of Optimism Fractal, this would be useful for individuals and teams, who are not sure what to contribute;

This is something we could start this season with whatever tools we already have and gradually improve every season (improve process and toolset).

## 1. Definitions

- *Season* - somewhere between the end of a RetroPGF round and beginning of a new one;
    - this is not yet strictly defined, but it should adapt to the RetroPGF schedule since this process depends on it;

## 2. Process

Optimism Fractal would determine a list of projects and their priority at the beginning of the season. During the middle of the season, work would happen by individual teams on these projects. Near the end of the season, Optimism Fractal would evaluate teams, which have contributed the most. Finally, the RetroPGF lists would be created based on these evaluations, so that contributors could be rewarded according to their evaluation.

1. Determine a list of projects for Optimism Fractal and their priority (OPF project list);
2. *Time window to work on projects*
3. Evaluate teams contributing to Optimism Fractal;
4. Evaluate teams contributing to Optimism;
5. Create RetroPGF lists for each of the evaluations above;

To perform steps 1, 2, 4 and 5  [Respect-weighted polling](https://docs.snapshot.org/user-guides/proposals/voting-types#what-is-a-voting-type) in snapshot could be used. The simplest example would be a type of poll where any Respect holders can add their own options and Respect holders vote by distributing their Respect-weighted vote among options. In case of 1st and 2nd steps more Respect-weighted votes would signal a bigger priority of a work item. In case of 4th and 5th steps more Respect-weighted votes for a team means that the teams contributions have more value.

OPF project list would be a list of projects, which directly serve Optimism Fractal the most.

To help perform steps 3 and 4 events could be hosted where teams present their work to Optimism Fractal participants. Something like RetroPitches, which have already been done during previous RetroPGF round. In case teams have been working on projects that have been ranked highly in step 1, they can present that as an argument for the value of their contributions.

## 3. Benefits

Optimism Fractal can help any RetroPGF applicant. Besides the opportunity to pitch your project in break-out groups they also get these benefits:

- They can use results from the evaluation polls as impact metrics in their RetroPGF application;
- They get a chance to be in a RetroPGF list derived from a decentralized consensus process;

Optimism Fractal can help badge-holders by providing a list determined by a fair and decentralized consensus process.

For Optimism Fractal this creates means for contributors to get rewarded. OPF project list can also help clarify direction of Optimism Fractal. This would be useful for individuals and teams who are not sure what to contribute.

### 3.1. Ecosystem of fractal governance experiments

The best strategy for contributing teams might be to create fractals using the same software as Optimism Fractal and improve it rapidly according to their needs while keeping them aligned with the needs of Optimism Fractal. This can help them determine the distribution of RetroPGF rewards (basing them on Respect). But more importantly (and why it's the best strategy), by improving this fractal software for themselves they are actually serving Optimism Fractal as well. This means that they might be able to participate in both lists created by Optimism Fractal (potentially doubling the rewards). If this is truly the best strategy then that benefits Optimism Fractal and the ecosystem as a whole greatly. For Optimism Fractal this can help do upgrades. It can simply look at what the best-contributing teams are using and adapt it to its own needs. So most innovations in fractal toolset would happen in smaller contributing fractals, with Optimism Fractal taking what works best. This would enable Optimism Fractal to improve without taking huge risks by deploying untested software.

Overall output of this whole ecosystem would be a truly fractal governance structure. A DAO toolset that would work for teams of all sizes at all levels of a hierarchy.