# Explore Integrations with Luma Events and Hats Protocol

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: The document discusses the potential integration of Luma Events and Hats Protocol, including the use of token gating features on the events site and the importance of such features in light of emerging deep fake technology. It also mentions the possibility of token gating with Higher Order Fractal events.
Parent-task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created time: March 18, 2024 7:16 PM
Last edited time: March 18, 2024 8:06 PM
Parent task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created by: Dan Singjoy

## Description

- 

## Composing Hats with Luma

- Our events site (lu.ma) also includes token gating features so at some point we could require that participants sign a transaction onchain and/or have some other attestations (such as x amount of respect) in order to participate in weekly meetings.
- I think this will become increasingly important this year with the emergence of real time deep fake technology, as you can see [here](https://twitter.com/LinusEkenstam/status/1735629674598769012).
- There could also be token gating with [Higher Order Fractal](Respond%20to%20Tadas%20about%20Higher%20Order%20Fractals%20and%20F%204ed31784754b4b24a070337384298bb4.md) events

- [Explore and Test Integrations with Respect Eligibility Module](https://www.notion.so/Explore-and-Test-Integrations-with-Respect-Eligibility-Module-e2ce61220d214f85812dc1e40a1b973e?pvs=21)