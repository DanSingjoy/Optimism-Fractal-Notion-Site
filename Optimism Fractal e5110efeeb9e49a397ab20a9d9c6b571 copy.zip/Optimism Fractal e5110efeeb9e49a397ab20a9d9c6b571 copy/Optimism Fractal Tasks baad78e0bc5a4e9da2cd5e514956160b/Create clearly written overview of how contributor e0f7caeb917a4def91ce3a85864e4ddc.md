# Create clearly written overview of how contributors to optimism fractal can earn from RetroPGF

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: In progress
Task Summary: This task aims to provide a clear and concise overview of how contributors to Optimism Fractal can earn from RetroPGF. It covers various opportunities for funding, steps to earn, and ways to make an impact within the Optimism Collective.
Summary: To earn from RetroPGF and contribute to Optimism Fractal, follow these steps: 1) Learn about Optimism and explore notion projects, 2) Contribute to projects that interest you and join weekly events, 3) Make an impact by promoting your work and participating in Optimism Town Halls, 4) Apply for funding through RetroFunding and other platforms, and 5) Promote your work and network with others. There are various opportunities to earn funding and make a positive impact, so take advantage of them.
Created time: March 26, 2024 11:55 AM
Last edited time: July 16, 2024 9:40 AM
Parent task: Create OptimismFractal.com/funding to show how Optimism Fractal can help people earn RetroFunding and other funding (Create%20OptimismFractal%20com%20funding%20to%20show%20how%20Opt%2045915c303ab94868b62bc2124430da06.md)
Created by: Dan Singjoy
Description: This document provides an overview of how contributors to Optimism Fractal can earn from RetroPGF. It includes information on funding opportunities, how to earn, how to make an impact, how to apply, and other opportunities available. Contributors can join events, contribute to projects, promote their work, and apply for RetroFunding. The document emphasizes the importance of creating impact and earning Respect within the collective.

# To Do

- [ ]  organize the following into subtasks
- [ ]  consider doing an audio note about this, then use AI to summarize

## Organize and create pages in notion for funding

- [ ]  add this to [Create [OptimismFractal.com/funding](http://OptimismFractal.com/funding) to show how Optimism Fractal can help people earn RetroFunding and other funding](Create%20OptimismFractal%20com%20funding%20to%20show%20how%20Opt%2045915c303ab94868b62bc2124430da06.md)

- [ ]  add notes from [Post in Optimism Fractal Developer Chat about development hub, superchain developments, and responding to nestor](https://www.notion.so/Post-in-Optimism-Fractal-Developer-Chat-about-development-hub-superchain-developments-and-respondi-969041b4397b47ba88b1b0171b0f3a71?pvs=21)

- [ ]  create funding opportunities page above the projects section
    - Right now there is project for funding opportunities, but it really should be a featured page in the notion site
    - [ ]  After building it in the notion site, it should probably also be added to [OptimismFractal.com](http://OptimismFractal.com)
        - [ ]  add this to [Update OptimismFractal/Optimystics’ websites](https://www.notion.so/Update-OptimismFractal-Optimystics-websites-ce0a2d7d71dc4b3c9d6bdfc8d36d986b?pvs=21)

## Promote Funding Opportunities

Did you know that you can earn funding by helping Optimism Fractal?

The biggest funding opportunity is RetroPGF. The Optimism Collective has allocated 850 OP towards funding public goods and Optimism Fractal is creating many public goods that are aligned with Optimism.

### RetroPGF Opportunities

The Optimism Foundation has announced 4 rounds of RetroPGF throughout 2024:

- Onchain Builders: …
- Governance
- …
- ….

Contributions to Optimism Fractal could be eligible for all four categories, though the rounds for Onchain Builders, Governance, and Dev Tooling are most fitting.  

- [ ]  add pictures from optimism article
- [ ]  create picture or use existing picture for

## How to Earn

- How can we break it down into the simplest instructions possible?
    - Keep in mind that 99.9999% of people don’t know what RetroFunding is, and most of the current community doesn’t know exactly how to earn funding.
    - Maybe we should make guides for absolute beginners and for people who already know a lot but not everything

1. Learn: 
    - It will take some time to learn the best ways for you to help
    - Join weekly events,
        - [Create Calendar of Events for Optimism Collective](Create%20Calendar%20of%20Events%20for%20Optimism%20Collective%206f142fcf13744f73bf57b2cf7d454160.md)
    - Learn about Optimism and see how you can help.
    - Explore notion projects,
        - [Optimism Fractal](../../Optimism%20Fractal%20e5110efeeb9e49a397ab20a9d9c6b571.md)
        - [Curate and create educational resources about the Optimism Collective](Curate%20and%20create%20educational%20resources%20about%20the%20%2058dc4c51824a4e27b6c4863bdcc8cf16.md)

1. Contribute: 
    - Choose to start working on projects that interest you
        - [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)
        - [Build Optimism Fractal Education Hub](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md)
    - Joining is a contribution in itself.

1. Make an impact: 
    - Promote your work and earn Respect every week as peers review your work
    - Contribute to Optimism Fractal
        - Participate in Optimism Town Halls to help lead Optimism Collective Governance for Round 6.
        - Help build Optimism Fractal tooling for collective decision making to earn from Round 7
        - Help in any other way to be eligble for RetroFunding, airdrops, and upcoming opportunities
            - With Impact=Profit,  lifetime contributions are rewarded
                - Ether’s pheonix and Optimistic vision- link

1. Apply for funding
    - Apply to RetroFunding,
    - Gitcoin, Octant, RetroPGF, Ethereum
    - See our guide or page for schedule of opportunities
        - [Create [OptimismFractal.com/funding](http://OptimismFractal.com/funding) to show how Optimism Fractal can help people earn RetroFunding and other funding](Create%20OptimismFractal%20com%20funding%20to%20show%20how%20Opt%2045915c303ab94868b62bc2124430da06.md)
        - [Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
        - [Organize Funding partnerships and monetization opportunities](https://www.notion.so/Organize-Funding-partnerships-and-monetization-opportunities-b7b5049895704f9ea259f5d88c6f21c1?pvs=21)
    - Join events and read discord to stay on top of latest

1. Promote
    - Share at RetroPitches and Respect Games
    - Network
    - [Respond to Will T in Eden Fractal and Optimism Fractal telegram chats about Let’s Grow Live broadcasts for livestream ](https://www.notion.so/Respond-to-Will-T-in-Eden-Fractal-and-Optimism-Fractal-telegram-chats-about-Let-s-Grow-Live-broadcas-88273bd248df4e7887b32a77ea0731cb?pvs=21)

### How to Make an Impact

No matter what kinds of skills or work you specialize, there is opportunity for everyone to earn from RetroPGF by contributing to Optimism Fractal and making a positive impact. Huge amount of work that can be done and low hanging fruit.

- Earn Respect
    - Respect can be used to signal the impact that you’ve created for the collective.
        - We’re working towards Respect Trees and RetroPitches combinations to
- Build with Optimism Fractal
    - Build software and integrations with Respect Game
    - Check out the development hub [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)
- Promote Optimism Fractal
- Promote your work in Superchain Builders show
- Participate in events
    - [Can i join Optimism Fractal even if I’m not contributing to Optimism? ](../Optimism%20Fractal%20FAQ%201ce16d6520064186b40f6ad1f211c5f3/Can%20i%20join%20Optimism%20Fractal%20even%20if%20I%E2%80%99m%20not%20contri%20e14066de522d4e7d9d40916adf74c89c.md)
- Play RetroPitches

### How to Apply

onchain builders, governance, and dev tooling

1. Create impact for Optimism by helping Optimism Fractal. Join events and see how you can contribute. Pick up a task or project that you think will be impactful and start working to create as much impact as possible before the rounds start in May.

1. Create an application that shows the contributions that you created for optimism fractal and how it created impact for the collective in the categories 
    1. Application could be individual or team
    2. You could apply to earn from RetroPGF as an individual, a team that you create, or a team that you help
    3. Include both the contribution, impact, and impact metrics
    4. Feel free to reach out to the Optimystics or other community members for support

Links to rounds and recap video and more

You could be eligible to RetroFunding in May-July if there’s any way that you can create a positive impact for Onchain builders 

contributions and impact carry over

Big news! Optimism announced the next four rounds of [RetroFunding](https://twitter.com/Optimism/status/1772664299359707556) (aka RetroPGF) today. The first round is Onchain Builders and applications open in May. After that I think we can apply to the rounds for Governance and Dev Tooling in August and October. There’s a [blog](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU) article and forum [post](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861) with more details. You can learn more in the [video](https://drive.google.com/file/d/1tEgcnEPWvb0IOVmHZEBt8w3ySK6Vj-sY/view?usp=sharing) and [recap](https://gov.optimism.io/t/optimism-community-call-recaps-recordings-thread/6937/33) from today’s Optimism community call. More details about the first round will be announced in the next few weeks…

[850M OP Dedicated to the Evolution of Retro Funding](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU)

[https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU)

[https://twitter.com/Optimism/status/1772664299359707556](https://twitter.com/Optimism/status/1772664299359707556)

### Other Opportunities

Missions usually happen every few months. So you could propose a mission or fulfill a mission. If there are any large projects that you have in mind and you need funding in order to do them, then consider starting to draft a mission proposal now so you’ll have it ready by the next season

Add RetroPGF article to post to of discord 

There are also many other important projects that need work and I’d be interested to hear if you have other ideas in mind about how you’d like to help. Tadas and Vlad are interesting in collaborating as well, though I think they’re mostly focused on the Respect Game app and Respect Trees so they don’t have much extra bandwidth to do other projects now and we’d all appreciate your help. Overall I think there’s a lot of ‘low hanging fruit’ that we could develop fairly quickly and we’d just need to figure out what fits best with your time and interests. There are also excellent funding opportunities available for doing development for Optimism Fractal (such as [RetroFunding](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU)) and I’d be happy to help you earn compensation for your work.