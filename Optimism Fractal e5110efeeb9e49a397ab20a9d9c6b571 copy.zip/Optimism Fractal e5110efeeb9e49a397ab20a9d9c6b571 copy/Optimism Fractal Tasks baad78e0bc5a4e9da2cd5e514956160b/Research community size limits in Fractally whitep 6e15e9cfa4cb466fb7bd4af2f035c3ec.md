# Research community size limits in Fractally whitepaper

Project: Research Community Limit Size (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Community%20Limit%20Size%2047629842db294dfbada49b38b739d858.md)
Status: Not started
Summary: The document provides information about the research community size limits in the Fractally whitepaper. It includes links to the Fractally website, a blog post about fractal democracy, and a Google Drive document.
Created time: March 19, 2024 8:36 PM
Last edited time: March 19, 2024 8:45 PM
Created by: Dan Singjoy

## Description

![[https://fractally.com/](https://fractally.com/)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Community%20Limit%20Size%2047629842db294dfbada49b38b739d858/Untitled%201.png)

[https://fractally.com/](https://fractally.com/)

[fractally | Next Generation DAOs](https://fractally.com/)

![Untitled](Research%20community%20size%20limits%20in%20Fractally%20whitep%206e15e9cfa4cb466fb7bd4af2f035c3ec/Untitled.png)

![Untitled](Research%20community%20size%20limits%20in%20Fractally%20whitep%206e15e9cfa4cb466fb7bd4af2f035c3ec/Untitled%201.png)

![Untitled](Research%20community%20size%20limits%20in%20Fractally%20whitep%206e15e9cfa4cb466fb7bd4af2f035c3ec/Untitled%202.png)

[What is Fractal Democracy?](https://fractally.com/blog/what-is-fractal-democracy)

![Untitled](Research%20community%20size%20limits%20in%20Fractally%20whitep%206e15e9cfa4cb466fb7bd4af2f035c3ec/Untitled%203.png)

![[https://drive.google.com/file/d/1HmLjHQBl75TOGzqRu25EtwVTLin-RjEz/view](https://drive.google.com/file/d/1HmLjHQBl75TOGzqRu25EtwVTLin-RjEz/view)](Research%20community%20size%20limits%20in%20Fractally%20whitep%206e15e9cfa4cb466fb7bd4af2f035c3ec/Untitled%204.png)

[https://drive.google.com/file/d/1HmLjHQBl75TOGzqRu25EtwVTLin-RjEz/view](https://drive.google.com/file/d/1HmLjHQBl75TOGzqRu25EtwVTLin-RjEz/view)