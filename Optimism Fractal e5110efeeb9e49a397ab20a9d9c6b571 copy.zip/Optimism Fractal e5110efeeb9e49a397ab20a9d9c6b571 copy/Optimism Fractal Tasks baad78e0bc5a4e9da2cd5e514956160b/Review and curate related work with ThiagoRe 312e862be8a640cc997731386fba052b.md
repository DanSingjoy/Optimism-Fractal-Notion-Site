# Review and curate related work with ThiagoRe

Project: Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md)
Status: Not started
Task Summary: This task aims to review and curate related work with ThiagoRe, a web3 social media platform empowered by fractal cooperative council. The platform allows creators to share content, interact with communities, and earn Thiago tokens. Created by Dan Singjoy, this task is currently in the planning stage with more details to be explored.
Summary: ThiagoRe is a web3 social media platform that allows creators to share content and interact with communities while earning Thiago tokens. It is created by Pascal NC, a leader in the Eden Fractal and Alien Worlds Fractal communities. More information can be found on http://thiagore.info/ and https://www.thiagore.com/. Pascal also launched http://edendonations.com/ to support open-source tools for fractal governance in Web3.
Created time: July 5, 2024 2:00 PM
Last edited time: July 5, 2024 2:30 PM
Parent task: Review and curate historical research and experiments with fractal social media (Review%20and%20curate%20historical%20research%20and%20experime%20ea73c13b0b63432d845e9f534e611504.md)
Created by: Dan Singjoy
Description: ThiagoRe is a web3 social media platform that allows creators to share content and interact with communities while earning Thiago tokens. It is created by Pascal NC, a leader in the Eden Fractal and Alien Worlds Fractal communities. More information can be found on http://thiagore.info/ and https://www.thiagore.com/. Pascal also launched http://edendonations.com/ to support open-source tools for fractal governance in Web3.

- [ ]  Find the Eden Fractal show notes about this
    - [ ]  Around [EdenFractal.com/34](http://EdenFractal.com/34) or somewhere around there,

### ThiagoRe

ThiagoRe is a web3 social media platform empowered by fractal cooperative council. The blogging platform enables creators to share content and interact with communities while earning Thiago tokens through an innovative, decentralized ‘UpLove' system. 

The SocialFi app is created by Pascal NC, a successful entreprenuer who is a leader in the Eden Fractal and Alien Worlds Fractal communities. You can learn about ThiagoRe by exploring [ThiagoRe.info](http://thiagore.info/), reading the [whitepaper](https://www.thiagore.info/whitepaper.html), and interacting on the platform on [ThiagoRe.com](https://www.thiagore.com/). 

You can learn more and watch Pascal introduce ThiagoRe at an Eden Fractal meeting in this [article](https://edenfractal.com/36#9a608bed95b649d484e8cbfb0e862bf1). In addition to building ThiageRe, Pascal also recently launched [EdenDonations.com](http://EdenDonations.com) to help fund ****open-source tools for fractal governance in Web3.

## Eden Fractal Story

 I wrote a bit about ThiagoRe in this week’s show notes and included timestamps for the presentation you shared during our breakout room last week. You can see the short story, links, and video presentation [here](https://edenfractal.com/36#9a608bed95b649d484e8cbfb0e862bf1). 

## Eden Town Hall Story

[32:29](https://www.youtube.com/watch?v=XiotcOZLGi8&t=1949s) Dan suggests moving onto next topic. Shares screen D news, shows tools. Recommends everyone check it out. Perry points out suggest button, click on to make suggestions. Great feature. Next topic Thiago Re, just launched by Pascal. Shared screen on website, explains details. Gives details on how it will work.

[43:22](https://www.youtube.com/watch?v=XiotcOZLGi8&t=2602s) Lennie gives more light on Thiago Re details , all content related to bitcoin or eos , wide scoped, focused on antelope.

![Untitled](Review%20and%20curate%20related%20work%20with%20ThiagoRe%20312e862be8a640cc997731386fba052b/Untitled.png)

![Untitled](Review%20and%20curate%20related%20work%20with%20ThiagoRe%20312e862be8a640cc997731386fba052b/Untitled%201.png)

![Untitled](Review%20and%20curate%20related%20work%20with%20ThiagoRe%20312e862be8a640cc997731386fba052b/Untitled%202.png)