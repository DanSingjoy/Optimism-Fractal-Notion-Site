# Create Checklist of Tasks to Prepare for each show or meeting

Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Not started
Task Summary: This task aims to create a comprehensive checklist of tasks to prepare for each show or meeting. By outlining the necessary steps and responsibilities, this checklist will help ensure smooth event execution and enhance collaboration among team members.
Summary: A checklist for preparing shows or meetings includes starting the Zoom room early, conducting sound checks, testing functions, and sending promotional messages. It emphasizes collaboration, smooth execution, and automation of the preparation process. Key tasks involve developing a comprehensive checklist and ensuring technical aspects are addressed before events.
Created time: July 7, 2023 10:02 AM
Last edited time: August 29, 2024 12:59 PM
Created by: Dan Singjoy
Description: A checklist for preparing shows or meetings includes starting the Zoom room early, conducting sound checks, testing functions, and sending promotional messages. It emphasizes collaboration, smooth execution, and automation of the preparation process. Additional tasks involve enabling recording permissions and facilitating discussions after events. Key points highlight the importance of thorough preparation for successful events.

## Checklist

- [ ]  Start zoom room at least 15 minutes earlier
    - [ ]  Do a sound check to ensure good audio output and input
    - [ ]  Turn off VPN to improve internet connection
    - [ ]  Test screenshare function in zoom
    - [ ]  Check activity monitor to make sure there is enough RAM and CPU
    - [ ]  Start a new meeting note and position the window for easy accessibility for notes during the meeting
    - [ ]  Set up welcoming music
    - [ ]  Set up welcoming video
    - [ ]  Send out promotional message
    - [ ]  Send out promotional message with Cagendas topic two days before event (this is probably better suited as a task in the project, whereas i think these other ones could just to do list blocks in the same page
        - [ ]  Consider the best way to organize this

- [ ]  Add this to the template for each project so we can easily generate the same tasks again for each show or meeting

- [ ]  Make sure the ‘Before the Respect Game’ easle shows at each event immediately before

- [ ]  Review [Blog Post Checklist](https://www.notion.so/Blog-Post-Checklist-f5efe05b630a43e0b247091c8b1ac94b?pvs=21) [Podcast Checklist](https://www.notion.so/Podcast-Checklist-5aba67c304e640c7a6f1b17627558ec0?pvs=21) [Publishing Checklist](https://www.notion.so/Publishing-Checklist-37b91ba5ec1b4e2c98dc8ecbd10f9a24?pvs=21) [Editing Checklist](https://www.notion.so/Editing-Checklist-00fab76bf8ed4065b3ed89ac62ab8d6a?pvs=21) from Thomas Frank for inspiration

## After 17 UTC

Can Rosmari do these instead of Dan? If so, add them to her checklist.

- [ ]  Enable recording permissions for each participant

- [ ]  Share link to [OptimismFractal.com/welcome](http://OptimismFractal.com/welcome)
    - Perhaps also [OptimismFractal.com/lead](http://OptimismFractal.com/leads)

## After the Respect Game

- If we’re able to return to the community room 10 minutes before the Town Hall, then there’s an opportunity for more open discussions
- If anyone is new then it’s a good time for introductions and feedback about their first experience
- Another little process/game that could be helpful is to ask some or each person to share a recap of what they shared in the respect game
    - For example, they could each speak for 15-20 seconds with a quick recap
    - Or only the people who earned level (5 or) 6 could speak
    - Or you could get 10 seconds to speak for each level that you earned
    - These are variations on the same process that may be worth experimenting with and could help make the community more informed and spark discussions. It could also synergize well with the videos of breakout rooms and contributions database/discord to allow people to preview/promote their work
        - This could also be a game for town hall. What would this game be called? Recaps? ReCAPS?

d

## Inspiration

- @Rosmari made a great point about doing this to be more prepared for meetings like Eden Fractal.
    - I completely agree that a check-list of things that we should prepare for each meeting is an excellent idea that will help us host better events and shows for everyone
    

## Pre-Event Checklist

- Rosemary and I will join 15 minutes early for each event
- Go through the pre-event checklist together
- Ensure proper screen sizing, audio quality, and other technical aspects

### Key Points

- Ensures smooth event execution
- Promotes collaboration and communication
- Automates the preparation process

### To-Do

- Develop a comprehensive pre-event checklist
- Automate the checklist process as much as possible
- Remind each other to follow the checklist, especially in the beginning