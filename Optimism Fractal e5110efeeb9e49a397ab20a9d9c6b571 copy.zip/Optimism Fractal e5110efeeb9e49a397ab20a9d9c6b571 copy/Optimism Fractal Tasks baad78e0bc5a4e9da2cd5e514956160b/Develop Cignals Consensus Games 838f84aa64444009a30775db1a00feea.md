# Develop Cignals Consensus Games

Project: Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md), Create different kinds of consensus games for seasonal celebrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20different%20kinds%20of%20consensus%20games%20for%20seas%20a62e1ceb57514af3ae9999b57973df4c.md), Create branding and educational resources for decision-making consensus games (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20branding%20and%20educational%20resources%20for%20deci%20188c45e0a1dc4773bd8202133ced6eb7.md), Create ways for community members to use Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20use%20Respect%20e74f7fadcdfd43f089f062594b5b06d4.md)
Status: Not started
Summary: No content
Created time: May 1, 2024 7:53 AM
Last edited time: May 1, 2024 10:29 AM
Created by: Dan Singjoy

## Description

This tooling could be branded as Cignals, which is a portmanteau of community and signals. The Cignals brand has been developing for over a year and has been used at several events to describe how communities can collectively send signals and individuals within a community can signal their opinions to each other (including during events to improve real-time coordination). The following articles provide an overview of Cignals and it’s pilot use cases so far. More resources and projects related to Cignals can be shared here if it would be helpful.

[Optimystics.io/cignals](http://Optimystics.io/cignals) 

[EdenCreators.com/cignals](http://EdenCreators.com/cignals) 

[https://optimystics.io/exploringretropitches](https://optimystics.io/exploringretropitches)

[Develop Cignals Consensus Games ](Develop%20Cignals%20Consensus%20Games%20838f84aa64444009a30775db1a00feea.md)