# Prepare for S6 Election Town Hall to present self-nomination for Optimism Grants Council

Assignee: Dan Singjoy
Due: June 9, 2024
Project: Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md), Explore Mission Opportunities in Optimism Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md)
Status: Done
Task Summary: This task aims to prepare for the S6 Election Town Hall where Dan Singjoy will present their self-nomination for the Optimism Grants Council. The document provides an overview of Dan's background, skills, and impact on the KPIs, highlighting their experience in Web3 and community-building efforts.
Summary: Dan Singjoy is presenting his self-nomination for the Optimism Grants Council. He highlights his background in Web3, experience in Optimism, and his contributions to the community. He emphasizes his skills in applicant satisfaction, task management, and community leadership. He expresses excitement about contributing to the grants council and thanks everyone for their attention and consideration.
Created time: June 7, 2024 7:46 PM
Last edited time: June 11, 2024 1:35 PM
Created by: Dan Singjoy

- Thank you Maxell, great to hear from all the nominees

- Hi, I'm Dan Singjoy and I’m asking for support to be a Optimism Mission Review

- **Background, Unique Skills, and Habits to help** *Grants Council to ensure it delivers measurable impact towards the approved KPIs*

- I have seven years of experience in Web3 and have been working full time in Optimism for about one year

- I'm the creator and host of Optimism Fractal, a community fostering collaboration and awarding public good creators on Optimism with weekly events playing onchain social games with builders

- Founder of the Optimystics, a team that builds open-source software for innovative consensus processes and onchain reputation systems that empower builders

- Recently launched a new community event and open collaborative called Optimism Town Hall to help more people contribute discussions about Optimism

- Everyone is welcome to join these events to collaborate with innovators and learn more on Thursdays at 17 UTC.
    - The weekly Optimism Fractal and Town Hall events provide unique opportunities personal connection with applicants in the Grants Council
    
- Technical Background: Coordinate open source development site and work closely with developers. I’ve done deep research into the OP ecosystem as a builder and have deep understanding of the challenges and opportunities for applicants

- I understand the intricacies of the grant process after creating mission requests and mission proposals over the past two season. I also created hosted community events and created videos with an overview of these processes to help other builders

- **Impact on KPIs**
    - My unique skills help increase satisfaction for applicants in the programs and make sure that all applicants get the attention they deserve.
    - Very organized with task management, high rate of satisfaction with everyone who I’ve collaborated, and generally very patient and kind
    - I’m really excited about all the Optimism is doing and that we’ll do together to create the optimistic vision
    
- **Closing**
    - Thank you all so much for your attention and consideration.
    - I appreciate your support, and look forward to contributing to our shared success at the grants council.

- Drafts
    
    
    - **Applicant Satisfaction**: My unique skills and habits ensure all applicants receive the attention they deserve, increasing their satisfaction with the program.
    
    - **Educational Contributions**: Hosting and producing content for Optimism Fractal has honed my ability to educate and inspire the community, directly impacting builder satisfaction.
    
    - **Community Leadership**: Founding Optimystics, I have led initiatives that grow Optimism through engaging communities and creating impactful content.
    
    - [ ]  Review KPIs below and answer question
    - [ ]  Give AI my application, the question, and the KPIs and ask it to answer in 60 seconds while also highlighting why my unique experience helps with this
    
    The structure of the Town Hall will be each nominee will have 60 seconds to answer one question from the Foundation:
    
    - *What unique skills or habits will you bring to the Grants Council to ensure it delivers measurable impact towards the approved KPIs?*
    
    - *What unique skills or habits will you bring to the Grants Council to ensure it delivers measurable impact towards the approved KPIs?*
    
    [Grants Council S6 Election Town Hall](https://gov.optimism.io/t/grants-council-s6-election-town-hall/8268)
    
    ![[https://gov.optimism.io/t/grants-council-s6-election-town-hall/8268](https://gov.optimism.io/t/grants-council-s6-election-town-hall/8268)](Prepare%20for%20S6%20Election%20Town%20Hall%20to%20present%20self-%206d8119fb23fd40718cf3522ff9d506c5/Untitled.png)
    
    [https://gov.optimism.io/t/grants-council-s6-election-town-hall/8268](https://gov.optimism.io/t/grants-council-s6-election-town-hall/8268)