# Create ‘Prepare for OF’ Template

Assignee: Dan Singjoy
Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Not started
Task Summary: This task aims to create a template for preparing for OF (Unknown acronym). It includes a button that needs to be copied from the "Prepare for OTH" project. The goal is to review prior notes and handle the task within the project without involving Rosmari yet, to avoid complicating the process and potential confusion.
Summary: Dan Singjoy is creating a 'Prepare for OF' template. He suggests considering copying a button from 'Prepare for OTH'. He also plans to review his prior notes and handle the project himself to avoid complicating it with a sub-project and potentially confusing Rosmari.
Created time: June 13, 2024 9:21 PM
Last edited time: June 28, 2024 2:06 PM
Created by: Dan Singjoy

- A button here hasn’t been started yet

- [ ]  consider copying the button from prepare for OTH

- review my prior notes, but just take care of it in my project without asking Rosmari to start working in this project yet
    - this will be better to avoid overcomplicating it with the sub-project and risking her getting thrown off by the new system