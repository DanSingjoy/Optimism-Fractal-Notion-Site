# See response from GALXE support via email about Quests

Project: Experiment with tools and growth strategies for incentivizing respect game playing  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Experiment%20with%20tools%20and%20growth%20strategies%20for%20in%204f707f64dbaf4465af0eb7128edd105d.md), Explore and Implement Incentivization Solutions to Promote the Growth of Fractals (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Implement%20Incentivization%20Solutions%20to%206b2385ffa8a04fb29728c1f363eba8ee.md)
Status: Not started
Task Summary: This task aims to provide a summary of the response received from GALXE support via email regarding Quests. The page includes information about the creator, status, and timestamps of the email. It also features two untitled images.
Summary: No content
Created time: May 20, 2024 11:40 AM
Last edited time: May 20, 2024 11:42 AM
Created by: Dan Singjoy

![Untitled](See%20response%20from%20GALXE%20support%20via%20email%20about%20Qu%209f7c090e84de471d9bc3b566757dfb44/Untitled.png)

![Untitled](See%20response%20from%20GALXE%20support%20via%20email%20about%20Qu%209f7c090e84de471d9bc3b566757dfb44/Untitled%201.png)