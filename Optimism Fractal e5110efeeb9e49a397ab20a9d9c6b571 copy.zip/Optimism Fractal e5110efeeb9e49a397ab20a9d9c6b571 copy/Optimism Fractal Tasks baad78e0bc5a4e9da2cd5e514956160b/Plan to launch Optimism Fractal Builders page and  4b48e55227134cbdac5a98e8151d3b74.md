# Plan to launch Optimism Fractal Builders page and Review Design Considerations

Project: Create Optimism Fractal Builders Site (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Builders%20Site%20b2364cd97d724ac78f2b7f30c2f476c2.md), Implement contributor funding in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Implement%20contributor%20funding%20in%20the%20Optimism%20Coll%20e94cb8eb2b5246ebaa47d1088b49b1cc.md), Improve Weekly Contributions Page and Workflows (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Weekly%20Contributions%20Page%20and%20Workflows%2038634e026b854eedabd1ddd5cc273106.md)
Status: Not started
Task Summary: This task aims to outline the plan for launching the Optimism Fractal Builders page while also reviewing the necessary design considerations. The goal is to ensure that the page effectively serves its intended audience and meets all relevant design standards.
Summary: The plan to launch the Optimism Fractal Builders page includes reviewing design considerations and potentially creating tasks for each aspect, as well as considering what information should be made public.
Created time: August 11, 2024 1:17 PM
Last edited time: August 11, 2024 1:23 PM
Created by: Dan Singjoy
Description: A plan to launch the Optimism Fractal Builders page includes reviewing design considerations and potentially creating tasks for each aspect, as well as considering what information to make public.

- [ ]  review and consider making tasks for each in [Create Optimism Fractal Builders Site](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Builders%20Site%20b2364cd97d724ac78f2b7f30c2f476c2.md)

- [ ]  consider making the following public: [Consider best ways to transition participants in Optimystics CRM to bootstrap Optimism Fractal Builders Site](https://www.notion.so/Consider-best-ways-to-transition-participants-in-Optimystics-CRM-to-bootstrap-Optimism-Fractal-Build-ef810aef951549e387d660931bee9185?pvs=21)

We discussed this on August 9th and decided that it’s best to keep records for all the Fractal participants in the Optimystics CRM Database for now, then carefully consider the next steps.

After some time for deliberation, I think the plan is to move OF participants to a separate OF builders database which is still kept in the Optimystics database, but made public and shown as a linked view of the database in the Optimism Fractal notion site at [Builder Profiles](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Builder%20Profiles%20c1d07ecb1c1b494aa2bc02189b0391ee.md). Then the Optimystics will give full access to people who request access for their personal page. So the entire database will be public but uneditable except for by the Optimystics or each person that requests and is granted access to write on their page.

## Considerations

- competitive advantage for Optimism Fractal community to have all the OF participants contact info in one spot, and how this could be potentially misused by competitors

- privacy implications, potential benefits, and preferences of participants
    - it’s not right for us to share the email in a public or community database since they haven’t opted into this
    - there’s a lot of potential benefit to curating this information if it’s done well
    - A good way to solve this is to [Add sign up form with onchain responses to indicate participant preferences regarding public or community database and shared information](Add%20sign%20up%20form%20with%20onchain%20responses%20to%20indicat%2031dc334562b841598fff02d27ad5f3f6.md)

- potential for be featured on the Builders site to be an exclusive opportunity only for people who have earned x amount of Respect
    - I think this is generally a good idea. Or perhaps there’s some tiers of access- so a low amount of respect is needed to be in the database, and more respect needed to be featured near the top or have full access
    - The usage of Hats protocol to automate access to each person’s page
    
- the potential to add this page directly to [optimismfractal.com/builders](http://optimismfractal.com/builders)

- the potential to include linked view of contributions database on each builder page by default, so that when they add contributions each week then it will automatically show up on their page
    - I think this is good idea.
        - [ ]  [Consider creating a template for the Optimism Fractal Builders site to minimize set up time for each profile page](Consider%20creating%20a%20template%20for%20the%20Optimism%20Frac%20bbd93818221744329356eaa9184bbc0e.md)
            - what other things should be on the template. maybe we should create a task to design a template for the Optimism Fractal Builders site
            - [ ]  [Consider if we should also create a template for the weekly contribution submission in ‣ ](Consider%20if%20we%20should%20also%20create%20a%20template%20for%20t%2079c08eb655834004a2539e8dce524456.md)
    - We could also offer a service where we add timestamps of their videos (or more like clips with the mission proposal)