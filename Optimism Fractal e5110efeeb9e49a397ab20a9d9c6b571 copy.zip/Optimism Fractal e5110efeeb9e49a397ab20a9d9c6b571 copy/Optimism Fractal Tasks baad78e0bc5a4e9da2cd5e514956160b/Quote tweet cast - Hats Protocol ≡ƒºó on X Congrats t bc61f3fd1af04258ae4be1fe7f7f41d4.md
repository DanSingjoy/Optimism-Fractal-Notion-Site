# Quote tweet/cast - Hats Protocol 🧢 on X: "Congrats to @OptimismFractal, one of the winners of the inaugural Hatathon! Let's take a look at what made this Hats tree special, including an Agreement Eligiblity module, automated onboarding, &amp; permissionless "leveling up" 🧵 https://t.co/deWp9bjOAY" / X

Status: Not started
URL: https://x.com/hatsprotocol/status/1833864343714513247
Task Summary: This task aims to highlight the achievements of @OptimismFractal as one of the winners of the inaugural Hatathon, hosted by Hats Protocol. It will provide an overview of the unique features of their Hats tree, including the Agreement Eligibility module, automated onboarding, and the concept of permissionless "leveling up."
Summary: Dan Singjoy congratulated @OptimismFractal for winning the inaugural Hatathon, highlighting features of their Hats tree, such as an Agreement Eligibility module, automated onboarding, and permissionless leveling up.
Created time: September 11, 2024 7:07 PM
Last edited time: September 11, 2024 7:07 PM
Created by: Dan Singjoy
Description: Dan Singjoy congratulated @OptimismFractal for winning the inaugural Hatathon, highlighting the unique features of their Hats tree, including an Agreement Eligibility module, automated onboarding, and permissionless leveling up.

[https://x.com/hatsprotocol/status/1833864343714513247](https://x.com/hatsprotocol/status/1833864343714513247)