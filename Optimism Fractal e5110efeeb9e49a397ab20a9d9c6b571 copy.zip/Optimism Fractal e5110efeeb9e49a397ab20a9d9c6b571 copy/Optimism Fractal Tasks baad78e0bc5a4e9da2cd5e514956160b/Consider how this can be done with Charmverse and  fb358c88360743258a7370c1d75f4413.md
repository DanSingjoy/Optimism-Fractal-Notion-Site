# Consider how this can be done with Charmverse and Hats Protocol

Project: Integrate Optimism Fractal notion page with Notion API and Pipedream (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20notion%20page%20with%20Notion%2071c1311213394726983236991c25e999.md)
Status: Not started
Summary: Consider using Charmverse and Hats Protocol for a more independent and web3 approach. Explore the possibility of using Airstack or a similar querying tool. Roles can be assigned using Hats.
Created time: March 9, 2024 10:21 AM
Last edited time: March 9, 2024 11:01 AM
Created by: Dan Singjoy

## Description

- Can we use Airstack or some similar querying tool to do this in a more independent, web3 way?`
    - [Research airstack](Research%20airstack%202b65bcb631ec45e2a803c93981788634.md)
    
- The roles could be assigned with Hats
    - [Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)