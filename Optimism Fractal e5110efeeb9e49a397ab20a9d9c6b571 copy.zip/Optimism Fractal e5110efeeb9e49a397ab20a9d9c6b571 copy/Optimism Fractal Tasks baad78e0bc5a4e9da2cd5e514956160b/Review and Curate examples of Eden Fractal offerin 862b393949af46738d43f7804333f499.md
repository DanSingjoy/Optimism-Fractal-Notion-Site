# Review and Curate examples of Eden Fractal offering consensus as a service for Alien Worlds to show how Optimism Fractal can offer similar services

Due: May 3, 2024
Project: Consider Developing Product and Service Offerings  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Consider%20Developing%20Product%20and%20Service%20Offerings%2065a79191ce1a48d88fe03cb71f4ca25b.md), Integrate Optimism Fractal and the Respect Game with RetroFunding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md), Enhance Optimism Token House governance with Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Enhance%20Optimism%20Token%20House%20governance%20with%20Optim%20c9c852e1e2f249baaf89cbdc197df824.md)
Status: Not started
Task Summary: This task aims to review and curate examples of Eden Fractal offering consensus as a service for Alien Worlds. The goal is to showcase how Optimism Fractal can provide similar services, highlighting the potential of democratic community consensus and the technical capabilities enabled by Antelope community computers.
Summary: This document discusses the use of Eden Fractal's consensus as a service for Alien Worlds and highlights how Optimism Fractal can offer similar services. It mentions the role of the bubble economy in Japan's economic history, the Plaza Accord's impact on the Japanese economy, and the changes in Japan's economic policies during the 80s. The document also includes quotes from Gnome, the creator of Antelope IBC, discussing the exciting potential of building protocols on top of IBC. Overall, the document emphasizes the importance of democratic community consensus and showcases the technical capabilities of IBC in connecting different chains.
Created time: May 5, 2024 11:43 AM
Last edited time: May 6, 2024 5:49 AM
Parent task: Curate Examples of Consensus as a Service from Fractal Communities (Curate%20Examples%20of%20Consensus%20as%20a%20Service%20from%20Fra%2091eef1b9b2be43b59f0f9e5dad6bfe1f.md)
Created by: Dan Singjoy

## To Do

- [ ]  See and organize task at [Review and Organize ideas about offering consensus as a service ](Review%20and%20Organize%20ideas%20about%20offering%20consensus%20bf8c18e57cb2467f98ba0504caba9189.md)

- [ ]  Consider - Is this a tool or a service?
    - Maybe we should create a service database
    - Yes this seems like a good idea and something we can also present here
    - There is already an offer section so it can be combined there
        - What is the best name? Offers? Services? Services and Offers?
            - I think Services is generally better for many use cases but both can work
            
- [x]  create new article at [EdenCreators.com/caas](http://EdenCreators.com/caas)

- [x]  curate section about recommendations in AWF article

- [x]  add newest writing from [Alien Worlds](https://www.notion.so/Alien-Worlds-eeddd97e076a4761bffa7d9f14a506be?pvs=21)

## Eden Fractal Recommendations

In addition to building Alien Worlds Fractal, we’ve also been working with [Eden Fractal](https://edenfractal.com/) to provide signals for Alien Worlds leaders. You can watch the [47th](http://edenfractal.com/47), [48th](https://edenfractal.com/48), and [54th](http://edenfractal.com/54) Eden Fractal meetings to see how we signaled consensus to support custodians on Planet Eyeke after the creator of Alien Worlds, Michael Yeates, requested our recommendations.

This is a momentous development that shows the potential superpower of democratic community consensus and showcases the technical capabilities with newly built IBC features on Antelope community computers. You can see Michael Yeates post about new software he created to facilitate Eden Fractal recommendations for Alien Worlds candidates via IBC [here](https://t.me/c/1979501745/138) and you can hear the creator of IBC, Gnome, share a really exciting update about how Eden Fractal players on EOS can recommend Alien Worlds candidates on WAX [here](https://www.youtube.com/live/RQ1W7bOtKdI?feature=share&t=4641). You can also see a [post](https://t.me/edenfractal/1/3411) about this from Dan Singjoy, who has been acting as representative for the Eden+Fractal council in Alien Worlds.

You can watch the videos and explore the show notes below to learn more about these cosmically exciting developments:

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/e8b7e6f4-ab81-4f0d-950c-0bb60389a37a/54_full255/w=3840,quality=80,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/e8b7e6f4-ab81-4f0d-950c-0bb60389a37a/54_full255/w=3840,quality=80,fit=scale-down)

### [EF 54: Signalling Alien Worlds, Part III](http://edenfractal.com/54)

In our first meeting after our one year anniversary, we voyage again to Alien Worlds and signal our support for Vlad and Red on Planet Eyeke 👽

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/49ba75e3-4ddd-4b46-b756-4d715a185da0/48_thumb25/w=3840,quality=80,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/49ba75e3-4ddd-4b46-b756-4d715a185da0/48_thumb25/w=3840,quality=80,fit=scale-down)

### [**EF 48: Signaling Alien Worlds**](https://edenfractal.com/48)

In our 48th meeting, we explore a pioneering proposal for Alien Worlds and signal our consensus opinion that Lisa & Duane should be custodians on Planet Eyeke 👽

In this week’s Eden Fractal meeting we formed unanimous consensus that Lisa and Duane should be custodians on Planet Eyeke. Ten people people voted yes in the [Consortium Poll](https://consortium.vote/poll/781077/0s7lmw10i6o/ofaqqnelrdwa) (including all 8 current Eden Fractal delegates) and you can see the consensus posted on-chain [here](https://bloks.io/account/consortiumlv). You can also see the spreadsheet that we use to more easily see votes from each delegate [here](https://docs.google.com/spreadsheets/d/1d9pOWFPgfbtUI-flk5s5IeG9EcIOlXKdBAjxHo1NDDs/edit#gid=0) and the on-chain account where we post delegate elections [here](https://bloks.io/account/edenfractest) to see the full consensus.

The Alien Worlds proposal was the main topic of discussion during this week’s Cagendas game and it was also a frequent topic during our breakout room in the beginning of the video. You can see us reach consensus around [1:48:49](https://www.youtube.com/watch?v=7rglsbn6VZI&t=6529s) and view show notes with comprehensive timestamps [here](https://edenfractal.com/48) ✨

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/fd04ad7c-4545-4936-9fa5-d78b282ad79a/471/w=3840,quality=80,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/fd04ad7c-4545-4936-9fa5-d78b282ad79a/471/w=3840,quality=80,fit=scale-down)

### [EF 47: Alien Worlds and Documentation](https://edenfractal.com/47)

In our forty seventh meeting, we discuss strategies to improve documentation for our tools and a proposal to support Lisa & Duane as planetary leaders in Alien Worlds! 🛸

In addition to our discussion about Alien Worlds at Eden Fractal meeting #48, we also discussed the same proposal for about thirty minutes in the prior week’s meeting. We reached an informal supermajority consensus that Lisa and Duane should be custodians during this meeting two weeks ago, but we decided to propose it again this week to more formally approve the proposal with the Eden+Fractal process and inspire a deeper discussion. 

You can read a brief summary that Dan wrote about this Alien Worlds proposal [here](https://t.me/edenfractal/1/2654) and explore the [show notes](https://edenfractal.com/47) for this week’s timestamps and more exciting details 💫

“You can watch the [47th](http://edenfractal.com/47), [48th](https://edenfractal.com/48), and [54th](http://edenfractal.com/54) Eden Fractal meetings to see how we signaled consensus to support custodians on Planet Eyeke after the creator of Alien Worlds, Michael Yeates, requested our recommendations.

This is a momentous development that shows the potential superpower of democratic community consensus and showcases the technical capabilities with newly built IBC features on Antelope community computers. You can see Michael Yeates post about new software he created to facilitate Eden Fractal recommendations for Alien Worlds candidates via IBC [here](https://t.me/c/1979501745/138) and you can hear the creator of IBC, Gnome, share a really exciting update about how Eden Fractal players on EOS can recommend Alien Worlds candidates on WAX [here](https://www.youtube.com/live/RQ1W7bOtKdI?feature=share&t=4641). You can also see a [post](https://t.me/edenfractal/1/3411) about this from Dan Singjoy, who has been acting as representative for the Eden+Fractal council in Alien Worlds.”

> “Now what we’re beginning to see is that literal protocols are being built on top of IBC.

Yesterday Michael Yeates (the creator of Alien Worlds) announced that he finished writing a smart contract that would allow players or participants in Eden Fractal on EOS to have their votes transferred through IBC to WAX and be taken into consideration for voting the custodians on the planets of Alien Worlds.

So that to me is ***really exciting*** because now we can see people building additional apps that are using IBC to build their own workflows and processes that connect chains together. So we’re really starting to see these distributed apps that reside on multiple chain at the same time and having the different parts of their applications communicating through this protocol. 

So this is very, very exciting stuff! I’m really looking forward to seeing what’s going to emerge out of that and it’s impossible to know. I think some people will blow our minds in the next few months and hopefully for years with amazing applications like this.”

- Gnome, Creator of [Antelope IBC](https://eosnetwork.com/blog/antelope-ibc-deep-dive-seamless-horizontal-scaling-launches-on-eos/) and co-founder of [UX Network](https://www.uxnetwork.io/) and [EOS Titan](https://www.eostitan.com/)
> 

 [Alien Worlds Fractal](https://edencreators.com/alienworldsfractal), [Fractalien Worlds](https://edencreators.com/fractalienworlds), and Eden Fractal Recommendations in Alien Worlds in the article

- More Details
    
    ## Gnome
    
    Gnome/Guilliame , 0rigin, Creator of [Antelope IBC](https://eosnetwork.com/blog/antelope-ibc-deep-dive-seamless-horizontal-scaling-launches-on-eos/) and co-founder of [UX Network](https://www.uxnetwork.io/) and [EOS Titan](https://www.eostitan.com/)
    
    [https://twitter.com/gbabint](https://twitter.com/gbabint)
    
    [https://genesis.eden.eoscommunity.org/members/gnomegenomes](https://genesis.eden.eoscommunity.org/members/gnomegenomes)
    
    [https://www.youtube.com/watch?v=GVogZ7xHLKo](https://www.youtube.com/watch?v=GVogZ7xHLKo)
    
    [https://www.youtube.com/watch?v=GVogZ7xHLKo](https://www.youtube.com/watch?v=GVogZ7xHLKo)
    
    [Alien Worlds Fractal](https://edencreators.com/alienworldsfractal): Started Recently approved for a grant by Planet Eyeke
    
    After Duane hosted a successful 3 month pilot last year, we started new. I have been hosting them, Vlad  and Tadas built Eden Fractal software, Rosmari promoting…. . 
    
    [Fractalien Worlds](https://edencreators.com/fractalienworlds): 
    
     A new metaverse game . I made a proposal to the Alien Worlds Fractal
    
    growing the metaverse fractally 
    
    [Eden Fractal Recommendations](https://edencreators.com/alienworldsfractal#311abee4fdb74e829f10876dcd9b8e56): 
    
    In a similar spirit to the Eden Smart Proxy… 
    
    Eden Fractal community members have held supermajority positions at Planet Eyeke for the past two months  has representatives at Planet Eyeke
    
    Here is a high level overview 
    
    “In addition to building Alien Worlds Fractal, we’ve also been working with [Eden Fractal](https://edenfractal.com/) to provide signals for Alien Worlds leaders. You can watch the [47th](http://edenfractal.com/47), [48th](https://edenfractal.com/48), and [54th](http://edenfractal.com/54) Eden Fractal meetings to see how we signaled consensus to support custodians on Planet Eyeke after the creator of Alien Worlds, Michael Yeates, requested our recommendations.
    
    This is a momentous development that shows the potential superpower of democratic community consensus and showcases the technical capabilities with newly built IBC features on Antelope community computers. You can see Michael Yeates post about new software he created to facilitate Eden Fractal recommendations for Alien Worlds candidates via IBC [here](https://t.me/c/1979501745/138) and you can hear the creator of IBC, Gnome, share a really exciting update about how Eden Fractal players on EOS can recommend Alien Worlds candidates on WAX [here](https://www.youtube.com/live/RQ1W7bOtKdI?feature=share&t=4641). You can also see a [post](https://t.me/edenfractal/1/3411) about this from Dan Singjoy, who has been acting as representative for the Eden+Fractal council in Alien Worlds.”
    
    - [ ]  update this text to make it so that we dont undersell Gnome’s comment- listen again and write it in his words. Maybe just quote him here. YES definitely try that.
    
    - [ ]  Also add Michael’s recent message to Kevin Rose about this
        - [ ]  also add this to the EF 54 show notes
    
    - [ ]  finish the EF 54 show notes
        - [ ]  see [Release Eden Fractal  54](https://www.notion.so/Release-Eden-Fractal-54-d84e2d70fd024c56aac78a30ea354a94?pvs=21)
    
    - [ ]  consider pasting another longer quote of the article here about vlad’s proposal and recent meetings