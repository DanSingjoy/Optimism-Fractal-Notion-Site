# Consider asking in jokerace telegram if a free version of jokerace can be deployed or is deployed anywhere

Assignee: Dan Singjoy
Project: Research JokeRace for Cagendas and OPTOPICS  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20JokeRace%20for%20Cagendas%20and%20OPTOPICS%2062b9e52fb4994fd2902dc10fb082e592.md)
Status: Not started
Task Summary: This task aims to inquire about the availability and deployment of a free version of Jokerace in the Jokerace Telegram group. The creator, Dan Singjoy, has initiated this task to gather information regarding the deployment of the game and seek answers from the community.
Summary: No content
Created time: May 31, 2024 9:52 PM
Last edited time: May 31, 2024 9:53 PM
Created by: Dan Singjoy