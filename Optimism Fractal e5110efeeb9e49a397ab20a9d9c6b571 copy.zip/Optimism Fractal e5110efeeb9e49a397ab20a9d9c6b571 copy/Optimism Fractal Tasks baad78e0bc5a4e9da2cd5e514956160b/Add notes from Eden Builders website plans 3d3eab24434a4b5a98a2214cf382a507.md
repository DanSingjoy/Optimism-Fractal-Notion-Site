# Add notes from Eden Builders website plans

Project: Create Optimism Fractal Builders Site (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Builders%20Site%20b2364cd97d724ac78f2b7f30c2f476c2.md)
Status: In progress
Task Summary: This task aims to add notes from the Eden Builders website plans. The plans include the creation of Optimism Fractal Builders, a social media network, collaborative blog, and directory for builders on the Superchain. The page provides an overview of Eden Builders and its vision to become a dynamic platform for creative collaboration and networking among builders on Optimism.
Summary: Eden Builders is envisioned as a new social media network, collaborative blog, and directory for builders on the Superchain. It aims to be a dynamic social media network, a feature-rich collaborative blog, a networking hub for builders on Optimism, a pioneering example in creative collaboration, and a website built with democratic governance.
Created time: July 17, 2024 8:41 PM
Last edited time: July 17, 2024 9:07 PM
Created by: Dan Singjoy
Description: Eden Builders is envisioned as a new social media network, collaborative blog, and directory for builders on the Superchain. It aims to provide a flexible canvas for dynamic social media networking, a feature-rich collaborative blog, a networking hub for builders on Optimism, and a pioneering example in creative collaboration.

Optimism Fractal Builders is envisioned as a new social media network, collaborative blog, and directory for builders on the Superchain.

[https://edencreators.notion.site/Eden-Builders-f1348214661844588bc5ec1b1331397f?pvs=4](https://www.notion.so/Eden-Builders-f1348214661844588bc5ec1b1331397f?pvs=21)

[Eden Builders](https://www.notion.so/Eden-Builders-f1348214661844588bc5ec1b1331397f?pvs=21) 

[Eden Builders Proposal](https://www.notion.so/Eden-Builders-Proposal-b3038697303b4723b0ab0fb0569e54f5?pvs=21) 

[Eden Builders Notes](https://www.notion.so/Eden-Builders-Notes-9df5853c10d44cfbbf012d9d2dffc94e?pvs=21) 

Optimism Builders is a new social media network, collaborative blog, and directory for builders on Optimism.

You can think of Eden Builders a bit like LinkedIn and Tumblr and …  weekly contributions and profiles, bio, skills, etc

Personal site, feature rich personal site. Deep features for making pages, etc

microblog

New form of collaborative website managed by the community

This site provides a highly flexible canvas that may soon become:

⬠ A dynamic social media network

⬠ A feature rich collaborative blog

⬠ A networking hub for builders on Optimism

⬠ A pioneering example in creative collaboration

⬠ A website built with democratic governance

⬠ And so much more . . .