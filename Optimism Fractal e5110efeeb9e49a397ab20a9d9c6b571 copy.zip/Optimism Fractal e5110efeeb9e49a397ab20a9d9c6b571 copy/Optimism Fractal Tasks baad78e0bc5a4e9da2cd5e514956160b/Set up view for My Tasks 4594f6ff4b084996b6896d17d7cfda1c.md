# Set up view for My Tasks

Due: May 3, 2024
Project: Develop Optimism Fractal Notion Workflow Resources (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%20Notion%20Workflow%20Resources%2000025cbe20b349dbac2a3983459ac1a5.md)
Status: Not started
Task Summary: This task aims to set up a view for "My Tasks" in order to effectively manage and track tasks. It includes details such as the creator, due date, status, and timestamps. Additionally, an image titled "Untitled" is included in the document.
Summary: Set up a view for My Tasks. Task is not started and was created by Dan Singjoy. Due date is May 3, 2024.
Created time: May 14, 2024 11:57 AM
Last edited time: May 14, 2024 11:58 AM
Created by: Dan Singjoy

![Untitled](Set%20up%20view%20for%20My%20Tasks%204594f6ff4b084996b6896d17d7cfda1c/Untitled.png)