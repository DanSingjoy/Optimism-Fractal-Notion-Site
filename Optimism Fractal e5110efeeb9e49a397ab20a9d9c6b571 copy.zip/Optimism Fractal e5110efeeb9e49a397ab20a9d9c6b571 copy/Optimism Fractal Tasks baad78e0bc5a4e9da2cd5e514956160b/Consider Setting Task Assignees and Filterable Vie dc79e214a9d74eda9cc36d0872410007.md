# Consider Setting Task Assignees and Filterable Views in the Template

Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Not started
Task Summary: This task aims to consider setting task assignees and filterable views in the template. By assigning tasks to specific team members and implementing personalized event preparation projects, the goal is to tailor event preparation to individual roles and responsibilities. This approach encourages collaboration, accountability, and continuous improvement, optimizing the overall event preparation process.
Summary: Consider setting task assignees and using filterable views in the template to tailor event preparation to individual roles and responsibilities, encourage collaboration and accountability, and allow for continuous improvement and experimentation. To-do: implement personalized event preparation projects, assign tasks based on roles, and evaluate and iterate as needed.
Created time: June 5, 2024 8:56 PM
Last edited time: June 5, 2024 9:33 PM
Created by: Dan Singjoy

- [ ]  Consider setting assignees for each task, then filtering a task database for the project so that each person only sees the tasks that are relevant for them

## 4. Personalized Event Preparation

- Use the same project to prepare for each event (e.g., Optimism Fractal 27)
- Each person has their own tasks to prepare for the event
- Experiment with this approach to optimize event preparation

### Key Points

- Tailors event preparation to individual roles and responsibilities
- Encourages collaboration and accountability
- Allows for continuous improvement and experimentation

### To-Do

- Implement personalized event preparation projects
- Assign tasks to each team member based on their role
- Evaluate the effectiveness of this approach and iterate as needed