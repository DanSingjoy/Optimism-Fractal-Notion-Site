# Watch Optimism Collective Token House call: May 14th, 2024

Assignee: Dan Singjoy
Due: May 20, 2024
Project: Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md), Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Prepare for OF 27 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2027%20a3a902d398094d0b826538ac88183391.md)
Status: Done
Task Summary: This task aims to provide a summary and details of the Watch Optimism Collective Token House call that took place on May 14th, 2024. The page includes information about the creator, assignee, due date, status, and timestamps. It also provides a recording of the call and a link to the Optimism Community Call Recaps & Recordings Thread for further reference.
Summary: This document provides information about the Watch Optimism Collective Token House call that took place on May 14th, 2024. It includes the creator, assignee, due date, status, and recording links for the call.
Created time: May 14, 2024 4:59 PM
Last edited time: May 23, 2024 11:52 AM
Created by: Dan Singjoy

Recording: [May 14, 2024 S6 AMA and Token House Call.mp4 - Google Drive](https://drive.google.com/file/d/1mAWfVMQkG0O_aWdPRtk5ojHuMXhsAgNg/view?usp=sharing)

[Optimism Community Call Recaps & Recordings Thread](https://gov.optimism.io/t/optimism-community-call-recaps-recordings-thread/6937/37)