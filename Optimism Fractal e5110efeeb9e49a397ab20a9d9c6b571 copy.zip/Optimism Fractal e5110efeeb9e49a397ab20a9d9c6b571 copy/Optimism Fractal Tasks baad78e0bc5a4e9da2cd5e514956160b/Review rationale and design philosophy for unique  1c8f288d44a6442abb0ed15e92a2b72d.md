# Review rationale and design philosophy for unique token design

Project: Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md)
Status: Not started
Summary: Review the rationale and design philosophy for the unique token design, including the implementation of ERC 20 and NFT standards. Tadas provides more details in a video and blog post, and the Github repository contains the smart contracts.
Created time: March 24, 2024 5:47 PM
Last edited time: March 24, 2024 5:52 PM
Created by: Dan Singjoy

## Description

## Succinct Explanation

Tadas wrote the following in [Improve representation of Respect on block explorers](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md), where you can find more details

The underlying cause of these issues is atypical implementation of token contract. It tries to implement both ERC-721 and ERC-20 with the end result that   neither is implemented  fully, because these standards have overlapping methods. I present rationale for this below.

This is similar to how cash works. Every dollar bill is actually unique (non-fungible), yet we typically treat them as fungible. There’s nothing preventing us from treating them as non-fungible (taking into account the serial number for example). So you have one currency with two different ways of looking at it (like two interfaces).

## More Details about this Design

You can see Tadas explain how the smart contract implements interfaces of both ERC 20 and NFT standard for the Respect token in this [video](https://youtu.be/dU7Whneo5yI?si=LS-MI-MJxiX_ykwl&t=640). If you’re interested in learning about the philosophy originally behind this design, you could also see this blog [post](https://hive.blog/dao/@sim31/fungibility-out-of-non-fungible-tokens) and video [clip](https://youtu.be/yr1NzIdezG8?si=rNJbTSEuRczlr2_X&t=4653) for more details. 

Tadas said that the best explanation of the contract’s design can be found [here](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md), though the resources above also provide unique insights. You can read the explanation in the ‘background’ section near the top of the page if you’re interested. 

## Repository

Here is the Github [repository](https://github.com/Optimystics/op-fractal-sc) with the Optimism Fractal smart contracts.