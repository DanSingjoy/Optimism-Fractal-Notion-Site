# Research base onchain content network

Assignee: Dan Singjoy
Due: August 9, 2024
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Increase Distribution for Optimism Fractal Videos and Promotions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Increase%20Distribution%20for%20Optimism%20Fractal%20Videos%20%200409af95af8d466aa7dd14bd8a3191dc.md), Increase Distribution for Optimism Fractal Videos and Promotions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Increase%20Distribution%20for%20Optimism%20Fractal%20Videos%20%2025e9f46903ab4652a3ef7613fec95999.md), Create Promotions for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Promotions%20for%20Optimism%20Fractal%20fccca47c97dd47df8ffe81b9b5e60c01.md)
Status: Not started
URL: https://x.com/davidtsocy/status/1816572223399854333?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to conduct research on an onchain content network. The research will focus on exploring the potential of decentralized content distribution and its implications for data security and censorship resistance. The findings will contribute to a deeper understanding of the benefits and challenges of utilizing blockchain technology in content delivery systems.
Summary: No content
Created time: July 25, 2024 5:00 PM
Last edited time: July 25, 2024 5:08 PM
Created by: Dan Singjoy
Description: No content

[https://x.com/davidtsocy/status/1816572223399854333?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/davidtsocy/status/1816572223399854333?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)