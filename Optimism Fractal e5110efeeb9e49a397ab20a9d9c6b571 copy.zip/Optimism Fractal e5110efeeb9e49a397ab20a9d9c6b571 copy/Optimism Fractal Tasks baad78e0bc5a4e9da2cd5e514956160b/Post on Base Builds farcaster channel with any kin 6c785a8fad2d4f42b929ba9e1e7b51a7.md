# Post on /Base Builds farcaster channel with any kind of build to earn part of 2 ETH weekly

Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Implement contributor funding in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Implement%20contributor%20funding%20in%20the%20Optimism%20Coll%20e94cb8eb2b5246ebaa47d1088b49b1cc.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md), Create Optimism Fractal Promotional Strategy (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Promotional%20Strategy%2092bfd89b01294e988511fe6e4f03f526.md), Create Promotions for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Promotions%20for%20Optimism%20Fractal%20fccca47c97dd47df8ffe81b9b5e60c01.md)
Status: In progress
Task Summary: This task aims to promote the opportunity to earn a portion of 2 ETH weekly by posting any kind of build on the /Base Builds farcaster channel. Created by Dan Singjoy, this initiative offers a chance to showcase your creations and potentially receive funding. Stay tuned for more details and watch the video featuring Jesse Pollock for further information.
Summary: This post announces a weekly opportunity to earn part of 2 ETH by posting any kind of build on the /Base Builds farcaster channel. The post includes a video by Jesse Pollock discussing the details and a link to participate.
Created time: May 5, 2024 4:03 PM
Last edited time: June 10, 2024 11:56 AM
Created by: Dan Singjoy

Jesse Pollock speaks about this in the video below

[https://www.youtube.com/watch?v=12ks-JzqLrE](https://www.youtube.com/watch?v=12ks-JzqLrE)

- [ ]  find timestamp

Every week 2 eth, post anything including onchain video post about OF

[Warpcast](Post%20on%20Base%20Builds%20farcaster%20channel%20with%20any%20kin%206c785a8fad2d4f42b929ba9e1e7b51a7/Warpcast%203468a88c8f6a45a293dc19b7dd9289d0.md)

[Jesse Pollak (jesse.xyz) 🛡️ on X: "share what you built this week, get rewarded a 2m overview of the new /base-builds grants that are open to everyone and the easiest way to get funded get started @ https://t.co/r47yHPyaPt https://t.co/qw1OZQ7oHO" / X](Post%20on%20Base%20Builds%20farcaster%20channel%20with%20any%20kin%206c785a8fad2d4f42b929ba9e1e7b51a7/Jesse%20Pollak%20(jesse%20xyz)%20%F0%9F%9B%A1%EF%B8%8F%20on%20X%20share%20what%20you%20bu%20fba0f05096b343ea86e4bf217ee810ab.md)