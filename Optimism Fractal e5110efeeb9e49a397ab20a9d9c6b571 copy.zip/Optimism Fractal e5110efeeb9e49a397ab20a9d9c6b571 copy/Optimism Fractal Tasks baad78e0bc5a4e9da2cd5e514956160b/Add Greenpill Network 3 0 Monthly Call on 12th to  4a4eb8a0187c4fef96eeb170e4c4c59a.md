# Add Greenpill Network 3.0 Monthly Call on 12th to calendar and optimism events calendar- Wednesdays

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Explore collaborations with Green Pill Network (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20collaborations%20with%20Green%20Pill%20Network%205420b81e60a141298e59e0a6e59174b4.md), Create Optimism Events Calendar (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Events%20Calendar%20ca8d2c50f36145fe898e2f9de1cd90f6.md), Network and collaborate with governance enthusiasts in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Network%20and%20collaborate%20with%20governance%20enthusiast%20d5efbbcde39e4bf9a7a16aec51786709.md)
Status: Not started
URL: https://lu.ma/gpn-monthly-call?
Task Summary: This task aims to add the Greenpill Network 3.0 Monthly Call on the 12th to the calendar and optimism events calendar. The call, hosted by Dan Singjoy, will provide an opportunity for participants to discuss guilds, chapters, and resources for getting involved in different areas.
Summary: The Greenpill Network 3.0 Monthly Call on the 12th of the month should be added to the calendar and the optimism events calendar. The event will include introductions, a discussion/presentation on guilds and chapters, and information on how to get involved in different areas.
Created time: May 4, 2024 1:05 AM
Last edited time: July 16, 2024 9:40 AM
Created by: Dan Singjoy
Description: The Greenpill Network 3.0 Monthly Call is scheduled for the 12th of the month and should be added to the calendar. The event will include introductions, a discussion on guilds and chapters, and information on how to get involved in different areas.

Hosted By

Registration

Approval Required

Welcome! To join the event, please register below.

About Event

​Agenda:

1. ​Introductions
2. ​Guilds and Chapters discussion/presentation
3. ​Resources and structure on how to get involved in different areas.