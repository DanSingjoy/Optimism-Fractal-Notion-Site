# Create webpages and educational resources about how you can contribute to Optimism Fractal and the Respect Game (OptimismFractal.com/contribute)

Project: Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md), Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md), Build Optimism Fractal Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md), Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md)
Status: Not started
Summary: This task aims to create webpages and educational resources about contributing to Optimism Fractal. It involves reviewing and curating existing resources, as well as creating original material. These pages will serve as an educational guide for anyone interested in learning about Optimism Fractal and the Respect Game. Assistance from interested individuals is greatly appreciated.
Created time: April 6, 2024 5:17 PM
Last edited time: April 6, 2024 5:52 PM
Created by: Dan Singjoy

## Description

This task aims to facilitate the creation of webpages and educational resources about contributing to Optimism Fractal. It includes resources that you can review to learn about this that we may want to curate in the resources and webpages. 

- More details
    
    This is part of a series of tasks in the project [Improve [OptimismFractal.com](http://OptimismFractal.com) Website (and Create Educational Resources)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md). This project aims to coordinate a collaborative community-driven creation of the website and various tasks are included for pages on the website. The first step of creating these webpages is to create educational resources in the notion page. This involves reviewing and curating the most helpful parts of related resources that have been created over the past few years, as well as creating original material. 
    
    These pages can serve as an educational guide to anyone interested in learning about Optimism Fractal and the Respect Game. We’d greatly appreciate help from anyone who is interested in learning and/or creating these educational resources. Enjoy!
    

- [ ]  /build or /buidl

## Related Resources to Review and Curate

- Add notes from [Create [OptimismFractal.com/funding](http://OptimismFractal.com/funding) to show how Optimism Fractal can help people earn RetroFunding and other funding](Create%20OptimismFractal%20com%20funding%20to%20show%20how%20Opt%2045915c303ab94868b62bc2124430da06.md)

- [Development Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Development%20Hub%20b4df0dfa78144997922bed973cee26f9.md)
    - [ ]  Consider creating a project or task to further develop this
    - The projects on this page

Overviews of Tools: [Optimystics.io/tools](http://Optimystics.io/tools) 

- The articles on this page

Github Repositories: [github.com/optimystics](https://github.com/optimystics)

- Github link

- Regen Builders thumbnail

- [Optimystics.io/tools](http://Optimystics.io/tools)

- [Curate Research about Developer Tooling](Curate%20Research%20about%20Developer%20Tooling%200b3fcc46ccf54581a653c00d6bfe9c25.md)

- Include [Create educational resources about the history of Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20about%20the%20history%20of%20%20fdcb0d490a9a41ce95992d8947236df6.md) and other more general educational resources that may be helpful for builders