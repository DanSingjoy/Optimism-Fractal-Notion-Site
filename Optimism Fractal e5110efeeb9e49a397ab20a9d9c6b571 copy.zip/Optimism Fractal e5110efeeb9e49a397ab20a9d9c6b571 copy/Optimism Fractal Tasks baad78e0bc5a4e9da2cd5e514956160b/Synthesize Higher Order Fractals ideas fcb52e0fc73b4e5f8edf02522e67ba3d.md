# Synthesize Higher Order Fractals ideas

Project: Develop Systems for Fractal Communities to Collaborate and Interact with Each Other (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Systems%20for%20Fractal%20Communities%20to%20Collabo%20d9ca753ed03b4732a97bc6023c8d24ab.md), Explore integrations with Roles and Reputations System (from Jacob Homanics with ATX DAO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20with%20Roles%20and%20Reputations%20Sy%20c85bbe3e9a8548bfb3ccf6a4aea29fde.md)
Status: Not started
Task Summary: This task aims to synthesize ideas about higher-order fractals, which propose a unique organizational structure for communities. It envisions a "fractal of fractals" where each unit is a fractal itself, allowing for more effective measurement and comparison of different governance models within decentralized autonomous organizations.
Summary: This document discusses the concept of higher order fractals and explores how Optimism Fractal and EdenFractal can serve as higher order fractals. It highlights the benefits of higher order fractals in promoting collaboration, scalability, and diverse representation. The document also touches upon how higher order fractals can signal respect and trust between communities and how they can integrate with roles and reputations systems. Additionally, it outlines the potential path for EdenFractal to transform into a higher order fractal and discusses the role of Optimism Fractal in the context of higher order fractals.
Sub-task: Respond to Tadas about Higher Order Fractals and Fractal Tournament Ideas (Respond%20to%20Tadas%20about%20Higher%20Order%20Fractals%20and%20F%204ed31784754b4b24a070337384298bb4.md)
Created time: October 25, 2023 11:10 AM
Last edited time: June 25, 2024 10:10 AM
Parent task: Explore ideas for collaboration between fractals and other communities (Explore%20ideas%20for%20collaboration%20between%20fractals%20a%2031fca5df27284d7e9864b369dc51abd4.md)
Created by: Dan Singjoy

# Overview

Higher-order fractals propose a novel organizational structure for communities, envisioning a "fractal of fractals" where each unit is a fractal itself, perhaps represented by delegates in less frequent, larger-scale consensus meetings. This model facilitates the measurement and comparison of different governance models by allowing fractal communities to present and rank collective achievements periodically. This approach could streamline complex decision-making and amplify the impact of collaborative efforts within the decentralized autonomous organization landscape.

**Table of Contents**

## Review Tadas’ Article about Higher order fractals

- Text from Higher order fractals article
    
    
    # Higher order fractals
    
    With more and more fractal-like DAOs springing up, I think it is time to start thinking about how these fractals could interact and organize among each other. Here I will propose one obvious model, which uses a concept of what I think could be called “a higher-order fractal”.
    
    ## Introduction
    
    In mathematics, a higher-order function is a function that either takes functions as arguments or returns a function. In other words - it is a function that deals with functions instead of just variables. In the same vein, **a higher-order fractal would be a fractal composed of fractals or other kinds of DAOs instead of individuals.**
    
    This creates a fractal pattern, so obviously, it does seem like a natural solution for organizations called “fractals”, but it does raise some critical questions about how meetings and consensus process of this higher-order fractal would work.
    
    In summary, I suggest that higher-order fractal can simply use the same Respect game and top-contributor-based consensus process as some existing fractals use, except the people participating in meetings would be representatives of DAOs (1 representative per DAO) and Respect would be awarded to a whole DAO. Consensus meetings of higher-order fractal should happen less often and there might be some additional small changes needed. I try to cover those in the [Design](https://www.notion.so/ea8a6aadf02a455cb21f936a1b0a4d56?pvs=21) section. But first, let’s talk about why we might want this.
    
    ## Motivation
    
    Respect game at the core of a fractal process, is a very straightforward way to create a common ground for all the DAOs, without much organizational complexity (which would be hard considering we are talking about DAOs organizing not individuals). This common ground can have the following benefits.
    
    ### Means to measure performance of different consensus processes / governance solutions
    
    We have already noticed that each new fractal often mutates a little in its processes. Some fractals make bigger changes, some smaller, but creators of a new fractal almost always put their twist on it. Plus you have kindred DAOs like Upscale (former Eden) and other DAO ecosystems which share a lot of common values with fractals (like [Hypha](https://hypha.earth/) DAOs).
    
    All this variety is very healthy for the ecosystem. We don’t know which processes are the best, but through this variety of experiments, we create data that can be used to compare all of these different governance workflows.
    
    This is where this higher-order fractal can be invaluable. One periodic meeting where each DAO presents their progress and then reaches consensus on rankings among themselves can create a very crucial data point for comparison of DAOs and their processes. Not to mention that rankings and Respect distribution that these meetings will output, will by themselves be a very interesting and telling metric.
    
    ### Contributor presentations will get a lot more interesting and valuable
    
    It’s one thing to listen to a presentation of what an individual did throughout one week, it’s whole another thing to listen to what a group of people did in a month or a couple of months. While the former typically just talks about an in-progress work being done, the latter can become a demo of an actual product of that work. This will provide useful content for what these communities are achieving that is meaningful to an outsider and not just old participants.
    
    It is also easier to evaluate and compare products of work rather than promises of effort being spent. By extending time between meetings and allowing groups of people to be represented we will move towards presentations of products rather than effort.
    
    ### Opportunity for smaller DAOs to get seen, get reputation, and attract more people and funding
    
    Higher-order fractal creates an opportunity for positive collaborations of people to get noticed and get reputation. Reputation can lead to other great things for a DAO like new members and potential funding.
    
    ### Competition and collaboration between DAOs
    
    This I think can be a motivating factor for contributors. Higher-order fractal meetings will add more meaning to work performed by individuals in the sub-DAOs because it will add up to something bigger that will be recognized and evaluated at the end of the period.
    
    It will also create opportunities for DAOs to learn more about each other and collaborate.
    
    ## Design
    
    The core of higher-order fractal would be Respect game like in the typical fractals we know of. But instead of individuals competing for Respect we want to have fractals. For this we need fractals to be able to:
    
    1. Present contributions;
    2. Build consensus with other fractals on the rankings of contributor fractals;
    
    The simplest solution is to have each fractal elect a representative. This I think should work perfectly for solving the first (presenting contributions). It would be individuals presenting contributions but they would be presenting contributions of a whole fractal instead of just theirs.
    
    For the second, I think representative is not enough because, while you can prepare a presentation that presents the work of the whole fractal, you can’t really prepare for a consensus process on rankings where you would represent your whole fractal (its opinion on the rankings). Therefore, I think that after all participant DAOs present their contributions, they should be given at least a week to build consensus on their rankings. This will provide time for fractals to discuss the performance of each contributor fractal internally, within their own fractal. The final consensus would still have to be signalled by representatives of each DAO, so that there’s a clear point of contact from each fractal which allows consensus building among fractals.
    
    So from a representative’s perspective, consensus building could be a 3 step process:
    
    1. Poll his fractal for their opinion of how all the contributor fractals should be ranked;
    2. Negotiate and build consensus with representatives of other fractals (who are presumably doing the 1st step as well);
    3. Signal consensus pre-agreed among representatives;
    
    If representatives do not properly represent their fractal (do not do the first step for example), it is up to that fractal to solve that issue internally and elect a better representative for the next higher-order fractal meeting.
    
    There are some other changes and considerations to the fractal process we might want to take into account.
    
    ### More time in between meetings
    
    Considering that the overhead required to reach consensus (even through representatives) is bigger in the higher-order fractal, meetings should happen less often than a typical 1 week. Plus each participant DAO usually has its own weekly meetings as well. At least 1 month in between higher-order fractal meetings would be more appropriate but an even bigger gap might be sensible as well. This will give more time for fractals to make something happen, which will make their contributions more interesting.
    
    ### More time for the presentation of each DAO
    
    Since each representative will be presenting contributions of the whole group, over a period longer than 1 week, I think they should be given more time to present. Currently, I think the typical time for each to present ranges between 3-5 minutes. For higher-order fractal, 10 minutes might be more appropriate. The time given to break-out groups should be extended as needed.
    
    ### Any kind of DAO should be allowed to participate even if it does not follow a fractally-like process
    
    As long as they present a required interface (i.e.: elect representatives) I don’t see a reason for higher-order fractal to not include them. A variety of different competing consensus processes is good for the ecosystem (see [Motivation](https://www.notion.so/c18cfb5756de4a11b0263e89ca375ccb?pvs=21))
    
    Furthermore, I would consider allowing 1 person DAOs to participate. This can be useful when a person is starting a project and has plans to accept community contributions to his project but has none yet. Then it makes sense for him to create a fractal that would eventually attract contributors. Meanwhile, he would still have a place to present his contributions regarding the project he wants to work on in higher-order fractal meetings. However, it is important that each DAO should be evaluated by the same standards regardless of its size. So 1 person DAO should normally not be able to compete with larger DAOs (assuming those larger DAOs are doing useful work).
    
    Participants of a higher-order DAO should try to evaluate its sub-DAOs primarily based on their output and not their internal structure. This respects the autonomy of each DAO, which I think is necessary (considering we are talking about decentralized *autonomous* organizations). This is kind of like having some base respect for the privacy of another person’s mind (their beliefs and opinions) as long as the person acts in a socially acceptable manner.
    
    I would make a proposition that bad governance processes would always eventually reflect in the outputs of a DAO. For example, if some sub-DAOs have a governance process that does not respect their members, eventually those members will leave and join other DAOs, which will eventually reflect in the output of that DAO and their rankings in higher-order fractal.
    
    ### Higher-order fractal needs a consensus process
    
    Since we are giving more time for presentations (so meetings will take longer), and consensus building among fractals will be slightly more complex, it might make sense to be more careful regarding who participates. Higher-order fractal needs a consensus process for adding (or at least removing) participating DAOs if nothing else. Another reason a consensus process might be needed is the scheduling of meetings.
    
    I don’t think [Eden+Fractal](https://edencreators.com/plus) is suitable here because it adds another consensus problem (electing a delegate fractal) and as already mentioned these consensus problems cost even more in higher-order fractal. Therefore, a top-contributor-based process[1](https://www.notion.so/Higher-order-fractal-829655f29b2d4f98b2de8de6b7b371be?pvs=21) would probably be more suitable. This means, however, that we will have to agree on a way by which each of the top fractals signal their approval of a proposal. Again, the question of what mechanism is used for participant DAO to decide to issue this signal is up to each participant DAO to determine.
    
    ### Should people be allowed to participate (contribute to) multiple participant DAOs?
    
    Generally when you have teams competing you don’t allow members of teams to overlap. So it would be natural to expect that being a member of multiple participant DAOs should not be allowed by the higher-order fractal. Plus competition might be more interesting this way. However, actually enforcing this would add a lot of complexity to the system and I would argue that we don’t have much to lose by allowing this.
    
    The complexity that enforcement of this rule would add would be a bad kind of complexity where higher-order fractal would have to influence the inner structure (membership list) of a sub-DAO (which means infringement on the autonomy of a DAO). Not to mention that any complexity in higher-order DAO is very costly since changing any of the rules will require consensus from all participant DAOs.
    
    One of the things that could happen if we allow participation in multiple sub-DAOs is that some contribution of a single individual ends up being claimed by multiple sub-DAOs. But then it simply means that these contributions “cancel out” when comparing these two DAOs.
    
    If some contributor is contributing different things to different DAOs (helping them both), then it means that he is splitting his time and that reflects a certain amount of respect for both DAOs. It means that both DAOs are doing something right because they are attracting contributors.
    
    Another argument against allowing participating in multiple sub-DAOs is that it would allow people to play dirty by sabotaging competitor DAOs from within. But this can be ascribed to be a problem of individual sub-DAOs as opposed to a problem of higher-order fractal. There are multiple things a DAO could do to protect from sabotage at a local level:
    
    - Transparency regarding who the members are - if members of a DAO are not anonymous then they would have to risk their reputation by trying to sabotage;
    - Review process for contributions (which is already being done to some extent in fractally-like DAOs) could catch any malicious contributions;
    - A good DAO should allow space for members to question the honesty of other members;
    - A DAO could (and probably should) have a mechanism for kicking out members who are malicious (detected to be sabotaging);
    - Simply not allowing people to participate if there’s evidence of them participating in other DAOs;
    
    It’s up to each DAO to decide what methods they apply. If a participant DAO fails to protect itself then it is useful information when evaluating its process and comparing it with other DAOs. Plus a higher-order fractal will not be able to protect from all cases of malicious behaviour. So DAOs will need to think about protection mechanisms for themselves anyway and I think it will be more useful for higher-order fractal to evaluate those mechanisms instead of enforcing them.
    
    So my preliminary answer is that higher-order fractal should not have a rule against allowing people to participate in multiple DAOs even if those DAOs are competing in a higher-order fractal.
    
    ## Conclusion
    
    DAOs / fractals can gain a lot of benefits from organizing into a kind of DAO of DAOs. Here I propose one model for that which I call “higher-order fractal”.
    
    The guiding principle behind higher-order fractal model is that the DAO that encompasses other DAOs should make a conceptual leap where its participants are smaller DAOs instead of individuals. This will give it a legitimate claim to be called DAO of DAOs. Other than that this DAO should mirror the design of a normal DAO composed of individuals as much as possible. This will make the system simpler and composable.
    
    I propose that this DAO of DAOs should mirror the structure of a typical fractal because it seems like the most natural way to create that kind of DAO. Think of it like a periodic conference for the ecosystem of DAOs, except besides just presenting their progress they would also be playing a game to rank each other’s progress. Besides providing many other [benefits](https://www.notion.so/6b784976920042829a6fdbf55af2199a?pvs=21), this simple game enables bootstrapping a whole higher-level governance process without requiring founder DAOs to agree on any sort of complex ruleset upfront.
    
    ---
    
    1. E.g.: top 6 contributor DAOs over the last N meetings have votes in approving proposals, where you need 4/6 votes in order to pass a proposal.↩
    

[An idea for how different fractals could collaborate](https://www.notion.so/1bf8fe7ed74d4cdaaa1f0cfb0a256515?pvs=21).

[Potential path for EdenFractal to implement the idea above.](https://www.notion.so/b831968892554853a312dedfdc6b8204?pvs=21)

## To Do

- [x]  ask AI to summarize higher order fractals based upon the following
    - [x]  summarize brief sentence and more details to create an article about this

- Text from Higher order fractals article
    
    
    # Higher order fractals
    
    With more and more fractal-like DAOs springing up, I think it is time to start thinking about how these fractals could interact and organize among each other. Here I will propose one obvious model, which uses a concept of what I think could be called “a higher-order fractal”.
    
    ## Introduction
    
    In mathematics, a higher-order function is a function that either takes functions as arguments or returns a function. In other words - it is a function that deals with functions instead of just variables. In the same vein, **a higher-order fractal would be a fractal composed of fractals or other kinds of DAOs instead of individuals.**
    
    This creates a fractal pattern, so obviously, it does seem like a natural solution for organizations called “fractals”, but it does raise some critical questions about how meetings and consensus process of this higher-order fractal would work.
    
    In summary, I suggest that higher-order fractal can simply use the same Respect game and top-contributor-based consensus process as some existing fractals use, except the people participating in meetings would be representatives of DAOs (1 representative per DAO) and Respect would be awarded to a whole DAO. Consensus meetings of higher-order fractal should happen less often and there might be some additional small changes needed. I try to cover those in the [Design](https://www.notion.so/ea8a6aadf02a455cb21f936a1b0a4d56?pvs=21) section. But first, let’s talk about why we might want this.
    
    ## Motivation
    
    Respect game at the core of a fractal process, is a very straightforward way to create a common ground for all the DAOs, without much organizational complexity (which would be hard considering we are talking about DAOs organizing not individuals). This common ground can have the following benefits.
    
    ### Means to measure performance of different consensus processes / governance solutions
    
    We have already noticed that each new fractal often mutates a little in its processes. Some fractals make bigger changes, some smaller, but creators of a new fractal almost always put their twist on it. Plus you have kindred DAOs like Upscale (former Eden) and other DAO ecosystems which share a lot of common values with fractals (like [Hypha](https://hypha.earth/) DAOs).
    
    All this variety is very healthy for the ecosystem. We don’t know which processes are the best, but through this variety of experiments, we create data that can be used to compare all of these different governance workflows.
    
    This is where this higher-order fractal can be invaluable. One periodic meeting where each DAO presents their progress and then reaches consensus on rankings among themselves can create a very crucial data point for comparison of DAOs and their processes. Not to mention that rankings and Respect distribution that these meetings will output, will by themselves be a very interesting and telling metric.
    
    ### Contributor presentations will get a lot more interesting and valuable
    
    It’s one thing to listen to a presentation of what an individual did throughout one week, it’s whole another thing to listen to what a group of people did in a month or a couple of months. While the former typically just talks about an in-progress work being done, the latter can become a demo of an actual product of that work. This will provide useful content for what these communities are achieving that is meaningful to an outsider and not just old participants.
    
    It is also easier to evaluate and compare products of work rather than promises of effort being spent. By extending time between meetings and allowing groups of people to be represented we will move towards presentations of products rather than effort.
    
    ### Opportunity for smaller DAOs to get seen, get reputation, and attract more people and funding
    
    Higher-order fractal creates an opportunity for positive collaborations of people to get noticed and get reputation. Reputation can lead to other great things for a DAO like new members and potential funding.
    
    ### Competition and collaboration between DAOs
    
    This I think can be a motivating factor for contributors. Higher-order fractal meetings will add more meaning to work performed by individuals in the sub-DAOs because it will add up to something bigger that will be recognized and evaluated at the end of the period.
    
    It will also create opportunities for DAOs to learn more about each other and collaborate.
    
    ## Design
    
    The core of higher-order fractal would be Respect game like in the typical fractals we know of. But instead of individuals competing for Respect we want to have fractals. For this we need fractals to be able to:
    
    1. Present contributions;
    2. Build consensus with other fractals on the rankings of contributor fractals;
    
    The simplest solution is to have each fractal elect a representative. This I think should work perfectly for solving the first (presenting contributions). It would be individuals presenting contributions but they would be presenting contributions of a whole fractal instead of just theirs.
    
    For the second, I think representative is not enough because, while you can prepare a presentation that presents the work of the whole fractal, you can’t really prepare for a consensus process on rankings where you would represent your whole fractal (its opinion on the rankings). Therefore, I think that after all participant DAOs present their contributions, they should be given at least a week to build consensus on their rankings. This will provide time for fractals to discuss the performance of each contributor fractal internally, within their own fractal. The final consensus would still have to be signalled by representatives of each DAO, so that there’s a clear point of contact from each fractal which allows consensus building among fractals.
    
    So from a representative’s perspective, consensus building could be a 3 step process:
    
    1. Poll his fractal for their opinion of how all the contributor fractals should be ranked;
    2. Negotiate and build consensus with representatives of other fractals (who are presumably doing the 1st step as well);
    3. Signal consensus pre-agreed among representatives;
    
    If representatives do not properly represent their fractal (do not do the first step for example), it is up to that fractal to solve that issue internally and elect a better representative for the next higher-order fractal meeting.
    
    There are some other changes and considerations to the fractal process we might want to take into account.
    
    ### More time in between meetings
    
    Considering that the overhead required to reach consensus (even through representatives) is bigger in the higher-order fractal, meetings should happen less often than a typical 1 week. Plus each participant DAO usually has its own weekly meetings as well. At least 1 month in between higher-order fractal meetings would be more appropriate but an even bigger gap might be sensible as well. This will give more time for fractals to make something happen, which will make their contributions more interesting.
    
    ### More time for the presentation of each DAO
    
    Since each representative will be presenting contributions of the whole group, over a period longer than 1 week, I think they should be given more time to present. Currently, I think the typical time for each to present ranges between 3-5 minutes. For higher-order fractal, 10 minutes might be more appropriate. The time given to break-out groups should be extended as needed.
    
    ### Any kind of DAO should be allowed to participate even if it does not follow a fractally-like process
    
    As long as they present a required interface (i.e.: elect representatives) I don’t see a reason for higher-order fractal to not include them. A variety of different competing consensus processes is good for the ecosystem (see [Motivation](https://www.notion.so/c18cfb5756de4a11b0263e89ca375ccb?pvs=21))
    
    Furthermore, I would consider allowing 1 person DAOs to participate. This can be useful when a person is starting a project and has plans to accept community contributions to his project but has none yet. Then it makes sense for him to create a fractal that would eventually attract contributors. Meanwhile, he would still have a place to present his contributions regarding the project he wants to work on in higher-order fractal meetings. However, it is important that each DAO should be evaluated by the same standards regardless of its size. So 1 person DAO should normally not be able to compete with larger DAOs (assuming those larger DAOs are doing useful work).
    
    Participants of a higher-order DAO should try to evaluate its sub-DAOs primarily based on their output and not their internal structure. This respects the autonomy of each DAO, which I think is necessary (considering we are talking about decentralized *autonomous* organizations). This is kind of like having some base respect for the privacy of another person’s mind (their beliefs and opinions) as long as the person acts in a socially acceptable manner.
    
    I would make a proposition that bad governance processes would always eventually reflect in the outputs of a DAO. For example, if some sub-DAOs have a governance process that does not respect their members, eventually those members will leave and join other DAOs, which will eventually reflect in the output of that DAO and their rankings in higher-order fractal.
    
    ### Higher-order fractal needs a consensus process
    
    Since we are giving more time for presentations (so meetings will take longer), and consensus building among fractals will be slightly more complex, it might make sense to be more careful regarding who participates. Higher-order fractal needs a consensus process for adding (or at least removing) participating DAOs if nothing else. Another reason a consensus process might be needed is the scheduling of meetings.
    
    I don’t think [Eden+Fractal](https://edencreators.com/plus) is suitable here because it adds another consensus problem (electing a delegate fractal) and as already mentioned these consensus problems cost even more in higher-order fractal. Therefore, a top-contributor-based process[1](https://www.notion.so/Higher-order-fractal-829655f29b2d4f98b2de8de6b7b371be?pvs=21) would probably be more suitable. This means, however, that we will have to agree on a way by which each of the top fractals signal their approval of a proposal. Again, the question of what mechanism is used for participant DAO to decide to issue this signal is up to each participant DAO to determine.
    
    ### Should people be allowed to participate (contribute to) multiple participant DAOs?
    
    Generally when you have teams competing you don’t allow members of teams to overlap. So it would be natural to expect that being a member of multiple participant DAOs should not be allowed by the higher-order fractal. Plus competition might be more interesting this way. However, actually enforcing this would add a lot of complexity to the system and I would argue that we don’t have much to lose by allowing this.
    
    The complexity that enforcement of this rule would add would be a bad kind of complexity where higher-order fractal would have to influence the inner structure (membership list) of a sub-DAO (which means infringement on the autonomy of a DAO). Not to mention that any complexity in higher-order DAO is very costly since changing any of the rules will require consensus from all participant DAOs.
    
    One of the things that could happen if we allow participation in multiple sub-DAOs is that some contribution of a single individual ends up being claimed by multiple sub-DAOs. But then it simply means that these contributions “cancel out” when comparing these two DAOs.
    
    If some contributor is contributing different things to different DAOs (helping them both), then it means that he is splitting his time and that reflects a certain amount of respect for both DAOs. It means that both DAOs are doing something right because they are attracting contributors.
    
    Another argument against allowing participating in multiple sub-DAOs is that it would allow people to play dirty by sabotaging competitor DAOs from within. But this can be ascribed to be a problem of individual sub-DAOs as opposed to a problem of higher-order fractal. There are multiple things a DAO could do to protect from sabotage at a local level:
    
    - Transparency regarding who the members are - if members of a DAO are not anonymous then they would have to risk their reputation by trying to sabotage;
    - Review process for contributions (which is already being done to some extent in fractally-like DAOs) could catch any malicious contributions;
    - A good DAO should allow space for members to question the honesty of other members;
    - A DAO could (and probably should) have a mechanism for kicking out members who are malicious (detected to be sabotaging);
    - Simply not allowing people to participate if there’s evidence of them participating in other DAOs;
    
    It’s up to each DAO to decide what methods they apply. If a participant DAO fails to protect itself then it is useful information when evaluating its process and comparing it with other DAOs. Plus a higher-order fractal will not be able to protect from all cases of malicious behaviour. So DAOs will need to think about protection mechanisms for themselves anyway and I think it will be more useful for higher-order fractal to evaluate those mechanisms instead of enforcing them.
    
    So my preliminary answer is that higher-order fractal should not have a rule against allowing people to participate in multiple DAOs even if those DAOs are competing in a higher-order fractal.
    
    ## Conclusion
    
    DAOs / fractals can gain a lot of benefits from organizing into a kind of DAO of DAOs. Here I propose one model for that which I call “higher-order fractal”.
    
    The guiding principle behind higher-order fractal model is that the DAO that encompasses other DAOs should make a conceptual leap where its participants are smaller DAOs instead of individuals. This will give it a legitimate claim to be called DAO of DAOs. Other than that this DAO should mirror the design of a normal DAO composed of individuals as much as possible. This will make the system simpler and composable.
    
    I propose that this DAO of DAOs should mirror the structure of a typical fractal because it seems like the most natural way to create that kind of DAO. Think of it like a periodic conference for the ecosystem of DAOs, except besides just presenting their progress they would also be playing a game to rank each other’s progress. Besides providing many other [benefits](https://www.notion.so/6b784976920042829a6fdbf55af2199a?pvs=21), this simple game enables bootstrapping a whole higher-level governance process without requiring founder DAOs to agree on any sort of complex ruleset upfront.
    
    ---
    
    1. E.g.: top 6 contributor DAOs over the last N meetings have votes in approving proposals, where you need 4/6 votes in order to pass a proposal.↩
    

- Relevant parts of transcript from EF 73
    
    
    last few weeks I've been working on something like what I call higher order fractal
    39:12
    idea so this is about how we can how we
    39:17
    have all of the these fractals and the idea is to create a fractal composed of
    39:24
    fractals so each of those fractals that we have we could elect a representative that would go into this
    39:32
    what they call higher order fractal present uh what they did as as a whole
    39:39
    fractal as a group and uh and then there is another
    39:46
    process where these fractals would virtually rank each other
    39:51
    uh yeah so where would have to be some
    39:56
    changes made but I I think I covered most of them and I think there are there
    40:02
    would be a lot of benefits to doing this uh starting with like useful data points
    40:10
    comparing different uh fractals different consensus
    40:15
    processes uh because different fractals are starting to like make changes to how
    40:22
    to how to how we are working and this would be
    40:27
    like this higher order fractal could could provide help help in evaluating
    40:33
    these different processes uh and I think it could like make for a fun event where people are
    40:41
    presenting not like their weekly contributions but uh may maybe monthly
    40:47
    work off of a whole group of people and
    40:53
    essentially this could become like presentations of of of products as
    40:58
    opposed to Simply like uh like Promises of work being done like
    41:07
    like we typically have uh I I cover more benefits in the in the post I shared it
    41:14
    in the chat and there is another related idea which is about like how Eden
    41:22
    fractal could become a higher order fractal if if it if it if it wants to go
    41:29
    in that direction where I can see counterarguments for that I did not cover all of them in this post but just
    41:37
    want wanted to throw it out there as an option
    41:43
    uh yes so yeah I made this
    
    I've got some something to contribute to that with regard to DS um I think
    52:25
    there's a role where I think role to play for
    52:35
    a to serve other fractals and and the Greater Community so I totally agree
    52:42
    with that with that idea um one one of the ideas that I've had is
    52:51
    that is that one revolves around tools and I I I think that's part of what you
    52:58
    were suggesting toas I'm not sure uh but I think that's the most that's what people are hungry for is different
    53:05
    tools uh and and and services for Dows and that's what I've been trying to push
    53:13
    upscale to do and then they decided that they wanted to be an ambassador program
    53:18
    and now now that everybody's gone and not showing up to the work group meetings they're now
    53:24
    introducing products and services for Downs so it's a very strange Dynamic that's going on
    53:30
    over there either way uh I think this needs to happen and frankly I think this
    53:36
    group here is eminently more qualified because this is where all this the software has been uh developed uh since
    53:45
    lmer has is is not with us uh in our in our community
    53:53
    anymore um and this is where so many different other fractals have been born
    53:59
    from so I think it's a great idea I'm interested to know uh I I don't I'm not
    54:04
    sure I guess the the the other side of the feedback would be I'm not sure about uh higher level that's I guess that
    54:13
    that's not really the most important thing but uh I don't see it as as a
    54:19
    being higher in terms of hierarchy in terms of power I
    54:25
    I think of it maybe as a more Central let's say where where information is
    54:31
    passing through uh but not not Central in terms of power but just information
    54:37
    and and and power and not power but uh but tools and services that are going
    54:43
    outward so I think of it just mentally as more of a a flat orientation relative
    54:49
    to other other fractals not not necessarily A Higher One and the reason
    54:54
    I I say that is because I think the natural tendency for I guess humans or just
    55:03
    whoever seeks power is to try to to to get things underneath them and right and
    55:11
    uh so we have to I'm not saying that that's we should never do that and
    55:17
    that's you know under all circumstances but we have to be conscious about that where we're we're now we're we're
    55:24
    allowing a parent organization to control us so the same would be true for
    55:30
    for fractals if we if we really accept the concept of a higher fractal versus I
    55:37
    don't know how else to word it except Central so that's my feedback on that and I really appreciate you thinking of
    55:44
    that and uh it's amazing that we're without even discussing it we're on the
    55:50
    same wavelength to us thanks yeah I'm I'm glad to hear that too and
    55:58
    you you touched some fascinating points here and I would love to discuss more uh
    56:05
    maybe we can do it either in the chat or you can leave comments in the I think in
    56:11
    oce where I where I where I publish these posts uh yeah or maybe in the main
    56:19
    room we will see but yeah uh yeah but now we have to reach consens right down
    56:26
    yep that's right thanks Perry for sharing your thoughts and I'd be happy to dive deeper into this uh when we
    56:32
    start playing kendes and maybe uh we'll come to consensus in the next five minutes or so or 10 minutes or however
    56:39
    long it takes and then we'll get back into that topic thanks for sharing your thoughts Perry and so far there's been four people who joined the frr group uh
    56:46
    we're missing Eric and Perry so Eric and Perry could you please join the program
    56:51
    group toas Shar the link in the zoom chat and in the meantime if anybody had any questions uh or like some questions
    57:00
    or relatively short comments about uh just just focus on the contributions if you want to clarify anything like that
    57:05
    for the purpose of respect game then now it' be a good time to share uh and then for more detailed discussions then I
    57:11
    suppose it's best to save that for after we come to consensus okay I'm I'm in telegram thank
    57:18
    you for reminding me you're welcome thank you Perry and now we're just waiting on Eric who has now joined for
    57:32
    here and everybody can enter your ears account as a reply to the message
    57:45
    now this is gon to be a really difficult one too to choose it often is seems like it's
    57:51
    more difficult every week almost to choose who should be level six and five and four and and so forth but thanks everybody so much for all the awesome
    57:56
    work what's up I'm not I'm not looking for any credit at this point so don't worry about me guys I'm not uh that's
    58:04
    not why I'm here this week I'll be back I'll be back when D news is released for for massive points I'll be asking for
    58:11
    like a hundred points that week okay well yeah I'm looking forward
    58:17
    to that release sounds really
    58:23
    exciting yeah so so far it's all the votes are
    58:30
    all over the place yeah we we're just missing a vote from Perry so far I think no no no okay
    58:38
    my bad I'll refresh it to see who voted yes so I voted for Eric and I urge
    58:44
    others to vote for him because of all the on conference events and fractal POA
    58:52
    as well I'm very interested in that that's like [Music] uh that's like basically
    59:01
    what where similar direction to where I'm going as well
    59:07
    with with K order fractals as well so well since I voted for you I'll respect
    59:14
    your
    59:20
    wishes okay and thanks for sharing so yeah I was I was trying to decide
    59:25
    uh who to vote for I wind end up voting for TAS um because I think that you did
    59:31
    super super helpful work but with both this uh higher order fral article I'm really excited to learn more about this
    59:36
    and I think it's going to be very helpful and then also all your work with Optimus I know you also did get level six optim Rital too so that's something
    59:43
    to consider I was think about voting for Ros Marie as well because she also did wonderful work like promoting like
    59:48
    promoting and then editing like a bunch of videos and doing great show notes and stuff like that and I thought of voting Eric too but one thing I did think about
    59:54
    with regards to Eric is that Eric has done a great job so far promoting the pror blues event and organizing
    59:59
    everything like that but uh generally this is mostly about retroactive uh
    1:00:05
    rewarding of work and so I was thinking maybe I would save uh giving Eric level six after next week's or after this
    1:00:12
    week's event to see how it goes and stuff like that I'd also be open to voting for Eric too if you all think it's best but that's the reason why I
    1:00:17
    voted for tadas and it was close between tadas and Rose for me for me so uh but I
    1:00:23
    also really appreciate what ER is doing of course as well as um I've too not this is not to promote myself but in
    1:00:30
    theory you give credit for work too yes so not do that but in future when when I
    1:00:36
    evaluate people I go yeah whether it was successful or not that's worth something
    1:00:42
    of course when somebody does something successful it's worth more of it for example if tadas worked on coding I
    1:00:49
    would say that's significant even if it's not released yet I completely agree
    1:00:55
    and that's a good point under that you should be I should be like getting all
    1:01:00
    week well yeah if you could tell us if you could tell us what you worked on then
    1:01:06
    sure yeah I can tell you but I don't want to you just said that's what I
    1:01:13
    mean since you won't tell us we can't give you credit for what you won't tell us about that's true that's
    1:01:20
    true okay so well i' be open to s for Eric and I see Perry and show voting for
    1:01:26
    Eric I think there's been some change to votes nowas has three votes from me rosary and uh evany as well and then
    1:01:33
    Eric is voting for me so um does anybody else want to share their thoughts and try to sway everybody to who they think
    1:01:39
    should be level six or does anybody else want to repeat for the record I'd be happy to go either way
    1:01:46
    basically Rosemary created chaos she's the she's the Troublemaker this
    1:01:53
    time I I voted I vote for toas because
    1:01:58
    he's been very proactive with uh with
    1:02:04
    everything he been helping with the marketing uh
    1:02:10
    missions um also these high order
    1:02:15
    articles that he wrote I look forward to reading them soon and all the engagement
    1:02:21
    in the chats for organizing the optimiz fro um
    1:02:29
    application and uh just being very
    1:02:34
    active so and for the coding of course and it all it all worked perfectly on
    1:02:41
    Friday when we tested it okay you convinced me I vote for
    1:02:46
    myself okay I just you the tools did work well Andi I'm sorry what you saying oh I was
    1:02:54
    just saying I I'm a child I'm too easily
    1:03:00
    swayed all right so I think we have consensus I think we have consensus
    1:03:06
    no yeah we did yes now level five
    1:03:17
    okay oh my God we're gonna do it again I like Perry's
    1:03:23
    announcing my my playby play okay oh yeah just like in the horse
    1:03:32
    races yeah there could be like a commentator like live stream and someone
    1:03:37
    would comment there yeah Sports commentator I thought that a lot we've
    1:03:44
    got Dan in the lead let me ask you this does this thing when consensus is
    1:03:49
    reached does it stop or it can it can be reversed even after consensus is reached
    1:03:55
    it it actually can be reversed okay so it's just informational
    1:04:01
    it's just it's just a tool to help Community like like
    1:04:07
    build consensus not not determined okay all
    1:04:13
    right well I think the answer oh good lord who's causing these problems here
    1:04:19
    who's voting for me it's Eric's turn come on ah thank you good
    1:04:26
    God wrong horse in the lead okay
    1:04:33
    okay there we go there we go okay so that looks like consensus no is six is
    1:04:39
    that cons there's consensus I guess
    1:04:45
    we yes now we have consensus
    1:04:51
    on okay cool
    1:04:58
    thanks everybody for The Respect by the way yeah Shar with me
    1:05:05
    before hello hello
    1:05:11
    hello so far there's four voters in five voters in for
    1:05:16
    level three I voted okay but it looks like four people
    1:05:22
    voted for you rosemarine including Perry excellent which is like pretty wild
    1:05:27
    because Rosemary did like tremendous work she edited like 10 videos this week and did amazing
    1:05:33
    work so none what's none of this is fair
    1:05:39
    yeah none of it is fair well it's longterm respector and we're all doing a lot so that's true that's true and just
    1:05:46
    go to show what everybody else is whatever he's doing so well that's an interesting point
    1:05:53
    um if if we have a bunch of people that are that are contributing a lot
    1:05:59
    theoretically you would you would hope or assume that there would be contributions to this group so people
    1:06:07
    who may even be at the lower half of the of the ranking could still be making
    1:06:13
    good money because the in because the contributions are higher so we're kind
    1:06:18
    of we're kind of playing in a in a in a playground here where things are not necessarily
    1:06:25
    realistic but I think it's worth continuing to play this uh the way we
    1:06:30
    are because we're learning okay who was delegate last week
    1:06:37
    was that me I don't remember check the spreadsheet now to see who's
    1:06:43
    delegate I think I became delegate last
    1:06:49
    week we consensus on level uh two by the way so thank you ay and thank you bar
    1:06:57
    thank you everybody very much and as for delegate last week has
    1:07:05
    this been updated uh to do or should I check the blockchain to
    1:07:11
    confirm I see in 54 Perry and the do were elected as a delegates but I don't know if that was this week or last week
    1:07:17
    I'll check the account yes yes it's I just was from last week
    1:07:24
    yeah so I'm out I don't need another one me too so also Dan has two positions
    1:07:34
    R Mar has one yes but my one is running out next week yes
    1:07:41
    okay well I'd be happy to have o for as a
    1:07:46
    delegate is anybody else interested in running or should we vote for R Marine
    1:07:52
    is if Guinea in there does he want to could be no think I I don't think I have
    1:08:00
    enough experience and and my English
    1:08:06
    not ready for this okay well your English is quite good you're
    1:08:14
    quite experience so if you are interested in being a delegate in future week I'd be happy to hear it but I'm
    1:08:20
    happy to vote for Rosary for this week
    1:08:25
    and we have consensus I started the action or I started the button so once s do Post
    1:08:32
    consensus results then we can all click it there and everything should work smoothly so please put that up on chain
    1:08:39
    when you get the opportunity you have to do post that and thanks everybody for the
    1:08:46
    awesome respect gam big round of applause for everybody thank you thank Youk
    1:08:52
    you all right and I suppose that we'll get into
    1:08:59
    the agendas we are we only have 40 minutes left because Eric's got the event going on at 18 UTC and um very
    1:09:08
    excited for the fractal pla coming up but we want to make sure we wrap it up in time so that we can smooth the
    1:09:14
    transition over to the Practical loser and so I suppose that we'll just get into the uh kendus game and yeah
    1:09:22
    normally we post on consorti but this week I actually didn't have a chance to put it on Consortium so if anybody did put a prop a topic on Consortium then
    1:09:29
    that would take priority over uh any of the topics I had up there so um I didn't
    1:09:35
    check it yet to see if anybody did but I'm assuming I don't think anybody did uh so if anybody did or or really if
    1:09:41
    anybody has any topic that you really want to discuss first then feel free to take the lead here um and let us know
    1:09:47
    whatever is on your mind but otherwise I suppose I'll just uh do a little quick screen share and I'll recap the topics I
    1:09:54
    had on the agenda before that I gave a little preview of and then we can take it from there and see what topics we
    1:10:00
    want to dive into deeper I know for example Perry expressed a lot of interest in diving deeper into the
    1:10:05
    higher order fractals which we could discuss here we could also discuss that in text and as said that you can come in the notion there too but uh would' be
    1:10:12
    happy to discuss that or any of the topics we have lots of exciting things to discuss so feel free to jump in if there's
    1:10:18
    anything on your mind if not then I'll start a screen share in a moment and recap the topics the agenda and yeah we
    1:10:24
    could just also play it by year to if anybody wants to jump in and dive in any topics deeper if I'm sharing the
    1:10:29
    presentation I'm curious to know how you feel about uh this this idea that tadas
    1:10:35
    has put forth have you read that article I've read probably half bit I've skimmed
    1:10:41
    over it and I've read in detail like half bit but I don't have a full understanding of everything uh yet so
    1:10:47
    I'm interested in Reading I wanted to read it all but it just been like a crazy busy week with uh trying to get
    1:10:52
    the application out for RPGs and trying to other websites like that so normally I would have just like dove into it and
    1:10:57
    read it all right away but I'm not totally informed but from what I understand I like it very much and it
    1:11:03
    sounds very interesting um and I think it's a really helpful idea I also see a lot of value too uh in like the weekly
    1:11:08
    meetings with people giving their personal contributions as well or people sharing what they personally did and I think to do agrees with that but I think
    1:11:15
    that there's definitely room for uh like a an event or a fractal um that has
    1:11:23
    events where people are sharing what they did with their fractal or with their group or with their community and
    1:11:29
    then coming to represent their Community uh and then it's it's kind of like the fractal paloa in many ways and I think
    1:11:35
    we could do that on a more recurring basis um and I think that'd be awesome and it also reminds me a little bit of
    1:11:41
    the uh the original conception of teams in the frackle white paper too by the
    1:11:47
    fra team they had this idea that people could form teams um with I think up to 12 people and basically people wouldn't
    1:11:54
    just be representing their own work during these rense games their respect game but they representing their entire
    1:12:00
    team's work and so I think that's really valuable and I think there's a lot of really great points that the do makes there um but yeah I'm looking forward to
    1:12:06
    also diving in deeper and uh and leaving comments on the notion page and Telegram
    1:12:11
    and so forth to get into all the other details all the exciting details and I'm really excited in general at toas is
    1:12:18
    shared another idea that seems super inspiring and super hopeful with us so
    1:12:23
    when I was looking at the uh art fractal I realized that in the real world I wasn't going to get more than an hour
    1:12:29
    times so we came up with a workflow that
    1:12:34
    alternates between the consensus and kajas every other week does an
    1:12:43
    hour and the delegates run the they get choose chosen one week um have to set up
    1:12:52
    the uh
    1:12:57
    agendas yeah I remember discussing that with you Eric as we were planning uh or
    1:13:03
    as you were playing the art FR and I was just helping to provide some feedback and discussing a lot of the early meetings I'd be curious at some point to
    1:13:08
    learn like any updates because I'm not totally sure the status is of art fractal but I I agree I think there's a
    1:13:16
    lot of room for I some of that will come across at fracto paloa is what I heard oh all right stay tuned stay tuned
    1:13:25
    seg motion pra for all right excellent which is also related to the higher
    1:13:31
    order fractal in some way as well so yeah I'm stoked about that and uh yeah I agreed there's a lot of room for
    1:13:37
    experimentation so far we've been kind of keeping simple with one specific form of fractal uh and like this one uh kind
    1:13:44
    of pretty similar system that we've been going with meeting with both the kendes
    1:13:49
    and the respect game but we've seen lots of iterations with different uh communities like aquadec and aw fractal
    1:13:56
    and so forth and uh with the r fractal for sure you can separate it from we basis as far as there's there's kind of
    1:14:02
    two things that organizations need to keep going and grow and one of them is
    1:14:09
    constant wins so the fact that we do delegates and get tokens whatever
    1:14:15
    fractal you're in gives you these constant wins but the other thing in
    1:14:20
    order to keep people here and engage is you need Unstoppable momentum which means that when you
    1:14:26
    finish one thing it needs to move on to another thing which means to move it on to another things so the other reason we
    1:14:32
    did that is because you have to move ahead on making decisions and getting
    1:14:39
    deliveries so that you have this road map that you're on a journey as opposed to you come to the same place now social
    1:14:47
    come together fine we're still here but if you want to get that that big growth
    1:14:53
    grow people have to feel like there's some momentum and that that comes from
    1:14:58
    making and executing decisions and saying oh oh look it worked Ju Just just
    1:15:03
    a thought is the other reason why I talked about alternating is because you
    1:15:09
    know you feed the constant wind and then you feed the Unstoppable
    1:15:16
    momentum there's more to it than that I could talk about that all day but those are good points
    1:15:23
    the thing I like about tas's suggestion is that it it's take it IT addresses the
    1:15:29
    things it's basically saying it's it's basically harnessing the things we're
    1:15:35
    doing naturally so I I like I've I've learned that it's much easier to get
    1:15:41
    things done if you if you take something whether it be a tool or whatever it is
    1:15:48
    you know you could be a it's I guess the best example and I hate to to make a metaphor for with us as as animals but
    1:15:56
    but it's best to take a a dog choose if you choose a dog that has
    1:16:01
    the right traits uh to train it correctly into
    1:16:07
    what you want it to do so you choose things that are already doing what you
    1:16:13
    want naturally and so our group is naturally building tools and naturally
    1:16:18
    sharing sharing news so that point that he made that I think is really it really
    1:16:25
    speaks the loudest to me uh if we can somehow uh institutionalize that so to
    1:16:33
    speak or or you know make that really our official mission and and and
    1:16:39
    focus uh then every time tadas comes out with a new tool or myself I come out
    1:16:45
    with a new service whatever the case may be or we're sharing we're sharing significant news with each other those
    1:16:51
    are wins those are wins for us and and we're we're actually we're actually
    1:16:58
    contributing to the Greater Community which is already happening I mean that's how that's how all these other fractals
    1:17:05
    had got have gotten started most of them had experience here in this room so I
    1:17:11
    think it's it's it's uh I think it deserves a lot of our attention over the over the next weeks I hope it does I
    1:17:18
    hope we can talk about that and U and move in that direction I think that's
    1:17:24
    great yeah and I'm very curious I don't know if anybody has any information as
    1:17:29
    to what the uh the sync group The Dan larer Leed
    1:17:35
    sync group is doing um and does anybody have any information I think Vlad said he he
    1:17:41
    thought that well Gregory Wexler flows up shows up at fractal paloa you'll know
    1:17:46
    more but um h is in a half an hour from now
    1:17:56
    yes so Gregory is tentatively planning to show up at that oh okay but the
    1:18:03
    bottom line is they're about ready to launch um with I think four three or
    1:18:08
    four groups I'm trying to get them to add a group for the uh real world
    1:18:14
    Community uh with the art fractal stuff I'm doing so they're talking about that and I talked to them about gaming how
    1:18:22
    about launch a gaming group but the they've developed their
    1:18:27
    tools their tools uh just have you log in using the normal login ways
    1:18:33
    Google Apple Facebook I know you can log in with Google and you're just ready to
    1:18:40
    go the tools are there all integrated and do do you get a sense of
    1:18:47
    uh the timing of the release yeah like now
    1:18:54
    wow okay okay awesome before the before the end of the year yeah okay fair
    1:19:01
    enough well that's good to hear yeah it's very exciting yeah it is very
    1:19:07
    exciting it could it could give everybody a big boost but while it can
    1:19:13
    um be attached to a chain it doesn't have to be which is important for me to
    1:19:20
    start it can't really okay can but it doesn't have to be it's written so you
    1:19:26
    can write that right to a chain but it's not a
    1:19:32
    requirement okay have you had a chance to see it or you're you're learning I I
    1:19:37
    have not but I have talked to the people directly okay
    1:19:45
    fantastic well that's good to know yeah I I'll be excited to to find out whether
    1:19:51
    uh whether wexley uh whether he's there or or not but uh
    1:19:58
    yeah so that's it at half an hour fantastic thanks yeah thanks so much Eric for
    1:20:06
    organizing that and coordinating that and thanks Perry for sharing all thoughts I learned some new stuff about
    1:20:11
    sync there I've been following like I read all their blog posts on [sync.com](http://sync.com/) and their substack and then I've been in
    1:20:17
    touch with James Mart a bit here and there but um I haven't heard much from Gregory and most of the team members uh
    1:20:22
    uh um so seeing what they've been building with their team for just about
    1:20:28
    a year now since the general start stopped um I'm sure that both uh sink
    1:20:34
    and sbase um they're building some really really exciting stuff that will'll be able to use and will help a
    1:20:40
    lot of communities out a lot so I'm very excited to learn
    1:20:47
    more all right cool does anybody else have any other thoughts on this topic or uh anything else you want to bring to
    1:20:54
    the attention of the group or any questions or comments or should I go ahead and maybe share a little overview of the other topics I had maybe that can
    1:21:01
    spark some thoughts or I don't know if Tashi wanted to go more into detail with the high fractal you brought up that a little bit
    1:21:06
    too the last comment I guess this is commenting on Perry's excellent comments
    1:21:12
    so the thing is if you go feed a lot of things they grow and a cage you get a win that's really good but it it doesn't
    1:21:20
    feel it's kind of like if people went on often played basketball what's the scoreboard so for
    1:21:27
    example if we're saying what are we promoting oh to Do's thing lad's things
    1:21:32
    and you're getting kind of a score of oh we're focusing this is the development
    1:21:37
    how can we help them with that this is developed how can we help with that so if there's a scoreboard it feels more
    1:21:44
    like an Unstoppable win than if we're you know throwing pebbles in the water
    1:21:49
    and saying oh look at the the w we created some down the line so it can't
    1:21:55
    just be momentum it has to feel like momentum can't just be a win it has to feel like a
    1:22:02
    win not sure if I know the distinction are you're talking about you needs to feel like a win meaning it needs to make
    1:22:08
    you money or which is not bad you just no it just needs to be I mean ju just an
    1:22:16
    example that imagine people played basketball and they did great shots and
    1:22:21
    they did it and oh at that great and a lot of great events happen in the basketball game it doesn't feel like a
    1:22:27
    win because there's no scoreboard that makes what is it that makes the basketball game exciting well
    1:22:34
    the play but it doesn't feel like play unless there's a scoreboard there yeah
    1:22:40
    that creates the intensity right it concentrates all that
    1:22:45
    down into an event so you know if they played basketball and then you get the
    1:22:51
    score imagine they played basketball but you only got the score a month later it it just doesn't it doesn't feel
    1:22:59
    you didn't see anything happened during that time you just said oh yeah here's here's the score here's Here's the final
    1:23:05
    score of that game well I don't think anybody's talking about taking away the rankings and getting points whether
    1:23:12
    those are associated with monetary rewards no I'm saying I'm saying we have a updated scoreboard for
    1:23:19
    us but for the events things projects like what tadas is doing we don't have a
    1:23:26
    scoreboard we hear about it it goes and that's great like like if you do
    1:23:32
    optimism when you submit that you have to say here's what our score counter
    1:23:37
    looks like how you GNA track that well um I'm not sure if we're talking about
    1:23:44
    the same thing maybe we are maybe it's related just different angles of the same thing it doesn't have it doesn't
    1:23:49
    have to be a big it just we have to tell the stories about what we're doing so you have a road map and people can see
    1:23:57
    it rather than saying oh Dan's Dan and rosemary are doing a media trip across
    1:24:03
    the country and then we don't we go and he's gonna go from east coast to West
    1:24:09
    Coast end up in San Diego of course because that's the best and then all you sudden you see Dan and rosemary end up
    1:24:15
    in San Diego we're all happy but where's when they stopped off at Oklahoma City and nebras
    1:24:24
    okay well even if we throw out once in a while and say oh by the way Rosemary and
    1:24:30
    Dan are here if you don't see that map and see pin it along the map it's
    1:24:36
    not as exciting it doesn't feel as much like we're there with them
    1:24:41
    and it's a win I see you're you're speaking I think more of a kind of a promotional marketing angle a
    1:24:48
    communication thing not we know that tadas is going out every week kicking
    1:24:54
    butt along with a lot of other people along with what you're doing we know that but but we to like oh here's a win
    1:25:03
    we go that's good and we're all behind it Well here here's here's my
    1:25:09
    perspective well just I just want to throw one thing Perry Tas say has hands raised and he's while so maybe we should
    1:25:16
    go to TOS first but but I'm very interested to hear respect of to Perry so I don't know if uh I suppose p and
    1:25:23
    then maybe come back to you Perry with that okay yeah sure no problem okay didn't see
    1:25:29
    that okay okay yeah and maybe just raise your hand in case anyone else wants to
    1:25:35
    talk so we have system I for me it seems
    1:25:41
    Eric what that what you're talking about is that we need a scoreboard not just an
    1:25:46
    inner scoreboard for like ranking each other like we do but also was scoreboard
    1:25:52
    for what we achieve as a group yeah the projects that we support
    1:25:58
    as a group yes exactly and that and that creates a kind of feeling of momentum
    1:26:04
    for for a group as a whole like because right now we are just sharing what we do
    1:26:11
    on our on our own and I guess we don't have that like as much of that sense of
    1:26:18
    achievement as a group yeah and it allows us to say where
    1:26:23
    do you need help it keeps an oh where are you toos what do you need next how can we help how can we help what can we
    1:26:29
    do is there anything we oh we can promote this we can test what do you need so it's it's that kind of it makes
    1:26:34
    us part of the journey and uh by the way uh I've already got the other Zoom open
    1:26:41
    for the next event and uh both Josh Seymour and Greg Wexler are in so want
    1:26:49
    to hear about PS excellent it's there ex super cool what I what I wanted to
    1:26:57
    the distinction that I wanted to make was the
    1:27:02
    uh the idea that that some of the things that that I would be offering and then
    1:27:10
    possibly I don't know exactly the form of of the of the code that tadas would
    1:27:17
    be offering but they both could I I think they could both be offered as services I'm just guessing I know for
    1:27:24
    sure mine could be offered as a service and and what I'm thinking of as
    1:27:30
    the winds are H are having other fractals view those Services as
    1:27:38
    valuable and and well worth paying for they would be they would they would say
    1:27:44
    I'm we are happy to come out of pocket for if we get this service that makes it
    1:27:49
    makes sense to us we'll pay this amount of money and we'll get this service and if we
    1:27:55
    have more than one of those a number of those services and we have people who
    1:28:00
    are going out and and selling so to speak but also
    1:28:06
    maintaining those services and then they're getting paid here in this
    1:28:11
    group for providing those Services part of it
    1:28:19
    could be D news but let's well let me use DS just as an example so you guys
    1:28:25
    get an idea what I'm talking about I have D news I'm producing D news I'm coming out with a new version of it that
    1:28:31
    I think is just super duper AI powered and just awesome and that and that
    1:28:37
    fractals will will look at it and say wow this really this was really helpful
    1:28:42
    we have to have this and the price is reasonable so we're willing to pay it uh
    1:28:48
    either in our own token or somehow we'll come up with you know with with the Fe because it just makes sense so those
    1:28:54
    fees now come into our group and and I as DSS would be willing to share those
    1:29:02
    funds with this group why well I yes it's true I I
    1:29:08
    develop D news and I maintain the website and I and I am responsible for updating the code and so on and so forth
    1:29:15
    but it might be members in this group that found the the fractal or identifi
    1:29:21
    or have or or are a member of that fractal and are willing to do
    1:29:28
    regular tasks that help maintain that service namely uploading meeting
    1:29:37
    videos or updating meeting recurring uh
    1:29:42
    events on a calendar those are the two basic uh uh uh task so this is this is
    1:29:50
    similar to what I had I had uh presented uh months
    1:29:55
    ago uh this is but it but my product is far more uh Advanced at this point from
    1:30:03
    there so that's that's what I'm suggesting is is that we actually make it a money-making adventure for our
    1:30:10
    group that's how we're we're we're getting paid because because fractals are willing to provide to pay for the
    1:30:18
    service and then we are paying ourselves by the ranking process we're deciding
    1:30:25
    right whether uh who gets paid what now I under those circumstances I would not
    1:30:31
    expect to be number six every every week but uh you know even though I'm even
    1:30:39
    though I'm sharing I'm doing a lot of the work by and I created the service
    1:30:44
    but I wouldn't expect to be number one either every week forever because that
    1:30:50
    means you hate me [Laughter] so uh I think it works I think it can
    1:30:58
    work out so imagining a fractal where where guys like myself are are providing
    1:31:04
    these services and tadas is providing a service which is you know whatever it is
    1:31:09
    I don't know which one is is most likely to to emerge but it's a service and those services are are contracted and
    1:31:16
    sold to other fractals and they pay a reasonable price for it and all of us who are assisting and providing that
    1:31:23
    service uh maintaining it we also get we get paid everybody gets paid so that's
    1:31:28
    what I'm talking about um those are wins is that is that momentum I think that's
    1:31:34
    momentum is that what you're referring to Eric something like that uh that works it doesn't matter I
    1:31:41
    you know I work for a software company we we had millions of customers all over the
    1:31:48
    world and uh what I noticed that our fans wanted to come on the ride with us so we did everything we could to make
    1:31:55
    them feel they were part of the journey they came in and tested their code with us They promoted us they contributed
    1:32:02
    code to us um and so there were a lot of we had actually 40 different markets 40
    1:32:09
    different markets of fans that were communicating with each other and you know they were part of the the team and
    1:32:16
    they wanted to feel that as we came out with our new release every year they were part of that Journey so I've
    1:32:22
    learned that in other things is it just answers the question what can you do that what do you want to support as a
    1:32:28
    group and how do you feel how do you make the group feel part of that journey and you can do it by pay you can do it
    1:32:35
    by inside information or special deals here's a thing there's a lot of ways you could do it but a lot of it of what we
    1:32:42
    did was just said here's the road map we made it very clear where we're going where we're going next and where we are
    1:32:48
    on that journey and every time we could we thanked people for helping us get on
    1:32:54
    their journey in fact once a year we gave awards for who has helped us and
    1:32:59
    that was a big deal from them I mean they get pictures and paper they put it in all their things so that I'm just
    1:33:07
    saying people have to feel there's one thing that's a social group which is we like each other we talk there's another
    1:33:13
    thing if you want to attract people is what's the journey you know and give us some map and make us feel part of that
    1:33:20
    Journey it doesn't have to be really hard time about build a lot of codes and things it sounds like what you're
    1:33:26
    talking about is the promotion of the future which is totally valid a road map and get excited and this is where we're
    1:33:33
    going that's awesome I totally support that what I'm referring to is is like
    1:33:39
    what's what can we offer today what will they pay for today what will pay us
    1:33:44
    today but that's a I think the combination is that's a right there we have this thing how do we get paid for
    1:33:50
    it that's a journey right there because you can't get P you can't do what you're doing right now so it's
    1:33:56
    not today we maybe next week maybe a month from now maybe months from now but
    1:34:02
    that's what we're talking about is what Journey are we on and where are we and you're just proposing another Journey
    1:34:08
    these Journeys don't have to be 10 years in the making they can be yeah but but very but I want to be very clear about
    1:34:14
    this I'm not suggesting that other fractals pay us on what we are proposing to do I'm I'm suggesting that that they
    1:34:22
    pay us for what we actually deliver week to week or month to month whatever
    1:34:28
    whatever the the frequency is I'm actual Services actual paid to be able to do
    1:34:33
    that to be able to do that together is a journey so I'm not I'm not dismissing
    1:34:39
    what you're saying I think they they
    1:34:44
    coexist so Perry and Eric I'm really appreciating the conversation it's fascinating um but also I know tasa has
    1:34:50
    hands up and also I also have some stuff I want to share too we have about 14 minutes left or so until the end of the
    1:34:55
    meeting so I also don't want to interrupt or cut you off but I just wanted to put it out there because St
    1:35:00
    has been waiting patiently is there anything else you wanted to add on there per Eric on that or should we pass off
    1:35:06
    in about five [Music] minutes I'm already Channel getting that up ready for forac toal use it okay cool
    1:35:14
    sounds good thank you Eric for letting us know and I'll feel free your drop off whenever you need and then I'm looking
    1:35:20
    forward to seeing you there in about uh Perry was there anything else you wanted to add there before we pass it on to to Dos or can we pass it on to dos
    1:35:25
    and I'll go next no thank you I think I I think I expressed it thank you okay sounds great thank you very much for
    1:35:32
    sharing the thoughts to us yeah so just wanted to say about
    1:35:38
    higher order fractal I think that's uh that's they can provide that kind of a
    1:35:44
    scoreboard literally for for different groups of people different fractals
    1:35:50
    because like you you you you the smaller fractal will know that that in like few
    1:35:57
    months we will have to present what they uh what they have done as a group and uh
    1:36:04
    uh and and we will get like uh a score for it basically compared to other
    1:36:11
    fractal uh yeah so besides that I'm also thinking about
    1:36:19
    this is a different topic like how how a group of developers could use something like a like a fractal system I I think
    1:36:27
    there might need some be some changes uh but yeah basically how do you
    1:36:34
    get fractal more focused than we currently have now because currently like everyone is mostly doing their own
    1:36:42
    projects and so on and yeah but the factal would be able to be Project based
    1:36:47
    and more focused that would uh I think that would make the higher order fractal
    1:36:54
    idea even more uh better because
    1:36:59
    simply the the presentations would be are more likely to be about some kind of
    1:37:05
    unified product instead of like lists of what different people
    1:37:15
    did great points thank you very much Das and uh I see had to go so thank you very
    1:37:22
    much evany um and yeah uh really looking forward to exploring more how um fractal
    1:37:32
    can coordinate and collaborate um and how the higher order fractals can help with that I also have some ideas too so
    1:37:37
    I don't know if you want to share anything more about that to Doss if any wants to respond to Dos then feel free to jump in but otherwise maybe I'll jump
    1:37:44
    in because we also only have like 12 minutes and I'll share a couple thoughts on my mind that are related to both these uh one thing I wanted to say and
    1:37:50
    we will start sharing my screen is uh that I think that this idea about um
    1:37:56
    her fractals and building momentum uh that people can rally around and kind of escore it also reminds me of stuff we've
    1:38:02
    talked about with three spect trees and also signals too and I think as like a road map but we can think of it kind of
    1:38:08
    like a fractor road map where it's like the roots basically of where we're like growing where we're expanding to and the
    1:38:13
    seeds that we're launching of new fractals so you can see with respect trees for example where in the respector
    1:38:19
    like you are at that point and where you're going forward and things like signals and stuff could potentially help with that maybe it's kind of out there
    1:38:24
    for now but I can also bring it down more to Earth in the future but I feel like we have the ways where we can now
    1:38:29
    vote and have much more coordination capacity to be able to decide okay what are what are our priorities and what are
    1:38:35
    the things that we're shooting for on our road map what are our milestones and so forth and those are kind of like the different points in the roofs or or
    1:38:41
    different roots that we're planting and stuff like that so thanks Eric for uh sharing the inspiration there and I'm
    1:38:48
    I'm loving how this is all coming together with the high ref fractal and fractal blues and stuff um I suppose
    1:38:54
    I'll just go ahead and just share my screen and just because I I think there's also three other topics I wanted to bring up to very curious to hear
    1:39:00
    people's thoughts about that uh but a couple topics I wanted to just maybe put out and then uh we can produce the video
    1:39:06
    and people can think about it uh before next week or in the future but a couple things I wanted to just put out there so
    1:39:12
    I'll go ahead and do that now I hope I'm sharing the right screen here I have two the same screens that
    1:39:18
    look the same right now so hold on one second please make sure I'm opening the right
    1:39:23
    one okay cool so yeah I showed you most of these topics before that I put in the
    1:39:30
    agenda and we discussed most of them enough and we can discuss them more in details but couple things I wanted to
    1:39:35
    bring up briefly before we wrap up this meeting is one I wanted to go over um
    1:39:41
    the idea about the new schedule and agenda for Eden fractal I already said that but just wanted briefly um in future weeks we're going to be starting
    1:39:48
    next week I'm going to put a message as well but we're going to start at 16 UTC rather than 1530 UTC uh and then we also
    1:39:54
    end 18 UTC pretty soon there's going to be daylight savings so I think this has a lot of reasons that be helpful so it's not so early for people and we'll have
    1:40:01
    uh time to be able to coordinate with Eric event and other events people won't be on calls for too long I think that's much better if anybody has any thoughts
    1:40:07
    about this then feel free to share we also have more details from last year uh about this time we decided eeden [cre.com](http://cre.com/)
    1:40:12
    time but just want to put that out there and we also be working to get it more organized as far as when we start and wrap up the presentations and sticking
    1:40:20
    closer to like the four or five minutes that people share in the respect game because I think that we're going to be entering opportunity with a lot of
    1:40:26
    growth and excitement um I mean there's already been a lot of growth excitement but also new people joining and so we want to have a really structured event
    1:40:32
    for new people who are joining uh I see Eric said see everyone at fractal Pala so very much looking forward to that it
    1:40:38
    coming up in about 10 minutes or so but before that one one thing I also wanted to share too that I was speaking about
    1:40:43
    with rosemary over this past week or so was this idea of the growing optimism with Eden fractal videos um and perhaps
    1:40:50
    I should should have brought this up more earlier uh and I can bring it up again next week but I encourage everybody check out these videos these
    1:40:56
    are like short clips and we talked about this uh back in week um 57 about like I
    1:41:02
    put out a poll about like how people feel about having their videos shared like short clips and stuff like that um
    1:41:07
    and so we also talked about like agreements too and ideas about that but we just want to make sure we're respecting
    1:41:13
    everybody's privacy or how much every wants to be like recorded and shared well at the same time we also want to
    1:41:19
    and need to promote what we're doing fractals and surf the best way to do it so this is something to consider and
    1:41:25
    most of these clips are mostly me talking with a couple questions here and there but just wanted to put it out there that we put these clips out there
    1:41:31
    and everybody can watch them so encourage you to do so and then if anybody has any thoughts about the best way to uh to do this then feel free but
    1:41:38
    basically we're working on this and I'll share more details next week also wanted to share uh the the Eden brto video
    1:41:44
    video that we released a few weeks had the most views that we ever had on interactor video um it currently has like 160 views something like that and
    1:41:51
    so uh pretty soon we'll be up there way more I think but really cool to see more people figuring out about Eden fractal
    1:41:57
    and really excited for our future as we grow so I just want to throw that out there and then also regarding uh Perry's
    1:42:02
    points too about like funding we were working on a business model we are working on a business model with optimistics too that could would be
    1:42:09
    great if were're able to reward uh people for participating praco meetings with the Retro pgf right now there's no
    1:42:14
    guarantee that we'll earn from R pgf um so it's still kind of up in the air and also there's like legal stuff that we're
    1:42:19
    trying to figure out but something that potentially could be helpful but for right now um there's no rewards like in terms of funding uh for these fractals
    1:42:27
    but it would be excellent to have funding for fractal so just wanted to put that out there because it might kind of relate to the other stuff that we're
    1:42:33
    doing with videos and everything like that uh and then for future weeks I'm also exciting to get some of the other topics too for example optimism season 5
    1:42:39
    opportunities I'm planning to apply for the optimism grants Council if people are looking for funding there's lots of opportunities here where you can work
    1:42:45
    within the opportunism ecosystem and uh there's quite a lot of places where you can earn decent funing funding while
    1:42:51
    helping out and doing stuff that's really interesting pioneering public goods and so forth so in case anybody
    1:42:56
    wants to check this out I know that the gr Council applications I think they're open for another week so if any wanted to look into this and you can feel free
    1:43:02
    to reach out to me um and then I also wanted to give a shout out to gou uh you can check out the video of The aquadec
    1:43:08
    Mastermind that we talked about yesterday too um or that we had yesterday we talked about earlier so
    1:43:14
    those are kind of the ideas that I wanted to bring up I also had a couple other links uh here about about respect
    1:43:19
    trees CU I mentioned that in really to the idea of how we can coordinate um and
    1:43:24
    like figure out a better road map and ways to coales around goals together and
    1:43:30
    have that kind of point system that we're all working towards together so [eden.com](http://eden.com/) resect trees and there's a
    1:43:36
    video here ef6 respector and [eden.com](http://eden.com/) signals we can learn more about how these might work together and I
    1:43:41
    encourage you all to check out the doss's post in [t.me](http://t.me/) eeden fractal uh to learn more about the higher order
    1:43:47
    fractal as well and leave some comments and share your thoughts as well as everybody can leave comments here too so if you have any comments about the
    1:43:53
    change in time or schedule anything that for optimis Factor then feel free uh or about the growing optimism with Eden
    1:43:58
    fractal videos and lastly I just wanted to once again uh encourage people to
    1:44:03
    check out uh what we check out optims fractal check out optim [fra.com](http://fra.com/) it's still work in development but there's lots of helpful resources here as well
    1:44:10
    as the rscp and details you can learn more about what we're doing uh growing optim Optimus fractal and encourage you
    1:44:16
    all to join the optimism fractal event in addition to eaten fractal events every Wednesday at 6 UTC uh we're now
    1:44:22
    starting to host these optim fractal every Monday at 17 UTC everybody is invited everybody's welcome to join uh
    1:44:28
    it's focused on helping optimism but it's also an excellent opportunity for all people who are interested in fractal
    1:44:33
    communities and growing fractals to grow fractals with optimism I see there's huge uh huge benefits and synergies
    1:44:39
    there for everybody here and probably everybody watching so encourage you to join uh you can join the Discord too to
    1:44:45
    learn more feel free to ask any questions here uh in the Eden verto meetings or in the telegram or in the Discord and then you can find this link
    1:44:51
    at lou. optimis facto and I also encourage you to watch our um our first
    1:44:57
    video Welcome to Optimus and fractal where we had the first meeting so you can learn more about optimis and fractal there and what we're doing and also see
    1:45:04
    a little introduction about what we're doing with the optimistics team too so I hope to see you all there we're also thinking about hosting an edent toown
    1:45:09
    Hall like special edition on um Monday maybe before after the event and that can be a way where because optim back
    1:45:16
    events will just be one hour long they're quite shorten to the point with respect game but also maybe we'll have the next half hour hour show just to
    1:45:22
    kind of go over some of the benefits and stuff and I'll share more details about the chat and encourage you all to check it out and join and would love to see
    1:45:28
    you there it' be really great for optimism fractal and what we're doing uh to show up with some of the Eden fractal
    1:45:33
    community members so we can help convey all the knowledge that we've learned over the past years um and past weeks
    1:45:39
    and months and all the amazing things that people are doing and help spread what we're doing with fractals and help out the optimism community and help
    1:45:44
    launch optims and fractal in an amazing way so um please feel free to reach out to any questions and we'll be happy to
    1:45:49
    see you there and and then lastly also encourage everybody to join the fractal paloa first event that Eric has
    1:45:56
    organized as he discussed you can find the link to this I don't know if he shared the link in the Eden fractal telegram chat but if not then I will
    1:46:02
    forward this message he posted in fract Alan worlds so I I'll forward it into the eaten fractal telegram chat so you
    1:46:07
    can find it there looking forward to hearing more from Eric about the art fractal and Dwayne about the aw fractal
    1:46:13
    we'll talk more about the op fractal eeden fractal talk about uh Prime Law Society with Joshua Joshua is working
    1:46:18
    with really exciting stuff with the prime law which is a it's a wonderful kind of one Commandment that can help people cooperate peacefully hear updates
    1:46:24
    from sync with Gregory and here updates from space rer Joe about up plan fractal
    1:46:30
    so that's that for my uh presentation here we only have a few minutes left so we could just wrap it up now or if
    1:46:36
    anybody has any uh last minute thoughts then we'd be happy to hear from
    1:46:41
    you any thoughts I'm I'm ready to wrap up and uh
    1:46:49
    and drop into the paloa and see what we learn with all those guys so thank you
    1:46:55
    Dan thank you for doing this every week and uh I appreciate you and
    1:47:02
    rosemary for making all this happen for us thank you thank you very much Perry I
    1:47:07
    appreciate you greatly as well I see to do gave a thumbs up too I think he was ready and he just uh snuck out into the
    1:47:14
    um proor pla I saw also Joe said thanks guys with uh praying peace kind of sign
    1:47:20
    hand gesture Emoji in the chat so it looks like Joe's over there too but yeah Perry I really appreciate you uh sharing
    1:47:26
    all your thoughts and all your support so thanks so much and I'm ready to go there too and thanks for with me of course it's been wonderful working with
    1:47:33
    you and seeing both you and everybody who's been joining thanks everybody so much for watching us here at Eden fractal we got a clap from Perry thank
    1:47:39
    you so much something we tried at optimis fractal was we have this idea about growing optimism so uh and then we said
    1:47:45
    grow optimis fractal and I kind of like that for Eden fractal too like grow Eden fractal as opposed to go fractal cuz
    1:47:51
    kind of like growing like fractals and stuff so if you want we could try it out I'm just putting it out there but also
    1:47:56
    I'm curious if Ro you have any last thoughts before we wrap up let's go let's go okay let's go let's go okay so
    1:48:02
    I suppose we can wrap it up we're already then um and if you all want to join we could say peace and love peace and love to the universe thanks
    1:48:07
    everybody for watching so much it's about peace and love Yeah peace and love
    1:48:13
    the world that's what the world needs right now peace and love absolutely very very well said well
    1:48:20
    thanks so much Perry thanks so much for thanks everybody for watching hope you have a wonderful day see you at fractal paluta growing Eden fractal growing
    1:48:27
    fractals wonderful things that we're doing to grow peace and love thanks everybody and see you next time see you
    

- Text from Eden Fractal as higher order fractal article
    
    
    # Eden Fractal as higher order fractal
    
    Recently I published a post about an idea of a higher-order fractal. Here I will try to present a path for EdenFractal to become one.
    
    ## Motivation
    
    Obviously, higher-order fractal could be implemented as some new fractal with some new name, so why would we focus on EdenFractal becoming a higher-order fractal?
    
    The most important reason is that in my eyes EdenFractal is already starting to perform that function:
    
    - Jorge is often presenting what he did with spanish-speaking fractal;
    - Multiple other people are presenting their contributions to Upscale;
    - Me and Dan are present our work to OP fractal as contributions;
    - Gudasoul is presenting Aquadac;
    - Multiple people are presenting their work in AW fractal as contributions;
    - Vlad is presenting work on what will become Zeos fractal;
    
    And I’m probably forgetting something…
    
    In other words, EdenFractal is starting to serve as a hub for sharing news and progress in different DAOs. It seems to me that EdenFractal is the most overlapping and the most central fractal. It is also a place where collaborations that produced some of these other fractals were born.
    
    EdenFractal does not have a formal mission statement, but I think it is fair to say that based on contributions presented in a typical meeting, the implicit mission statement is something like “spreading fractal democracy” or “experiment with decentralized governance models”. This is a general mission to which all the other existing fractals seem to be aligned.
    
    ### Potential path towards EdenFractal becoming higher-order fractal
    
    A higher-order fractal should assign Respect to fractals / DAOs (accounts representing them) as opposed to individuals. This means that the current Respect distribution of EF is incompatible with it being a higher-order fractal. But this could be resolved in the following way.
    
    1. Have each fractal (except EF) signal their willingness to be participant in EF, if EF becomes a higher-order fractal;
    2. Create a poll where EdenFractal participants could vote with their Respect on fractals which signalled approval in the first step;
    3. Create a new fractal called EdenFractal 2 (version 2 of EdenFractal or EF2);
    4. Create an initial Respect distribution for EF2 by each fractal receiving an amount equal to the amount of Respect votes received in the poll created in the second step;
    5. Stop current EF weekly meetings and start periodic (every 1/2/3 months?) EF2 meetings, which would work roughly in a way described in post …
    
    This path would keep the existing Respect distribution of EF before it was transformed on-chain for historical purposes.
    
    I don’t suggest that we actually start using the name EdenFractal 2 instead of EdenFractal. In everyday speech, we could refer to EdenFractal 2 as *the* EdenFractal. It’s just that it would be version 2 of EdenFractal that would currently be active. It’s like a blockchain network doing a hard-fork to upgrade.
    
    ### Conclusion
    
    EdenFractal already has important prerequisites for being a higher-order fractal:
    
    - It is a place where people from different fractals meet to share updates about their fractals;
    - Its mission is aligned with missions of participant fractals;
    
    So instead of adding a burden of another periodic fractal meeting for higher-order fractal maybe it makes sense to transform EdenFractal into higher-order fractal?
    
    This transformation will require some drastic changes but it could be seen as natural evolution of EdenFractal and if it would succeed in pulling this off, it would be an impressive demonstration of its ability to adapt and stay relevant.
    
    This is just one option for how to create a higher-order fractal and EdenFractal could evolve. There might be some downsides to this, which are worth considering… But the point of this post is to spark the discussion.
    

- Dan’s Feedback
    
    
    For the second, I think representative is not enough because, while you can prepare a presentation that presents the work of the whole fractal, you can’t really prepare for a consensus process on rankings where you would represent your whole fractal (its opinion on the rankings). Therefore, I think that after all participant DAOs present their contributions, they should be given at least a week to build consensus on their rankings.
    
    Another option is to livestream the respect game amongst contributors of other fractals and allow the other contributors to vote in real time.
    
    I’m not sure if the week long delay might decrease some of the natural excitement of fractals. The fact that you can reach consensus in an hour and the game isn’t stretched out for very long is a big advantage of the Respect Game. People might not be as motivated to play it if takes a week to deliberate and feels more like work than play.
    
    Imagine a game where the representatives are like team members of each fractal who are ‘going up to bat’ for the fractal. That’s a reference to baseball where the other players are in the dugout and cheering on the batter. The other fractal members are rooting them on and playing a less active role by participating just in consensus, while the representative is participating in both consensus and presentation. 
    
    This is similar to baseball. In a baseball game, each team spends half of the time in the dugout cheering on one batter for their team and the other half of the time in the field. In the higher order fractal game, everyone in the fractal would watch a livestream of the higher order fractal game and participate in consensus to rank the other fractals. The consensus process for the sub-fractals could be a vote of recent respect like we tested with cignals games and the consensus process for the higher order fractal could be the respect game as you wrote. 
    
    Alternatively, the consensus process of the subfractal could be an eden+fractal council or a council of top contributors where 4/6 agree how to rank other fractals during the livestream. This might have a closer analogy to a sport like basketball where there are five players on the court, but only one player with the ball. Playing offense is comparable to giving a presentation in that only one player can have a ball (or have the mic) to be able to present. Playing defense is comparable to reaching consensus in that everyone on the team plays a more active role during this part of the game. Obviously the analogy only goes so far here and the other connotations for offense and defense don’t really apply here. 
    
    There could even be an analogy for ‘passing the ball’ where participants in the higher order fractal could call up their team members to give part of the presentation or answer a question which requires their specialized knowledge. This reminds me of how big companies like Apple or Github give annual keynotes where they have different employees give different presentations for various products. These presentations are very well produced and it would be awesome for fractals to do something like this in a higher order fractal respect game 
    
    I can see a week long consensus process working in some contexts, but I really like the potential of fractals as discrete events that are fun for participants and I think that this idea of a livestreamed event could be very interesting. I’d be curious to hear your thoughts about this…
    
    I could see higher order fractals work well on a weekly basis for two reasons:
    
    1. Teams can do a lot in a short amount of time, much more than individuals. Especially with advances in AI and other tools. The amount of output of final products from a team of 10 or 100 or 1000 people in a week could be vastly greater than an individual over months.
    
    2. With so much contributions from larger teams, it could put a lot of pressure into trying to convey so much in a small amount of time. This might reduce the accuracy of the measurement of success and put undue pressure on a lesser amount of meetings.
    
    It depends on the design, circumstances, and awards or rewards for the winners. I think either timeframe could work. Maybe monthly is better for a nearer term scenario where fractals are relatively smaller and more meetings is more suited for larger fractals in the future
    

## Original Post

![Untitled](Synthesize%20Higher%20Order%20Fractals%20ideas%20fcb52e0fc73b4e5f8edf02522e67ba3d/Untitled.png)

[An idea for how different fractals could collaborate](https://www.notion.so/1bf8fe7ed74d4cdaaa1f0cfb0a256515?pvs=21).

[Potential path for EdenFractal to implement the idea above.](https://www.notion.so/b831968892554853a312dedfdc6b8204?pvs=21)

## Videos

![[https://youtu.be/Qme5QU5Czc0](https://youtu.be/Qme5QU5Czc0)](Synthesize%20Higher%20Order%20Fractals%20ideas%20fcb52e0fc73b4e5f8edf02522e67ba3d/EF_73_thumbnail_demo.png)

[https://youtu.be/Qme5QU5Czc0](https://youtu.be/Qme5QU5Czc0)

### [EF 73: Fractal Sports](https://youtu.be/ZFoAoZgwx3g)

What are the best ways for fractals communities to collaborate? We explore ideas about higher order fractals, a new team called the Optimystics, and analogies with fractal games as sports ⚽️

## Dan’s Feedback

- [ ]  See Dan’s Feedback at [Respond to Tadas about Higher Order Fractals and Fractal Tournament Ideas](Respond%20to%20Tadas%20about%20Higher%20Order%20Fractals%20and%20F%204ed31784754b4b24a070337384298bb4.md)

# Overview

The concept of higher-order fractals is proposed as a natural evolution for DAOs (Decentralized Autonomous Organizations) structured like fractals, where these entities are not composed of individuals but of other DAOs or fractals. This model envisions a "fractal of fractals," where each participating entity represents a collective itself, rather than just a single individual. In these higher-order fractals, DAOs act as singular units in a larger assembly, each represented typically by a single delegate during consensus meetings.

The key motivation for this structure is to streamline the process of measuring and comparing the performance of different governance models across various DAOs. By conducting periodic meetings where DAOs present their progress and achievements and then collectively rank each other, it facilitates a structured comparison and benchmarking of governance efficacy. This not only highlights successful strategies but also fosters a competitive yet collaborative environment where DAOs can learn from each other’s successes and failures.

The implementation of a higher-order fractal would involve representatives from each DAO participating in structured consensus meetings, which would likely occur less frequently than typical DAO meetings due to the complexity and scale of discussion. These representatives would present the contributions of their respective collectives over an extended period, rather than weekly or individual efforts. This allows for a more substantial presentation of completed projects or significant progress, rather than ongoing or minor tasks.

Furthermore, this setup encourages smaller or newer DAOs to gain visibility and reputation, potentially attracting new members and resources. It also introduces a competitive element among DAOs, driving them to improve and innovate in their respective domains. In essence, higher-order fractals could significantly enhance the dynamism within the DAO ecosystem by formalizing a platform for inter-DAO interaction, collaboration, and competition, leading to a more robust, innovative, and efficient network of decentralized organizations.

## Summary 1

Higher-order fractals propose a novel organizational structure for DAOs, envisioning a "fractal of fractals" where each unit is a DAO itself, represented by delegates in less frequent, larger-scale consensus meetings. This model facilitates the measurement and comparison of different governance models by allowing DAOs to present and rank collective achievements periodically. Such a structure enhances visibility for smaller DAOs, fosters a competitive yet collaborative environment, and drives innovation across the ecosystem by promoting inter-DAO learning and cooperation. This approach could streamline complex decision-making and amplify the impact of collaborative efforts within the decentralized autonomous organization landscape.

### Summary 2

Higher-order fractals represent an advanced organizational structure where individual fractals or DAOs act as nodes within a larger fractal. These entities, instead of individuals, join to form a higher-order fractal, which functions much like a fractal but on a grander scale. In this model, each fractal elects a representative to participate in higher-order meetings, presenting their collective achievements. The core of their interaction is a modified Respect game, where fractals assess each other’s contributions and achievements, establishing a data-driven approach to evaluate and compare different governance models across the ecosystem. This setup encourages a dynamic where fractals collaborate, compete, and mutually enhance their effectiveness and visibility within a larger community.

Create a blog post about Higher Order Fractals

## **Unveiling Higher Order Fractals: A New Dimension in DAO Collaboration**

As the decentralized autonomous organization (DAO) landscape expands, the emergence of higher order fractals proposes a groundbreaking approach to scaling and enhancing inter-DAO cooperation. This blog post delves into the concept of higher order fractals, exploring how they could revolutionize collaborations and decision-making processes within the DAO ecosystem.

### **Understanding Higher Order Fractals**

A higher order fractal is essentially a fractal made up of other fractals or DAOs, rather than individuals. Drawing inspiration from mathematical fractals, where similar patterns recur at progressively smaller scales, higher order fractals apply this concept to organizational structures. Instead of focusing on individuals, these fractals integrate entire DAOs as their fundamental units, creating a complex yet coherent network of interlinked DAOs.

### **The Operational Dynamics**

In higher order fractals, each participating DAO elects a representative who acts much like an ambassador for their community. These representatives gather in periodic meetings to present their DAO’s progress and achievements. The purpose is not merely to share updates but to engage in a structured consensus process, evaluating and ranking the contributions of each DAO. This method fosters a competitive yet collaborative environment, encouraging DAOs to contribute actively to the collective success of the ecosystem.

### **The Role of the Respect Game**

Central to the functioning of higher order fractals is the Respect Game, adapted from lower-level fractal operations. In this game, DAO representatives present their achievements and strategize to gain respect points from their peers, which are crucial for ranking and resource allocation. The Respect Game not only motivates DAOs to perform but also provides a metric for assessing the effectiveness of different governance models and operational strategies.

### **Benefits of Higher Order Fractals**

1. **Enhanced Collaboration**: By allowing DAOs to interact within a structured framework, higher order fractals encourage the sharing of resources, knowledge, and strategies. This collaborative environment leverages the strengths of diverse DAOs, leading to more robust solutions to common challenges.
2. **Scalability**: Traditional DAO structures can struggle with scalability due to the increasing complexity of managing a large number of participants. Higher order fractals address this by organizing collaboration at a higher structural level, making it easier to manage large-scale initiatives without overwhelming the foundational DAO processes.
3. **Innovation Through Competition**: The competitive element of the Respect Game drives innovation, as DAOs are incentivized to not only participate actively but also to excel in their projects and contributions to the community. This healthy competition spurs creativity and continuous improvement.
4. **Standardization of Measurements**: By establishing a common ground for evaluating contributions, higher order fractals help standardize measurements of success across the DAO ecosystem. This standardization is crucial for transparent and fair resource distribution and for tracking the effectiveness of different DAOs.

### **Challenges and Considerations**

While higher order fractals present numerous benefits, they also bring challenges, particularly in terms of consensus-building and representation. Ensuring that all DAOs have a voice and that the consensus process remains efficient and effective as the network grows are critical areas that require thoughtful design and continuous refinement.

### **The Future Outlook**

As DAOs continue to evolve, the concept of higher order fractals offers a promising avenue for enhancing inter-DAO cooperation and governance. By building on the foundational principles of fractal organizations and adapting them to larger scales, higher order fractals have the potential to shape the future of decentralized collaboration, making it more scalable, efficient, and impactful.

In conclusion, higher order fractals represent a significant innovation in the DAO space, promising to transform how decentralized organizations collaborate, compete, and evolve. As this concept continues to be explored and implemented, it could very well define the next generation of DAOs, making them more adaptive, resilient, and aligned with the collective goals of their participants.

## Does higher order fractals involve other fractals signaling respect for each other and building trust systems together? if so explain how

Yes, higher-order fractals involve other fractals signaling respect for each other and building trust systems together. In this model, each fractal or DAO sends a representative to participate in larger, collective meetings of the higher-order fractal. During these meetings, representatives present the accomplishments and contributions of their respective fractals over a specified period.

The core activity in these meetings is a consensus-building process similar to the Respect game used in individual fractals. However, instead of individuals, entire fractals participate, with each fractal represented by their delegate. After presentations, representatives engage in discussions to rank the contributions of each participating fractal.

The outcome of these rankings forms a basis for awarding Respect at a fractal level, which serves as a trust and reputation metric within the higher-order fractal. This Respect can be seen as a measure of recognition and credibility conferred by peer fractals, based on perceived value and contribution to the collective goals. Thus, this system not only fosters a cooperative environment where DAOs can showcase their achievements and progress but also builds a trust network where DAOs can rely on the collective judgment of their peers to gauge reliability and reputation within the ecosystem. This inter-fractal respect and trust are crucial for facilitating more significant collaborative efforts and strategic alliances among DAOs.

# Sports Fractal

Create a blog post about this sport inspired version of higher order fractals

- Prompt
    
    
    summarize this feedback about higher order fractals
    
    For the second, I think representative is not enough because, while you can prepare a presentation that presents the work of the whole fractal, you can’t really prepare for a consensus process on rankings where you would represent your whole fractal (its opinion on the rankings). Therefore, I think that after all participant DAOs present their contributions, they should be given at least a week to build consensus on their rankings.
    
    Another option is to livestream the respect game amongst contributors of other fractals and allow the other contributors to vote in real time.
    
    I’m not sure if the week long delay might decrease some of the natural excitement of fractals. The fact that you can reach consensus in an hour and the game isn’t stretched out for very long is a big advantage of the Respect Game. People might not be as motivated to play it if takes a week to deliberate and feels more like work than play.
    
    Imagine a game where the representatives are like team members of each fractal who are ‘going up to bat’ for the fractal. That’s a reference to baseball where the other players are in the dugout and cheering on the batter. The other fractal members are rooting them on and playing a less active role by participating just in consensus, while the representative is participating in both consensus and presentation. 
    
    This is similar to baseball. In a baseball game, each team spends half of the time in the dugout cheering on one batter for their team and the other half of the time in the field. In the higher order fractal game, everyone in the fractal would watch a livestream of the higher order fractal game and participate in consensus to rank the other fractals. The consensus process for the sub-fractals could be a vote of recent respect like we tested with cignals games and the consensus process for the higher order fractal could be the respect game as you wrote. 
    
    Alternatively, the consensus process of the subfractal could be an eden+fractal council or a council of top contributors where 4/6 agree how to rank other fractals during the livestream. This might have a closer analogy to a sport like basketball where there are five players on the court, but only one player with the ball. Playing offense is comparable to giving a presentation in that only one player can have a ball (or have the mic) to be able to present. Playing defense is comparable to reaching consensus in that everyone on the team plays a more active role during this part of the game. Obviously the analogy only goes so far here and the other connotations for offense and defense don’t really apply here. 
    
    There could even be an analogy for ‘passing the ball’ where participants in the higher order fractal could call up their team members to give part of the presentation or answer a question which requires their specialized knowledge. This reminds me of how big companies like Apple or Github give annual keynotes where they have different employees give different presentations for various products. These presentations are very well produced and it would be awesome for fractals to do something like this in a higher order fractal respect game 
    
    I can see a week long consensus process working in some contexts, but I really like the potential of fractals as discrete events that are fun for participants and I think that this idea of a livestreamed event could be very interesting. I’d be curious to hear your thoughts about this…
    
    I could see higher order fractals work well on a weekly basis for two reasons:
    
    1. Teams can do a lot in a short amount of time, much more than individuals. Especially with advances in AI and other tools. The amount of output of final products from a team of 10 or 100 or 1000 people in a week could be vastly greater than an individual over months.
    
    2. With so much contributions from larger teams, it could put a lot of pressure into trying to convey so much in a small amount of time. This might reduce the accuracy of the measurement of success and put undue pressure on a lesser amount of meetings.
    
    It depends on the design, circumstances, and awards or rewards for the winners. I think either timeframe could work. Maybe monthly is better for a nearer term scenario where fractals are relatively smaller and more meetings is more suited for larger fractals in the future
    
    ChatGPT
    
    Higher-order fractals offer an enhanced model for DAO interaction, where individual DAOs operate as a collective in periodic collaborative meetings. Here, representatives present their DAO's accomplishments, followed by a consensus-building phase on rankings, which could take a week to allow thoughtful deliberation. Concerns are raised about the potential loss of excitement and engagement due to this extended process, which contrasts with the quick, game-like atmosphere of traditional fractal meetings. Alternatives suggested include livestreaming the respect game, allowing real-time voting by DAO members, thereby maintaining engagement and immediacy. The concept is likened to sports, where team members support a representative 'player', enhancing the collective aspect of the game while allowing individual contributions during presentations. This setup could promote a more dynamic and interactive environment, potentially leading to monthly or more frequent meetings depending on the size and activity level of the fractals involved.
    

## summarize this feedback about higher order fractals

- 
    
    
    For the second, I think representative is not enough because, while you can prepare a presentation that presents the work of the whole fractal, you can’t really prepare for a consensus process on rankings where you would represent your whole fractal (its opinion on the rankings). Therefore, I think that after all participant DAOs present their contributions, they should be given at least a week to build consensus on their rankings.
    
    Another option is to livestream the respect game amongst contributors of other fractals and allow the other contributors to vote in real time.
    
    I’m not sure if the week long delay might decrease some of the natural excitement of fractals. The fact that you can reach consensus in an hour and the game isn’t stretched out for very long is a big advantage of the Respect Game. People might not be as motivated to play it if takes a week to deliberate and feels more like work than play.
    
    Imagine a game where the representatives are like team members of each fractal who are ‘going up to bat’ for the fractal. That’s a reference to baseball where the other players are in the dugout and cheering on the batter. The other fractal members are rooting them on and playing a less active role by participating just in consensus, while the representative is participating in both consensus and presentation. 
    
    This is similar to baseball. In a baseball game, each team spends half of the time in the dugout cheering on one batter for their team and the other half of the time in the field. In the higher order fractal game, everyone in the fractal would watch a livestream of the higher order fractal game and participate in consensus to rank the other fractals. The consensus process for the sub-fractals could be a vote of recent respect like we tested with cignals games and the consensus process for the higher order fractal could be the respect game as you wrote. 
    
    Alternatively, the consensus process of the subfractal could be an eden+fractal council or a council of top contributors where 4/6 agree how to rank other fractals during the livestream. This might have a closer analogy to a sport like basketball where there are five players on the court, but only one player with the ball. Playing offense is comparable to giving a presentation in that only one player can have a ball (or have the mic) to be able to present. Playing defense is comparable to reaching consensus in that everyone on the team plays a more active role during this part of the game. Obviously the analogy only goes so far here and the other connotations for offense and defense don’t really apply here. 
    
    There could even be an analogy for ‘passing the ball’ where participants in the higher order fractal could call up their team members to give part of the presentation or answer a question which requires their specialized knowledge. This reminds me of how big companies like Apple or Github give annual keynotes where they have different employees give different presentations for various products. These presentations are very well produced and it would be awesome for fractals to do something like this in a higher order fractal respect game 
    
    I can see a week long consensus process working in some contexts, but I really like the potential of fractals as discrete events that are fun for participants and I think that this idea of a livestreamed event could be very interesting. I’d be curious to hear your thoughts about this…
    
    I could see higher order fractals work well on a weekly basis for two reasons:
    
    1. Teams can do a lot in a short amount of time, much more than individuals. Especially with advances in AI and other tools. The amount of output of final products from a team of 10 or 100 or 1000 people in a week could be vastly greater than an individual over months.
    
    2. With so much contributions from larger teams, it could put a lot of pressure into trying to convey so much in a small amount of time. This might reduce the accuracy of the measurement of success and put undue pressure on a lesser amount of meetings.
    
    It depends on the design, circumstances, and awards or rewards for the winners. I think either timeframe could work. Maybe monthly is better for a nearer term scenario where fractals are relatively smaller and more meetings is more suited for larger fractals in the future
    

Higher-order fractals offer an enhanced model for DAO interaction, where individual DAOs operate as a collective in periodic collaborative meetings. Here, representatives present their DAO's accomplishments, followed by a consensus-building phase on rankings, which could take a week to allow thoughtful deliberation. Concerns are raised about the potential loss of excitement and engagement due to this extended process, which contrasts with the quick, game-like atmosphere of traditional fractal meetings. Alternatives suggested include livestreaming the respect game, allowing real-time voting by DAO members, thereby maintaining engagement and immediacy. The concept is likened to sports, where team members support a representative 'player', enhancing the collective aspect of the game while allowing individual contributions during presentations. This setup could promote a more dynamic and interactive environment, potentially leading to monthly or more frequent meetings depending on the size and activity level of the fractals involved.

## **Game On: Envisioning Higher Order Fractals Through the Lens of Sports**

In the ever-evolving world of decentralized autonomous organizations (DAOs), the concept of higher order fractals introduces a thrilling game-like element reminiscent of sports. This innovative approach transforms traditional meetings into dynamic and engaging sessions where strategy, teamwork, and real-time decision-making come to the forefront. Let's dive into how this sport-inspired model could revolutionize the way fractals interact and collaborate.

### **Setting the Field: The Basic Setup**

Higher order fractals can be visualized as a league of teams—each team representing a fractal or DAO. Just like in sports, each team selects representatives to 'play' on their behalf. These representatives are akin to players stepping up to bat in baseball, ready to present their team's achievements and strategic moves over a recent period.

### **The Gameplay: Dynamic and Interactive**

The core of this new meeting format is the respect game, played not over weeks, but in real-time, during a livestreamed event. This setup retains the spontaneity and excitement of quick, game-like sessions that define traditional fractal meetings. Representatives present their fractal's accomplishments, after which all team members participate in ranking other teams, fostering a sense of active engagement akin to cheering from the dugout.

### **Strategy and Teamwork: More Than Just a Game**

Incorporating elements from team sports, the model promotes a deeper level of strategy and collaboration. For instance, just as a basketball player might pass the ball to a teammate better positioned to score, a representative could 'pass the mic' to another team member during a presentation to highlight specific expertise or accomplishments. This not only enriches the content but also underscores the collaborative spirit essential in a DAO's success.

### **The Scoring: Building Consensus**

After presentations, the teams would engage in a consensus-building phase to decide on the rankings—a critical part of the game where teamwork and strategy are paramount. This phase could be likened to a sports team discussing tactics in a timeout. The possibility of using a real-time voting system during the livestream adds a layer of immediacy and excitement, allowing for spontaneous strategic decisions based on the presentations.

### **Production Value: The Keynote Effect**

Borrowing a page from major tech companies like Apple, these meetings could evolve into well-produced events where different team members take turns showcasing various projects or achievements. This not only makes the events more engaging but also helps in accurately portraying the breadth and depth of a DAO's initiatives.

### **Frequency and Impact: Weekly Matches to Monthly Tournaments**

The frequency of these higher order fractal meetings could vary based on the size and scope of the participating fractals. Smaller, more agile fractals might benefit from weekly sessions, where quick, impactful decisions are made. Larger fractals, handling more substantial projects, might find monthly meetings more practical, giving adequate time for preparation and strategic planning.

### **The Future of Collaboration: A League of Its Own**

The sport-inspired model of higher order fractals could fundamentally change how DAOs interact and operate. By making meetings more engaging, strategic, and interactive, fractals can foster a competitive yet collaborative environment that not only drives progress but also builds a strong, united community.

In conclusion, higher order fractals, infused with the dynamism and team spirit of sports, offer a promising new framework for DAOs. As these organizations continue to grow and evolve, adopting such innovative approaches will be crucial in harnessing collective intelligence and achieving shared goals. The game is on, and it's more exciting than ever!

# Blog post about how Optimism Fractal could serve as a higher order

Write a blog post about how Optimism Fractal could serve as a higher order fractal and how this could benefit the optimism collective and the world. Include how optimism fractal can signal it's respect for other communities

## **Optimism Fractal as a Higher Order Fractal: Pioneering Global Collaboration and Governance**

In the ever-evolving landscape of decentralized organizations, the Optimism Fractal stands out with a unique opportunity to redefine collaboration and governance through the lens of a higher order fractal. This transformative approach could significantly benefit the Optimism Collective and extend its influence across the broader blockchain ecosystem.

### **What is a Higher Order Fractal?**

A higher order fractal is a concept where a fractal, or a self-similar cooperative structure, is composed not of individuals but of groups or communities—each a fractal in its own right. This structure allows for a more scalable and robust form of consensus and collaboration, as it aggregates the contributions and needs of diverse groups into a unified decision-making process.

### **The Role of Optimism Fractal**

Optimism Fractal, initially designed to foster collaboration and support within the Optimism ecosystem, is ideally positioned to evolve into a higher order fractal. This evolution involves transitioning from individual contributions to collective contributions from various community projects and DAOs within the Optimism ecosystem.

### **Benefits to the Optimism Collective and Beyond**

1. **Enhanced Collaboration:** As a higher order fractal, Optimism Fractal can facilitate deeper collaboration between different projects and communities. This structure supports a more integrated approach to solving complex problems, allowing for shared resources and knowledge.
2. **Scalable Governance:** By operating at a higher order, the fractal can manage more significant and complex decisions efficiently. This scalability is crucial for accommodating the rapid growth and diversity within the Optimism ecosystem.
3. **Diverse Representation:** A higher order fractal ensures that diverse community voices are heard and considered in the decision-making process. This inclusivity strengthens the ecosystem’s resilience and innovation capacity.

### **Signaling Respect Across Communities**

A key mechanism for interaction within a higher order fractal is through the signaling of respect. In the context of Optimism Fractal, respect could be distributed not just based on individual contributions but also based on the collective achievements and reputations of entire communities or projects. Here’s how it could work:

- **Respect Voting System:** Communities within the Optimism ecosystem could participate in periodic consensus meetings where they present their progress and contributions. Following these presentations, participants could vote to allocate "Respect" to other communities based on their contributions to the ecosystem.
- **Respect as a Metric of Influence:** The accumulated Respect would then determine the influence of each community in key decisions, aligning decision-making power with proven contributions and community value.
- **Dynamic Feedback Loop:** This system creates a dynamic feedback loop where communities are motivated to contribute more to the ecosystem, knowing that their efforts are directly tied to their governance influence and resource access.

### **Global Implications**

The adoption of a higher order fractal model by Optimism Fractal can serve as a pioneering example for other blockchain ecosystems and even traditional organizations seeking to decentralize and democratize their governance structures. This model promotes a transparent, inclusive, and efficient governance framework that could inspire global adoption, potentially influencing sectors beyond blockchain.

### **Conclusion**

Transforming Optimism Fractal into a higher order fractal presents an exciting frontier for decentralized governance. By leveraging the collective strength and diversity of its communities, Optimism Fractal can enhance its internal dynamics and provide a valuable blueprint for others in the blockchain space and beyond. This evolution not only promises to strengthen the Optimism Collective but also offers a glimpse into the future of collaborative global governance, where communities are empowered to lead with respect and mutual support.

## Summaries with Roles and Reputations

summarize each in 1-3 sentences:

higher order fractals

Optimism fractal as a higher order fractal

How higher order fractals can signal respect and trust between other communities

How higher order fractals can work with Roles and Reputations

1. **Higher Order Fractals**: Higher order fractals are cooperative structures composed of groups or communities rather than individuals, allowing for scalable and robust consensus processes. This model enhances collaboration by integrating contributions from various groups into unified decision-making, promoting scalability in governance.

2. **Optimism Fractal as a Higher Order Fractal**: Optimism Fractal, originally fostering collaboration within the Optimism ecosystem, is well-positioned to become a higher order fractal. This transition would allow it to manage decisions and collaborations more efficiently by aggregating inputs from diverse community projects and DAOs within the ecosystem.

3. **Signaling Respect and Trust in Higher Order Fractals**: In higher order fractals, communities can signal respect and trust through a voting system where "Respect" is allocated based on the collective achievements of communities. This respect then influences each community's decision-making power within the fractal, creating a feedback loop that encourages active and beneficial participation.

4. **Higher Order Fractals Working with Roles and Reputations**: Higher order fractals can integrate with roles and reputations systems by assigning roles based on the reputations communities earn through their contributions. This structure ensures that decision-making and resource allocation are merit-based, aligning roles with proven impact and fostering a transparent governance model.

## How can Roles and Reputations project play a role in Higher Order Fractals? Can it do so and is it a very fitting software for this project?

The Roles and Reputations project can significantly enhance the functionality and efficacy of Higher Order Fractals by providing a structured framework for acknowledging and rewarding the contributions of different community groups or DAOs within the fractal ecosystem. Here’s how it could play a crucial role:

1. **Role Assignment Based on Contributions**: In Higher Order Fractals, various fractals or community groups could be assigned roles based on their reputational scores, which reflect their contributions and effectiveness within the larger ecosystem. This system ensures that groups with a history of positive impact and reliable participation have a greater say in decision-making processes.

2. **Dynamic Reputational Feedback**: The reputations project can track the ongoing contributions of each fractal, adjusting their reputational scores in real-time based on the latest evaluations and feedback from other community members. This dynamic approach ensures that the system remains fair and responsive, encouraging continuous engagement and improvement.

3. **Merit-Based Resource Allocation**: Using the reputations scores, Higher Order Fractals can allocate resources more effectively, directing support and opportunities to those fractals that demonstrate the most initiative, capability, or need. This could include access to shared resources, funding, or specialized support, ensuring that contributions are reciprocated with appropriate rewards and recognition.

4. **Enhanced Transparency and Accountability**: By integrating the Roles and Reputations project, Higher Order Fractals can enhance transparency and accountability. Each fractal’s role and reputation score would be visible to all members, making the criteria for decision-making and resource allocation clear and understandable. This transparency helps build trust and fosters a sense of fairness within the community.

5. **Incentivizing Collaboration and Innovation**: With clear roles and a reputations system, fractals are incentivized to collaborate and innovate, knowing that their efforts will be recognized and rewarded. This not only boosts the overall productivity of the ecosystem but also encourages diverse fractals to bring unique ideas and perspectives to the table.

Overall, the Roles and Reputations project is a fitting and powerful tool for Higher Order Fractals, providing a robust framework for recognizing and managing the diverse contributions of community groups within a decentralized network. This integration can lead to more efficient governance, stronger collaboration, and a more dynamic and resilient fractal ecosystem.

summarize each in 1-3 sentences:

higher order fractals

Optimism fractal as a higher order fractal

How higher order fractals can signal respect and trust between other communities

How higher order fractals can work with Roles and Reputations

1. **Higher Order Fractals**: Higher order fractals are cooperative structures composed of groups or communities rather than individuals, allowing for scalable and robust consensus processes. This model enhances collaboration by integrating contributions from various groups into unified decision-making, promoting scalability in governance.
2. **Optimism Fractal as a Higher Order Fractal**: Optimism Fractal, originally fostering collaboration within the Optimism ecosystem, is well-positioned to become a higher order fractal. This transition would allow it to manage decisions and collaborations more efficiently by aggregating inputs from diverse community projects and DAOs within the ecosystem.
3. **Signaling Respect and Trust in Higher Order Fractals**: In higher order fractals, communities can signal respect and trust through a voting system where "Respect" is allocated based on the collective achievements of communities. This respect then influences each community's decision-making power within the fractal, creating a feedback loop that encourages active and beneficial participation.
4. **Higher Order Fractals Working with Roles and Reputations**: Higher order fractals can integrate with roles and reputations systems by assigning roles based on the reputations communities earn through their contributions. This structure ensures that decision-making and resource allocation are merit-based, aligning roles with proven impact and fostering a transparent governance model.

- prompt
    
    
    Summarize this other article related to higher order fractals. Include how optimism fractal can serve as a higher order fractal as well and write a blog post about it
    

# **The Evolution of Eden Fractal into a Higher Order Fractal: A Path Forward**

In the ever-evolving landscape of decentralized autonomous organizations (DAOs), the concept of a higher order fractal presents a revolutionary step in the development and interaction of fractals. EdenFractal, known for its dynamic involvement across various DAOs and fractal communities, stands at a pivotal point where it could transform into a higher order fractal. This blog post explores the potential path for this transformation and discusses how EdenFractal could serve as a hub for these expansive networks.

### **EdenFractal: A Central Hub for DAOs**

EdenFractal has naturally begun functioning as a central hub for various fractals, showcasing the work of its members across different DAOs such as the Spanish-speaking fractal, Upscale, OP fractal, Aquadac, AW fractal, and the emerging Zeos fractal. This organic convergence has positioned EdenFractal uniquely as a place of collaboration and innovation, making it an ideal candidate to evolve into a higher order fractal.

### **The Path to Transformation**

Transforming EdenFractal into a higher order fractal involves several key steps:

1. **Consensus and Willingness**: Each fractal associated with EdenFractal would need to signal their willingness to participate in this new structure if EdenFractal evolves into a higher order fractal.
2. **Respect Voting Poll**: Implement a poll where current EdenFractal participants can vote with their Respect points for other fractals that have signaled approval. This would help in determining the initial Respect distribution for the new structure.
3. **Creation of EdenFractal 2 (EF2)**: Launch a new version of EdenFractal, referred to as EF2, which would operate based on the new Respect distributions derived from the poll results.
4. **Transition to Periodic Meetings**: Shift from weekly meetings to periodic gatherings (every one to three months) under EF2, aligning more closely with the needs and operations of a higher order fractal.

This proposed transformation would not only maintain the historical Respect distribution of EdenFractal for archival purposes but also adapt its operational model to better suit the requirements of a higher order fractal.

### **The Role of Optimism Fractal**

In addition to EdenFractal's evolution, the concept of Optimism Fractal can also serve as a model for a higher order fractal within its specific ecosystem. Optimism Fractal could function similarly by gathering various project teams and DAOs within the Optimism ecosystem, facilitating a platform where these groups can share progress, collaborate on initiatives, and collectively drive the ecosystem forward. This role complements the broader vision of higher order fractals by fostering interconnectivity and mutual support among different initiatives.

### **Conclusion**

The potential evolution of EdenFractal into a higher order fractal represents a natural progression of its current function as a collaborative hub. This transformation would leverage the intrinsic synergies across various fractals, enhancing their collective ability to experiment with decentralized governance models and spread fractal democracy. While this path suggests a significant shift in the operational dynamics of EdenFractal, it promises a robust framework for fostering collaboration and innovation across the DAO landscape.

By adopting this model, EdenFractal can demonstrate adaptability and relevance, potentially setting a precedent for other fractals and DAOs. The discussion around this transformation is crucial, as it will shape the future interactions and effectiveness of fractal-based governance within the broader blockchain and DAO communities.

# Integrations with Roles and Reputations and Hats Protocol?

I’m not sure if Roles and Reputations is a fitting solution for Higher Order Fractals or if this is a high priority at this point, but am curious if it could be integrated with higher order fractals in the long-term as Roles and Reputations seems to have some similar goals regarding sharing trust between entities.

- Details about how Roles and Reputations may help with Higher Order Fractal
    
    

- Details about how Hats Protocol may help with Higher Order Fractals
    
    
    ## How can Hats Protocol play a role in Higher Order Fractals? Can it do so and is it a very fitting software for this project?
    
    Hats Protocol can play a significant role in the operation and effectiveness of Higher Order Fractals by providing a decentralized framework for role management and access control within these complex governance structures. Here’s how it can contribute and why it is particularly suitable for this application:
    
    ### **How Hats Protocol Can Contribute to Higher Order Fractals**
    
    1. **Role-Based Permissions**:
        - **Defining Roles**: Hats Protocol can be used to define specific roles within the Higher Order Fractal, each associated with different levels of access and control over shared resources or decision-making processes.
        - **ERC-1155 Tokens**: Utilizing ERC-1155 tokens, Hats Protocol can assign unique, non-fungible tokens (NFTs) to represent these roles, ensuring that permissions are securely managed and verifiable on the blockchain.
    2. **Access Control**:
        - **Secure Access**: By assigning tokenized hats that represent different roles, Hats Protocol ensures that only authorized individuals or fractals can access certain functionalities within the Higher Order Fractal. This could include voting rights, access to special forums, or the ability to initiate projects.
        - **Dynamic Role Assignment**: As community members' contributions evolve, their roles can be adjusted dynamically, with new hats issued or old ones burned to reflect their current standing within the fractal hierarchy.
    3. **Governance and Decision-Making**:
        - **Token-Gated Participation**: Use hats to control participation in specific governance decisions, ensuring that only stakeholders with the relevant roles and responsibilities can influence outcomes in certain areas.
        - **Automated Governance Rules**: Automate certain governance actions based on the distribution and ownership of specific hats, such as automatically triggering funding for projects that receive approval from a majority of a specific role group.
    4. **Reward and Incentive Structures**:
        - **Rewarding Contributions**: Distribute hats as rewards for contributions to the fractal, recognizing efforts and achievements within the community. These hats can confer not just status but also practical privileges and access.
        - **Incentive Alignment**: Create incentive structures where the accumulation of specific hats leads to greater influence or rewards, aligning individual goals with the broader objectives of the Higher Order Fractal.
    
    ### **Suitability of Hats Protocol for Higher Order Fractals**
    
    1. **Decentralization and Security**:
        - Hats Protocol’s blockchain-based approach provides a secure and transparent method for managing roles and permissions, essential in decentralized communities where trust must be distributed.
    2. **Scalability**:
        - The protocol can easily scale to accommodate an increasing number of roles or a growing number of fractal participants, crucial for Higher Order Fractals that might expand rapidly as new fractals or DAOs join.
    3. **Customizability**:
        - Hats Protocol allows for the customization of roles and permissions to fit the unique needs of different fractal organizations, supporting a diverse range of governance models within the same overarching structure.
    4. **Interoperability**:
        - By using standard ERC-1155 tokens, Hats Protocol ensures that roles and permissions are interoperable with other Ethereum-based systems and applications, facilitating integration with a wide array of governance tools and platforms.
    
    In conclusion, Hats Protocol offers a robust and flexible solution for managing roles, permissions, and governance within Higher Order Fractals. Its blockchain-based, token-centric approach aligns well with the decentralized, scalable, and customizable needs of these complex governance entities, making it an ideal tool for fostering organized collaboration and secure decision-making in large-scale decentralized organizations.
    

# Comparisons

## How do the ideas of community gardens, consensus as a service, and higher order fractals relate to each other? Are these entirely separate ideas and products or is there some way in which they should merge or are connected?

The concepts of Community Gardens, Consensus as a Service (CaaS), and Higher Order Fractals, while distinct in their primary focus and applications, do share overlapping principles and can synergistically enhance one another when integrated thoughtfully. Here’s how they relate and potentially intersect:

### **Community Gardens**

Community Gardens are metaphorical or literal spaces where members of a community come together to cultivate shared resources, ideas, or projects. In a digital context, this translates into collaborative environments where individuals contribute to and benefit from collective efforts, fostering growth and innovation.

### **Consensus as a Service (CaaS)**

Consensus as a Service is a mechanism by which organizations or communities leverage structured, transparent decision-making processes to achieve agreement among stakeholders. It is particularly valuable in settings where decisions require legitimacy derived from broad-based community support.

### **Higher Order Fractals**

Higher Order Fractals are organizational structures composed of multiple smaller groups (fractals) that interact within a larger framework. This model facilitates complex, scalable coordination across diverse entities or groups, aligning them towards common goals while preserving the autonomy of individual groups.

### **Integration and Connection**

1. **Framework for Collaboration**: Community Gardens provide a fertile ground for the principles of Higher Order Fractals to take root. In such a setting, different fractal groups can come together to work on shared projects or challenges, each contributing their unique perspectives and resources. The community garden becomes a living lab for decentralized collaboration.
2. **Consensus Mechanisms**: Within both Community Gardens and Higher Order Fractals, reaching decisions that reflect the collective will and are fair to all participants is crucial. Here, Consensus as a Service can be instrumental. It offers a robust framework to facilitate decision-making processes, ensuring that they are equitable, transparent, and accountable. For instance, decisions on resource allocation or project directions in a Community Garden can be effectively managed through CaaS, leveraging the diverse inputs of its members.
3. **Scalability and Complexity Management**: Higher Order Fractals inherently deal with the complexities of managing multiple groups with potentially divergent interests. The structured approach of CaaS can help manage these complexities by providing a clear protocol for interaction and decision-making across fractals. Similarly, as Community Gardens grow and involve more participants, the fractal approach can help manage this scalability by organizing participants into sub-groups with specific roles or focuses, each operating under the overarching consensus framework.
4. **Innovation and Evolution**: By integrating these concepts, there is a potential for a dynamic, evolving structure where new ideas can be tested and implemented rapidly, feedback can be efficiently gathered and acted upon, and the entire system can adapt to changing needs and circumstances. Community Gardens can serve as incubators for innovation within this framework, Higher Order Fractals can provide the organizational structure to implement these innovations at scale, and CaaS can ensure that all changes are consensually agreed upon.

### **Conclusion**

While Community Gardens, Consensus as a Service, and Higher Order Fractals can stand alone as separate concepts, their integration offers a powerful model for community-driven innovation, scalable collaboration, and democratic governance. This integrated approach not only enhances the effectiveness of each individual concept but also creates a more robust, adaptive, and resilient system for managing collective efforts in diverse settings.