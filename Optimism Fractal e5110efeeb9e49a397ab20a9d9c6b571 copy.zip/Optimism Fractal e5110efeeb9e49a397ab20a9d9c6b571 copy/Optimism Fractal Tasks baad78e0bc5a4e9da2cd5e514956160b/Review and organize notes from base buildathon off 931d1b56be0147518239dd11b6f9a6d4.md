# Review and organize notes from base buildathon office hours.  And review other Subtask and organize here

Assignee: Dan Singjoy
Due: August 2, 2024
Status: Not started
Task Summary: This task aims to review and organize notes from the Base Buildathon office hours, as well as review and organize other subtasks related to the event. It also involves adding workshops from the provided link to the calendar, promoting the work in the Base Discord channels, and updating various event pages to include Superchain. Additionally, it includes tasks such as asking how to join the Base Telegram group, applying for Base Camp, and addressing support tickets.
Summary: This document is a task list for organizing notes from a base buildathon office hours session. It includes tasks such as adding workshops to the calendar, promoting in the Base Discord channels, updating event pages to include Superchain, and applying for Base Camp. There are also subtasks to review and organize various notes and support tickets.
Created time: June 11, 2024 4:11 PM
Last edited time: July 25, 2024 12:10 PM
Created by: Dan Singjoy
Description: This document contains notes and tasks related to the base buildathon office hours. It includes adding workshops to the calendar, promoting work in the base discord channels, updating event pages to include Superchain, and applying for base camp. There are also support tickets that need attention.

Go to the workshops in the link- [https://onchain-summer.devfolio.co/schedule](https://onchain-summer.devfolio.co/schedule)

and add them to calendar as well

Add base buildathon office hours to community calendar, personal calendar, alarm. Every Tuesday at 20 utc and Thursday at 10 utc. Will said there is q and a where you can ask questions or promote work - definitely promote respect game at optimism fractal here and ask other questions- [https://discord.gg/sDchHkhT?event=1247506303337762889](https://discord.gg/sDchHkhT?event=1247506303337762889)

Guests can join the office hours on video . It’s also possible to share a screen on the office hours 

Will said that we should post casts in the base discord and base can recast them to help promote our work. So we should add this to our promotional project template . We should also add the word base and Superchain to the optimismfractal website to make it clearer 

- [ ]  organize the following into subtasks

## Review and Post in Base Discord Channels

- [ ]  start promoting in many of these channels in the base discord
    - [ ]  consider adding these to the event promotion template
    - [ ]  consider creating tasks for other promotions in these channels, like promoting the release of fractal tools in the development channel

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled.png)

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%201.png)

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%202.png)

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%203.png)

projects that can submit now and show something that they’re already Clyde superchain

Include Superchain  , they appreciate thi

Update the town hall article and event page to include Superchain

Update the OF event page to include Superchain 

[https://paragraph.xyz/@grants.base.eth/calling-based-builders](https://paragraph.xyz/@grants.base.eth/calling-based-builders)

## Ask how to join base telegram

- [ ]  search transcript of the recording of base builders and figure out who to ask

## Apply base camp

[Apply to join BaseCamp July 29-August 4th- consider doing it after launching something with base play](../../EC%20Tasks%201951af2e70bd4666850a3d112e65f7a8/Apply%20to%20join%20BaseCamp%20July%2029-August%204th-%20conside%2042832f2c861844269e40dd98db279d8e.md) 

Is there a deadline to apply for the Base Camp?

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%204.png)

## Support Tickets

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%205.png)

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%206.png)

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%207.png)

![Untitled](Review%20and%20organize%20notes%20from%20base%20buildathon%20off%20931d1b56be0147518239dd11b6f9a6d4/Untitled%208.png)