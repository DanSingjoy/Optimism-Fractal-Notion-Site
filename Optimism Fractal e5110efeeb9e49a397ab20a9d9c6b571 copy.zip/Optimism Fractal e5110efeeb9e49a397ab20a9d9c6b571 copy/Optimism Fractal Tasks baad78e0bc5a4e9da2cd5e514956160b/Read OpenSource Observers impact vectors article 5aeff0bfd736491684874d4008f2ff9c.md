# Read OpenSource Observers impact vectors article

Assignee: Dan Singjoy
Due: August 5, 2024
Project: Curate Optimism Fractal community reading list (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Optimism%20Fractal%20community%20reading%20list%20cc9fd290fdb84e359fd9654107562d5d.md)
Status: Not started
Task Summary: This task aims to read the article titled "OpenSource Observers impact vectors." The article provides insights into the impact vectors observed by OpenSource Observers and their significance. By reading this article, one can gain a deeper understanding of the various factors that influence open-source projects and their outcomes.
Summary: The task is to read the article "OpenSource Observers impact vectors" by Dan Singjoy. The article can be found at the provided link.
Created time: May 2, 2024 4:07 AM
Last edited time: July 15, 2024 5:43 PM
Parent task: Explore the Optimism Collective’s Experiment in Metrics-based Evaluation (Explore%20the%20Optimism%20Collective%E2%80%99s%20Experiment%20in%20Me%2042f580862b8f4fe98e65c70e3327ac67.md)
Created by: Dan Singjoy
Description: The task is to read the article on impact vectors in OpenSource Observers. The task has not been started yet.

- [ ]  Read OpenSource Observers [impact vectors](https://mirror.xyz/cerv1.eth/qL9YKLN9-dBzM89qKaZYgHK2ccpZy2XLPz2Z1PObwCg)

### **Experiment:** Metrics-based Evaluation

- Thesis: By leveraging quantitive metrics, citizens are able to more accurately express their preferences for the types of impact they want to reward, as well as make more accurate judgements of the impact delivered by individual projects.

In Retro Funding 3, badgeholders voiced that non-standardized impact metrics added difficulty to the voting process and expressed desire to  directly vote based on metrics. Examples of this approach include Buidl Guidl’s [impact calculator](https://gov.optimism.io/t/experimentation-impact-metric-based-voting/7727) and OpenSource Observers [impact vectors](https://mirror.xyz/cerv1.eth/qL9YKLN9-dBzM89qKaZYgHK2ccpZy2XLPz2Z1PObwCg). Metrics-based evaluation will be used to reward downstream impact, as this category can benefit from a quantitive approach to measuring impact.

### Related Tasks

- [ ]  Explore Buidl Guidl’s [impact calculator](https://gov.optimism.io/t/experimentation-impact-metric-based-voting/7727)
    - [Read OpenSource Observers impact vectors article](Read%20OpenSource%20Observers%20impact%20vectors%20article%205aeff0bfd736491684874d4008f2ff9c.md)
- [ ]  Read OpenSource Observers [impact vectors](https://mirror.xyz/cerv1.eth/qL9YKLN9-dBzM89qKaZYgHK2ccpZy2XLPz2Z1PObwCg)
    - [Explore Buidl Guidl’s [impact calculator](https://gov.optimism.io/t/experimentation-impact-metric-based-voting/7727) for evaluating RetroFunding projects](Explore%20Buidl%20Guidl%E2%80%99s%20impact%20calculator%20for%20evalua%2062e9359bc5194cb89ae548907d837d7f.md)
- [ ]  Explore the Optimism Collective’s Experiment in Metrics-based Evaluation
    - [Explore the Optimism Collective’s Experiment in Metrics-based Evaluation](Explore%20the%20Optimism%20Collective%E2%80%99s%20Experiment%20in%20Me%2042f580862b8f4fe98e65c70e3327ac67.md)

- [ ]  See Open Source Observers Data Challenge and Request for impact metrics
    - [Organize Project to Submit Respect and Respect Voting as Impact Metric for Open Source Observer(OSO)](Organize%20Project%20to%20Submit%20Respect%20and%20Respect%20Vot%208097d7a2b8114247859cb30ad8b174cf.md)