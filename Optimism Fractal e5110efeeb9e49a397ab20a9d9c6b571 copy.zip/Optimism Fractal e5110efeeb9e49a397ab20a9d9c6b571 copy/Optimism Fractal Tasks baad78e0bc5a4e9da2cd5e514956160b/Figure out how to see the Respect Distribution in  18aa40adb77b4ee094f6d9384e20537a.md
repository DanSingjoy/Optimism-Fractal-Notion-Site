# Figure out how to see the Respect Distribution in Optimism Fractal (ie scoreboard, leaderboard)

Project: Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md), Build Scoreboard for Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Scoreboard%20for%20Respect%20d7a8b49bef094d80b36d3f30749c033c.md)
Status: Done
Summary: To see the total distribution of Respect in Optimism Fractal and the respect scores for each player onchain, currently there is no way to do so. It is suggested to dig into old 'submitranks' actions on the contract account to find other accounts that have earned respect.
Created time: December 30, 2023 5:56 PM
Last edited time: April 4, 2024 9:37 PM
Created by: Dan Singjoy

## Description

![Untitled](Figure%20out%20how%20to%20see%20the%20Respect%20Distribution%20in%20%2018aa40adb77b4ee094f6d9384e20537a/Untitled.png)

![Untitled](Figure%20out%20how%20to%20see%20the%20Respect%20Distribution%20in%20%2018aa40adb77b4ee094f6d9384e20537a/Untitled%201.png)

![Untitled](Figure%20out%20how%20to%20see%20the%20Respect%20Distribution%20in%20%2018aa40adb77b4ee094f6d9384e20537a/Untitled%202.png)

Thank you for sharing and distributing Respect!

I can see that 505 Respect tokens have been distributed and the amount of Respect for each account on the transaction you shared, but I don’t know how to see what other accounts have earned respect without digging into old ‘submitranks’ actions on the contract account. It also shows that there are no token holders when I click on the ‘Holders’ tab on the token account, which is a bit confusing.

It would be nice to see any overview the total distribution of Respect. This would make it easier for people to see the benefits of Respect and could potentially enable Optimism Fractal participants to vote with Respect points in an upcoming RetroPitches game. Is there any way to see the total respect scores for each player onchain all in one spot?

Currently, no