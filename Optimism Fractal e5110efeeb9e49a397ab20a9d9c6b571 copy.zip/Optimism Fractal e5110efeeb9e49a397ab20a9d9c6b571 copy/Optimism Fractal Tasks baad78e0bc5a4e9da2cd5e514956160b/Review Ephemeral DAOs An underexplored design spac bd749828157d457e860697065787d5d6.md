# Review Ephemeral DAOs: An underexplored design space - 🧙 🧙‍♀️ Ideas and Open Discussion - Gitcoin Governance

Project: Explore Integrations of Quests with the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Integrations%20of%20Quests%20with%20the%20Respect%20Ga%202a4d3601ec8c4f10b683a139862dd9e7.md)
Status: Not started
Task Summary: This task aims to explore the design space of Ephemeral DAOs, which are decentralized organizations that exist for a short, finite period to achieve specific goals. By examining the unique characteristics and advantages of these temporary entities, this discussion highlights their potential for innovation, experimentation, and agile decision-making in decentralized governance.
Summary: Ephemeral DAOs are temporary decentralized organizations designed to achieve specific goals before dissolving, allowing for lower stakes, pragmatic decision-making, and bold experimentation. They can vary in duration and intent, and their design encourages iterative learning and adaptation. Examples include Gitcoin Grants and pop-up villages. This innovative approach promotes agile, purpose-driven engagements and reshapes collective action in the digital age.
Created time: May 7, 2024 1:51 AM
Last edited time: September 11, 2024 11:04 AM
Created by: Dan Singjoy
Description: Ephemeral DAOs are temporary decentralized organizations designed to achieve specific goals and dissolve afterward, promoting innovation and experimentation with lower stakes. They allow for pragmatic decision-making and iterative learning, exemplified by various initiatives like pop-up villages and Gitcoin Grants. The concept encourages flexibility in defining DAOs, emphasizing the importance of context and purpose over rigid adherence to traditional definitions.

[https://gov.gitcoin.co/t/ephemeral-daos-an-underexplored-design-space/18749](https://gov.gitcoin.co/t/ephemeral-daos-an-underexplored-design-space/18749)

*Thanks to [@MathildaDV](https://gov.gitcoin.co/u/mathildadv) , Soloszo, mr_j_rossman, gnovak, Ethereal Forest community, and other respondents to [this tweet 4](https://twitter.com/owocki/status/1787196344097992747) for helping to shape these ideas.*

# TLDR

- Ephemeral means “lasting for a very short time.”.
- Ephemeral DAOs are DAOs that exist emergently for a short time and then are designed to dissolve.
- Ephemeral DAOs offer a novel approach to decentralized organization, departing from rigid definitions and embracing fluidity in group coordination.
- By embracing ephemerality, we can operate in a design space with lower stakes, pragmatic decision-making, and bold experimentation within shorter timeframes. This opens doors to new opportunities of value creation
- Some examples of Ephemeral DAOs: SealOrg whitehat campaigns, pop up villages, Gitcoin Grants or Optimism Rounds.

# What are DAOs?

A canonical definition of DAOs: A DAO is a digital entity governed by smart contracts and operated by its members rather than a central authority. It allows for decentralized decision-making and management of resources.

An alternative definition of DAOs: DAOs are how groups of humans coordinate around a shared objective.

From the perspective of the 2nd definition, it is okay to treat the literal definition of DAOs as more of a spectrum. Some projects will be 100% decentralized, 100% autonomous, + an organization, some will only be partially so. Projects that are not 100% pure, I call “DAO-ey” - as in, they have some attributes of DAOs but not all.

# What are Ephemeral DAOs?

Ephemeral DAOs exist for a finite period of time to achieve specific goals or objectives. Once the goals or objectives of the ephemeral DAO have been achieved, the DAO is dissolved, and its assets, if any, are distributed back to the participants or transferred to another entity.

# Why are Ephemeral DAOs powerful?

Ephemerality and DAO-iness are powerful because:

1. without the burden of having to last forever, the stakes are lower. Which enables more experimentation.
2. without the burden of having to last forever, we can make more pragmatic decisions about what to do over a short period of time without worrying about entrenching power.
3. without the burden of having to last forever, we can test/iterate with bold bets in the short term.
4. we can learn from decentralized movements of the past, many of which ebbed and flowed, (Occupy Wall St or the Civil Rights movement are two examples) + transcribe their lessons into our ephemeral DAO experiments…

# Ephemeral DAO Design Space

## Examples

Examples of Ephemeral DAOs:

1. Pop up villages like Edge City or Zuzalu or Metacamp. *(weeks long)*
2. @_SEAL_Org or other “Whitehat group” style fund rescue operations *(several hours - several weeks long)*
3. Gitcoin style QF rounds. *(weeks long)*
4. Optimism style Retro Funding Rounds *(weeks long)*
5. Accelerator cohorts go through an educational cohort together over an 8 week program (months long)
6. Point in time fundraisers like ConstitutionDAO or [The Free Alexey & Roman Legal Defense Fundraise](https://juicebox.money/@free-pertsev-and-storm) *(weeks long)*
7. Protocol Guild’s first cohort *(1 year long)*
8. Projects like Meta Cartel, which dissolved itself after transferring all their remaining assets to the lawyers of tornado cash devs. *(years long)*
9. Investment DAOs like those created by [Hydra Ventures](https://www.hydraventures.xyz/) last only as long as they have capital to deploy *(years long)*

## DAO-purity

Some definitions of DAOs out there have rigid adherence to the properties of autonomousness (emphasis on computer code doing most of the work), achieving very high levels of decentralization (e.g. no member can have more power than another) and being an organization (as opposed to a network).

I find myself gravitating towards a more simple & broad definition: DAOs are how groups of humans coordinate around a shared objective.

Projects that are in between the more rigid definition of DAOs and the more simple/broad one can be said to be DAO-ey.

I can hear the naysayers say to me “Kevin those don’t count as DAOs. We shouldn’t be flexible in our interpretation of our design space and should be dogmatic about 100% decentralization + autonomy”. Well, I’m sorry I failed your purity test. But I disagree. We should choose the right amount of autonomy + decentralization for the job. For decentralized money (BTC, ETC), we need 100% purity. For other use cases, it’s okay to work on things that treat DAOiness as a spectrum.

Here’s what I think the design space for Ephemeral DAOs looks like.

![https://gov.gitcoin.co/uploads/db4391/original/2X/1/1ec839606914ffe3e895b2a90e0354d78acb30b8.png](https://gov.gitcoin.co/uploads/db4391/original/2X/1/1ec839606914ffe3e895b2a90e0354d78acb30b8.png)

## Short Longevity vs Long Longevity

I also think there is a spectrum of “how much longevity is baked into each Ephemeral DAO?

Ephemeral DAOs can be shorter lasting (like a SealOrg Whitehat op which could be hours-long) or longer lasting (or MetaCartel, which wound down after several years).

[Screenshot 2024-05-06 at 1.41.22 PM](https://gov.gitcoin.co/uploads/db4391/original/2X/1/1a92db5da1850b3f9a700b5d70b25a1d0d33f471.png)

![https://gov.gitcoin.co/uploads/db4391/optimized/2X/1/1a92db5da1850b3f9a700b5d70b25a1d0d33f471_2_1172x372.png](https://gov.gitcoin.co/uploads/db4391/optimized/2X/1/1a92db5da1850b3f9a700b5d70b25a1d0d33f471_2_1172x372.png)

## Fixed vs Variable Intent

Another spectrum that Ephemeral DAOs can be on is fixed intent (eg they were always intended to wind down - like a RetroPGF round) vs variable intent (the decision to wind down was only made after some time - like MetaCartel DAO).

![https://gov.gitcoin.co/uploads/db4391/original/2X/e/e16b42f7348493c7dfd2a6f0b996d29155e21746.png](https://gov.gitcoin.co/uploads/db4391/original/2X/e/e16b42f7348493c7dfd2a6f0b996d29155e21746.png)

## For Profit vs Non-Profit Ephemeral DAOs

Another spectrum that Ephemeral DAOs can be on is non-profit (like a QF or RetroPGF round) vs for profit (like a [Hydra ventures](https://www.hydraventures.xyz/)  investment DAO)

![https://gov.gitcoin.co/uploads/db4391/original/2X/0/072e1b82d985b71ed20df8157dd31c53c4f0643b.png](https://gov.gitcoin.co/uploads/db4391/original/2X/0/072e1b82d985b71ed20df8157dd31c53c4f0643b.png)

## Evolutionary Ephemeral DAOs

Another attribute of Ephemeral DAOs is how evolutionary they can be. By launching ephemeral DAOs that last for only for a short amount of time, then tweaking their designs, and then launching the next one, DAO designers can iterate towards a design goal. Here is a visual example of how Public Goods Funding rounds (each is a ephemeral DAO) can be evolutionary experiments creating more value over time through learning + iteration.

![https://gov.gitcoin.co/uploads/db4391/optimized/2X/0/0e98e05ed9606cfb5f8c852e84bdfeccf2f786a6_2_1248x926.png](https://gov.gitcoin.co/uploads/db4391/optimized/2X/0/0e98e05ed9606cfb5f8c852e84bdfeccf2f786a6_2_1248x926.png)

I explored the concept of evolutionary Public Goods Funding Campaigns in the recent post entitled [Public Goods Funding must be evolutionary. 1](https://gov.gitcoin.co/t/public-goods-funding-must-be-evolutionary/18728) Read more there!

From this perspective, projects like Gitcoin are kind of an Ephemeral DAO factory. Gitcoin launches Grants rounds (Ephemeral DAOs) and then round over round, tweaking the protocols they run on to launch progressively better & better ephemeral DAOs.

# Best Practices for Ephemeral DAOs

- Leverage the advantages of Ephemeral DAOs (less stakes, less risk of entrenching power, ability to be iterative) when designing your Ephemeral DAO.
- To be both successful and ephemeral, an org has to have mechanisms for fairly winding down
- Have a hypothesis behind each Ephemeral DAO launch. Design each Ephemeral DAO launch as an experiment + then Learn from it, use those learnings to evolve your DAO design forward in the next launch. (repeat)

# Conclusion

In summary, Ephemeral DAOs exemplify a transformative frontier in the realm of decentralized organizations, where the temporary nature of these entities not only promotes innovation but also allows for agile, purpose-driven engagements that dissolve upon goal completion.

This design strategy minimizes long-term commitments and facilitates rapid experimentation and learning, offering a fresh perspective on collaborative efforts and governance.

As this underexplored space continues to evolve, it holds the promise of reshaping our understanding of collective action and organizational life cycles in the digital age.

# Just for fun

Ephemeral DAOs remind me of sand mandalas! A sand mandala is a Tibetan Buddhist art form created with colored sand to represent the universe. They are meticulously swept away upon completion to symbolize impermanence and the transient nature of existence.

[Screen Recording 2024-05-06 at 1.37.00 PM](https://twitter.com/owocki/status/1787318481291010503)

![https://gov.gitcoin.co/uploads/db4391/original/2X/e/ebdd84d652b8f3e0d711b8c4e208f64835f3aff7.gif](https://gov.gitcoin.co/uploads/db4391/original/2X/e/ebdd84d652b8f3e0d711b8c4e208f64835f3aff7.gif)

[Screenshot 2024-05-06 at 1.41.22 PM](https://gov.gitcoin.co/uploads/db4391/original/2X/1/1a92db5da1850b3f9a700b5d70b25a1d0d33f471.png)

[Screen Recording 2024-05-06 at 1.37.00 PM](https://twitter.com/owocki/status/1787318481291010503)

[Decentralizedceo](https://gov.gitcoin.co/u/Decentralizedceo)

owocki:  Here’s what I think the design space for Ephemeral DAOs looks like.  

From the looks of it, does this mean that some DAO tooling would be considered Ephemeral due to it’s operational period? Such as the QF grant rounds and such. I also like the notion that Ephemeral DAOs have a fixed intent so contributors know the exact time frame and what to expect vs variable which the wind down can be unpredicted and may lead to contributor’s lack of coordination.

I think that it would make a lot of sense to include this description in the new Impact DAO V2 print for all to see.

### New & Unread Topics

| Topic | Replies | Views | Activity |
| --- | --- | --- | --- |
| [RFC: AI Dashboard for Governance Proposals](https://gov.gitcoin.co/t/rfc-ai-dashboard-for-governance-proposals/16561)   [🧙 🧙‍♀️ Ideas and Open Discussion](https://gov.gitcoin.co/c/open-discussion/9) [governance](https://gov.gitcoin.co/tag/governance) |  | 1.5k | [Nov '23](https://gov.gitcoin.co/t/rfc-ai-dashboard-for-governance-proposals/16561/11) |
| [[Proposal] Gitcoin killer app](https://gov.gitcoin.co/t/proposal-gitcoin-killer-app/17347)   [🧙 🧙‍♀️ Ideas and Open Discussion](https://gov.gitcoin.co/c/open-discussion/9) |  | 673 | [Dec '23](https://gov.gitcoin.co/t/proposal-gitcoin-killer-app/17347/5) |
| [Brainstorming from Gitcoin community members to find new ideas to develop existing products or ideas for new products](https://gov.gitcoin.co/t/brainstorming-from-gitcoin-community-members-to-find-new-ideas-to-develop-existing-products-or-ideas-for-new-products/16883)   [🧙 🧙‍♀️ Ideas and Open Discussion](https://gov.gitcoin.co/c/open-discussion/9) |  | 664 | [Oct '23](https://gov.gitcoin.co/t/brainstorming-from-gitcoin-community-members-to-find-new-ideas-to-develop-existing-products-or-ideas-for-new-products/16883/2) |
| [Shape Rotators Guide to Funding What Matters](https://gov.gitcoin.co/t/shape-rotators-guide-to-funding-what-matters/17174)   [🧙 🧙‍♀️ Ideas and Open Discussion](https://gov.gitcoin.co/c/open-discussion/9) |  | 1.3k | [Dec '23](https://gov.gitcoin.co/t/shape-rotators-guide-to-funding-what-matters/17174/7) |
| [[UPDATES] DAO Financial Report - January 2024](https://gov.gitcoin.co/t/updates-dao-financial-report-january-2024/17517)   [🧙 🧙‍♀️ Ideas and Open Discussion](https://gov.gitcoin.co/c/open-discussion/9) |  | 527 | [Jan 31](https://gov.gitcoin.co/t/updates-dao-financial-report-january-2024/17517/2) |