# Create proposal to update core intent of Optimism Fractal

Assignee: Dan Singjoy
Due: June 13, 2024
Status: Done
Task Summary: This task aims to create a proposal to update the core intent of Optimism Fractal. The proposal suggests changing the core intents of Optimism Fractal to focus on fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain. The proposal includes rationale and invites community members to vote on the proposed changes.
Summary: The proposal suggests updating the core intents of Optimism Fractal to focus on fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain. The proposal introduces two changes from the current version, including the inclusion of 'optimizing governance' and specifying 'the Optimism Superchain.' The rationale for the proposal can be found on the provided page and a discussion on this topic can be watched in the given video link.
Parent-task: Propose new core intents for Optimism Fractal (Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md)
Created time: June 14, 2024 2:56 PM
Last edited time: June 19, 2024 1:31 PM
Parent task: Propose new core intents for Optimism Fractal (Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md)
Created by: Dan Singjoy

Create proposal to update core intent of Optimism Fractal

## Should we change the core intents of Optimism Fractal?

Vote yes if you agree to change the core intents of Optimism Fractal to the following: “Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.”

If this proposal is approved then these new core intents will replace the previous core intents near the top of OptimismFractal.com/details. The new core intents will also be featured at the top of the website homepage, social media profiles, and other in other places.

This proposal introduces two changes from the current version, which is “Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.” The two changes in this proposal are the inclusion of ‘optimizing governance’ and the specifying of Optimism as ‘the Optimism Superchain.’

You can see rationale for the proposal in this [page](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md) and watch a [discussion](https://www.youtube.com/watch?feature=shared&t=3974&v=JI0mreeaSgY&themeRefresh=1) on this topic at last week’s Optimism Town Hall to learn more about this proposal.

Vote yes if you agree to change the core intents of Optimism Fractal will be changed to the following: 

**“Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.”**

If this proposal is approved then these new core intents will replace the previous core intents at the top of [OptimismFractal.com/details](http://OptimismFractal.com/details). The new core intents will also be featured at the top of the website homepage, social media profiles, and other in other places. 

This proposal introduces two changes from the current version, which is “**Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism**.**”** The two changes in this proposal are the inclusion of ‘optimizing governance’ and  the specifying of Optimism as ‘the Optimism Superchain.’ 

You can see rationale for the proposal in this [page](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md) and watch a [discussion](https://youtu.be/JI0mreeaSgY?feature=shared&t=3974) about this at last week’s Optimism Town Hall video from last week to learn more about this proposal. 

## Discord Post

GM all, hope you enjoyed the weekend!

Following up on our discussion from last week, I just created a proposal to update Optimism Fractal’s Core Intents to the following: “Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.”

If this proposal is approved then these new core intents will replace the previous core intents near the top of OptimismFractal.com/details. The new core intents will also be featured at the top of the website homepage, social media profiles, and other in other places. 

This proposal introduces two changes from the current version, which is “Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.” The two changes in this proposal are including ‘optimizing governance’ and specifying ‘the Optimism Superchain.’ 

You can see rationale for the proposal in this [page](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md) and watch a [discussion](https://www.youtube.com/watch?feature=shared&t=3974&v=JI0mreeaSgY&themeRefresh=1) on this topic at last week’s Optimism Town Hall to learn more about this proposal.

The community members who registered to be in this week’s [council](https://optimismfractal.com/council) are me, @rosmari, and @zaal. I just voted to approve this proposal, so we’ll have sufficient consensus and it will be approved if either Rosmari or Zaal approve as per our approved [consensus process](https://optimismfractal.com/details#block-e42fb7c2317c49bb92fc4165c01b20ae).

GM! Hope you enjoyed the weekend and are having a great week!

Following up on our discussion from last week, I just created a [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xbe0d658597adfea76ddf7d082682ac238c521fb39836ced176c8ad7a604f6d84) to update Optimism Fractal’s Core Intents to the following: “Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.”

If this proposal is approved then these new core intents will replace the previous core intents near the top of OptimismFractal.com/details. The new core intents will also be featured at the top of the website homepage, social media profiles, and other in other places. This proposal introduces two changes from the current version, which is “Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.” The two changes in this proposal are including ‘optimizing governance’ and specifying ‘the Optimism Superchain.’ 

You can vote on the proposal [here](https://snapshot.org/#/optimismfractal.eth/proposal/0xbe0d658597adfea76ddf7d082682ac238c521fb39836ced176c8ad7a604f6d84), see rationale in this [page](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md), and watch a [discussion](https://www.youtube.com/watch?feature=shared&t=3974&v=JI0mreeaSgY&themeRefresh=1) on this topic at last week’s Optimism Town Hall to learn more about this proposal. The community members who registered to be in this week’s [council](https://optimismfractal.com/council) are me, @rosmari, and @zaal. I voted to approve this proposal, so it will be approved if either Rosmari or Zaal vote yes as per our approved [consensus process](https://optimismfractal.com/details#block-e42fb7c2317c49bb92fc4165c01b20ae).

Looking forward to seeing you on Thursday! 🙏🏽🌻

I’m also planning to introduce Optimism Fractal at today’s Onchain Summer Office Hours hosted by Base, which recur on Tuesdays at 20 UTC and Thursdays at 10 UTC. The next one starts in about half an hour in the [Base Discord](https://discord.gg/axekT9KmWT?event=1247505681716609126) and it would be great to see you there :)

![OF 30 promotion and superchain image copy.png](Create%20proposal%20to%20update%20core%20intent%20of%20Optimism%20%20e2c93b9a89494965a628fae508b424ce/OF_30_promotion_and_superchain_image_copy.png)

## Gov Forum Post

GM Optimists! Hope you enjoyed the weekend and are having a great week! 🔴✨

Following up on our discussion from last week, I just created a [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xbe0d658597adfea76ddf7d082682ac238c521fb39836ced176c8ad7a604f6d84) to update Optimism Fractal’s Core Intents to the following: “Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.”

If this proposal is approved then these new core intents will replace the previous core intents near the top of OptimismFractal.com/details. The new core intents will also be featured at the top of the website homepage, social media profiles, and other in other places. This proposal introduces two changes from the current version, which is “Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.” The two changes in this proposal are including ‘optimizing governance’ and specifying ‘the Optimism Superchain.’ 

You can vote on the proposal [here](https://snapshot.org/#/optimismfractal.eth/proposal/0xbe0d658597adfea76ddf7d082682ac238c521fb39836ced176c8ad7a604f6d84), see rationale in this [page](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md), and watch a [discussion](https://www.youtube.com/watch?feature=shared&t=3974&v=JI0mreeaSgY&themeRefresh=1) on this topic at last week’s Optimism Town Hall to learn more about this proposal. The community members who registered to be in this week’s [council](https://snapshot.org/#/optimismfractal.eth/proposal/0x5043537235bae798dc8b8f21631273f064e23dd6340379ad92127452c0d27868) are me, @rosmari, and @zaal. I voted to approve this proposal, so it will be approved if either Rosmari or Zaal vote yes as per our approved [consensus process](https://optimismfractal.com/details#block-e42fb7c2317c49bb92fc4165c01b20ae).

Looking forward to seeing you on Thursday! 🙏🏽🌻

🙌🏽 💪🏽

I’m also planning to introduce Optimism Fractal at today’s Onchain Summer Office Hours hosted by Base, which recur on Tuesdays at 20 UTC and Thursdays at 10 UTC this June. The next one starts in about half an hour in the [Base Discord](https://discord.com/invite/buildonbase) and it would be great to see you there :)

![OF 30 promotion and superchain image copy.png](Create%20proposal%20to%20update%20core%20intent%20of%20Optimism%20%20e2c93b9a89494965a628fae508b424ce/OF_30_promotion_and_superchain_image_copy%201.png)

GM all, hope you enjoyed the weekend!

Following up on our discussion from last week, I just created a proposal to update Optimism Fractal’s Core Intents to the following: “Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.”

If this proposal is approved then these new core intents will replace the previous core intents near the top of OptimismFractal.com/details. The new core intents will also be featured at the top of the website homepage, social media profiles, and other in other places. 

This proposal introduces two changes from the current version, which is “Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.” The two changes in this proposal are including ‘optimizing governance’ and specifying ‘the Optimism Superchain.’ 

You can see rationale for the proposal in this [page](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md) and watch a [discussion](https://www.youtube.com/watch?feature=shared&t=3974&v=JI0mreeaSgY&themeRefresh=1) on this topic at last week’s Optimism Town Hall to learn more about this proposal.

The community members who registered to be in this week’s [council](https://optimismfractal.com/council) are me, @rosmari, and @zaal. I just voted to approve this proposal, so we’ll have sufficient consensus and it will be approved if either Rosmari or Zaal approve as per our approved [consensus process](https://optimismfractal.com/details#block-e42fb7c2317c49bb92fc4165c01b20ae).

Vote yes if you agree to change the core intents of Optimism Fractal to the following: “Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.”

If this proposal is approved then these new core intents will replace the previous core intents near the top of OptimismFractal.com/details. The new core intents will also be featured at the top of the website homepage, social media profiles, and other in other places.

This proposal introduces two changes from the current version, which is “Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.” The two changes in this proposal are the inclusion of ‘optimizing governance’ and the specifying of Optimism as ‘the Optimism Superchain.’

You can see rationale for the proposal in this [page](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md) and watch a [discussion](https://www.youtube.com/watch?feature=shared&t=3974&v=JI0mreeaSgY&themeRefresh=1) on this topic at last week’s Optimism Town Hall to learn more about this proposal.

@zaal @rosmari

[Propose new core intents for Optimism Fractal](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md)