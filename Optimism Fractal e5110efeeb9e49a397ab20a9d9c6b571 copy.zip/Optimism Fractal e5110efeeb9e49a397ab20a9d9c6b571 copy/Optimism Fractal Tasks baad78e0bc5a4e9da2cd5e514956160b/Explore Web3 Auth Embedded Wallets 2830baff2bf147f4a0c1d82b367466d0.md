# Explore Web3 Auth Embedded Wallets

Status: Not started
Task Summary: This task aims to explore the concept of Web3 Auth Embedded Wallets. It is a project created by Dan Singjoy that is currently in the not started stage. The goal is to understand and delve into the functionalities and benefits of web3 authentication, as well as its potential applications in various contexts.
Summary: This document provides information about exploring Web3 Auth embedded wallets. It includes a description and links to http://web3auth.io/ for more details.
Parent-task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created time: March 18, 2024 6:00 PM
Last edited time: June 8, 2024 11:42 PM
Parent task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created by: Dan Singjoy

## Description

- 

# Web3Auth

Web3 Auth:

[web3auth.io](http://web3auth.io) 

 [https://web3auth.io/why-web3auth.html](https://web3auth.io/why-web3auth.html)

![[web3auth.io](http://web3auth.io) ](Explore%20Web3%20Auth%20Embedded%20Wallets%202830baff2bf147f4a0c1d82b367466d0/Untitled.png)

[web3auth.io](http://web3auth.io) 

[https://twitter.com/Web3Auth/status/1768517484955812164](https://twitter.com/Web3Auth/status/1768517484955812164)

[https://twitter.com/EthereumDenver/status/1763640826708500838](https://twitter.com/EthereumDenver/status/1763640826708500838)