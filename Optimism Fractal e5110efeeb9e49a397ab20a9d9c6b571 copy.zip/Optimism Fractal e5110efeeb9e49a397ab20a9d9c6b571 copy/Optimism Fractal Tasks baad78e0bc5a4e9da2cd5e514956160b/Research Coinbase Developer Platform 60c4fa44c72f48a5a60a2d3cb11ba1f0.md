# Research Coinbase Developer Platform

Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md), Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Research Account Abstraction Services for Gasless Transactions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Account%20Abstraction%20Services%20for%20Gasless%20%2066379e2fdde445b194a7eb797b74e96c.md)
Status: In progress
Task Summary: This task aims to research the Coinbase Developer Platform. It was created by Dan Singjoy and is currently in progress. The goal is to create a 2-4 sentence summary and overview of the CDP.
Summary: Research the Coinbase Developer Platform, including completing subtasks and curating an overview of CDP.
Sub-task: Research Coinbase Developer Platform Paymaster API (Research%20Coinbase%20Developer%20Platform%20Paymaster%20API%206e367d9908bf49bf9f7a4658ffc2e222.md), Explore Coinbase Cloud Embedded Wallets as a service and Compare with Privy (Explore%20Coinbase%20Cloud%20Embedded%20Wallets%20as%20a%20servi%203e8d5a6bfa4a4896a4f5293ddc194822.md), Research OnchainKit from Coinbase Developer Platform (Research%20OnchainKit%20from%20Coinbase%20Developer%20Platfo%209828b1780cbe497699060bac1714ff3f.md), Research Smart Wallet from Coinbase Developer Platform (Research%20Smart%20Wallet%20from%20Coinbase%20Developer%20Plat%20d699b048ee4e4c328f4f8f3948204de8.md)
Created time: June 1, 2024 7:52 PM
Last edited time: June 8, 2024 11:45 PM
Created by: Dan Singjoy

- [ ]  See subtasks

- [ ]  Curate overview of CDP