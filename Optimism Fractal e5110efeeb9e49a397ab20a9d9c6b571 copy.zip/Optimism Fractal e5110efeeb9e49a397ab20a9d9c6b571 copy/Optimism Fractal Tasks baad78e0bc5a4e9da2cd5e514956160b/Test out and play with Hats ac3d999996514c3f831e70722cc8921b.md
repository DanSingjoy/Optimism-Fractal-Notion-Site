# Test out and play with Hats

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: In progress
Task Summary: This task aims to test out and play with various hats, exploring their features and functionalities. The goal is to provide insights and feedback on the different styles and uses of hats in various contexts.
Summary: The document outlines a task titled "Test out and play with Hats," created by Dan Singjoy, which is currently in progress. However, there is no description provided.
Created time: February 15, 2024 8:28 PM
Last edited time: September 26, 2024 5:06 PM
Parent task: Join Hats Community (Join%20Hats%20Community%208a1d178643654de0a1c8038fc3fb2ab3.md)
Created by: Dan Singjoy
Description: The document outlines a task to test and play with Hats, created by Dan Singjoy, which is currently in progress. However, there is no additional description provided.

## Description

-