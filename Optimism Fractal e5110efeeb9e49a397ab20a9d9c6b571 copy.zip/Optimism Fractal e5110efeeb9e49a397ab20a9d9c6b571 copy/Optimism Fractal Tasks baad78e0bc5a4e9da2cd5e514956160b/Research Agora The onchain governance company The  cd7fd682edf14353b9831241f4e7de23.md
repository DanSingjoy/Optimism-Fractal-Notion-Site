# Research Agora: The onchain governance company. The new product has many helpful features that we may want, including optimistic polling and snapshot integrations. Overall it seems that it’s focused moreso on larger protocols with lots of money like L2s , but it seems simple to test and has large feature set. The snapshot integration might be key and a way to provide alot of value with little work. Try deploying it with no code at agora.xyz then connecting with snapshot to see how it looks

Project: Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Integrate Optimism Fractal and the Respect Game with RetroFunding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
URL: https://www.agora.xyz/#Product
Summary: Research Agora is an onchain governance company offering a new product with helpful features like optimistic polling and snapshot integrations. While it seems more focused on larger protocols, it is simple to test and has a large feature set. The snapshot integration is highlighted as a way to provide value with little effort. Top protocols choose Agora for secure decentralization and community-led growth. Agora's governor is based on OZ governor, offering battle-tested properties and advanced features. Agora is designed to scale with the needs of the community and offers role management, delegation tools, multiple proposal types, and compatibility with various tools. It also provides gasless voting, multiple choice proposals, security council, dual governance, proposal sponsorship, staking token support, optimistic proposals, transaction simulation, API, snapshot integration, and discourse integration. Agora is fully open-source and offers different product tiers for communities at different stages.
Created time: May 3, 2024 3:09 AM
Last edited time: May 3, 2024 3:10 AM
Created by: Dan Singjoy

Your best engineers should be working on your protocol. Use Agora to deploy the best end-to-end governance system without writing a single line of code.

![https://www.agora.xyz/assets/placeholder.png](https://www.agora.xyz/assets/placeholder.png)

![https://www.agora.xyz/assets/reeds/windmill_no_reeds.png](https://www.agora.xyz/assets/reeds/windmill_no_reeds.png)

![https://www.agora.xyz/assets/treeWithLeaves/leaves1.png](https://www.agora.xyz/assets/treeWithLeaves/leaves1.png)

## Top protocols choose Agora to move their goals forward

### 1. Secure decentralization

Agora help you decentralize progressively, while avoiding technical and social risks

### 2. Community-lead growth

Use Agora's ecosystem growth tooling to turn your community into champions for your protocol's growth.

Agora helped the Optimism Collective's Token House implement new voting mechanisms that allow for governance minimisation and strategic prioritization

Justine H. – Head of Governance at Optimism

Agora has helped Uniswap increase both the number and quality of delegates contributing to protocol governance, namely through a campaign redistributing 8M+ UNI to delegates

Devin Walsh – Uniswap Foundation Executive Director

Agora helped us migrate our governance from mainnet to our rollup, reducing cost of voting and increasing participation.

Agora has been an incredible partner in driving Ether.fi’s progressive decentralization roadmap.

Mike Silagadze – Ether.fi CEO

[vote.optimism.io](https://vote.optimism.io/)

[vote.ether.fi](https://vote.ether.fi/)

Coming soon

## Get the most-battle tested governor

The Agora governor is based on OZ governor, the standard trusted by the top protocols to secure tens of billions of value. With Agora, you get all the battle-tested properties of OZ gov – and access to a powerful suite of advanced features without writing a line a code.

![https://www.agora.xyz/assets/chart.png](https://www.agora.xyz/assets/chart.png)

### 600k+ votes cast on Agora governor

Votes cast on Agora

### 103k users using Agora monthly

Users using Agora monthly

## Agora is designed to scale with your needs

Start simple, and add powerful features via additional modules as your community grows.

![https://www.agora.xyz/assets/feature_1.png](https://www.agora.xyz/assets/feature_1.png)

### Role management lets you give the right permissions to the right stakeholders

Grant the right parties the right permissions and checks and balances by managing who can propose, veto, or execute specific functions.

![https://www.agora.xyz/assets/feature_2.png](https://www.agora.xyz/assets/feature_2.png)

### Leverage our powerful delegation tools to activate your large tokenholders

Agora lets your largest token holders easily engage in governance via delegation while remaining secure and compliant.

![https://www.agora.xyz/assets/feature_3.png](https://www.agora.xyz/assets/feature_3.png)

### Use proposal types to make the simple stuff easy, while keeping high stake changes difficult

Major protocol upgrades shouldn’t run through the same process as funding a small grants program. With Agora, they won’t.

![https://www.agora.xyz/assets/feature_4.png](https://www.agora.xyz/assets/feature_4.png)

### Agora works out of the box with all tools your community and investors love Coingecko, Coinmarketcap, Anchorage, Coinbase Custody, etc.

Agora’s governor is designed to play well with both retail investor tooling and institutional investor tooling.

## Agora has every capability you need to run your protocol the way you want

### Gasless voting & proposing

Agora relays makes voting & proposing free

### Multiple choice proposals

Instead of Yes/No, let voters choose among options

### Security council

Let multisig block or execute certain functions

### Dual governance

Let multiple stakeholder groups vote

### Proposal sponsorship

Allow voters to sponsor proposals for others

### Staking token support

Use staked token in governance

### Optimistic proposals

Allow low stake actions without a full vote

### Transaction simulation

Verify a proposal before submitting

### API

Let anyone build apps and integrations

### Snapshot integration

Show and create snapshot polls on Agora

### Discourse integration

Show discourse conversations for proposals

## Radically transparent and aligned – Agora is the only fully MIT-licensed Open Source governance platform

Agora's software is always free to fork and deploy for any project big or small. Our goal is to create a new standard to push the industry forward.

![https://www.agora.xyz/assets/garden.png](https://www.agora.xyz/assets/garden.png)

## Agora product tiers

## Core

For

Communities just getting started

What

1-click to deploy all you need to get started. No need to figure out which governor to fork and deploy and how

## Growth

What

Agora is the most powerful and customizable framework designed to work with critical Ethereum infrastructure protocols.

## Roll your own

What

Agora is fully open-source. You can always fork our code and deploy your customized instance.

# Your protocol is your focus. Let us help you with governance.

![https://www.agora.xyz/assets/treehouse.png](https://www.agora.xyz/assets/treehouse.png)