# Consider strategies for voting with Respect, such as ranked choice voting, weighted voting, and quadratic voting

Project: Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Create Notion API integration that allows upvoting with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Notion%20API%20integration%20that%20allows%20upvoting%201bba7e8a0bda4237854946b51a32c98e.md)
Status: Not started
Summary: No content
Created time: May 1, 2024 2:24 AM
Last edited time: May 1, 2024 2:27 AM
Created by: Dan Singjoy

## Description

## Alternative Voting Strategies

Before taking the next steps in developing tooling, it might be prudent to scope out the design, specifications, and integrations. We could also explore alternative strategies such as Ranked Choice or Quadratic Voting in the Snapshot Subspace, though I think that a weighted voting across polls in a subspace would be a sufficiently immense upgrade in itself and alternative voting strategies would provide a relatively lesser benefit that would be good to explore after developing a weighted voting system.

[Quadratic Voting](https://www.notion.so/Quadratic-Voting-9f8d777d80764d56adeb5e203695fadd?pvs=21) 

Pilot use cases with ranked choice voting:

- [Optimystics.io/retropitches](http://Optimystics.io/retropitches)
- [EdenFractal.com/53](http://EdenFractal.com/53)
- [EdenFractal.com/55](http://EdenFractal.com/55)
- [EdenFractal.com/56](http://EdenFractal.com/56)