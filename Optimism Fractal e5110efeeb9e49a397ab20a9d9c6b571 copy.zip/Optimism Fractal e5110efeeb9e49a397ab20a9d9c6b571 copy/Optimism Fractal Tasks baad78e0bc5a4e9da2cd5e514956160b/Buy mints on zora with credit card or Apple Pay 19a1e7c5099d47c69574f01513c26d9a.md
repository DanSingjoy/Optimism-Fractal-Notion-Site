# Buy mints on zora with credit card or Apple Pay

Project: Build app component to make it easy for participants to give personal respect at the end of each game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md)
Status: Not started
Task Summary: This task aims to facilitate the purchase of mints on Zora using either a credit card or Apple Pay. It outlines the steps needed to complete the transaction efficiently and highlights the payment options available for a seamless shopping experience.
Summary: The task is to buy mints on Zora using a credit card or Apple Pay, which has not yet been started. The document includes a link for reference.
Created time: May 21, 2024 8:26 AM
Last edited time: September 11, 2024 10:44 AM
Created by: Dan Singjoy
Description: A task to buy mints on Zora using a credit card or Apple Pay is created by Dan Singjoy, with the status marked as not started. The document includes a link for further details.

[https://x.com/ourzora/status/1778112226353942780?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/ourzora/status/1778112226353942780?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/ourzora/status/1778112226353942780?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/ourzora/status/1778112226353942780?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)