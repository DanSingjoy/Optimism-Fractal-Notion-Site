# Propose Optimism Fractal Season 4 and topic proposal for OTH

Assignee: Dan Singjoy
Due: July 7, 2024
Project: Plan Optimism Fractal Season 4 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%204%2042304244bc404fceb0b2c1279508ed7e.md), Prepare for OF 34 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2034%200c98b5f4f06240b688d1caf3b6038e9b.md), Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md)
Status: Done
Task Summary: This task aims to propose the start of Season 4 for Optimism Fractal and gather topic proposals for discussions in the upcoming season. The page includes a proposal for the start date of Season 4, as well as an open discussion about the seasonal structure, goals, and adjustments for the new season. Feedback and input from participants are encouraged to shape the future of Optimism Fractal.
Summary: This document proposes starting the 4th season of Optimism Fractal on August 15th and invites discussion on the seasonal structure and plans for the upcoming season. It also includes a topic proposal for preparing for Season Four, with questions about adjusting Season 3, setting themes or goals for Season Four, and suggestions for the next few weeks of the current season. Feedback and input are encouraged, and there is a suggestion to change the cadence of Optimism Fractal Respect Games and Optimism Town Hall events.
Created time: July 7, 2024 3:27 PM
Last edited time: July 15, 2024 8:05 PM
Created by: Dan Singjoy
Description: This document proposes starting the 4th season of Optimism Fractal on August 15th and invites discussion on the seasonal structure and plans for the upcoming season. Topics include evaluating Season 3, setting themes and goals for Season 4, and suggestions for improvement. Feedback and input from participants are encouraged.

## Proposal

**Do you agree to start the 4th season of Optimism Fractal on August 15th?**

Vote yes on this proposal if you agree to start the third season of Optimism Fractal on August 15th, following a two week summer break. This means that the last event of our third season will be on July 25th.

For more information, you can vote on a topic proposal to discuss plans this in the Optimism Town Hall snapshot [space](https://snapshot.org/#/optimismtownhall.eth) and discussions about our seasonal structure linked in the prior [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xf45036110a5299421d27e37716f8e1f6b8ca962d3c85e5a9c0786f1fb45d269a) to start Season 3.

- 
    
    
    For more details, you c
    
    The season of Optimism Fractal may be generally aligned with the upcoming round of [Retro Funding](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU) 
    
    prior proposal to start Season 3
    
    More details can be found in this [post](https://discord.com/channels/1164572177115398184/1164572177878765591/1228017013004304496) and this [discussion](https://www.youtube.com/watch?v=JhtgnEqC_Es?si=o-ITXZvC-sUvObCW&t=3485) during last week’s planning session.
    

![optimism fractal  season 4.png](Propose%20Optimism%20Fractal%20Season%204%20and%20topic%20propos%20da62fbb0c0f8498ba405d855da633360/optimism_fractal__season_4.png)

## Topic Proposal: Preparing for Season Four

Vote for this topic if you’d like to have an open discussion around our seasonal structure and plans for the upcoming season. I just create a [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0x76cceda79c54773345ae3ed16622da0ac12787aa7865acc977c2d89fb9933385) to start Season Four on August 15th and am curious to hear everyone’s thoughts as we prepare to head into a new season.

- We could discuss plans, themes, goals for the season. Should we set some specific theme or goal for season four?

- What do you think of Season 3 and how should we adjust going forward?

- Could share how you’d like to help or what you’d like to see different in the next season

- Is there anything you’d like to focus on in the next few weeks of our third season?

- I’m thinking about an idea to change our cadence to have Respect Games for Optimism Fractal every other week, then an hour long Optimism Town Hall on the alternate week. C

- Share any thoughts about our seasonal structure and

## Topic Proposal: Preparing for Season Four

Vote for this topic if you’d like to have an open discussion around our seasonal structure and plans for the upcoming season. I just created a [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0x76cceda79c54773345ae3ed16622da0ac12787aa7865acc977c2d89fb9933385) to start Season Four on August 15th and am curious to hear everyone’s thoughts as we prepare to head into a new season. Some questions that we might want to consider include:

- What do you think of Season 3 and how should we adjust going forward in the next season?
- Is there anything you think that we should focus on in the next few weeks of our third season?
- Should we set some specific theme, goals, or other intentions for Season Four?
- Is there anything in particular that you’d like to contribute or see achieved in the next season?

Any feedback is welcome and I appreciate your input. You can learn more about our seasonal structure by watching this [video](https://www.youtube.com/watch?v=JhtgnEqC_Es?si=o-ITXZvC-sUvObCW&t=3485) and exploring the links in this [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xf45036110a5299421d27e37716f8e1f6b8ca962d3c85e5a9c0786f1fb45d269a) from last season. In addition, I’d also like to share an idea for changing the cadence of Optimism Fractal Respect Games to a biweekly schedule and making Optimism Town Hall an hour long event on the alternate weeks.

As always, whichever poll has the most votes in the Optimism Town Hall snapshot space on Monday at 17 UTC will be first topic we discuss and you can feel free to suggest or propose any other topics on your mind. Looking forward to hearing your thoughts!

 Another  interesting idea that I’d like to share is about changing our cadence of Optimism Fractal Respect Games to every other week, then move Optimism Town Hall to become an hourlong event on the alternate weeks.

Share any thoughts about our seasonal structure and potential changes.

Your feedback is invaluable as we aim to refine and improve our approach. Let's ensure that Season Four is our best yet by collaboratively setting clear goals and addressing any areas for improvement.

![optimism fractal  next seasons.png](Propose%20Optimism%20Fractal%20Season%204%20and%20topic%20propos%20da62fbb0c0f8498ba405d855da633360/optimism_fractal__next_seasons.png)