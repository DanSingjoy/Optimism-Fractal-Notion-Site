# Research: Ladders.Vision help display respect across networks?

Project: Explore integrations with Roles and Reputations System (from Jacob Homanics with ATX DAO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20with%20Roles%20and%20Reputations%20Sy%20c85bbe3e9a8548bfb3ccf6a4aea29fde.md), Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md)
Status: Not started
Task Summary: This task aims to investigate whether Ladders.Vision can help display respect across networks. The page, created by Dan Singjoy, provides information about the status and timeline of the project. For more details, you can visit the https://x.com/homanics/status/1787699266036646169?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ.
Summary: No content
Created time: May 7, 2024 1:02 AM
Last edited time: May 16, 2024 10:00 AM
Created by: Dan Singjoy

## Cross-Chain Visibility

 [ladders.vision](https://ladders.vision/) is an open sourced and decentralized approach to viewing ALL data for any NFT on any blockchain. 

- Will this be integrated into the Roles and Reputation repository so that Respect would be viewable on any blockchain?
- Does it work with all token standards?

[https://x.com/homanics/status/1787699266036646169?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/homanics/status/1787699266036646169?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/homanics/status/1787699266036646169?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/homanics/status/1787699266036646169?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)