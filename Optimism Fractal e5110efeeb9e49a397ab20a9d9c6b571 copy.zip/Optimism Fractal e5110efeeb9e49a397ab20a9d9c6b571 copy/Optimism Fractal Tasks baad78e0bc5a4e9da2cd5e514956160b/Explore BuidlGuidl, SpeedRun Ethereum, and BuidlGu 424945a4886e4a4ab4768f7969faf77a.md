# Explore BuidlGuidl, SpeedRun Ethereum, and BuidlGuidl

Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md)
Status: Not started
URL: https://buidlguidl.com/
Task Summary: This task aims to create a 2-4 sentence summary/intro for the page titled "Explore BuidlGuidl, SpeedRun Ethereum, and BuidlGuidl." BuidlGuidl is a platform that supports up-and-coming high-impact developers through Open Developer Streams and Focused Cohort Streams. Developers can receive funding and freedom to work on important projects, while also benefiting from collaboration and guidance within the ecosystem. Learn more about BuidlGuidl and its initiatives at https://buidlguidl.com/.
Summary: BuidlGuidl offers Open Developer Streams to fund development and support up-and-coming developers. They also have Focused Cohort Streams that bundle developer streams for specific objectives. Collaboration opportunities are available through partnerships and co-funding.
Created time: May 4, 2024 3:26 AM
Last edited time: May 4, 2024 3:37 AM
Created by: Dan Singjoy

[https://buidlguidl.com/_next/image?url=%2Fassets%2Fsre-forest.png&w=1080&q=75](https://buidlguidl.com/_next/image?url=%2Fassets%2Fsre-forest.png&w=1080&q=75)

[https://buidlguidl.com/_next/image?url=%2Fassets%2Fse2-ui.png&w=1920&q=75](https://buidlguidl.com/_next/image?url=%2Fassets%2Fse2-ui.png&w=1920&q=75)

## Supporting  up-and-coming  high-impact devs

Open Developer Streams are a unique way to fund development and give developers at the edges the freedom to build what they think is most important.

Their smart contracts get replenished monthly and allows them to withdraw funds whenever they like by submitting a few sentences about the work or a PR.

This approach produces novel open source solutions and a vibrant learning environment.

[https://buidlguidl.com/_next/image?url=%2Fassets%2Fsupport-high-impact-devs.png&w=1920&q=75](https://buidlguidl.com/_next/image?url=%2Fassets%2Fsupport-high-impact-devs.png&w=1920&q=75)

## Partnering with ecosystem heroes

Focused Cohort Streams bundle together a group of developer streams and focuses them on a pre-determined objective.

These cohorts provided the structure and guidance of an Operator who identifies, adds, and removes developers from the pool.

IN COLLABORATION WITH

[Co-fund with us](mailto:partnerships@buidlguidl.com)

[BuidlGuidl v3 | BuidlGuidl](Explore%20BuidlGuidl,%20SpeedRun%20Ethereum,%20and%20BuidlGu%20424945a4886e4a4ab4768f7969faf77a/BuidlGuidl%20v3%20BuidlGuidl%20afe296555fc041a2af04e4533841d638.md)

[](https://x.com/austingriffith/status/1783133693424349188?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

- 
    
    [https://x.com/austingriffith/status/1783133693424349188?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/austingriffith/status/1783133693424349188?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)