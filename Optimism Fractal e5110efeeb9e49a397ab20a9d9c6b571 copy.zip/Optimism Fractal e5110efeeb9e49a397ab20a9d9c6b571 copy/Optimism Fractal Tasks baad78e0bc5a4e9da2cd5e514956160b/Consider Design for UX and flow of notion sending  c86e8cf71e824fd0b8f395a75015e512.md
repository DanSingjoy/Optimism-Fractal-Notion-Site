# Consider Design for UX and flow of notion sending out event via api towards snapshot or tally

Project: Create tools and processes to track and prioritize projects and tasks for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20tools%20and%20processes%20to%20track%20and%20prioritize%20104241e49716490eb641cd12529159b9.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Explore deeper integrations between Optimism Fractal and Discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Optimism%20Fract%20337d632e686e44e68cd899e6e12e05f3.md), Improve optimism fractal discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20optimism%20fractal%20discord%20f0810fb48cfc4a08b49fc433c1ebaffb.md), Improve notification and provenance system for optimism fractal notion site via discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20notification%20and%20provenance%20system%20for%20opt%202bd6ce3108b64785a23f1bba8557407f.md), Create Notion API integration that allows upvoting with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Notion%20API%20integration%20that%20allows%20upvoting%201bba7e8a0bda4237854946b51a32c98e.md), Integrate Optimism Fractal notion page with Notion API and Pipedream (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20notion%20page%20with%20Notion%2071c1311213394726983236991c25e999.md), Improve Optimism Fractal Notion Site (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20Notion%20Site%20d2c9d9db20cf4635a1e9b86c653f8c19.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: In progress
Summary: This document discusses considerations for designing the user experience and flow of sending out events via API from Notion to Snapshot or Tally. It explores the possibility of limited voting in Snapshot, sending notifications in Discord, updating Notion properties with votes from Snapshot, and using platforms like dework.xyz. It also raises questions about the readiness of Snapshot and the use of on-chain or off-chain solutions. Additionally, it suggests using different spaces if the subspaces approach is complicated and inquires about signing into Snapshot with account abstraction smart accounts.
Created time: March 25, 2024 10:23 PM
Last edited time: March 27, 2024 6:34 PM
Created by: Dan Singjoy

if notion can emit an event then this may be more flexible if the voting is in snapshot

- [ ]  ask snapshot if it allows a limited amount of votes in the space
    - perhaps either you can vote with your respect each week, or you can only vote with your respect once
        - this could use [custom calculations](https://docs.snapshot.org/space-handbook/custom-calculations) or a [plugin](https://docs.snapshot.org/developer-guides/create-a-plugin)?

- [ ]  ask chatgpt about this

- [ ]  ask chat gpt
    - [ ]  can notion send a message out whenever a new project, task, or topic is created?
    - [ ]  can snapshot listen for a message and create a poll whenever a message is received that a new task, project, or topic is created
    - [ ]  would it be possible to automatically give notifications of this in discord?
    - [ ]  would it be possible to then add the votes in the snapshot polls to the notion properties for the task, project, or task that receives votes?
        - this would involve notion listening via api for a message from snapshot or something like the graph, then the message triggering the notion api to update the properties in the database for votes
        - perhaps something like pinax substreams or alchemy’s subgraphs could help with this
        - it might be needed to check the API at some recurring interval for cost reasons, ie it doesn’t call the api every second but maybe once a week or once an hour or once every minute or 10 minutes  or something like that if it’s too expensive. faster is better and the ultimate goal but it could work in cheaper setup as well if needed
    - [ ]  would it be helpful to use [dework.xyz](http://dework.xyz) somewhere in this flow?
    - [ ]  when will snapshot x be ready to do this onchain? does it make more sense to use something like tally instead? does this need to be onchain for it to work or could it work offchain with the current version of snapshot?

- if the subspaces thing doesn’t work or is too complicated, then just do it in a totally different space, such as projects.optimismfractal.eth or cagendas.optimismfractal.eth which i can set up with ENS
    - that might be better than subspaces anyway

- is it possible to sign into snapshot with account abstraction smart accounts?

More related ideas: [Research deeper integrations of Appflowy or Charmverse into a Respect Trees, Cagendas app or more comprehensive fractal app](Research%20deeper%20integrations%20of%20Appflowy%20or%20Charmv%207c9448d231e548838b36f54bc23f8da3.md)