# review the fractally whitepaper social media design and consider implementing this

Project: Explore and Create Integrations between Farcaster and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md)
Status: Not started
Summary: Review the fractally whitepaper social media design and consider implementing it. Also, consider using the algorithm for the OF channel and proposing additional awards for promotions and great content on the OP Stack and Optimism channel.
Created time: February 8, 2024 9:51 PM
Last edited time: February 15, 2024 8:01 PM
Created by: Dan Singjoy

- [ ]  review the fractally whitepaper social media design and consider implementing this
    - [ ]  [fractally.com](http://fractally.com)
    - [ ]  review [EdenCreators.com/tools](http://EdenCreators.com/tools) section about social media with pages
    - [ ]  curate

- [ ]  and consider using this algorithm for the OF channel
    - Does it have any special functions like hive?
    
- [ ]  consider also proposing additional awards for promotions and great content on the OP Stack  and Optimism channel