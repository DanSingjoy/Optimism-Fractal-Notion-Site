# Join L2Beat Office Hours and discuss Missions for Optimism Season 6

Assignee: Dan Singjoy
Due: September 11, 2024
Status: Not started
Task Summary: This task aims to facilitate participation in the L2Beat Office Hours, where participants will discuss the Missions for Optimism Season 6. Engaging in these sessions will provide insights into the operational processes and the application timeline.
Summary: Join L2Beat office hours on Tuesdays at 15 UTC to discuss Missions for Optimism Season 6, and ensure to add this to the calendar and set alarms.
Parent-task: Consider creating mission requests for Optimism Season 6 (Consider%20creating%20mission%20requests%20for%20Optimism%20Se%208fd2aae8e83b40cea5ed6369887d84d0.md)
Created time: May 25, 2024 10:11 AM
Last edited time: August 18, 2024 12:16 PM
Created by: Dan Singjoy
Description: Join L2Beat Office Hours on Tuesdays at 15 UTC to discuss Missions for Optimism Season 6, and ensure to add this to the calendar and set alarms.

- [ ]  Join [L2Beat Office Hours ](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Events%20ea9e175f88f5452f9bd834bbabcab0a4/Optimism%20Fractal%20Events%20Calendar%209fe995ccda1b492daae39353c5452549/L2Beat%20Office%20Hours%20a3e9b03989494bea81e3366012b4adb9.md) on Tuesdays at 15 UTC to gain a better idea about exactly how this works and when/how we apply
    - [ ]  Add this to the calendar and set alarms

[Season 6: Reflection Period Guide](https://gov.optimism.io/t/season-6-reflection-period-guide/8130#season-6-preview-13)

![Untitled](Consider%20creating%20mission%20requests%20for%20Optimism%20Se%208fd2aae8e83b40cea5ed6369887d84d0/Untitled.png)

![Untitled](Consider%20creating%20mission%20requests%20for%20Optimism%20Se%208fd2aae8e83b40cea5ed6369887d84d0/Untitled%201.png)

- Mission Requests must be proposed by before June 27th, maybe earlier