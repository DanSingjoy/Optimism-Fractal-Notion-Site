# Tag aneri from base and mint

Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
Status: Not started
Task Summary: This task aims to tag Aneri from Base and Mint. The creator of the task is Dan Singjoy, and it is currently in the "Not started" status. The task was created on May 21, 2024, at 9:47 PM and last edited on May 23, 2024, at 3:55 PM. For more details, you can refer to the https://x.com/0xaneri/status/1792993851939926313?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ.
Summary: No content
Created time: May 21, 2024 5:47 PM
Last edited time: May 23, 2024 11:55 AM
Created by: Dan Singjoy

[https://x.com/0xaneri/status/1792993851939926313?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/0xaneri/status/1792993851939926313?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/0xaneri/status/1792993851939926313?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/0xaneri/status/1792993851939926313?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)