# Set up HeroCast and read next steps at Hats Protocol | FarcasterDelegator: share FIDs onchain

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Create and Execute Promotional Strategy for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20and%20Execute%20Promotional%20Strategy%20for%20Optimi%20ea86a4b0098f48da970a5a108ec02544.md), Create Optimism Fractal Promotional Strategy (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Promotional%20Strategy%2092bfd89b01294e988511fe6e4f03f526.md), Explore and Create Integrations between Farcaster and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md)
Status: In progress
URL: https://blog.hatsprotocol.xyz/farcasterdelegator?referrer=0x516cafd745ec780d20f61c0d71fe258ea765222d
Task Summary: This task aims to set up HeroCast and guide readers through the next steps outlined in the Hats Protocol | FarcasterDelegator. The page provides information and instructions on sharing FIDs onchain, with the goal of facilitating seamless communication and collaboration.
Summary: Set up HeroCast and read next steps at Hats Protocol | FarcasterDelegator: share FIDs onchain. Created by Dan Singjoy, assigned to Dan Singjoy. Due on August 2, 2024. In progress. URL: https://blog.hatsprotocol.xyz/farcasterdelegator?referrer=0x516cafd745ec780d20f61c0d71fe258ea765222d. Created on May 23, 2024, at 12:20 PM. Last edited on July 23, 2024, at 4:07 PM.
Created time: May 23, 2024 8:20 AM
Last edited time: July 23, 2024 12:07 PM
Created by: Dan Singjoy
Description: Set up HeroCast and read next steps at Hats Protocol | FarcasterDelegator: share FIDs onchain. Created by Dan Singjoy, assigned to Dan Singjoy, due on August 2, 2024. In progress. URL: https://blog.hatsprotocol.xyz/farcasterdelegator?referrer=0x516cafd745ec780d20f61c0d71fe258ea765222d. Created on May 23, 2024 at 12:20 PM, last edited on July 23, 2024 at 4:07 PM.

![3788d46a5feb5b6a17fddf3ccc79415d.jpg](Set%20up%20HeroCast%20and%20read%20next%20steps%20at%20Hats%20Protoc%20ad155d3f37144650b2f01cffd8e1f903/3788d46a5feb5b6a17fddf3ccc79415d.jpg)