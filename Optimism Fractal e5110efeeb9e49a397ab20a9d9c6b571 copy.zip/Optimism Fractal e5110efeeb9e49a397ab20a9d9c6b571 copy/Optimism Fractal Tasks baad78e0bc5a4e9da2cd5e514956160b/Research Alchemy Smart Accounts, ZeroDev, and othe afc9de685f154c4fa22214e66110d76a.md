# Research Alchemy Smart Accounts, ZeroDev, and other Account Abstraction wallet tools that enable Gasless Transactions

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md), Research Account Abstraction Services for Gasless Transactions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20Account%20Abstraction%20Services%20for%20Gasless%20%2066379e2fdde445b194a7eb797b74e96c.md)
Status: Not started
Task Summary: This task aims to research and explore Alchemy Smart Accounts, ZeroDev, and other Account Abstraction wallet tools that enable Gasless Transactions. The goal is to understand the benefits and functionality of these tools, their relevance to Optimism Fractal, and their potential impact on transaction fees and user experience. While not a high priority for Optimism Fractal at the moment, it is important to gather knowledge and insights for future considerations.
Summary: Research Alchemy Smart Accounts, ZeroDev, and other Account Abstraction wallet tools that enable Gasless Transactions. While it may not be a high priority for Optimism Fractal due to low fees, there may be other benefits worth exploring.
Priority: Low
Created time: February 23, 2024 9:49 AM
Last edited time: February 23, 2024 10:24 AM
Created by: Dan Singjoy

- I think this would be nice but it isn’t a huge priority for Optimism Fractal because we can just send people like a dollar worth of ETH and the fees are so low that it will last them for a very long time
    - There are probably other great benefits and it’s good to learn more but for now it doesn’t seem like a big priority

[https://twitter.com/privy_io/status/1760403025875947629](https://twitter.com/privy_io/status/1760403025875947629)

[https://twitter.com/zerodev_app/status/1760748801063591992](https://twitter.com/zerodev_app/status/1760748801063591992)

[https://twitter.com/dabit3/status/1759666632874394084](https://twitter.com/dabit3/status/1759666632874394084)

[https://twitter.com/dabit3/status/1757468525285781807](https://twitter.com/dabit3/status/1757468525285781807)

[https://twitter.com/privy_io/status/1756032355561865342](https://twitter.com/privy_io/status/1756032355561865342)