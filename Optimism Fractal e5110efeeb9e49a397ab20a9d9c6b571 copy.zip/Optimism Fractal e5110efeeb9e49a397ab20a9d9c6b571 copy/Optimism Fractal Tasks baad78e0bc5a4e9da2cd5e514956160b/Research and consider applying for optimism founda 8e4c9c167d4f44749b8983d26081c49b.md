# Research and consider applying for optimism foundation RFP for metric to measure decentralization - due beginning of June

Due: May 31, 2024
Project: Submit Respect and Respect Votes as Impact Metrics for Open Source Observer(OSO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Submit%20Respect%20and%20Respect%20Votes%20as%20Impact%20Metrics%2012ebf87ca05b40379c0f6a4266ffb847.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md), Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md)
Status: Archived
URL: https://x.com/lalalavendr/status/1788228128520777983?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to research and consider applying for the optimism foundation RFP to develop a metric for measuring decentralization. The deadline for submission is at the beginning of June. However, after conducting research, Dan Singjoy concluded that while it is possible, it is not currently feasible for the organization to apply.
Summary: The document discusses the opportunity to apply for an optimism foundation RFP to measure decentralization. However, it is determined that it is not very feasible to apply at the moment.
Created time: May 8, 2024 11:30 AM
Last edited time: June 10, 2024 12:02 PM
Created by: Dan Singjoy

[https://x.com/lalalavendr/status/1788228128520777983?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/lalalavendr/status/1788228128520777983?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

Dan researched this and it’s possible but not very feasible for us to apply right now