# Message Vlad and Tadas about sharing Optimystics Project for developing Fractal app in public OF site

Assignee: Dan Singjoy
Status: Done
Summary: No content
Parent-task: Respond to Hodlon about his project with bitbeckers and message Optimystics about sharing Respect Game project (Respond%20to%20Hodlon%20about%20his%20project%20with%20bitbecker%2021182bbed0af41378db660c64918e566.md)
Created time: April 16, 2024 5:46 AM
Last edited time: April 16, 2024 5:47 AM
Created by: Dan Singjoy

## Description

## Message Vlad and Tadas about this

Hey @vlad and @tadas, do you mind if i share the Respect Game [project](https://www.notion.so/Develop-Respect-Game-app-and-or-Fractal-app-on-EVM-f26a8815731a48968a2299b43137b8c8?pvs=21) and related tasks/pages publicly in the Optimism Fractal notion site?

This project includes screenshots of our conversations about developing the app here in this private chat. Before sharing it I would review it carefully then remove any details about specific clients like Joshua and any other details that aren’t related to the app. I’d like to create a project to “Create Optimism Fractal App,” which could help coordinate a community-driven design and development process. The Optimism Fractal app would likely include more advanced features for decision-making than we’re planning to deliver for the first version for other communities and other features that the Optimism Fractal community wants. The app would likely include components of the Fractal App and I imagine it would synergize quite well the Optimystics’ development process.

I think that sharing this project would be helpful as part of our ‘Bazaar’ development strategy to help us to build more in public like we discussed last month. It would allow Hodlon, BitBeckers, and other builders to better understand and benefit from our work. Sharing this project would also enable a more collaborative and decentralized approach to product design and development going forward, which can complement the ‘Cathedral’ parts of our development strategy wherever we see it. What do you think?

Vlad, do you mind if I share your figma file publicly there too?

I’m curious to hear your thoughts about Hodlon and Bitbecker’s project requirement document. It has a lot of similarities to the app that we’ve been developing and some unique ideas that would be good to integrate as well. They would appreciate if you can share feedback on the HackMD article or Optimism Fractal Discord. I’d also be happy to help facilitate a meeting or any other kind of discussion if you’d like