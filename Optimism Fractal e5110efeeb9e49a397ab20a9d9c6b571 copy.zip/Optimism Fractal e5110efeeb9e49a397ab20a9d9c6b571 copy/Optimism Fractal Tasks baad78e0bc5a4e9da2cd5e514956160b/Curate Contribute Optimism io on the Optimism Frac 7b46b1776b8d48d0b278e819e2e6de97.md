# Curate Contribute.Optimism.io on the Optimism Fractal Education Hub

Project: Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md)
Status: Not started
Summary: No content
Sub-task: Update Contribute FAQ and OptimismFractal.com/contribute  (Update%20Contribute%20FAQ%20and%20OptimismFractal%20com%20cont%20fab8c571ee644d13b9d25b9ac00b9fcf.md)
Created time: April 6, 2024 8:46 PM
Last edited time: April 6, 2024 9:39 PM
Created by: Dan Singjoy

## Description

-