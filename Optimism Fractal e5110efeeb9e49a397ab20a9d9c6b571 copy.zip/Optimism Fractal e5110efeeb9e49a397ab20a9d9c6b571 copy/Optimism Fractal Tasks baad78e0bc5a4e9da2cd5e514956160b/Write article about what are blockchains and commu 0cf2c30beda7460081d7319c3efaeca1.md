# Write article about what are blockchains and community computers?

Project: Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md)
Status: Not started
Task Summary: This task aims to write an article that explores the concepts of blockchains and community computers. The article will provide an overview of what blockchains are and how they function, as well as an explanation of community computers and their role in decentralized systems. It will delve into the potential benefits and challenges associated with these technologies.
Summary: No content
Created time: May 1, 2024 11:44 AM
Last edited time: May 8, 2024 6:09 AM
Created by: Dan Singjoy

[https://twitter.com/spengrah/status/1781709809651220965](https://twitter.com/spengrah/status/1781709809651220965)

[https://twitter.com/spengrah/status/1781709809651220965](https://twitter.com/spengrah/status/1781709809651220965)