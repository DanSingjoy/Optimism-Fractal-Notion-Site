# Explore alternatives to Snapshot

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Summary: Consider alternatives to Snapshot such as Tally.xyz, EasyRetroPGF.xyz, or http://jokerace.io/, but Snapshot seems to be well positioned based on research. Snapshot is open-source and well funded by RetroFunding and VC funding.
Created time: May 1, 2024 7:52 AM
Last edited time: May 1, 2024 7:54 AM
Created by: Dan Singjoy

## Description

It’s may also be possible to use a different software like [Tally.xyz](http://Tally.xyz), [EasyRetroPGF.xyz](http://EasyRetroPGF.xyz), or [JokeRace.io](http://JokeRace.io) instead of Snapshot; but from my [research](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md) Snapshot seems to be well positioned to provide what we need.

Snapshot is open-source and appears well funded from RetroFunding and a round of VC funding a couple years ago