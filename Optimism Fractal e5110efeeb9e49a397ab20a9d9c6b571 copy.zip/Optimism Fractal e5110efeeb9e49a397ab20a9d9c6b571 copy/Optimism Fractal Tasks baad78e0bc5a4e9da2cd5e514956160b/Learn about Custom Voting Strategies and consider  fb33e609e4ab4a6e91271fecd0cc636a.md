# Learn about Custom Voting Strategies and consider creating one

Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to introduce and explore the concept of Custom Voting Strategies. It encourages readers to learn about the benefits and considerations of creating their own voting strategies. By following the provided link, readers can access a guide that provides step-by-step instructions on how to create a voting strategy using the Snapshot platform.
Summary: Learn about custom voting strategies and consider creating one using the guide provided at https://docs.snapshot.org/developer-guides/create-a-strategy/voting-strategy.
Created time: June 3, 2024 9:03 AM
Last edited time: June 3, 2024 9:03 AM
Created by: Dan Singjoy

[Create a voting strategy | snapshot](https://docs.snapshot.org/developer-guides/create-a-strategy/voting-strategy)