# Mint rewards on zora can help people earn by playing the respect game and minting respect then sharing with friends

Project: Build app component to make it easy for participants to give personal respect at the end of each game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md)
Status: Not started
Task Summary: This task aims to explore how mint rewards on Zora can enable individuals to earn rewards by engaging in the respect game. By minting respect and sharing it with friends, participants can enhance their experience and potentially increase their earnings within the platform.
Summary: Minting rewards on Zora allows users to earn by playing the respect game, minting respect, and sharing it with friends.
Created time: May 21, 2024 8:24 AM
Last edited time: September 11, 2024 10:44 AM
Created by: Dan Singjoy
Description: Minting rewards on Zora allows users to earn by participating in the respect game, where they can mint respect and share it with friends.

[https://x.com/ourzora/status/1779971474599690583?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/ourzora/status/1779971474599690583?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/ourzora/status/1779971474599690583?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/ourzora/status/1779971474599690583?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)