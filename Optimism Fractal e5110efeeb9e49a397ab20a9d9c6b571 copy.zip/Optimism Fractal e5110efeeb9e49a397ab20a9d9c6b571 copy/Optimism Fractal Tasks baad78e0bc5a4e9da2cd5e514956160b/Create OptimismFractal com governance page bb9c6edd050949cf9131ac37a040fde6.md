# Create OptimismFractal.com/governance page

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Curate resources from Optimystics Blog into Optimism Fractal website and Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20resources%20from%20Optimystics%20Blog%20into%20Optimi%203d60d2fb04b7474db55c1fb8a462e4fe.md), Create branding and educational resources for decision-making consensus games (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20branding%20and%20educational%20resources%20for%20deci%20188c45e0a1dc4773bd8202133ced6eb7.md), Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md), Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md), Create Documentation for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Documentation%20for%20Optimism%20Fractal%203ddb136554ea454b875ca8ec00d3900d.md)
Status: Not started
Task Summary: This task aims to create the http://optimismfractal.com/governance page, which will provide comprehensive information about the governance model of Optimism Fractal. The page will cover various aspects such as the council, history of fractal governance, respect trees, OREC, fractal democracy, and more. It will also emphasize the significance of these concepts in improving governance and encourage readers to get involved in the Optimism Fractal community.
Summary: The http://optimismfractal.com/governance page should include information about the council, history of fractal governance, respect trees, OREC, fractal democracy, Cagendas, Optimism town hall, OPTOPICS, Eden fractal, more equal animals, Daniel Larimer, the optimism collective governance structure, ways to get involved, and related videos. It should also have a brief section on how the council is inspired by fractally and include notes about governance.
Created time: June 17, 2024 9:04 AM
Last edited time: July 23, 2024 12:07 PM
Created by: Dan Singjoy
Description: The http://optimismfractal.com/governance page should include information about the council, history of fractal governance, respect trees, OREC, fractal democracy, Cagendas, Optimism town hall, OPTOPICS, Eden fractal, more equal animals, Daniel Larimer, the optimism collective governance structure, and ways to get involved. It should also have a brief section on how the council is inspired by fractally and include related videos and notes about governance.

This page should include more than just the council and it should be linked on the home page. 

There are many ways in which optimism fractal pioneers and helps optimize governance. It’s important to explain the significance of the council and how all of these concepts/innovations work together to improve governance . 

This is especially important for retro funding round 6 and the wider adoption of frapps

- [ ]  give this to AI as well as the other resources that would be helpful to feed Ai with information (Ie each of the articles below)

It should include:

- council
- History of fractal governance
- Respect trees
- OREC
- Fractal democracy
- Cagendas
- Optimism town hall
- OPTOPICS
- Eden fractal
    - Eden fractal stories and speeches , vision and mission
- More equal animals
- Daniel Larimer
- The optimism collective governance structure and Core intents to improve governance
- Ways to get involved
    - Participate
    - Join council
    - Speak at town hall
    - Vote on topics
    - Propose topics
    - Build with frapps
    - Deploy frapps

All of these are examples of how optimism fracta contributes towards improving governance 

- [ ]  also add to the council page a brief section about how this is inspired by fractally.
    - [ ]  Include some of the parts from the history of fractals that introduce and link to fractal democracy, more equal animals, Daniel Larimer, and fractally
    - we could just copy and paste it
    
- [ ]  add related videos

- [ ]  add/organize notes about governance in [Propose new core intents for Optimism Fractal](Propose%20new%20core%20intents%20for%20Optimism%20Fractal%20491265791bd546fdaeefb5e237b9e4c5.md)

### Rationale

I believe that it’s helpful to change the core intents in this way for the following reasons:

1. Optimism Fractal is now pioneering collective decision-making in various ways, including our  [Council](https://optimismfractal.com/council), advanced software for granular decision-making like [Respect Trees](https://optimystics.io/respect-trees), and topic discussion games at [Optimism Town Hall](https://lu.ma/optimismtownhall). When the Optimystics initially set the current core intents last October, Optimism Fractal was just beginning and had less to offer in terms of collective governance. Now, it has grown significantly and can make a substantial impact on Optimism Collective governance.

2. Optimism Fractal is rooted in [fractal democracy](https://fractally.com/blog/what-is-fractal-democracy), a governance process designed to truly empower people throughout society. This [article](https://optimystics.io/blog/fractalhistory) about the History of Fractals explains how the goal of improving collective governance is deeply ingrained in the fabric of Optimism Fractal. You can explore the article to understand how Optimism Fractal evolved from Eden Fractal, More Equal Animals, ƒractally, and the efforts of hundreds of dedicated builders optimizing governance processes.

1. The Optimism Collective aims to improve governance and the first intent ratified by the Collective in [Season 6](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md) is to move towards decentralization. As stated in the intent ratification [article](https://gov.optimism.io/t/season-6-intents-ratification/8104), “This includes both technical and organizational decentralization – including work to improve upgrade processes, governance execution, the development ecosystem, and governance processes of the Collective.” Optimism Fractal can play an increasingly important role on the Collective’s Path to Open MetaGovernance of the community leadership, which you can learn more about on this [page](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20and%20Strategize%20to%20provide%20Optimism%20Collec%20ad36d53370ce43a18be5b0ff973a2052.md).

2. The [6th round of Retro Funding](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861#retro-funding-6-governance-14) focuses on governance and setting this as a core intent can help Optimism Fractal community members to earn funding by providing a positive impact on Optimism Collective governance. You can learn more about how Optimism Fractal can help you earn Retro Funding in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md) and how we’re preparing for a successful RetroFunding round this season of Optimism Fractal [here](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md).

3. By incorporating a focus on optimizing collective governance into our core intent and consistently highlighting it in our messaging, we can more clearly convey the value that the Optimism Fractal community provides to the Collective and attract others interested in improving collective decision-making.

You can see more rationale at the bottom of the page in the section about alternate versions and some questions that were considered while making this draft proposal for those who are interested.