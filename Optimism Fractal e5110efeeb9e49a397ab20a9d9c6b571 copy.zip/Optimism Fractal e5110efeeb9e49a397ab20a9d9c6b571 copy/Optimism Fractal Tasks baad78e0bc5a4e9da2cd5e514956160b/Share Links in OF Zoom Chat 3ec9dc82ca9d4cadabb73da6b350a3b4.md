# Share Links in OF Zoom Chat

Project: Prepare for OF 28 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2028%2055526595a95345fd888501f23774c254.md)
Status: Not started
Task Summary: This task aims to share links in the OF Zoom chat during the introductory presentation. The links include the Optimism Fractal Welcome Guide, which contains additional resources shared during the presentation, as well as the Optimism Fractal Discord and Farcaster Channel.
Summary: In the introductory presentation, it is suggested that Rosmari shares the following links in the Zoom chat: the Optimism Fractal Welcome Guide, Optimism Fractal Discord, and Optimism Fractal Farcaster Channel.
Created time: May 25, 2024 5:28 PM
Last edited time: May 25, 2024 5:28 PM
Created by: Dan Singjoy

- I think it’d be good if Rosmari shares the following links in the zoom chat during the introductory presentation
    - [Optimism Fractal Welcome Guide](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md)
        - This includes the links that I shared during the presentation
    - Optimism Fractal Discord
    - Optimism Fractal Farcaster Channel