# Read James Mart’s Article about Sovereign Tokens

Project: Explore Concepts of Sovereign Tokens, Intersubjective Consensus, ICP, and Firmament (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Concepts%20of%20Sovereign%20Tokens,%20Intersubject%20762925eb0d724c3aafa95e7fe2f2f811.md)
Status: Not started
Summary: No content
Created time: April 30, 2024 3:48 AM
Last edited time: April 30, 2024 3:54 AM
Created by: Dan Singjoy

article from James Mart

Very interesting new article from James Mart. It reminds me of [Optimystics.io/firmament](http://Optimystics.io/firmament) and some ideas we discussed for funding fractals

[Growing Communities](https://www.notion.so/Growing-Communities-61a27b0db002427393a3eab5932b4197?pvs=21) 

[Firmament ](https://www.notion.so/Firmament-73e62da8d6bd4bf0a14be24b31812080?pvs=21) 

[https://twitter.com/_JamesMart/status/1725192327063298514](https://twitter.com/_JamesMart/status/1725192327063298514)