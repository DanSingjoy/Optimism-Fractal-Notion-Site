# Curate Posts about Base

Status: Not started
Task Summary: This task aims to curate posts about Base, a project focused on bringing 1B+ people onchain. The posts include updates on the development of Base, announcements, and discussions about its vision and features.
Summary: This document contains a collection of tweets and links related to Base, including updates, announcements, and discussions about the project. It also mentions events, collaborations, and the vision of Base as an open ecosystem for building decentralized apps.
Created time: August 11, 2023 4:48 PM
Last edited time: May 27, 2024 7:46 PM
Created by: Dan Singjoy

- Old Posts that might be worth curating better with AI at some point
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 28](https://twitter.com/BuildOnBase/status/1630586408904581122)
    
    The vision of Base is to bring 1B+ people onchain. For the next 5 days, we’ll be evolving the artwork on our ‘Base, Introduced’ NFT to tell the story of the builders who will make that happen. Check your NFT for the latest evolution every day at 12p ET from today until 3/6.
    
    1,632
    
    335.9K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 3](https://twitter.com/BuildOnBase/status/1631715462139592705)
    
    1/ You've been asking for
    
    [@Chainlink](https://twitter.com/chainlink)
    
    oracle support on Base, and we've been listening👇 Today, [#Chainlink](https://twitter.com/hashtag/Chainlink?src=hashtag_click) Data Feeds are live on [#Base](https://twitter.com/hashtag/Base?src=hashtag_click) testnet, while also making oracle services available to developers at a lower cost through participating in the Chainlink SCALE program.
    
    1,470
    
    186.2K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 24](https://twitter.com/BuildOnBase/status/1629225746731237388)
    
    1/ Web3 developers – join us on Base, a new, open-source Ethereum L2 with a vision for decentralization and scale. Base is built by Coinbase builders, for the world’s builders. It is designed to be an open ecosystem where anyone, anywhere can build.
    
    [0:24](https://twitter.com/BuildOnBase/status/1629225746731237388/mediaviewer)
    
    1,412
    
    204.4K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 6](https://twitter.com/BuildOnBase/status/1632567215605030913)
    
    🔵 3 hours left to mint 'Base, Introduced' Mint yours @ [mint.base.org](https://t.co/69G4zj1Ne8)
    
    1,401
    
    136.4K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 10](https://twitter.com/BuildOnBase/status/1634255776070918145)
    
    🌈 👏
    
    Quote Tweet
    
    Rainbow
    
    [@rainbowdotme](https://twitter.com/rainbowdotme)
    
    ·
    
    [Feb 23](https://twitter.com/rainbowdotme/status/1628788858539081737)
    
    @Coinbase created @BuildonBase L2 using the OP Stack to onboard the next billion users to web3 We believe L2s are the future—they make crypto easier, cheaper, & safer to use Rainbow will proudly support Base & future OP Stack chains → base.org
    
    1,323
    
    78.3K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [May 17](https://twitter.com/BuildOnBase/status/1658845417927311362)
    
    Introducing Base Camp – a self-paced learning program for smart contract development, designed to empower experienced developers & onchain enthusiasts alike 📚[docs.base.org/base-camp/docs…](https://t.co/r7F1QprjzL)
    
    GIF
    
    1,314
    
    214.1K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 30](https://twitter.com/BuildOnBase/status/1641539956349779974)
    
    It’s been a month since we launched Base testnet, with a vision to bring the next billion users onchain. A 🧵on our favorite moments And more detail in our blog:
    
    [base.mirror.xyzHow the Builders Met BaseWe’re dedicating this post to the Base community by sharing some of our favorite highlights.](https://t.co/QxF6Um5q4h)
    
    1,207
    
    158.5K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 27](https://twitter.com/BuildOnBase/status/1630000242882904064)
    
    We’re extending the free mint for 1 week to include builders at
    
    [@EthereumDenver](https://twitter.com/EthereumDenver)
    
    and to make sure as many people as possible can celebrate Base. Why? Because Base is for everyone. 1 per address @ [mint.base.org](https://t.co/69G4zj1Ne8)
    
    Quote Tweet
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 26](https://twitter.com/BuildOnBase/status/1629981232732749830)
    
    People are loving ‘Base, Introduced’, our commemorative NFT on @ourZORA: 261K unique minters #1 gas burn over last 24h Join us by minting mint.base.org
    
    1,125
    
    312.8K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 6](https://twitter.com/BuildOnBase/status/1632873693725483008)
    
    🔵 'Base, Introduced' - 7 unique pieces of art - 485,090 mints; 368,547 holders - One of the largest open-edition Ethereum collections We’re excited to build Base with all of you.
    
    GIF
    
    1,169
    
    185.5K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Apr 26](https://twitter.com/BuildOnBase/status/1651309761718091789)
    
    Shields up 🛡️🔵
    
    1,163
    
    106.2K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 7](https://twitter.com/BuildOnBase/status/1632936354937192449)
    
    🚀
    
    Quote Tweet
    
    Major props to @coinbase on the launch of Base, their new Ethereum L2 solution! Offering a secure and affordable way to build decentralized apps, Base is helping pave the way for the next era of cryptocurrency. Check it out! twitter.com/coinbase/statu…
    
    1,137
    
    48.9K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 24](https://twitter.com/BuildOnBase/status/1639292978161131520)
    
    Are you a builder passionate about making the onchain economy grow, but looking for where to start? We just published a Request for Builders: four areas we’d love to see builders explore on Base (with funding from the Base Ecosystem Fund) 🧵
    
    [base.mirror.xyzRequest for BuildersWe recently launched Base, a secure, low-cost, developer friendly Ethereum L2. Our vision is to collectively work towards an ambitious goal: bringing the next billion users onchain. One of our values...](https://t.co/XSSdPnusyc)
    
    1,094
    
    184K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 23](https://twitter.com/BuildOnBase/status/1628773307834068993)
    
    We have a vision Of scaling Ethereum With a Superchain 🔵🔴⚫⚪ You can learn more in our post or read more in the 🧵[base.mirror.xyz/H_KPwV31M7OJT-…](https://t.co/OBo5Cq2GsJ)
    
    71
    
    1,130
    
    189.6K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Jul 27](https://twitter.com/BuildOnBase/status/1684615998027227137)
    
    To our builder community: Have you applied for the Genesis Builder NFT? Be sure to get this permanent onchain record of your early support of the Base mission via our Builder site, powered by
    
    [@deformapp](https://twitter.com/deformapp)
    
    [builder.base.orgBecome a Base Genesis BuilderINSTRUCTIONS 1. Connect deployer wallet. Connect the wallet used to deploy your dapp’s smart contract. 2. Verify contract. Verify the smart contract you deployed on Base Mainnet. 3. Fill out the...](https://t.co/aXrvNGR2N9)
    
    1,254
    
    153K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Apr 24](https://twitter.com/BuildOnBase/status/1650613978307985414)
    
    🔀 First hardfork coming up on Base testnet: April 27 at 10a PT 🧵
    
    1,073
    
    167.8K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 7](https://twitter.com/BuildOnBase/status/1632926037049737218)
    
    ✨
    
    Quote Tweet
    
    Magic Eden
    
    [@MagicEden](https://twitter.com/MagicEden)
    
    ·
    
    [Feb 23](https://twitter.com/MagicEden/status/1628852213131927552)
    
    0:46. twitter.com/coinbase/statu…
    
    1,063
    
    52.7K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 23](https://twitter.com/BuildOnBase/status/1628759593491873794)
    
    Replying to
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    8/ Become a part of Base history Mint “Base, Introduced” — a commemorative NFT that celebrates the initial launch of Base. 1 per address, freely mintable on
    
    [@OurZora](https://twitter.com/ourZORA)
    
    through Sunday at midnight EST.
    
    [zora.coBase, IntroducedMeet Base, an Ethereum L2 that offers a secure, low-cost, developer-friendly way for anyone, anywhere, to build decentralized apps. We collectively minted ‘Base, Introduced’ to celebrate the testnet...](https://t.co/hfJbShAEVK)
    
    216.5K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Jun 7](https://twitter.com/BuildOnBase/status/1666497552680640517)
    
    1/ As the second core contributor to the OP Stack, we’ve begun making meaningful contributions to the codebase that powers Base, OP Mainnet, & other OP Stack chains. We’re sharing a deep dive on a recent scalability improvement we made.
    
    [base.mirror.xyzContributing to the Scalability of Base and the OP Stack: A Tech…By Michael de Hoog](https://t.co/bK7fPcx2WC)
    
    174.9K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [May 15](https://twitter.com/BuildOnBase/status/1658242139933880321)
    
    Are you a Base NFT holder and going to
    
    [@EDC_LasVegas](https://twitter.com/EDC_LasVegas)
    
    ? We’re excited to share a surprise for our vibrant Base community. Stop by the Coinbase Token Club, an immersive experience at EDC! 🕺
    
    289.9K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 3](https://twitter.com/BuildOnBase/status/1631799257639313409)
    
    BOUNTY ALERT: We're looking for web3 enthusiasts to solve our crypto bounty! First 50 finishers will get $250 in ETH, first 500 finishers will earn an exclusive NFT, and an opportunity to score a convo with a recruiter at Coinbase. 👀 Check it out 👇 [coinbase.com/bounty/ethdenv…](https://t.co/bDewzzEwE1)
    
    264.3K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    Prep your questions. Join the Base team for an AMA on r/ethereum on March 21 at 12 pm ET / 4 pm UTC
    
    Quote Tweet
    
    Jesse Pollak (jesse.xyz)
    
    [@jessepollak](https://twitter.com/jessepollak)
    
    ·
    
    [Mar 17](https://twitter.com/jessepollak/status/1636786605112573952)
    
    me and the @BuildOnBase team will be hosting a @Reddit AMA next week on r/ethereum. we'll be answering live at 12 pm ET on Tuesday, March 21, but you can get started asking questions today! reddit.com/r/ethereum/com…
    
    67.2K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    🔵 The ‘Base, Introduced’ NFT is evolving. Today, we’re telling the story of collaboration. Base is made possible by all of us working together to build an open and decentralized future. Join us onchain @ mint․base․org
    
    [zora.coBase, IntroducedMeet Base, an Ethereum L2 that offers a secure, low-cost, developer-friendly way for anyone, anywhere, to build decentralized apps. We collectively minted ‘Base, Introduced’ to celebrate the testnet...](https://t.co/69G4zj1Ne8)
    
    86.8K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    A huge thank you to the Ethereum community for another successful upgrade with Shapella and Withdrawals. We're excited to continue contributing to securing and scaling Ethereum with EIP4844 and beyond.
    
    Quote Tweet
    
    [terence.eth](https://twitter.com/terencechain)
    
    [@terencechain](https://twitter.com/terencechain)
    
    ·
    
    [Apr 12](https://twitter.com/terencechain/status/1646279674702729216)
    
    Ethereum proof-of-stake chain has upgraded to Shapella. Withdrawal is now enabled This closes the loop of the original beacon chain design. Validator can deposit -> withdrawal.
    
    23
    
    97.8K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    REMINDER – don’t miss today’s AMA with the Base team: 12 pm ET / 4pm UTC on r/ethereum. Start queuing your questions 🔵
    
    [reddit.comFrom the ethereum community on RedditExplore this post and more from the ethereum community](https://t.co/KUjhifCUm5)
    
    33.3K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    We’re grateful for all the devs that have been working tirelessly through the last few months to prepare for Base’s mainnet launch Every day it feels more and more like Onchain Summer Who's feeling it?
    
    71.2K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    ICYMI -- check out this moment in base.eth history
    
    Quote Tweet
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Apr 5](https://twitter.com/BuildOnBase/status/1643746071645138945)
    
    base.org → base.eth Thanks to an anonymous gift from a stranger who shares our vision of decentralization, base.eth is now our primary onchain identity. Mint this piece of Base history on @ourZORA, available until 4/12 at 5pm PT / 8pm ET: zora.co/collections/0x…
    
    38
    
    88.1K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    🎉 Thanks to everyone who joined our 2nd Base Friday Q&A!
    
    24
    
    61.2K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    P.S. In case you’re keeping track, with the completion of these audits, we’ve now fulfilled ⅘ of our criteria for mainnet launch… [base.mirror.xyz/gxOzGCE-9C7cNZ…](https://t.co/eRarQ4R7zG)
    
    Quote Tweet
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Jun 29](https://twitter.com/BuildOnBase/status/1674521479227273217)
    
    Security is an essential part of bringing the next million developers and billion users onchain We're sharing how we’ve approached security, how we’re preparing for a secure mainnet launch with internal and external security audits, and how we draw on Coinbase’s best practices
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    People are loving ‘Base, Introduced’, our commemorative NFT on
    
    [@ourZORA](https://twitter.com/ourZORA)
    
    : 🔵261K unique minters 🔥#1 gas burn over last 24h Join us by minting 👇
    
    [zora.coBase, IntroducedMeet Base, an Ethereum L2 that offers a secure, low-cost, developer-friendly way for anyone, anywhere, to build decentralized apps. We collectively minted ‘Base, Introduced’ to celebrate the testnet...](https://t.co/69G4zj1Ne8)
    
    333.2K
    
    Base
    
    The latest evolution of ‘Base, Introduced’ represents decentralization. 👇 Today at 12 pm ET, it will evolve again with new artwork and a new theme. We continue to tell the story of builders creating the onchain future. Mint at [mint.base.org](https://t.co/69G4zj1Ne8), powered by .
    
    GIF
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    Base builders now have an easy way to onboard new users to their dapps with wallet services. Happy building! 🤝
    
    Quote Tweet
    
    Coinbase Cloud
    
    gm builders! We're excited to announce that Wallet as a Service now supports @BuildOnBase Goerli testnet Base makes it easy to build onchain applications, offering the security and benefits of Ethereum at 10x lower cost.
    
    81.8K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    Replying to
    
    6/ Base is for Everyone. We’re excited to launch Base with an incredible group of builders from across the crypto ecosystem, with more joining in every day. The best products are built in community and Base will be an open ecosystem where anyone, anywhere can build.
    
    288.6K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    🔵 The ‘Base, Introduced’ NFT is evolving. Today’s artwork embodies decentralization, transparency, and collaboration - many come together as one to build a better future for all. Join us in the final 12 HOURS of the mint at [mint.base.org](https://t.co/69G4zj1Ne8), powered by .
    
    111.8K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    Base Goerli Regolith Hardfork was a success today 🎉 This upgrade enhances block formation on Base: 🔢 Deposit transactions now have nonces for easy tracking 🔗 Contract addresses align better with standard EVM address derivation
    
    77.2K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    Want to see a dapp deployed on Base? We’ve made a helpful guide for crafting governance proposals that shares the why and how behind bringing dapps to the Base ecosystem
    
    81.5K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    The ‘Base, Introduced’ NFT mint is closing on 3/6. Have you minted yours? [mint.base.org](https://t.co/69G4zj2l3G) 👉 powered by
    
    [@ourZORA](https://twitter.com/ourZORA)
    
    [zora.coBase, IntroducedMeet Base, an Ethereum L2 that offers a secure, low-cost, developer-friendly way for anyone, anywhere, to build decentralized apps. We collectively minted ‘Base, Introduced’ to celebrate the testnet...](https://t.co/69G4zj2l3G)
    
    130.8K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Apr 11](https://twitter.com/BuildOnBase/status/1645883373980725249)
    
    Join us on Discord on Fri at 9am PT for the 2nd Base Friday Q&A! 🎉 We’ll answer questions about Base & spotlight builders 🚀 Know a cool project? Share in [#builders](https://twitter.com/hashtag/builders?src=hashtag_click)-spotlight on the Base Discord & it might be featured! 🌟 Submit & upvote questions in [#base](https://twitter.com/hashtag/base?src=hashtag_click)-friday-questions
    
    75.2K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Apr 5](https://twitter.com/BuildOnBase/status/1643424081402896386)
    
    1/ Chúng tôi đã có một thời gian tuyệt vời ở Việt Nam! We’re introducing Base to builders worldwide. Our second stop: Vietnam 🇻🇳
    
    72.6K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Jun 29](https://twitter.com/BuildOnBase/status/1674521479227273217)
    
    Security is an essential part of bringing the next million developers and billion users onchain We're sharing how we’ve approached security, how we’re preparing for a secure mainnet launch with internal and external security audits, and how we draw on Coinbase’s best practices
    
    200.5K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Apr 28](https://twitter.com/BuildOnBase/status/1651979065744605184)
    
    🎉 We had an amazing time at our recent meetup in Singapore, co-hosted with
    
    [@infura_io](https://twitter.com/infura_io)
    
    🇸🇬 This was our third stop in Asia after unforgettable events in Vietnam 🇻🇳 and Japan 🇯🇵
    
    58.7K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 23](https://twitter.com/BuildOnBase/status/1628759582666371072)
    
    Replying to
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    1/ Important: Base is *not* a token We do not plan to issue a new network token for Base and will use ETH as the native gas token.
    
    93K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Feb 23](https://twitter.com/BuildOnBase/status/1628759585182953472)
    
    Replying to
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    3/ Base will be: → The onchain home for → An open ecosystem where anyone, anywhere, can build dapps that reach the next 1B+ users → A bridge that brings our users onchain and enables them to go anywhere, including L1, other L2s, and ecosystems like Bitcoin & Solana
    
    508.6K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Mar 2](https://twitter.com/BuildOnBase/status/1631356320677781509)
    
    🔵 The ‘Base, Introduced’ NFT is evolving. Today’s artwork tells the story of building. We solve hard, technical problems. We know that progress isn’t made overnight, but keep going until we create something big and worth celebrating. Join us onchain @ [mint.base.org](https://t.co/69G4zj1Ne8)
    
    GIF
    
    67.3K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [May 16](https://twitter.com/BuildOnBase/status/1658480528172134402)
    
    Miami-bound this weekend? Join us for a gallery event hosted by and Base. Dive into the vibrant world of NFTs from talented creators including
    
    [@andreoshea](https://twitter.com/andreoshea)
    
    , whose artwork inspired builders in our first Builder Quest. Can't wait to see you: [lu.ma/a0vsuee6](https://t.co/MaXfrO1Ehb) 🎉🎨
    
    [lu.maWeb3 Art and Culture Showcase at BTC Miami · LumaJoin us for an exclusive gallery event hosted by Chainlink and Base. This unique event will showcase the beauty and power of NFTs created by talented and innovative creators across the Web3...](https://t.co/MaXfrO1Ehb)
    
    11
    
    453
    
    57.1K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [Apr 19](https://twitter.com/BuildOnBase/status/1648688113542103041)
    
    🔵Smart contract security, brought to you by
    
    [@OpenZeppelin](https://twitter.com/OpenZeppelin)
    
    👇
    
    13
    
    64
    
    529
    
    58.1K
    
    Base
    
    [@BuildOnBase](https://twitter.com/BuildOnBase)
    
    ·
    
    [https://twitter.com/buildonbase?s=11&t=xP2VArgrZ3VqnY5S2s8WeQ](https://twitter.com/buildonbase?s=11&t=xP2VArgrZ3VqnY5S2s8WeQ)
    

## Base

[https://www.youtube.com/watch?v=Ho0k9L8Be6U&t=3268s](https://www.youtube.com/watch?v=Ho0k9L8Be6U&t=3268s)

[54:28](https://www.youtube.com/watch?v=Ho0k9L8Be6U&t=3268s)

[Brian Armstrong new podcast ](Curate%20Posts%20about%20Base%2042c94531345847df8bb16c540ea3b9f7/Brian%20Armstrong%20new%20podcast%20022e2509a37d44ea9da0744a000e69f9.md)

[On chain summer](Curate%20Posts%20about%20Base%2042c94531345847df8bb16c540ea3b9f7/On%20chain%20summer%207c46f92ef246426c8d2e37fde9fd5986.md)

[Onchain](Curate%20Posts%20about%20Base%2042c94531345847df8bb16c540ea3b9f7/Onchain%2037752a79a47243e181d303b8f477341f.md)

[Nouns and base giving 100 eth this summer - add to clients partners monetization opportunities pages](Curate%20Posts%20about%20Base%2042c94531345847df8bb16c540ea3b9f7/Nouns%20and%20base%20giving%20100%20eth%20this%20summer%20-%20add%20to%207d23e621bf6049479dd8f38c9e081536.md)

[Onchain summer.xyz vídeo ](Curate%20Posts%20about%20Base%2042c94531345847df8bb16c540ea3b9f7/Onchain%20summer%20xyz%20vi%CC%81deo%2034c5f78526e146358774afb4edf2c468.md)

[https://twitter.com/optimismfnd/status/1690095059109019648?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://twitter.com/optimismfnd/status/1690095059109019648?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://twitter.com/optimismfnd/status/1690095059109019648?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://twitter.com/optimismfnd/status/1690095059109019648?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)