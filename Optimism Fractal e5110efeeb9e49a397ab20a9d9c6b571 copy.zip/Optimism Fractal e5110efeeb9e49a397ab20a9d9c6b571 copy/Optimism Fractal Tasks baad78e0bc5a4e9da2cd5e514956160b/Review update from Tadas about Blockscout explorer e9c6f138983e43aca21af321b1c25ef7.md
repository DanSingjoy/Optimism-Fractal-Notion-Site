# Review update from Tadas about Blockscout explorer

Project: Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md)
Status: Not started
Summary: Review update from Tadas about Blockscout explorer. The message includes a link to the Blockscout explorer for a specific token.
Created time: February 14, 2024 11:15 PM
Last edited time: March 24, 2024 5:52 PM
Created by: Dan Singjoy

A few weeks after recording the video, Tadas shared the following message:

![Untitled](Review%20update%20from%20Tadas%20about%20Blockscout%20explorer%20e9c6f138983e43aca21af321b1c25ef7/Untitled.png)

[https://optimism.blockscout.com/token/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC?tab=holders](https://optimism.blockscout.com/token/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC?tab=holders)