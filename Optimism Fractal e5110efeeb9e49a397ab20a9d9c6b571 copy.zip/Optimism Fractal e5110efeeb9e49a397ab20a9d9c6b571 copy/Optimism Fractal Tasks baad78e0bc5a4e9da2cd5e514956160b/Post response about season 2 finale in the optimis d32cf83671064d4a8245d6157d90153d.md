# Post response about season 2 finale in the optimism governance forum

Assignee: Dan Singjoy
Due: April 29, 2024
Project: Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md), Create different kinds of consensus games for seasonal celebrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20different%20kinds%20of%20consensus%20games%20for%20seas%20a62e1ceb57514af3ae9999b57973df4c.md)
Status: Done
Summary: This document is a post response about the season 2 finale in the optimism governance forum. It includes tasks such as including the snapshot poll and video of the event, thanking everyone for the great season, and proposing the start of the 3rd season of Optimism Fractal with links to discussions and posts.
Created time: April 18, 2024 3:10 PM
Last edited time: May 1, 2024 10:59 AM
Created by: Dan Singjoy

[https://gov.optimism.io/t/optimism-fractal-weekly-events/7378/15](https://gov.optimism.io/t/optimism-fractal-weekly-events/7378/15)

- [x]  rosmari didn’t include the snapshot poll, just the discord post, so i should include the snapshot poll

- [ ]  Include the video of the event

- [x]  thank everyone for the great season and looking forward to next. consider adding my tweet

![Untitled](Post%20response%20about%20season%202%20finale%20in%20the%20optimis%20d32cf83671064d4a8245d6157d90153d/Untitled.png)

Here is the proposal on

[@SnapshotLabs](https://twitter.com/SnapshotLabs)

to start the 3rd Season of Optimism Fractal. The proposal includes links to recent discussions and posts with more details. Everyone is welcome to participate in the consensus process to help lead

[@OptimismFractal](https://twitter.com/OptimismFractal)

![https://abs-0.twimg.com/emoji/v2/svg/1f33b.svg](https://abs-0.twimg.com/emoji/v2/svg/1f33b.svg)

[https://snapshot.org/#/optimismfractal](https://t.co/X4PLetpUJ4)