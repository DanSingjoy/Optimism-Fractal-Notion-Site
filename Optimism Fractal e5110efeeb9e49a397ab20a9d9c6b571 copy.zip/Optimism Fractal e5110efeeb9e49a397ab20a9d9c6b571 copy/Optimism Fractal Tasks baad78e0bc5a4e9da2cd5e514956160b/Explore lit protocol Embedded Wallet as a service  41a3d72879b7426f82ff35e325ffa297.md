# Explore lit protocol Embedded Wallet as a service platform

Status: Not started
Task Summary: This task aims to explore the Lit Protocol Embedded Wallet as a service platform. The page provides an overview of the platform, including its creator, status, and creation time. For more information, visit https://www.litprotocol.com/.
Summary: No content
Parent-task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created time: March 18, 2024 8:45 PM
Last edited time: June 8, 2024 11:42 PM
Parent task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created by: Dan Singjoy

## Description

[https://www.litprotocol.com/](https://www.litprotocol.com/)

![Untitled](Explore%20lit%20protocol%20Embedded%20Wallet%20as%20a%20service%20%2041a3d72879b7426f82ff35e325ffa297/Untitled.png)

![Untitled](Explore%20lit%20protocol%20Embedded%20Wallet%20as%20a%20service%20%2041a3d72879b7426f82ff35e325ffa297/Untitled%201.png)

![Untitled](Explore%20lit%20protocol%20Embedded%20Wallet%20as%20a%20service%20%2041a3d72879b7426f82ff35e325ffa297/Untitled%202.png)

![Untitled](Explore%20lit%20protocol%20Embedded%20Wallet%20as%20a%20service%20%2041a3d72879b7426f82ff35e325ffa297/Untitled%203.png)

![Untitled](Explore%20lit%20protocol%20Embedded%20Wallet%20as%20a%20service%20%2041a3d72879b7426f82ff35e325ffa297/Untitled%204.png)