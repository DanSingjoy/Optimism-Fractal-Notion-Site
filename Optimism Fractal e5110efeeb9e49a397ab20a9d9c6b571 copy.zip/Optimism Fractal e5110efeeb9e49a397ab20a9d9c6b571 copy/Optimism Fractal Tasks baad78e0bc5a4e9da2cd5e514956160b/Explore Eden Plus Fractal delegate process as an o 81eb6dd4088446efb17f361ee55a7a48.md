# Explore Eden Plus Fractal delegate process as an option

Project: Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md)
Status: On Pause
Summary: Explore Eden Plus Fractal delegate process as an option. Eden+Fractal combines Eden Elections and ƒractally to help communities cooperate for mutual benefit. Community members respect contributions and elect delegates, who form councils to represent the community's will and make decisions.
Created time: January 12, 2024 9:33 AM
Last edited time: February 15, 2024 8:31 PM
Created by: Dan Singjoy

## Articles

[EdenCreators.com/plus](http://EdenCreators.com/plus) 

[Tadas' original article](https://peakd.com/fractally/@sim31/edenfractal-consensus-process)

## Overview

Eden+Fractal is an innovative consensus game that combines the benefits of [Eden Elections](http://edenelections.com/) and [ƒractally](https://fractally.com/) to help communities cooperate for mutual benefit.

With this elegant process, community members both respect contributions to the community and elect delegates during the same breakout room. Delegates form councils that update each week, then recent councils cooperate to represent the will of the community, express shared opinions, and make community decisions.

![Untitled](Explore%20Eden%20Plus%20Fractal%20delegate%20process%20as%20an%20o%2081eb6dd4088446efb17f361ee55a7a48/Untitled.png)

## Related Links

[EdenElections.com](http://EdenElections.com) 

[https://optimystics.io/blog/our-fractal-journey-to-optimism#530095581f3d4290a2541a956cb9193a](https://optimystics.io/blog/our-fractal-journey-to-optimism#530095581f3d4290a2541a956cb9193a)

## Video

[https://www.youtube.com/watch?v=SagAwK2md0M](https://www.youtube.com/watch?v=SagAwK2md0M)

- [ ]  @Dan Singjoy will fix the link to this on [edencreators.com/talk](http://edencreators.com/talk) site
    - [ ]  [Update Creator Talk DNS Website](https://www.notion.so/Update-Creator-Talk-DNS-Website-c3865745c1454870b827e81645b2e454?pvs=21)