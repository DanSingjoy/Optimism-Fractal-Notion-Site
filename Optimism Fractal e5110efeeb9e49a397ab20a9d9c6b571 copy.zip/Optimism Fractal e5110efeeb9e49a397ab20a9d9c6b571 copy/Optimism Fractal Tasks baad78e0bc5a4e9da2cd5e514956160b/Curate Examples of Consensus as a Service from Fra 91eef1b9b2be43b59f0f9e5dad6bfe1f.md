# Curate Examples of Consensus as a Service from Fractal Communities

Due: May 3, 2024
Project: Consider Developing Product and Service Offerings  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Consider%20Developing%20Product%20and%20Service%20Offerings%2065a79191ce1a48d88fe03cb71f4ca25b.md)
Status: Not started
Task Summary: This task aims to curate examples of Consensus as a Service from Fractal Communities. It highlights the potential of democratic community consensus and showcases the technical capabilities of newly built IBC features on Antelope community computers. The examples include how Eden Fractal signaled consensus to support custodians on Planet Eyeke and the use of IBC to facilitate Eden Fractal recommendations for Alien Worlds candidates.
Summary: The document discusses the use of consensus as a service in Fractal Communities, specifically highlighting examples from the Eden Fractal meetings and their support for custodians on Planet Eyeke. It also mentions the technical capabilities of IBC features on Antelope community computers and provides links to related posts and videos.
Sub-task: Review and Curate examples of Eden Fractal offering consensus as a service for Alien Worlds to show how Optimism Fractal can offer similar services (Review%20and%20Curate%20examples%20of%20Eden%20Fractal%20offerin%20862b393949af46738d43f7804333f499.md)
Created time: May 5, 2024 11:42 AM
Last edited time: May 5, 2024 11:49 AM
Created by: Dan Singjoy

## To Do

- [ ]  See and organize task at [Review and Organize ideas about offering consensus as a service ](Review%20and%20Organize%20ideas%20about%20offering%20consensus%20bf8c18e57cb2467f98ba0504caba9189.md)

- [ ]  Consider - Is this a tool or a service?
    - Maybe we should create a service database
    - Yes this seems like a good idea and something we can also present here
    - There is already an offer section so it can be combined there
        - What is the best name? Offers? Services? Services and Offers?
            - I think Services is generally better for many use cases but both can work
            
- [x]  create new article at [EdenCreators.com/caas](http://EdenCreators.com/caas)

- [x]  curate section about recommendations in AWF article

- [x]  add newest writing from [Alien Worlds](https://www.notion.so/Alien-Worlds-eeddd97e076a4761bffa7d9f14a506be?pvs=21)

## Eden Fractal Recommendations

In addition to building Alien Worlds Fractal, we’ve also been working with [Eden Fractal](https://edenfractal.com/) to provide signals for Alien Worlds leaders. You can watch the [47th](http://edenfractal.com/47), [48th](https://edenfractal.com/48), and [54th](http://edenfractal.com/54) Eden Fractal meetings to see how we signaled consensus to support custodians on Planet Eyeke after the creator of Alien Worlds, Michael Yeates, requested our recommendations.

This is a momentous development that shows the potential superpower of democratic community consensus and showcases the technical capabilities with newly built IBC features on Antelope community computers. You can see Michael Yeates post about new software he created to facilitate Eden Fractal recommendations for Alien Worlds candidates via IBC [here](https://t.me/c/1979501745/138) and you can hear the creator of IBC, Gnome, share a really exciting update about how Eden Fractal players on EOS can recommend Alien Worlds candidates on WAX [here](https://www.youtube.com/live/RQ1W7bOtKdI?feature=share&t=4641). You can also see a [post](https://t.me/edenfractal/1/3411) about this from Dan Singjoy, who has been acting as representative for the Eden+Fractal council in Alien Worlds.

You can watch the videos and explore the show notes below to learn more about these cosmically exciting developments:

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/e8b7e6f4-ab81-4f0d-950c-0bb60389a37a/54_full255/w=3840,quality=80,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/e8b7e6f4-ab81-4f0d-950c-0bb60389a37a/54_full255/w=3840,quality=80,fit=scale-down)

### [EF 54: Signalling Alien Worlds, Part III](http://edenfractal.com/54)

In our first meeting after our one year anniversary, we voyage again to Alien Worlds and signal our support for Vlad and Red on Planet Eyeke 👽

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/49ba75e3-4ddd-4b46-b756-4d715a185da0/48_thumb25/w=3840,quality=80,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/49ba75e3-4ddd-4b46-b756-4d715a185da0/48_thumb25/w=3840,quality=80,fit=scale-down)

### [**EF 48: Signaling Alien Worlds**](https://edenfractal.com/48)

In our 48th meeting, we explore a pioneering proposal for Alien Worlds and signal our consensus opinion that Lisa & Duane should be custodians on Planet Eyeke 👽

In this week’s Eden Fractal meeting we formed unanimous consensus that Lisa and Duane should be custodians on Planet Eyeke. Ten people people voted yes in the [Consortium Poll](https://consortium.vote/poll/781077/0s7lmw10i6o/ofaqqnelrdwa) (including all 8 current Eden Fractal delegates) and you can see the consensus posted on-chain [here](https://bloks.io/account/consortiumlv). You can also see the spreadsheet that we use to more easily see votes from each delegate [here](https://docs.google.com/spreadsheets/d/1d9pOWFPgfbtUI-flk5s5IeG9EcIOlXKdBAjxHo1NDDs/edit#gid=0) and the on-chain account where we post delegate elections [here](https://bloks.io/account/edenfractest) to see the full consensus.

The Alien Worlds proposal was the main topic of discussion during this week’s Cagendas game and it was also a frequent topic during our breakout room in the beginning of the video. You can see us reach consensus around [1:48:49](https://www.youtube.com/watch?v=7rglsbn6VZI&t=6529s) and view show notes with comprehensive timestamps [here](https://edenfractal.com/48) ✨

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/fd04ad7c-4545-4936-9fa5-d78b282ad79a/471/w=3840,quality=80,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/fd04ad7c-4545-4936-9fa5-d78b282ad79a/471/w=3840,quality=80,fit=scale-down)

### [EF 47: Alien Worlds and Documentation](https://edenfractal.com/47)

In our forty seventh meeting, we discuss strategies to improve documentation for our tools and a proposal to support Lisa & Duane as planetary leaders in Alien Worlds! 🛸

In addition to our discussion about Alien Worlds at Eden Fractal meeting #48, we also discussed the same proposal for about thirty minutes in the prior week’s meeting. We reached an informal supermajority consensus that Lisa and Duane should be custodians during this meeting two weeks ago, but we decided to propose it again this week to more formally approve the proposal with the Eden+Fractal process and inspire a deeper discussion. 

You can read a brief summary that Dan wrote about this Alien Worlds proposal [here](https://t.me/edenfractal/1/2654) and explore the [show notes](https://edenfractal.com/47) for this week’s timestamps and more exciting details 💫

“You can watch the [47th](http://edenfractal.com/47), [48th](https://edenfractal.com/48), and [54th](http://edenfractal.com/54) Eden Fractal meetings to see how we signaled consensus to support custodians on Planet Eyeke after the creator of Alien Worlds, Michael Yeates, requested our recommendations.

This is a momentous development that shows the potential superpower of democratic community consensus and showcases the technical capabilities with newly built IBC features on Antelope community computers. You can see Michael Yeates post about new software he created to facilitate Eden Fractal recommendations for Alien Worlds candidates via IBC [here](https://t.me/c/1979501745/138) and you can hear the creator of IBC, Gnome, share a really exciting update about how Eden Fractal players on EOS can recommend Alien Worlds candidates on WAX [here](https://www.youtube.com/live/RQ1W7bOtKdI?feature=share&t=4641). You can also see a [post](https://t.me/edenfractal/1/3411) about this from Dan Singjoy, who has been acting as representative for the Eden+Fractal council in Alien Worlds.”

> “Now what we’re beginning to see is that literal protocols are being built on top of IBC.

Yesterday Michael Yeates (the creator of Alien Worlds) announced that he finished writing a smart contract that would allow players or participants in Eden Fractal on EOS to have their votes transferred through IBC to WAX and be taken into consideration for voting the custodians on the planets of Alien Worlds.

So that to me is ***really exciting*** because now we can see people building additional apps that are using IBC to build their own workflows and processes that connect chains together. So we’re really starting to see these distributed apps that reside on multiple chain at the same time and having the different parts of their applications communicating through this protocol. 

So this is very, very exciting stuff! I’m really looking forward to seeing what’s going to emerge out of that and it’s impossible to know. I think some people will blow our minds in the next few months and hopefully for years with amazing applications like this.”

- Gnome, Creator of [Antelope IBC](https://eosnetwork.com/blog/antelope-ibc-deep-dive-seamless-horizontal-scaling-launches-on-eos/) and co-founder of [UX Network](https://www.uxnetwork.io/) and [EOS Titan](https://www.eostitan.com/)
> 

 [Alien Worlds Fractal](https://edencreators.com/alienworldsfractal), [Fractalien Worlds](https://edencreators.com/fractalienworlds), and Eden Fractal Recommendations in Alien Worlds in the article