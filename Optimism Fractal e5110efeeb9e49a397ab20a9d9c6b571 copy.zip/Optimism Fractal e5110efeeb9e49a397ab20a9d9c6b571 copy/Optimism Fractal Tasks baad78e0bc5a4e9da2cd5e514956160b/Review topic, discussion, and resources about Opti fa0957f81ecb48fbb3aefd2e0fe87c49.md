# Review topic, discussion, and resources about Optimism Collective Identity

Project: Create Auxiliary Respect Tokens for Optimism Collective (ie OPC) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Auxiliary%20Respect%20Tokens%20for%20Optimism%20Colle%20b78abde1bff54c499c648628e459c689.md)
Status: Not started
Task Summary: This task aims to explore the concept of Optimism Collective Identity by reviewing relevant topics, facilitating discussions, and gathering resources. The goal is to deepen understanding and foster collaboration within the community regarding this important subject.
Summary: No content
Parent-task: Create and Organize Topic(s) for Optimism Fractal 38  (Create%20and%20Organize%20Topic(s)%20for%20Optimism%20Fractal%20%20cc66d864b0a6469d97fbcb3f22237580.md)
Created time: August 22, 2024 11:05 AM
Last edited time: August 22, 2024 2:59 PM
Parent task: Create and Organize Topic(s) for Optimism Fractal 38  (Create%20and%20Organize%20Topic(s)%20for%20Optimism%20Fractal%20%20cc66d864b0a6469d97fbcb3f22237580.md)
Created by: Dan Singjoy
Description: No content

## 👁️ Optimism Collective Identity

The Optimism Foundation is working to create a robust system for identity and reputation within the Optimism Collective, which can improve RetroFunding, the Citizen’s House, and many other systems.

At this week’s event we can explore the Optimism Foundation’s thinking on identity systems in the Collective and how Optimism Fractal can help. I can share a brief overview of identity systems on Optimism and we can have an open discussion about it.

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can find related resources and learn more about identity in the Optimism Collective in these [tabs](https://arc.net/folder/1A6CF438-10DE-4161-9851-F26018B96591) and this [notion page](../%F0%9F%90%99%20Optimism%20Town%20Hall%20Topics%20and%20OPTOPICS%20Database%206415ae101d154bf8a3c1b25d218295d5/%F0%9F%91%81%EF%B8%8F%20Optimism%20Collective%20Identity%2052fe94446c2645cab1aca7de0d67925c.md).