# Start finishing the breakout rooms sooner

Project: Improve event structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20event%20structure%20for%20Optimism%20Fractal%201e2afc98737f4bf58af066788f956622.md)
Status: Not started
Summary: To optimize the timing and allow for more discussion in the main room, it is suggested to finish breakout rooms 5 or 10 minutes early. This will provide time for the whole group to gather before the top of the hour. Additionally, there is a proposal to end the respect game at 45 or 50 past the hour to allow for more conversation in the main room. The idea is to create a better experience for all participants and promote collaboration among builders. The size of the breakout rooms and the preference for more intimate discussions should be taken into consideration. Overall, the goal is to have more time together in the main room and optimize the waiting time between breakout rooms.
Created time: March 15, 2024 4:04 PM
Last edited time: March 28, 2024 11:47 AM
Created by: Dan Singjoy

# Instructions

- Try to finish your breakout room 5 or 10 minutes early if you can, so we have time as a whole group before the top of the hour

- [ ]  We need to check to see if/how zoom allows breakout groups to go back to the community room whenever they’re ready
    - Feel free to let us know in the discord whenever your group is ready

# Feedback and Thoughts that Inspired This

## Rosmari’s Message to Dan

btw i thought about making the time in the breakout room a bit shorter to end like 45 past or 50 past. Below are a few reasons:

- some people have to go at the top of the hour like Hodlon who said he's got a scheduled meeting (idk if its recurrent)
- there will be more time for conversation in the main room as right now is just presenation and going straight to breakout rooms (where most of the talking between us happens)
- after the first one hour, people are a bit more tired and less consentrated so if we can make the event shorter by 10-15 mins, that will be a bonus. We dont necessarily have to change the time but maybe lets say if the planning session starts at 17:50 instead of 18:00 that will give us more time together and maybe we can finish earlier. Also this structure will give more chance for people which have to go at the top of the hour to first say what they think and still be heard by others and say bye, etc.

These are very rough notes of my thoughts but i think it's worth doing also because:

- when we are a group of 4 people per breakout room, we tend to finish sooner and not use the full time collectively as a cohesive group of builders (which is often what we promote). We do work together in the planning sessions and also in the breakout rooms however if we can expand that time with all builders together in the main room where it's all recorded, that is ultimately a better experience for all. it makes sense for that time when we finish which is around 45 past until the top of the hour, to be together in the main room and hear more from other participants which were in the other breakout room too.
- All of the above will give some time for the two breakout rooms to also do some mix and matching of 'oh how was your breakout group' and kind of 'who won' and maybe we can share some thoughts about special contributions (like highlights) from both rooms which can be part of the main recording.

Also when there's time when we're not together it kind of slows down the vibes because we are sort of waiting for the other breakout room to finish and i think we can optimize that time if we just all try to finish by 45 past and make it all in the main room

There could be an option to use that 15 mins time ONLY in special cases and we can communicate with each other during the event if either room needs these additional 15 mins

What do you think? We can discuss it tomorrow on a call if you want. I can of course put all of those thought into a Notion page bc it seems like its quite a lot lol

Now that I re-read it all i think we should definitely do it if most community members agree of course

## Dan’s Response

It sounds like a good idea, thank you for writing and sharing. I agree that we should finish and go back to the community room by 50 or 55 so that everyone can see each other and speak for a bit before people need to leave at the top of the hour. Ending the respect game at 17:45 is a good aim but seems too aggressive as an expectation unless we start the breakout room earlier. A lot of breakout rooms aren’t done by then and we don’t want to rush people too much.

A lot of this depends on the size of the breakout room as well. A group with 6 people usually takes at least 50% more time than a room with 4 people. As the community grows most of the breakout rooms will be 6 people and many people might prefer might prefer more time in intimate breakout room more than a community room with many people. The vibe with six people is often more talkative as well since more people are likely to have questions for each other or interested in leading a conversation. The meeting structure needs to provide enough time to accommodate relaxed meetings with six people. I don’t think we should change the time of the planning session because it’s much simpler go say 17 and 18 utc, but it will work well for the respect game to end 5-15 minutes before the top of the hour and have some relaxed unstructured time for before the planning session starts.

Your feedback makes a lot of sense and I agree that we should start going back to the community room sooner, especially in the near future while we’re in this state where we have many rooms with 4 people. I’ll add your notes here to our topics so we can discuss it more tomorrow if you want and figure out the best way to do it. I think I’ll make a reminder announce this intention at next weeks meeting as well, but it’s probably best to discuss it first at some point soon

## Related

[Punctuality and preparing for meetings - Optimism Fractal 6 and RetroPitches](https://www.notion.so/Punctuality-and-preparing-for-meetings-Optimism-Fractal-6-and-RetroPitches-3905fc3574f74422916f92b2347a4eb3?pvs=21) 

[Punctuality Refinements for OF and EF](https://www.notion.so/Punctuality-Refinements-for-OF-and-EF-8ff3412aaf164538ad1556ec0fba6d0b?pvs=21) 

[Improve Punctuality and Introductory Presentation](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Punctuality%20and%20Introductory%20Presentation%20a493a7e559f649f99038588431aa7c88.md)