# Respond to Hodlon about RetroFunding Categories and Applicants

Assignee: Dan Singjoy
Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Done
Summary: Contributions to Optimism Fractal could qualify for onchain builders, governance, and dev tooling rounds for RetroFunding. The assignee, Dan Singjoy, is writing a blog post and is open to discussing the topic further in the planning session.
Created time: April 6, 2024 12:44 PM
Last edited time: April 6, 2024 12:45 PM
Created by: Dan Singjoy

## Description

- 

![Untitled](Respond%20to%20Hodlon%20about%20RetroFunding%20Categories%20an%206d177eb0f26a460f84895d43f6e8e510/Untitled.png)

Good question! I think that contributions to Optimism Fractal could qualify for the onchain builders, governance, and dev tooling rounds this year. Here is an overview of each from the [announcement post](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU):

![Untitled](Respond%20to%20Hodlon%20about%20RetroFunding%20Categories%20an%206d177eb0f26a460f84895d43f6e8e510/Untitled%201.png)

![Untitled](Respond%20to%20Hodlon%20about%20RetroFunding%20Categories%20an%206d177eb0f26a460f84895d43f6e8e510/Untitled%202.png)

![Untitled](Respond%20to%20Hodlon%20about%20RetroFunding%20Categories%20an%206d177eb0f26a460f84895d43f6e8e510/Untitled%203.png)

![Untitled](Respond%20to%20Hodlon%20about%20RetroFunding%20Categories%20an%206d177eb0f26a460f84895d43f6e8e510/Untitled%204.png)

I’ve been thinking about this a lot and am writing a blog post to share my thoughts. I’ll share the post asap and would be happy to discuss this topic at today’s planning session. I’m curious to hear everyone’s thoughts about this and excited to help Optimism Fractal community members earn RetroFunding!