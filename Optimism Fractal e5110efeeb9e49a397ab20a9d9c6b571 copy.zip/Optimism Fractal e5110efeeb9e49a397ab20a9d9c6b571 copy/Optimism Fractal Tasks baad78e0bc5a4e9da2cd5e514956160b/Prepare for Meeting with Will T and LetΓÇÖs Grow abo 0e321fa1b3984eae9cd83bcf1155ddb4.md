# Prepare for Meeting with Will T and Let’s Grow about Cagendas

Assignee: Dan Singjoy
Due: July 1, 2024
Project: Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Create Educational Resources about Cagendas (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20Resources%20about%20Cagendas%203a6542c696a54beeb4d9f2a025d6aaea.md)
Status: Done
Task Summary: This task aims to prepare for a meeting with Will T and Let's Grow to discuss Cagendas. The page includes details about the meeting, an invitation to join related events, and mentions of the Respect Game and Optimism Fractal. It also addresses pain points and highlights the interest and involvement of Donny.
Summary: This document is a meeting preparation for a discussion with Will T and Let's Grow about Cagendas. The document includes expressions of appreciation, offers for assistance, suggestions for discussion topics, and invitations to join various events. A pain point is mentioned regarding the ability to pick topics, and the invitation is extended to anyone.
Created time: July 23, 2024 12:11 PM
Last edited time: July 24, 2024 10:26 PM
Created by: Dan Singjoy
Description: This document is a meeting preparation for a discussion with Will T and Let's Grow about Cagendas. The document includes expressions of appreciation, offers for assistance, and suggestions for discussion topics. It also mentions the Respect Game and Cagendas as potential topics of interest. Additionally, it invites anyone to join Optimism Fractal weekly events, Eden Fractal, Optimism Town Hall, and Fractal Office Hours events. A pain point is mentioned regarding the ability to pick topics, and it is noted that Donny enjoys it.

- Thanks for all the great work with Let’s Grow
    - I really enjoy and appreciate your work

- How can I help?
    - I think Will said that the first 10-15 minutes of the meeting are allocated for this discussion
    - Let me know if there’s anything in particular that you’d like to discuss or ask

- Should I provide an overview of Optimism Fractal, the Respect Game, and Cagendas?
    - If so, should I share my screen to provide a more visual overview ?

- Are you interested in playing the Respect Game?
    - Interested in implementing the Respect Game in weekly or bi-weekly meetings?
    - The Respect Game provides a powerful foundation that helps facilitate other meetings and collective decision-making
    - I’d be happy to provide more details and share links if you’d like
        - [ ]  open up [Review and organize notes from the meeting with Amanda Tyler](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Review%20and%20organize%20notes%20from%20the%20meeting%20with%20Am%20a9fbc9884e73479da63761e79b7b1aa2.md) for a better introduction to optimism fractal

- Are you interested in playing Cagendas?
    - I can share how we play at Optimism Town Hall (after Optimism Fractal weekly events) and Eden Fractal

- You’re welcome to join Optimism Fractal weekly events on Thursdays at 17 UTC
    - The last event of the season is happening this Thursday, July 25th.
    - After that we'll have a two week summer break and return for Optimism Fractal's fourth season on August 15th. You can find more details about this [here](https://gov.optimism.io/t/optimism-fractal-season-3/8095/18?u=dansingjoy) if you'd like.
    - Benefits and reasons to join
    
- You’re also welcome to join Eden Fractal, Optimism Town Hall, and Fractal Office Hours events
    - The dates and times for each
    - Benefits and reasons to join each

## Pain Point

- Being able to pick topics

- Donny really likes it

## Invite

Anyone