# Explore Funding Opportunities for integrating Smart Wallet and/or Embedded Wallet into Optimism Fractal App during Onchain Summer

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: Not started
Task Summary: This task aims to explore funding opportunities for integrating Smart Wallet and/or Embedded Wallet into the Optimism Fractal App during Onchain Summer. The goal is to leverage the available funding on Bounty Caster, which offers over $150k for integrating various tools while building, to enhance the functionality and features of the app.
Summary: Explore funding opportunities for integrating Smart Wallet and/or Embedded Wallet into Optimism Fractal App during Onchain Summer. Over $150k in funding is available on Bounty Caster for integrating various tools while building. More information can be found on the Onchain Summer Bounties page.
Created time: June 8, 2024 9:36 PM
Last edited time: June 9, 2024 12:45 PM
Created by: Dan Singjoy

## Integrate Smart Wallet and/or Embedded Wallet into Optimism Fractal App during Onchain Summer

In addition to the main rewards for the Buildathon, there is over $150k in funding available on Bounty Caster for integrating various tools while building. You can the Onchain Summer Bounties on this [page](https://www.bountycaster.xyz/onchainsummer).

[https://twitter.com/jessepollak/status/1796669836090871820](https://twitter.com/jessepollak/status/1796669836090871820)

[https://www.bountycaster.xyz/onchainsummer](https://www.bountycaster.xyz/onchainsummer)