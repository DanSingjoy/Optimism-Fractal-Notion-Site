# Review Prior Research into Codes of Conduct, Dispute Resolution Systems, and Community Agreements

Project: Consider Implementing Robert’s Rules, Participant Agreement, Code of Conduct, and Dispute Resolution Process (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Consider%20Implementing%20Robert%E2%80%99s%20Rules,%20Participant%20%2088a4fe9e4fcd40619dddfb81a3d4ad7b.md), Implement onchain Optimism Fractal participant/contributor agreement (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Implement%20onchain%20Optimism%20Fractal%20participant%20con%206a8b18dff0c242f2bc58a6f260774939.md)
Status: Not started
Task Summary: This task aims to review prior research into codes of conduct, dispute resolution systems, and community agreements. By examining existing frameworks and methodologies, we can enhance our understanding of effective governance and conflict resolution within communities, ultimately leading to more harmonious interactions.
Summary: The document outlines the need to review prior research on Codes of Conduct, Dispute Resolution Systems, and Community Agreements, referencing past discussions and indicating that more related articles will be added later.
Created time: March 24, 2024 9:49 AM
Last edited time: August 7, 2024 10:04 AM
Created by: Dan Singjoy
Description: The document outlines a plan to review prior research on Codes of Conduct, Dispute Resolution Systems, and Community Agreements, referencing past discussions and suggesting the inclusion of additional articles and resources when appropriate.

## Review Research into Code of Conduct and Dispute Resolution Systems

We have discussed agreements, Codes of Conduct, and Dispute Resolution Systems many times in past fractal events and communities. There are a few related articles below and we can add much more when the time is right:

[Code of Conduct](https://www.notion.so/Code-of-Conduct-0c7fa609b3f64b8bb1a934ff92dca132?pvs=21) 

[Dispute Resolution](https://www.notion.so/Dispute-Resolution-7545fae354084dcb9a226c2a1708b371?pvs=21) 

[EdenCreators.com/tools](http://EdenCreators.com/tools) 

- Sociocratic Method
    - EF 36?

### Agreements

We have discussed onchain agreements for fractal communities many times and I’ve curated extensive resources on the subject, which you can find in the link below. 

[EdenCreators.com/agreement](http://EdenCreators.com/agreement) 

- Regarding agreements, review [Create participant agreement for Optimism Fractal with Hats Protocol](Create%20participant%20agreement%20for%20Optimism%20Fractal%20%20c82f58d2abe34190826d61a0e70811aa.md)