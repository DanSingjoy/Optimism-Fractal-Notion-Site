# See Jrocki’s Response to Book the next available Optimism Demo Day

Assignee: Dan Singjoy, Rosmari
Due: August 2, 2024
Project: Create and Execute Promotional Strategy for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20and%20Execute%20Promotional%20Strategy%20for%20Optimi%20ea86a4b0098f48da970a5a108ec02544.md)
Status: In progress
Task Summary: This task aims to book the next available Optimism Demo Day and document Jrocki's response to it. The page includes information about the creator, assignees, due date, status, and timestamps of creation and last edit.
Summary: No content
Created time: May 23, 2024 8:59 AM
Last edited time: July 23, 2024 12:08 PM
Created by: Dan Singjoy
Description: No content

![Untitled](See%20Jrocki%E2%80%99s%20Response%20to%20Book%20the%20next%20available%20O%204981dfd4a527433b91452b696f068f4c/Untitled.png)

![Untitled](See%20Jrocki%E2%80%99s%20Response%20to%20Book%20the%20next%20available%20O%204981dfd4a527433b91452b696f068f4c/Untitled%201.png)