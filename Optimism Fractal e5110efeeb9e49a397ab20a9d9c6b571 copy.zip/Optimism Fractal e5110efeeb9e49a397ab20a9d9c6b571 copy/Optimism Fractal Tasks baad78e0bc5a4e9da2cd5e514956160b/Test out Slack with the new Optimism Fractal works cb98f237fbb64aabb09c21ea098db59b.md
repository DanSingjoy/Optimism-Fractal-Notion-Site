# Test out Slack with the new Optimism Fractal workspace and see how it works

Project: Improve notification and provenance system for optimism fractal notion site via discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20notification%20and%20provenance%20system%20for%20opt%202bd6ce3108b64785a23f1bba8557407f.md)
Status: Not started
Summary: Test out Slack with the new Optimism Fractal workspace and see how it works. The task is not started yet.
Created time: February 18, 2024 1:09 PM
Last edited time: February 18, 2024 1:11 PM
Created by: Dan Singjoy

## Description

-