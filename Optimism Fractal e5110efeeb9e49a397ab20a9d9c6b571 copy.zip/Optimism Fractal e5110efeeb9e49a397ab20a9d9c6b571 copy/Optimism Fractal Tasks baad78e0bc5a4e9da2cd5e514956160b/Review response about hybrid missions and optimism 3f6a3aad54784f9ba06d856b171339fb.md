# Review response about hybrid missions and optimism foundation office hours; and remember that Applicants no longer need to define the type of grant (builder or growth), this will be done internally. So teams only need to follow the mission application guide:

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Explore Mission Opportunities in Optimism Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md)
Status: Done
Task Summary: This task aims to review responses regarding hybrid missions and the office hours of the Optimism Foundation. It is important to note that applicants no longer need to specify the type of grant they are applying for, as this will be determined internally. Teams should focus on adhering to the mission application guide.
Summary: Applicants no longer need to specify the type of grant (builder or growth) as this will be handled internally. Teams should follow the mission application guide for hybrid missions and optimism foundation office hours.
Created time: June 26, 2024 11:37 AM
Last edited time: August 30, 2024 9:04 AM
Created by: Dan Singjoy
Description: Applicants for hybrid missions no longer need to specify the type of grant (builder or growth) as this will be handled internally. Teams should follow the mission application guide for submissions.

[Add to Personal Calendar, OF Community Calendar, and Start Joining Optimism Office Hours, Superchain Demo Day, Optimism Foundation Builder Office, Anticapture Commission Office Hours, and Ambassador Chat](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Add%20to%20Personal%20Calendar,%20OF%20Community%20Calendar,%20a%20dadd5640bb904becad0a987bd7014dc9.md) 

![Untitled](Review%20response%20about%20hybrid%20missions%20and%20optimism%203f6a3aad54784f9ba06d856b171339fb/Untitled.png)

[https://gov.optimism.io/t/season-6-suggested-mission-requests/8107/9](https://gov.optimism.io/t/season-6-suggested-mission-requests/8107/9)

![Untitled](Review%20response%20about%20hybrid%20missions%20and%20optimism%203f6a3aad54784f9ba06d856b171339fb/Untitled%201.png)

remember that Applicants no longer need to define the type of grant (builder or growth), this will be done internally. So teams only need to follow the mission application guide:

[https://gov.optimism.io/t/season-6-mission-application-guide/8114](https://gov.optimism.io/t/season-6-mission-application-guide/8114)