# Consider ways to allocate speaking time during Optimism Town Hall with Respect in Cagendas

Project: Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md)
Status: Not started
Task Summary: This task aims to explore different approaches for allocating speaking time during the Optimism Town Hall with Respect in Cagendas. The focus is on considering factors such as Respect, badgeholder status, and past contributions to determine speaking priority. By implementing a structured approach, the goal is to ensure fair and inclusive participation as the community grows in size.
Summary: Consider implementing a structure to allocate speaking time during the Optimism Town Hall based on respect and other metrics like badgeholder status or previous RetroPGF recipients. This may not be necessary for a small group, but can be designed in advance for future scalability. Another option is to use snapshot polls or slido with token-weighted or weighted voting to determine topic transitions. Hands raised can give priority to more respected community members.
Created time: April 24, 2024 3:48 AM
Last edited time: May 10, 2024 3:22 AM
Created by: Dan Singjoy

## Description

## Allocating Speaking Time with Respect

- If the community grows to have a large amount of people who want to talk, then implement the structure where we organize speaking time by Respect and other metrics like if they are a badgeholder or have earned from RetroPGF in the past
    - We could use Lindsay’s list for this to determine who is badgeholder and previous reciever of RetroFunding. We could give x amount of speaking ‘respect’ to people who qualify for this.
    
- This isn’t necessary with just a group of say 10 people so we don’t need to implement it now, but we can start designing it now so that we’ll be able to implement it once we have say 20 or 30 people and there are many people who want to speak at the same time

- [ ]  Add/merge this to [Design Cagendas at Optimism Fractal](https://www.notion.so/Design-Cagendas-at-Optimism-Fractal-3e9f883f2ac740d5a2ac11e50f6616ef?pvs=21)

## Allocating Speaking Time

1. Another snapshot poll (or series of polls) is used to move to the next topic. Ie if 50% of votes say move to the next topic. Or an optimistic variant where something like 10-20% of votes can move to next topic with a 3 minute timer that people can add if they want. Alternatively we could use slido.

Use token weighted 

Use weighted voting poll type in snapshot: [https://docs.snapshot.org/user-guides/proposals/voting-types#what-is-a-voting-type](https://docs.snapshot.org/user-guides/proposals/voting-types#what-is-a-voting-type)

Hands raised give priority to more respected community members?