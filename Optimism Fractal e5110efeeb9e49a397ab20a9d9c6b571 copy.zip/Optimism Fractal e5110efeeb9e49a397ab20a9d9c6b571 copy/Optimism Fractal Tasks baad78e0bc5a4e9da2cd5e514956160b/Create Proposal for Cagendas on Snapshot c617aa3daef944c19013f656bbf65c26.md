# Create Proposal for Cagendas on Snapshot

Assignee: Dan Singjoy
Due: May 9, 2024
Status: Done
Task Summary: This task aims to create a proposal for implementing Cagendas on Snapshot. The proposal will outline the details and objectives of integrating Cagendas into the Snapshot platform, providing a comprehensive plan for its implementation and usage.
Summary: Create a proposal for Cagendas on Snapshot, assigned to Dan Singjoy. The proposal should be created by May 9, 2024, and it has been marked as done. An image named "cagendas proposal image2 new.png" is included in the proposal.
Parent-task: Propose Cagendas and Make Promotional Post for OF 25 (Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b.md)
Created time: May 9, 2024 7:08 AM
Last edited time: May 10, 2024 3:18 AM
Created by: Dan Singjoy

## Create Proposal on Snapshot

**Should we implement Cagendas to organize discussion time in weekly events after playing the Respect Game?**

Cagendas is a social coordination game for collaborative agenda setting that empowers community members to propose, discuss, and vote on topics with Optimism Fractal Respect. There are simple rules to play Cagendas and an introduction to a new event below. Vote YES on this proposal if you agree to implement the following:

1. Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

2. Anyone who has earned Respect at Optimism Fractal can vote on polls with their Respect to help determine the discussion topic for each weekly event. 

3. Whichever poll has received the most votes in the Topic Poll by Monday at 17 UTC will be the topic discussed during the week’s event after the Respect Game.
    1. The poll for the topic proposal must end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event.

The Optimism Town Hall is envisioned as a collaborative forum and weekly event for structured discussions about Optimism. It is intended to replace our planning sessions with a more organized format and a greater focus on facilitating conversations that provide a positive impact for Optimism Collective governance. You can find more details about Cagendas, Optimism Town Hall, and rationale for this proposal on [this page](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md).

![cagendas proposal image2 new.png](Create%20Proposal%20for%20Cagendas%20on%20Snapshot%20c617aa3daef944c19013f656bbf65c26/cagendas_proposal_image2_new.png)