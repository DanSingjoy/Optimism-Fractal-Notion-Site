# Research, Try, and Share Superchain App Accelerator from thirdweb

Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Build Respect Game app (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: Not started
Summary: This document is about the Superchain App Accelerator from thirdweb. It provides a link to the grant page and a blog post about accelerating the Superchain with Optimism. There is also a link to the thirdweb YouTube channel.
Created time: May 1, 2024 11:30 AM
Last edited time: May 1, 2024 11:36 AM
Created by: Dan Singjoy

[https://thirdweb.com/grant/superchain](https://thirdweb.com/grant/superchain)

[https://www.youtube.com/watch?v=0xz_gsGjlb8&t=1475s&pp=ygUcb3B0aW1pc20gY29sbGVjdGl2ZSB0aGlyZHdlYg==](https://www.youtube.com/watch?v=0xz_gsGjlb8&t=1475s&pp=ygUcb3B0aW1pc20gY29sbGVjdGl2ZSB0aGlyZHdlYg==)

![Untitled](Research,%20Try,%20and%20Share%20Superchain%20App%20Accelerato%203e6b554ac8e7498bb50b185fad7e38d0/Untitled.png)

![Untitled](Research,%20Try,%20and%20Share%20Superchain%20App%20Accelerato%203e6b554ac8e7498bb50b185fad7e38d0/Untitled%201.png)

[Accelerating the Superchain with Optimism](https://blog.thirdweb.com/accelerating-the-superchain-with-optimism)

![Untitled](Research,%20Try,%20and%20Share%20Superchain%20App%20Accelerato%203e6b554ac8e7498bb50b185fad7e38d0/Untitled%202.png)

[https://www.youtube.com/@thirdweb_](https://www.youtube.com/@thirdweb_)