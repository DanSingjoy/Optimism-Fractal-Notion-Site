# Ask Tadas about testing the Optimism Fractal software and the draft proposal to change the seasons of OF and EF

Assignee: Dan Singjoy
Due: June 26, 2024
Status: Archived
Task Summary: This task aims to discuss testing the Optimism Fractal software and propose changes to the seasons of OF and EF. It includes a proposal for a shorter season with a longer break to allow for more focus on other aspects of the project. The document also seeks input on the testing timeline for the software and the possibility of deploying it for Eden Fractal alongside Optimism Fractal.
Summary: Dan Singjoy is seeking Tadas' input on testing the Optimism Fractal software and proposing a change to the seasons of OF and EF. Dan suggests finishing Season 3 after 10 weeks with a 3-week summer break to focus on other tasks and improve event quality. He seeks Tadas' thoughts on how this change would impact testing the software and asks for guidance on the amount of testing required. Dan also considers deploying the software for Eden Fractal and switching to biweekly events. He asks for Tadas' opinion on when to start testing the software at Eden Fractal.
Created time: June 18, 2024 1:41 PM
Last edited time: July 3, 2024 9:58 PM
Created by: Dan Singjoy
Description: Dan Singjoy is seeking Tadas' input on testing the Optimism Fractal software before Season 4 and proposing a change to the season schedule. Dan suggests finishing Season 3 after 10 weeks with a 3-week break, aiming to focus on other tasks, reduce workload, and improve event quality. Dan seeks Tadas' thoughts on how this change may affect testing the software and if there are any risks involved. Additionally, Dan plans to propose biweekly events for Eden Fractal and deploying the software for testing. Input and feedback from Tadas are requested regarding the deployment timeline for Eden Fractal.

- [ ]  transcribe/summarize and give to turquoise
    - [Transcribe, reformat, and summarize recording about business plan, summer strategy, minimum viable product, and targeted outreach ](../../EC%20Tasks%201951af2e70bd4666850a3d112e65f7a8/Transcribe,%20reformat,%20and%20summarize%20recording%20abou%2089fa71bc7e6d40ce871252ba926ee634.md)

- [ ]  see newer plan in [Propose 4 week summer break from Eden fractal, Eden Fractal Epoch 2, biweekly optimystics office hours events, and two week break from optimism fractal](https://www.notion.so/Propose-4-week-summer-break-from-Eden-fractal-Eden-Fractal-Epoch-2-biweekly-optimystics-office-hou-e7bdb4a20b5047a6943e8043e0e94f3d?pvs=21)

Tadas, do you have thoughts about how much testing you’d like to do for the fractal software before season 4 of Optimism Fractal?

I’m considering to propose that we finish Season 3 after 10 weeks and then take a 3 week summer break from events. This would provide moe time away from events compared to our previous arrangement, which was a 12 week season followed by a 2 week break. I think that this is a good idea that will give more time to work on other things outside of the events (such as promoting videos, building relationships, and applying for grants), reduce the workload from hosting/producing two events each week, and help focus on quality over quantity to provide better experiences at each event.

We’ll have our 7th event of the season on this Thursday, so if we do a 10 week season with a 3 week break then that would mean that the last event of this season would be on July 11th and we would return for Season 4 on August 8th. If we do a 12 week season with a 2 week break like last time, then we’d end the season on July 25th and return on August 15th. It’s also worth noting that the Optimism Foundation seems to have pushed back Retro Funding Round 6 (which is focused on Governance) so applications will open in September instead of August. I think that the 10 week schedule with 3 week break could position us better for the upcoming RetroFunding round and be a better way grow going forward in the upcoming seasons.

I’m curious what you think about this generally and how it might synergize with your plans to test the fractal app software this season. I remember that you wrote a plan about how we can test the software that you’re building around weeks 7-12 of Season 3, but if we decided to do a shorter season then there would only be four more events of this season (including this week). I’m wondering if shortening the season would cause any issues for your timeline and if making this change to length of this season would make a big difference for the development/testing of this software.

I’m not sure how much testing is sufficient and would appreciate your guidance before proposing it. Are there risks involved with testing the software at less events before season 4? If so, what are they? I’m also open to other suggestions as well if you think a different season schedule might work better.

Should/can we fully deploy it for Eden Fractal immediately when it’s available (while Optimism Fractal tests it for 6 weeks alongside the current app)?

On another note, I’m also planning to propose that Eden Fractal switches to biweekly events instead of a weekly events for the near future. This would further reduce the workload and provide more time for other kinds of work. I’m considering to propose a three week break for Eden Fractal on the same schedule as Optimism Fractal, though I’m open to feedback or other suggestions with all of this.

I’d like for Eden Fractal to start playing Respect Games on Base with the software in the near future and am wondering when you think it makes sense to deploy it for Eden Fractal. I think that using the software will be much better than not using any software like we’re doing now and it could provide big opportunities for Eden Fractal, so I think it’s probably best to start using it immediately once it is ready. Perhaps testing the software at Eden Fractal in the coming weeks could help further test the software in addition to testing it at Optimism Fractal. Do you have any thoughts about when is best to test the software at Eden Fractal?