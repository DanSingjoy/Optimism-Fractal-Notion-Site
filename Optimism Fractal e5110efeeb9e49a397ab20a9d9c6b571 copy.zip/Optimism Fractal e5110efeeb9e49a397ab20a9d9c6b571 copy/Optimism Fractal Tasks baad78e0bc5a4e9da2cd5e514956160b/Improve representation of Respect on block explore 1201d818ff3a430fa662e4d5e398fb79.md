# Improve representation of Respect on block explorers

Project: Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md), Build app component to make it easy for participants to give personal respect at the end of each game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20app%20component%20to%20make%20it%20easy%20for%20participan%204643870ba8fd464f98149a4f65684d0a.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: In progress
Summary: The document discusses the current issues with the representation of Respect on block explorers, specifically Etherscan and Blockscout. The main issue is the atypical implementation of the token contract, which tries to implement both ERC-721 and ERC-20 standards. The proposed solution is to emit both ERC-721 and ERC-20 events using assembly. The solution has been tested on Optimism Sepolia and Optimism Goerli, with Etherscan displaying the holders list and both events in Respect distribution transactions. However, Blockscout still recognizes ERC-20 transfer events as ERC-721 events. The document also suggests considering the possibility of migrating to the ERC-1155 standard to prevent future issues.
Created time: February 19, 2024 4:17 AM
Last edited time: April 23, 2024 3:04 PM
Created by: Tadas Vaitiekunas

## Current situation on mainnet

### Etherscan

- [ ]  Holders list does not display any holders;
- [ ]  Would be nice if in transaction which distributes Respect you could see how much Respect each participant received for that meeting (value of each NTT);

Both of these issues can be solved by ERC-20 event being emitted.

## Blockscout

Here holders list works.

- [ ]  Would be nice if in transaction which distributes Respect you could see how much Respect each participant received for that meeting (value of each NTT);

## Background

The underlying cause of these issues is atypical implementation of token contract. It tries to implement both ERC-721 and ERC-20 with the end result that   neither is implemented  fully, because these standards have overlapping methods. I present rationale for this below.

This is similar to how cash works. Every dollar bill is actually unique (non-fungible), yet we typically treat them as fungible. There’s nothing preventing us from treating them as non-fungible (taking into account the serial number for example). So you have one currency with two different ways of looking at it (like two interfaces).

I think it sometimes makes perfect sense to have a *single* token with both fungible and non-fungible token interfaces. Respect token is one such example. From non-fungible interface you get information about who attended what meeting (proof-of-attendance), and how much Respect they earned in that meeting (could record more things in the future). From fungible interface you can get a total amount of Respect over series of meetings. So each Respect NTT has a value field. To get someone’s fungible balance you sum values of all NTTs they earned.

It still might have been a better decision to use ERC-1155 standard and to implement these parts as separate tokens (or to implement these interfaces as separate tokens). But at the time when creating Respect contract it seemed to me that ERC-1155 (or at least its OpenZeppelin implementation) was an inefficient way of implementing what I described above. Now I’m reconsidering that in light of the issues with block explorers.

Current Respect interface: [https://github.com/Optimystics/op-fractal-sc/blob/main/contracts/IRespect.sol](https://github.com/Optimystics/op-fractal-sc/blob/main/contracts/IRespect.sol)

## Solution 1

The main issue here is that only ERC721 transfer event is emitted and not ERC20 one. Etherscan detects holders from ERC20 transfer events.

These two events have exactly the same signatures, and differ only in that last argument in ERC20 version specifies amount and in ERC721 token id. So I did not see a way to emit both of these events in solidity, when creating the first version of a contract.

Now I found a way to do that using assembly: [https://github.com/Optimystics/op-fractal-sc/commit/a4296ecdff14fbf8b80d2fbfc356556cb475892a](https://github.com/Optimystics/op-fractal-sc/commit/a4296ecdff14fbf8b80d2fbfc356556cb475892a)

Deployed and tested this on Optimism Sepolia and Optimism Goerli. Results:

- On Etherscan:
    - Holders list now works but as was to be expected, only holders for which the transfer event was emitted are displayed (so accounts which received Respect before contract upgrade are not displayed).
    - In Respect distribution transaction you can now see both ERC-721 and ERC-20 events (which is nice because people can see who earned how much in the meeting): [https://sepolia-optimism.etherscan.io/tx/0xef89e0f54c9c11edf3fc1f9d748370116f6a743a79488019722f46e87808d5b4](https://sepolia-optimism.etherscan.io/tx/0xef89e0f54c9c11edf3fc1f9d748370116f6a743a79488019722f46e87808d5b4)
- On Blockscout
    - Blockscout does not recognize ERC-20 transfer events as ERC-20 transfer events and thinks it’s another ERC-721 event: [https://optimism-sepolia.blockscout.com/tx/0xef89e0f54c9c11edf3fc1f9d748370116f6a743a79488019722f46e87808d5b4](https://optimism-sepolia.blockscout.com/tx/0xef89e0f54c9c11edf3fc1f9d748370116f6a743a79488019722f46e87808d5b4)

So remaining issues:

- [ ]  Make etherscan discover holders which earned Respect before the upgrade
- [ ]  Blockscout does not recognize ERC-20 transfer events as ERC-20 transfer events and thinks it’s another ERC-721 event: [https://optimism-sepolia.blockscout.com/tx/0xef89e0f54c9c11edf3fc1f9d748370116f6a743a79488019722f46e87808d5b4](https://optimism-sepolia.blockscout.com/tx/0xef89e0f54c9c11edf3fc1f9d748370116f6a743a79488019722f46e87808d5b4)

# Alternative

- [ ]  Consider possibility of migrating to ERC-1155 standard. Might be the safest path to prevent future issues we haven’t discovered yet;

[https://www.notion.so/edencreators/Improve-representation-of-Respect-on-block-explorers-1201d818ff3a430fa662e4d5e398fb79?pvs=4](Improve%20representation%20of%20Respect%20on%20block%20explore%201201d818ff3a430fa662e4d5e398fb79.md)

## Related

[Consider migrating to ERC-1155](Consider%20migrating%20to%20ERC-1155%20f447d18a99be4f2abc9fa710c29f6602.md)