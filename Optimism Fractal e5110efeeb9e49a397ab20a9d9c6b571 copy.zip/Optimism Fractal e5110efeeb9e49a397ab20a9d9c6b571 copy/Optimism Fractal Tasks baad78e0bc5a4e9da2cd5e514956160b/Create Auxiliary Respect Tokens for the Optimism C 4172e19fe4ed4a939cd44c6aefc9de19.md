# Create Auxiliary Respect Tokens for the Optimism Collective

Project: Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Create RetroPGF UI to sort applicants by Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20RetroPGF%20UI%20to%20sort%20applicants%20by%20Respect%2064ea936bf8714afbb84382bafe857662.md), Integrate Optimism Fractal and the Respect Game with RetroFunding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md), Improve Processes for Impact Measurement and Evaluation in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Processes%20for%20Impact%20Measurement%20and%20Evalu%20538192791aa94cf4ac328c1571d17f40.md), Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Create Auxiliary Respect Tokens for Optimism Collective (ie OPC) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Auxiliary%20Respect%20Tokens%20for%20Optimism%20Colle%20b78abde1bff54c499c648628e459c689.md)
Status: Not started
Task Summary: This task aims to create auxiliary respect tokens for the Optimism Collective and explore ideas for many other kinds of tokens. The task involves creating multiple types of respect, such as OPF, OPC, OPC3, and OPC Respect Allocation, and considering the allocation of respect to badgeholders, RetroPGF recipients, delegates, and other members of the Optimism Collective. Various resources and strategies are discussed to enable OPC voting and promote the announcement of OPC respect.
Summary: This task aims to create auxiliary respect tokens for the Optimism Collective, including OPF, OPC, OPC3, and OPC Respect Allocation. The tokens will be used for voting and to recognize the contributions of badgeholders, RetroPGF recipients, delegates, and other members. Various resources and strategies are discussed, including Respect Trees and Cignals. The allocation of respect to different stakeholders is also explored.
Created time: April 24, 2024 3:43 AM
Last edited time: May 21, 2024 3:57 PM
Sub-tasks: Create OPC Respect Token for Optimism Collective (Create%20OPC%20Respect%20Token%20for%20Optimism%20Collective%20676e1495963d4174895d3812adc1955a.md)
Created by: Dan Singjoy

## Description

This task aims to create auxiliary respect tokens for the Optimism Collective and explore ideas for many other kinds of tokens. The task involves creating multiple types of respect, such as OPF, OPC, OPC3, and OPC Respect Allocation, and considering the allocation of respect to badgeholders, RetroPGF recipients, delegates, and other members of the Optimism Collective. Various resources and strategies are discussed to enable OPC voting and promote the announcement of OPC respect.

## Benefits

We’re exploring ideas of issuing new forms of Respect to recognize the work of all kinds of leaders in the Optimism Collective, such as an [OPC token](Create%20OPC%20Respect%20Token%20for%20Optimism%20Collective%20676e1495963d4174895d3812adc1955a.md) that enables various stakeholders in the Optimism Collective to vote using [methods](Review%20Methods%20for%20Voting%20with%20Respect%20in%20Notion%20a%20b037b35cca164e52898682c5957aa1a2.md) and tooling like [Respect Trees](https://optimystics.io/respect-trees) or consensus games like [Cignals](https://optimystics.io/cignals) that are being pioneered at Optimism Fractal. The OPC token could also be used at events like the [Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md) to help facilitate structured, Respectful discussions with [Cagendas](Design%20Cagendas%20for%20Optimism%20Fractal%20and%20Optimism%20%2064e8dcfb50bb48c2a8d38e9a09560fe4.md). 

## To Do

- [ ]  Create multiple different types of Respect with the Optimism Fractal Council
    - See [Create Auxiliary Respect Tokens for the Optimism Collective](Create%20Auxiliary%20Respect%20Tokens%20for%20the%20Optimism%20C%204172e19fe4ed4a939cd44c6aefc9de19.md)
    - OPF: Current implementation of Respect earned at Optimism Fractal
    - OPF3: Respect earned at Optimism Fractal in Season 3
    - OPC: A distribution of Respect which Respects badgeholders, RetroPGF recipients, delegates, Optimism Fractal participants, and other members of the Optimism Collective
        - Consider also including:
            - Badgeholders and RetroPGF participants from Lindsay’s List
            - By integrating this with the [GovScore](https://twitter.com/limes_eth/status/1772326422972899764), we will swiftly gain a deeper insight into the identities of the citizens and their areas of expertise. However, please ensure that this does not result in additional power being granted to The Foundation.
            - Gitcoin Passport and [Steward list](https://gov.gitcoin.co/t/introducing-steward-health-cards-2-0/10418)
            - Galxe and Worldcoin ID solutions
            - [ ]  Create a project to Create Optimism Fractal Respect for the Collective, Create Optimism Fractal ID System, or Create Optimism Fractal Auxiliary Respect Tokens or something like that
    - OPC3: A distribution of Respect which Respects badgeholders, RetroPGF recipients, Optimism Fractal participants, and other members of the Optimism Collective with a focus on this season?
    

## Respecting Optimism Collective Members

- Should we give Respect to badgeholders and people who earned from RetroPGF or some other token for voting power?
    - I think it’s worth considering giving them Respect and not just some other voting token.
    - It makes sense for Optimism Fractal to respect the contributions to the Optimism Collective even if they haven’t joined the event and this may help to align the collective more around Optimism Fractal
        - On the other hand, this is a design decision that would require thought and may not be an easy task to do it in a fair way, and perhaps keeping it simpler by just awarding people who join events could be best for now
            - Another option is to give a small amount of Respect to others in the Collective, but give a much larger amount of Respect to people who join Optimism Fractal events. This might be a way to ease into this kind of larger Respect distribution and test the waters without giving too much Respect, then we can always give more if it’s helpful.
                - For example, Optimism Fractal could give a beautiful NTT with 5 Respect to all badgeholders
                - Eventually we could also potentially give Respect to others like Gitcoin participants, people who use Worldcoin, Vitalik, etc
    - I can see related ideas in Bear about giving Eden Respect to Eden on EOS and other communities

## OPC Respect Allocation

- We can use the following lists to easily allocate OPC to Badgeholders, Delegates, and RetroPGF recipients

![Untitled](Create%20Auxiliary%20Respect%20Tokens%20for%20the%20Optimism%20C%204172e19fe4ed4a939cd44c6aefc9de19/Untitled.png)

### CVS File of Badgeholders and RetroPGF 3 Projects

[list of addresses](https://optimism.easscan.org/address/0x621477dBA416E12df7FF0d48E14c4D20DC85D7D9)

### CSV of Delegates

[https://drive.google.com/file/d/19BL_9MEFt_jHqARzA9jE4RfZ16No-Zl8/view?usp=sharing](https://drive.google.com/file/d/19BL_9MEFt_jHqARzA9jE4RfZ16No-Zl8/view?usp=sharing)

### Additional Resources

[Apollo Server](https://optimism.easscan.org/graphql)

[Loom Video](https://www.loom.com/share/331ad74482d14d11afaef41b951a0a49?sid=6524ae2f-35e6-4bbb-b086-271bd194c084)

- OPC: A distribution of Respect which Respects badgeholders, RetroPGF recipients, delegates, Optimism Fractal participants, and other members of the Optimism Collective
    - Consider also including:
        - Badgeholders and RetroPGF participants from Lindsay’s List
        - By integrating this with the [GovScore](https://twitter.com/limes_eth/status/1772326422972899764), we will swiftly gain a deeper insight into the identities of the citizens and their areas of expertise. However, please ensure that this does not result in additional power being granted to The Foundation.
        - Gitcoin Passport and [Steward list](https://gov.gitcoin.co/t/introducing-steward-health-cards-2-0/10418)
        - Galxe and Worldcoin ID solutions
        - [ ]  Create a project to Create Optimism Fractal Respect for the Collective, Create Optimism Fractal ID System, or Create Optimism Fractal Auxiliary Respect Tokens or something like that
- OPC3: A distribution of Respect which Respects badgeholders, RetroPGF recipients, Optimism Fractal participants, and other members of the Optimism Collective with a focus on this season?

![Untitled](Create%20Auxiliary%20Respect%20Tokens%20for%20the%20Optimism%20C%204172e19fe4ed4a939cd44c6aefc9de19/Untitled%201.png)

## Enabling OPC Voting in Snapshot Subspaces and Notion Databases

It would be great to augment the ability to vote with different kinds of Respect in Notion or Snapshot. We could potentially integrate these different kinds of Respect votes into different snapshot subspaces and notion properties, which would allow people to easily sort and filter databases according to their preferences, a higher resolution of consensus, and provide useful information for data scientists. 

See [Review Methods for Voting with Respect in Notion and Snapshot via the Notion API](Review%20Methods%20for%20Voting%20with%20Respect%20in%20Notion%20a%20b037b35cca164e52898682c5957aa1a2.md) for more details

### Add ideas about voting with multiple tokens at once in snapshot

- [ ]  See [Review, transcribe, format, summarize and parse do to’s from this audio about Optimism Fractal Season 3, Optimism Town Hall, Cagendas and promotional strategies](Review,%20transcribe,%20format,%20summarize%20and%20parse%20do%20220eb7b187114e1793e2d0a0511613b5.md) and sync the relevant ideas here

## Research GovScore

[GovScore Updates (Hedgey RPGF Re-Grant Winner) - 📢 Updates and Announcements - Optimism Collective](Create%20Auxiliary%20Respect%20Tokens%20for%20the%20Optimism%20C%204172e19fe4ed4a939cd44c6aefc9de19/GovScore%20Updates%20(Hedgey%20RPGF%20Re-Grant%20Winner)%20-%20%F0%9F%93%A2%20ee926c73a1214251a425c355654fe066.md)

## Create Promotional Strategy for Announcing OPC Respect

- We could announce OPC in Citizens’ House Governance topics - Optimism Collective gov forum
    
    ![391d6e71a279a9f881f75bfa7df5cdf3cf905b3f.png](Create%20Auxiliary%20Respect%20Tokens%20for%20the%20Optimism%20C%204172e19fe4ed4a939cd44c6aefc9de19/391d6e71a279a9f881f75bfa7df5cdf3cf905b3f.png)
    
    Welcome to the Optimism Collective! You can learn more about the Collective’s Vision and Governance Processes [here](https://gov.optimism.io/t/welcome-to-the-optimism-collective-discourse/7).
    
    We are currently in Season 5. You can read our Guide to Season 5 [here](https://gov.optimism.io/t/guide-to-season-5/6894). See [Get a Grant](https://community.optimism.io/docs/governance/get-a-grant/) to learn more about applying for a Collective Grant.
    

[](https://gov.optimism.io/c/citizens-house-gov/79)

- [ ]  See [Plan to Announce and Promote the Optimism Town Hall](Plan%20to%20Announce%20and%20Promote%20the%20Optimism%20Town%20Hal%206fc653df900b4f19b63432f3686253d8.md) and consider syncing syncing they’re likely to have a similar promotional strategy