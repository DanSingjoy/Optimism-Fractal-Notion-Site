# Post topic proposal for Fractal Forums at Eden Fractal during event 99

Assignee: Dan Singjoy
Due: May 20, 2024
Project: Prepare for OF 27 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2027%20a3a902d398094d0b826538ac88183391.md), Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md)
Status: Done
Task Summary: This task aims to create a 2-4 sentence summary/introduction for the page titled "Post topic proposal for Fractal Forums at Eden Fractal during event 99." The summary will provide an overview of the post and its purpose.
Summary: This document is a post topic proposal for Fractal Forums at Eden Fractal during event 99. Fractal Forums is a collaborative conversation process aimed at enriching discussions at Eden Fractal. The proposal outlines the game rules and dynamics of Fractal Forums, including suggesting and voting on topics, and transitioning to different topics. The document also mentions the development of Fractal Forums, its historical context, and the introduction of OPTOPICS, another conversational process. Overall, Fractal Forums aims to optimize meeting time, encourage dynamic participation, and empower the community in decision-making.
Created time: May 18, 2024 10:14 PM
Last edited time: May 23, 2024 12:35 PM
Created by: Dan Singjoy

## Post on EF Telegram

Hello everyone, hope you’re having an awesome week and are excited for today’s event!

Here is a topic proposal to experiment with a deliberative discussion process called Fractal Forums:

![fractalforumsatef.png](Post%20topic%20proposal%20for%20Fractal%20Forums%20at%20Eden%20Fra%20942513e62c734403a93e900bc0fc6cc1/fractalforumsatef.png)

Fractal Forums is a type of event based around collaborative conversation processes to enrich our discussions at Eden Fractal. Fractal Forums can feature new kind of Cagendas games that allows community members to suggest, upvote, and coordinate discussion topics then form consensus on key issues during our events.

There are many ways to experiment with Fractal Forums and I just made a topic proposal to try a very simple version today, so anyone who has earned Respect can now upvote it as per the rules of [Cagendas](https://edenfractal.com/welcome#d2d4bf862c55481492e6073d6328befc) at Eden Fractal. If this topic proposal is approved, we’ll experiment with Fractal Forums in the following way during today’s event:

**Game Rules**

1. Anyone can propose a topic writing a message here in telegram or using the Q&A panel in Slido. Everyone will be able to easily suggest and upvote topics directly in Zoom without needing to go to any other website (thanks to Slido’s smooth new integration with Zoom). 

1. Fractal Forums begins at 17:00 UTC at today’s Eden Fractal event. After a brief introductory presentation and a few moments for everyone to upvote topics, we’ll discuss the topic that receives with most upvotes first.

1. Anyone can propose to move to the next topics with the second most upvotes by typing ‘next topic’ in the zoom chat or Eden Fractal telegram chat, which triggers a one-minute countdown. 

1. Any other participant can veto this by typing ‘same topic’ within the minute. If vetoed, neither the proposer nor the vetoer can make the same motion for the current topic. If there’s no veto, the discussion moves to the next most upvoted topic.

1. If over half of experienced community members who have joined 3 fractal events agree, then we can move to a new topic immediately. Approval may be indicated by a thumbs-up in the chat or on the video call.

**More Details**

We’re also planning to try a similar conversational process featuring a new Cagendas game called [OPTOPICS](https://optimystics.io/optopics) at the second [Optimism Town Hall](https://optimystics.io/optimismtownhall), which is happening tomorrow. OPTOPICS leverages Respect earned at Optimism Fractal enable a more meritocratic topic selection processes, whereas today’s Fractal Forums event uses Slido which doesn’t yet work with Respect but has some other neat features built in. I’d like to enable Respect in Fractal forums in the coming weeks and you can find more details about this in Rosmari’s post above.

You may also be interested to know that Fractal Forums has been in development since 2021. In April of 2022, I published this [article](https://edencreators.com/fractalforums) with details about Fractal Forums that curates many early discussions and thoughts from community members about this concept. The article also includes the draft of a proposal to start a more complex version of weekly Fractal Forums event, which I published at the same time as the [original proposal](https://edencreators.com/originalproposal) to start Eden Fractal. After much discussion with others involved with starting Eden Fractal, we decided to put the idea for Fractal Forums on pause and focus exclusively on Eden Fractal. 

The topic proposal for today’s event has many differences from the original conception of Fractal Forums, but there are many similarities and the is an exciting design space of developments that we can explore in future weeks. I’ve been dreaming of bringing Fractal Forums to life since then and looking forward to try it with you all!

![Untitled](Post%20topic%20proposal%20for%20Fractal%20Forums%20at%20Eden%20Fra%20942513e62c734403a93e900bc0fc6cc1/Untitled.png)

Feel free to share any topic suggestions here before the event starts in a half hour. All topics suggested here will be added to Slido so we can upvote them throughout the event. I’ll start it off with a few topics that I’m interested in discussing:

- Fractal Forums and Optimism Town Hall
- Eden Fractal’s 2nd Anniversary
- Product Packaging
- Engaging with [Base](https://www.base.org/)

## Prepare Topic Proposals

[Prepare for Eden Fractal Second Anniversary](https://www.notion.so/Prepare-for-Eden-Fractal-Second-Anniversary-f7f009c068c64eddb0d5beac1a453977?pvs=21) 

[Product Packaging Discussions](https://www.notion.so/Product-Packaging-Discussions-fcab6e8e328b427282038b6acbd49fc2?pvs=21) 

[Build with Base](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md) 

[Engage in Optimism Collective Season 6](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md) 

---

---

---

## **Introducing Fractal Forums**

- [x]  ask ai for good names to describe this game- give the following script and ask it to describe a better name
    - this is different from optopics as its rank order, whereas optopics uses quadratic voting

- [ ]  ask ai to replace Topic Ranks with Fractal forums below
- [x]  consider how this should align with Ingenious topics
    - i think ingenious topics is good as thumbnail title and fractal forums is good as youtube title and proposal title

This collaborative agenda process is designed to optimize our meeting time by providing a simple structure that facilitates more interactive conversations and helps us focus on what’s most important to the community. Fractal Forums leverages the Slido voting app to grow Eden Fractal with the diverse perspectives of participants at our events and implement fractal decision-making processes throughout society.

## **Game Rules**

Fractal Forums begins at 17:00 UTC at the Eden Fractal event. The main dynamics of Fractal Forums are oriented around suggesting topics, allocating votes on topics, and transitioning to different topics. 

### Suggesting and Voting on Topics

Fractal Forums allow participants to easily suggest then rank order discussion topics at any time according to their preference.

- **Suggest topics:** Starting at 17 UTC on Monday, respected community members can suggest discussion topics in the telegram group for Eden Fractal. The topic can be very simple, like a quick question or just a few words. The topic could also be more complex with detailed information and links. Feel free to suggest any topic related to fractal decision-making processes and consensus games.

- **Vote on Topics:** A poll will be created in the Eden Fractal slido snapshot space on Wednesday and all topics that were suggested in the Discord channel by 15 UTC on Wednesday will be included as options. You can allocate your Respect votes across as many topics as you’d like to influence the community’s agenda and the votes are weighted quadratically. Participants can change their votes at any point before or during the Eden Fractal event to reflect their current interests.

### Moving to the Next Discussion Topic

During the event, respected participants can adjust their topic preferences in real-time to influence the discussion 

The game begins at 16:00 UTC at the Eden Fractal event. Participants can adjust their topic preferences in real-time by voting in the Slido Q & A section as the game progresses and move the group to the next topic with an optimistic topic transition system.

- **Topic Transition Rules:**
    1. **Initiate Change:** Any experienced community member who has joined at least 5 fractal events can propose to switch topics by typing ‘next topic’ in the chat, triggering a one-minute countdown.
    2. **Veto Option:** Any similarly experienced member can veto this by typing ‘same topic’ within the minute. If vetoed, neither the proposer nor the vetoer can make the same motion for the current topic.
    3. **Consensus Transition:** If there’s no veto, the discussion moves to the next highest-ranked topic on Snapshot.
    
- **Proposing New Topics:** If at least 51% of experienced community members agree, a new topic can be introduced immediately. Approval can be indicated by three thumbs-up from respected members in the chat.

## Historical Context

The idea for Fractal Forums was conceived in 2021 and a significant amount of work was 

## OPTOPICS

article about [Cagendas](https://optimystics.io/cagendas)

   Over two years ago

## **Benefits of Optopics**

- **Dynamic Participation:** Optopics empowers participants to propose and reorder discussion topics dynamically through a ranked choice voting system. This flexibility ensures that our meetings adapt to the most pressing and relevant issues as they evolve, enabling us to focus on what truly matters to the community.

- **Enhanced Meeting Efficiency:** By allowing community members to dynamically propose and prioritize topics, Optopics helps ensure that our meeting time is optimized. This setup helps in covering multiple topics effectively, ensuring that every meeting is as productive as possible.

- **Empowered Community Control:** Through this game, respected community members can guide the flow of conversations, ensuring that discussions remain focused and aligned with the community’s interests. This control mechanism ensures that our meetings are not just discussions, but fruitful exchanges that can lead to actionable insights and decisions.

- **Technologically Inspired:** Drawing inspiration from the optimistic rollup technology used in the Optimism Superchain, Optopics incorporates a similar mechanism for swift and efficient topic transitions. Well-respected community members can propose to move to the next topic, which can be vetoed by others, promoting a fast-paced, engaging, and democratic discussion environment.

Fractal Forums is designed to be a trailblazer in how we conduct meetings, ensuring that every participant can have their voice heard in a structured yet flexible manner. This game is about more than just optimizing time; it’s about maximizing our collective impact. If successful, it may provide a huge boost for the Eden Fractal community and pave the path for many other communities and organizations to also organize speaking time with Respect and Cagendas. Join us as we pilot Fractal Forums at the next Eden Fractal, and let’s experience firsthand the power of structured, democratic, and dynamic discussions.

## **Participation and Feedback**

If you support this initiative, please upvote this [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff) on Snapshot. Feel free to share any questions or comments, I’m eager to hear your thoughts and suggestions as we develop this game. Your participation and feedback is much appreciated. Fractal Forums is designed to make our meetings not just more efficient but also more enjoyable and productive. We look forward to exploring this new format with you and believe it will significantly improve our ability to make decisions that are fair, fast, and fun. Join us to experience the future of community engagement at Eden Fractal!