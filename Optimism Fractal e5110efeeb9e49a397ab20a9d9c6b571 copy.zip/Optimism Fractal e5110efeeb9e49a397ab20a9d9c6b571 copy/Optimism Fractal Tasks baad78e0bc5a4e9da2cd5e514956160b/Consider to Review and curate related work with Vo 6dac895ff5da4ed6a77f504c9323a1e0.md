# Consider to Review and curate related work with Voice

Project: Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md)
Status: Not started
Task Summary: This task aims to review and curate related work with Voice. It is created by Dan Singjoy and is currently in the "Not started" status. The goal is to gather articles and posts that discuss early ideas about http://voice.com/, although their priority is uncertain.
Summary: Consider reviewing and curating related work with http://voice.com/, as there are early ideas and articles that may be helpful to add, although it may not be a priority.
Created time: July 5, 2024 2:02 PM
Last edited time: July 5, 2024 2:30 PM
Parent task: Review and curate historical research and experiments with fractal social media (Review%20and%20curate%20historical%20research%20and%20experime%20ea73c13b0b63432d845e9f534e611504.md)
Created by: Dan Singjoy
Description: Consider reviewing and curating related work with http://voice.com/, including early ideas from articles and posts, though it may not be a priority.

There were many articles and posts with early ideas about [Voice.com](http://Voice.com) that may be helpful to add here, though it may not be a priority- not sure