# Welcome and Respond in Hats Protocol and Optimism Fractal group

Status: Not started
Summary: This document discusses the collaboration and synergies between Hats Protocol and Optimism Fractal. The author expresses gratitude for joining the group and discusses the potential of integrating Hats Protocol into Optimism Fractal. They mention organizing an introduction to Optimism Fractal for the Hats community and exploring mutual benefits through collaboration. The author invites questions and offers assistance, and shares information about upcoming events and resources.
Parent-task: Respond in group chat for Hats Protocol + Optimism Fractal (Respond%20in%20group%20chat%20for%20Hats%20Protocol%20+%20Optimism%20c87b847414704e5e927c9640f938ae85.md)
Created time: March 19, 2024 11:47 AM
Last edited time: March 19, 2024 11:49 AM
Parent task: Respond in group chat for Hats Protocol + Optimism Fractal (Respond%20in%20group%20chat%20for%20Hats%20Protocol%20+%20Optimism%20c87b847414704e5e927c9640f938ae85.md)
Created by: Dan Singjoy

## Description

![Untitled](Welcome%20and%20Respond%20in%20Hats%20Protocol%20and%20Optimism%20%200aec9ce1b310439baae220591c2f3699/Untitled.png)

Hey everyone! Welcome and thanks for joining the group! 🤠🌻

![Untitled](Welcome%20and%20Respond%20in%20Hats%20Protocol%20and%20Optimism%20%200aec9ce1b310439baae220591c2f3699/Untitled%201.png)

Wow that sounds amazing, thank you Spencer! 🙌🏽

I really appreciate you taking the time to check out the FractalRespect contract and put together the solidity code for the module. We’ve been aiming to create a kind of configurable, flexible, and granular permission system using Respect earned in recent events for a long time and the Respect eligibility module you described sounds like it could work perfectly. 

It also seems like Hats Protocol could make this much more powerful than I previously imagined… I’m curious what you think should be the next steps and excited to try it out!

![Untitled](Welcome%20and%20Respond%20in%20Hats%20Protocol%20and%20Optimism%20%200aec9ce1b310439baae220591c2f3699/Untitled%202.png)

Thank you Hodlon, I really appreciate how you’ve been helping so far and love what’s going on here too!

Thanks again so much to everyone on the Hats Protocol team for hosting the event at ETH Denver, it was such a pleasure meeting everyone and an awesome experience!

I see many opportunities for collaborations between Hats Protocol and Optimism Fractal and am excited for all that we can do together. To help get this started I’m working on organizing an intro to Optimism Fractal for the Hats community, a project about integrating Hats Protocol into Optimism Fractal, and an overview of some mutual benefits that we can gain by collaborating. I’ll share these here as soon as possible.

Please feel free to let me know if you have any questions about Optimism Fractal or if there’s anything I can do to help. I’m stoked to collaborate with Hats and curious to hear what everyone thinks :)

Of course everyone is also welcome to join Optimism Fractal weekly [events](https://lu.ma/optimismfractal) on Thursdays, where you can earn Respect for contributions to Hats Protocol. The next event is on March 21st at 17 UTC, which I think is right after the Hats Protocol Town Hall

- 
    
    
     exploring collaborations and synergies between Hats Protocol and Optimism Fractal
    
    Feel free to share any questions about Optimism Fractal or Hats Protocol here and let me know if there’s anything I can do to help.
    
    If anyone any the Hats Protocol team has any questions about Optimism Fractal then feel free to let me know. Please feel free to share any thoughts here 
    
    I put together a bunch of resources to introduce the Hats Protocol community to Optimism Fractal on this page.
    
    I shared a bunch of introductory resources with Spencer and would be happy to share links or provide more information if it’d be helpful for you
    
    I’d also be happy to share any of the links to our software or any other resources that would be helpful if Spencer hasn’t shared them with you already. 
    
    I’ll forward this to Tadas as well since we started 
    
    flexible and granular eligibility mdoule 
    
     I also shared several links with Spencer and