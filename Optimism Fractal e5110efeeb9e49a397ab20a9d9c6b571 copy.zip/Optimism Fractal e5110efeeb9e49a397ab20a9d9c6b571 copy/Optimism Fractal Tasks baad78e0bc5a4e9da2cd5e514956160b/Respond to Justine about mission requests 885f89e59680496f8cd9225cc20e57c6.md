# Respond to Justine about mission requests

Assignee: Dan Singjoy
Due: June 10, 2024
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md), Explore Mission Opportunities in Optimism Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md)
Status: Done
Task Summary: This task aims to respond to Justine's mission requests. It provides an overview and status update on the mission requests, along with relevant details such as the creator, assignee, due date, and timestamps of creation and last edit.
Summary: No content
Created time: June 27, 2024 11:55 AM
Last edited time: June 28, 2024 9:55 AM
Created by: Dan Singjoy

![Untitled](Respond%20to%20Justine%20about%20mission%20requests%20885f89e59680496f8cd9225cc20e57c6/Untitled.png)