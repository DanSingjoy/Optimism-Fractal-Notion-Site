# Send Message to Snapshot Discord to ask about desired features

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to send a message to the Snapshot Discord to inquire about desired features. The page includes a list of questions regarding functionality and potential improvements, such as automatically posting Snapshot polls on Discord and Telegram, viewing the distribution of votes at a specific time, implementing weighted voting across polls, and limiting the number of votes for each participant within a given time period. The author seeks assistance and advice to enhance the community's experience with Snapshot.
Summary: The author is seeking help with several questions and desired features for Snapshot. They are interested in automatically posting Snapshot polls on Discord and Telegram, seeing the distribution of votes at a certain time without ending the poll, weighted voting across polls in a subspace, and limiting the amount of votes for each participant during a given time period. They also mention saving additional questions for future messages.
Created time: May 31, 2024 5:16 PM
Last edited time: July 16, 2024 9:41 AM
Created by: Dan Singjoy
Description: The author is seeking help with several questions regarding desired features in Snapshot. These include automatically posting polls on Discord and Telegram, seeing the distribution of votes at a certain time without ending the poll, weighted voting across polls, and limiting the amount of votes for each participant within a given time period. The author is open to providing more details and sharing links for further information.

Hi, I'm using Snapshot often to facilitate collective decision-making and choose discussion topics at community events. I love the product and would appreciate some help with a few questions. Can anyone please answer these:

1. Is there any way to automatically post Snapshot polls onto Discord and/or Telegram so everyone can easily see new proposals?
    1. Is there any way to create notifications for Snapshot polls in a more decentralized, resilient, and open-source manner than relying on Discord or Telegram (such as using messages to wallets via a protocol like [XMTP.org](http://xmtp.org/) or an app like interface.app)?
    
2. Is there any way to see the distribution of votes at a certain time without having the poll end at that time? I imagine that the onchain version of Snapshot X at Snapshot.xyz might be able to help with this, though I see it's in beta and haven't tried it yet. I've done some research into how protocols like The Graph, data availability solutions, or other history solutions might help with this and would appreciate advice about the best way to make it easy for community members to see the distribution of votes at a certain time (without needing to end the poll at this time).

3. Weighted voting across polls in a subspace: Is there any way to allow people to vote with only a portion of their voting weight on a particular poll? I've used the Weighted Voting and Quadratic Weighted Voting strategies and these are excellent for many use cases, but there are also some use cases where I'd like to allow community members to upvote discussion topics with a percentage of their voting power where each discussion topic is represented by a unique poll.

4. Is there any way to limit the amount of votes for each participant during a given time period in a Snapshot Space? For example, if someone has 1000 voting tokens then it would be great to only allow them to to vote with those 1000 tokens once per week. This could be combined with the use case described above to alllow a limited amount of upvotes that can be spread across discussion topics each week.

I’d be happy to provide more details or share links where you can learn more about these desired features and use cases if you’d like. Thanks!

## Save for next messages

1. Can the Snapshot API enable polls to be automatically created based upon an input from another application?

1. Is there any way to allow poll options to be edited after the poll has started? Or is there any way to allow community members to add their own options to polls?

1. Why are subspaces not working? 
    - [ ]  First test this and see if i can get it to work
    
2. Is there a way to use a different ranked choice voting algorithm where each successive higher rank receives 60% more percentage than the lower rank?

- [ ]  [Review Methods for Voting with Respect in Notion and Snapshot via the Notion API](Review%20Methods%20for%20Voting%20with%20Respect%20in%20Notion%20a%20b037b35cca164e52898682c5957aa1a2.md) and see if there are other questions i should ask now that a conversation is started