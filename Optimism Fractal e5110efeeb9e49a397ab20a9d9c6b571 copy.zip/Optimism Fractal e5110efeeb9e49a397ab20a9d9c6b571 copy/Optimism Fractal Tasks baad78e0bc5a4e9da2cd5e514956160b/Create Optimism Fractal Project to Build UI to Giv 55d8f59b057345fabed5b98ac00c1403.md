# Create Optimism Fractal Project to Build UI to Give Respect

Due: April 19, 2024
Project: Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: In progress
Summary: This project aims to build a UI for giving respect, with tasks including creating the project, inquiring about platforms for embedding ERC1155 NFT creation, customizing the widget, and reviewing the conversation about automating transactions and prefilling certain fields.
Parent-task: Organize Plans for Personal Respect, Distributing after Respect Games, Respect Networks, and Synergies with Optimism Fractal (Organize%20Plans%20for%20Personal%20Respect,%20Distributing%20%20404d4123e7974215968180a9f01a8945.md)
Sub-task: Organize these notes in EAS project and Review Ideas for Message to Vlad (Organize%20these%20notes%20in%20EAS%20project%20and%20Review%20Ide%208aee58d8c2b14145974a882e0bbd5ab9.md)
Created time: April 6, 2024 12:39 PM
Last edited time: April 24, 2024 3:40 AM
Sub-tasks: Organize these notes in EAS project and Review Ideas for Message to Vlad (Organize%20these%20notes%20in%20EAS%20project%20and%20Review%20Ide%208aee58d8c2b14145974a882e0bbd5ab9.md)
Parent task: Organize Plans for Personal Respect, Distributing after Respect Games, Respect Networks, and Synergies with Optimism Fractal (Organize%20Plans%20for%20Personal%20Respect,%20Distributing%20%20404d4123e7974215968180a9f01a8945.md)
Created by: Dan Singjoy

## Description

- [ ]  Create project for build ui to give respect .
- [ ]  Ask chatgpt if [manifold.xyz](http://manifold.xyz) or some other platform offers widget or code that makes it easy to embed erc1155 nft creation in your website or app.
- [ ]  Also ask if it can be customized in a specific way, ie giving the option to customize the picture and text but prefilling the amount of nfts created to 55 34 etc and making them soulbound but deletable.
- [ ]  Also review the convo with chatgpt about whether eas can do this sort of embedding or automating with our transactions with some fields of a certain schema prefilled (and not shown, abstracted from user) and some of the fields mutable from the user like if they want to tag the game or community or choose their own art (though the art should happen automatically depending on their selection of the picture so they won’t need to actually choose it)