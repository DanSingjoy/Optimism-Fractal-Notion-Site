# Review Checklist Before Event

Project: Prepare for OF 28 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2028%2055526595a95345fd888501f23774c254.md)
Status: Not started
Task Summary: This task aims to provide a review checklist to be completed before an event. The checklist, created by Dan Singjoy, includes important items to consider and review. It serves as a guide to ensure that all necessary preparations are made for a successful event.
Summary: No content
Created time: May 25, 2024 5:28 PM
Last edited time: May 25, 2024 5:28 PM
Created by: Dan Singjoy

- [ ]  Start zoom room at least 15 minutes earlier
    - [ ]  Do a sound check to ensure good audio output and input
    - [ ]  Turn off VPN to improve internet connection
    - [ ]  Test screenshare function in zoom
    - [ ]  Check activity monitor to make sure there is enough RAM and CPU
    - [ ]  Start a new meeting note and position the window for easy accessibility for notes during the meeting
    - [ ]  Set up welcoming music
    - [ ]  Set up welcoming video
    - [ ]  Send out promotional message
    - [ ]  Send out promotional message with Cagendas topic two days before event (this is probably better suited as a task in the project, whereas i think these other ones could just to do list blocks in the same page
        - [ ]  Consider the best way to organize this