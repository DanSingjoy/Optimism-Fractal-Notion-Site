# Create OptimismFractal.com/season1 , season2, season3, etc

Project: Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Increase Distribution for Optimism Fractal Videos and Promotions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Increase%20Distribution%20for%20Optimism%20Fractal%20Videos%20%2025e9f46903ab4652a3ef7613fec95999.md), Increase Distribution for Optimism Fractal Videos and Promotions (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Increase%20Distribution%20for%20Optimism%20Fractal%20Videos%20%200409af95af8d466aa7dd14bd8a3191dc.md)
Status: Not started
Task Summary: This task aims to establish the website http://optimismfractal.com/ with dedicated sections for each season, including season 1, season 2, season 3, and so on. By organizing the episodes in this manner, users will have an easier time navigating and accessing older content, enhancing the overall user experience.
Summary: The task involves creating sections for http://optimismfractal.com/ for seasons 1, 2, and 3, linking governance forum posts, and utilizing gallery database views to facilitate access to older episodes. The project is currently not started.
Created time: August 9, 2024 10:24 PM
Last edited time: August 9, 2024 10:31 PM
Created by: Dan Singjoy
Description: The task involves creating sections for http://optimismfractal.com/ for seasons 1, 2, and 3, linking governance forum posts, and utilizing gallery database views to facilitate easier access to older episodes.

- [ ]  link the governance forum posts

- This will be easy to do with gallery database views once we set this up
    - [Create Optimism Fractal Blog, Videos, and Media Pages/Database](Create%20Optimism%20Fractal%20Blog,%20Videos,%20and%20Media%20Pa%204a14d328758449458bfdb23f720247b0.md)
    - [Update OF, EF, and Optimystics Videos Pages to work with databases](https://www.notion.so/Update-OF-EF-and-Optimystics-Videos-Pages-to-work-with-databases-f3c8a33c27984d2d87e669e42e9b0a8b?pvs=21)

this will make it easier to find and view older episodes