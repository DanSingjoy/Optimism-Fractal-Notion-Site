# Research tool that protects your @CoinbaseDev Paymaster API from abuse by ensuring that only calls to an allowed list of contracts

Status: Not started
URL: https://twitter.com/LukeYoungblood/status/1796922481871339713
Task Summary: This task aims to introduce a research tool called "Paymaster API Protector" created by Dan Singjoy. The tool is designed to safeguard the @CoinbaseDev Paymaster API from abuse by allowing only calls to a pre-approved list of contracts. The project, currently in the "Not started" status, is being developed as an open-source initiative inspired by a video by LukeYoungblood.eth.
Summary: This document introduces a research tool created by Dan Singjoy that aims to protect the CoinbaseDev Paymaster API from abuse by allowing only calls to an approved list of contracts. The tool is designed to run as a Cloudflare worker and is inspired by a video by Jesse. More information can be found at the provided URL.
Created time: June 1, 2024 7:52 PM
Last edited time: June 8, 2024 9:59 PM
Parent task: Research Coinbase Developer Platform Paymaster API (Research%20Coinbase%20Developer%20Platform%20Paymaster%20API%206e367d9908bf49bf9f7a4658ffc2e222.md)
Created by: Dan Singjoy

[https://twitter.com/LukeYoungblood/status/1796922481871339713](https://twitter.com/LukeYoungblood/status/1796922481871339713)

LukeYoungblood.eth 🛡️ on X: "Jesse's video inspired me to open source something I built this week on @Base: A Paymaster / Bundler proxy that runs as a @Cloudflare worker and protects your @CoinbaseDev (or @pimlicoHQ) Paymaster API from abuse by ensuring that only calls to an allowed list of contracts are" / X