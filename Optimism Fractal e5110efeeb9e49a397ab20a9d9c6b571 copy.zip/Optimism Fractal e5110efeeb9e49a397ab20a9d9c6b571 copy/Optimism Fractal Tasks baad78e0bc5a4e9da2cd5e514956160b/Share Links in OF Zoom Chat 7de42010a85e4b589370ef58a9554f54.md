# Share Links in OF Zoom Chat

Status: Not started
Task Summary: This task aims to provide instructions for sharing links in the OF Zoom chat. It includes the links for the Optimism Fractal Welcome Guide, Optimism Fractal Discord, and Optimism Fractal Farcaster Channel, which will be shared during the introductory presentation.
Summary: During the introductory presentation, it is suggested that Rosmari shares the following links in the Zoom chat: the Optimism Fractal Welcome Guide, Optimism Fractal Discord, and Optimism Fractal Farcaster Channel.
Created time: May 11, 2024 5:41 AM
Last edited time: May 11, 2024 5:42 AM
Created by: Dan Singjoy

- I think it’d be good if Rosmari shares the following links in the zoom chat during the introductory presentation
    - [Optimism Fractal Welcome Guide](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md)
        - This includes the links that I shared during the presentation
    - Optimism Fractal Discord
    - Optimism Fractal Farcaster Channel