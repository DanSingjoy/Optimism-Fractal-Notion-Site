# Respond in hats telegram about mad hatter, town hall event, Welcome Will and Rosmari to the Hats + OF Chat and Respond to Zeugh

Due: July 1, 2024
Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: In progress
Task Summary: This task aims to facilitate communication and updates regarding the Hats Telegram, particularly focusing on the Mad Hatter event and the ongoing Optimism Town Hall discussions. It includes welcoming new members, responding to key participants, and proposing topics for future events. The goal is to enhance community engagement and collaboration within the Hats Protocol ecosystem.
Summary: The document outlines plans for an upcoming Optimism Town Hall, including discussions on the Hats Protocol and the Optimism Fractal Hats Tree. It welcomes new participants, Will and Rosmari, and highlights the recent achievements of the Hats community, including co-winning the Mad Hatter grand prize. The document also proposes topics for the town hall, encourages collaboration, and expresses excitement for future developments and presentations related to Hats Protocol.
Created time: September 6, 2024 9:42 AM
Last edited time: September 18, 2024 7:53 PM
Created by: Dan Singjoy
Description: The document outlines plans for an upcoming Optimism Town Hall, including discussions on the Hats Protocol and the Optimism Fractal Hats Tree. Key participants such as Will, Rosmari, and Jacob are welcomed, and there are proposals for topics related to Hats, including presentations from co-winners of the Mad Hatter prize. The document emphasizes collaboration and excitement about the future of Hats Protocol and its integrations.

Here is the topic proposal for this week’s Optimism Town Hall:

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image.png)

Sounds good David, we can schedule for you to speak at the town hall on October 3rd. We can discuss the Hatathon at this week’s town hall and then do another episode with you then more in-depth explorations of Hats Protocol integrations. I’m looking forward to seeing you then

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%201.png)

Great, I’m looking forward to meeting Wasabi and learning more about the Let’s GROW Hats Tree at the town hall. I’ll propose and vote for a topic about Hats for this week’s Optimism Town Hall that provides some time for Wasabi to show the Let’s GROW Hats Tree

## Propose Town Hall Topic

## Respond to David

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%202.png)

Hey David, thank you so much! I’m honored that Optimism Fractal hats tree was selected as a co-winner of the Mad Hatter grand prize and very glad that you loved how we used modules. I’m really excited to see how our tree grows in the coming weeks and months too, as well as in the coming years as both Hats Protocol and Optimism Fractal continue to develop!

Thank you for letting us know about the hat-wearer prize and the LetsGROWDAO tree as well, I enjoyed exploring their tree and am looking forward to seeing the hats trees from all the other winners in the hatathon. I’m eager to see the messages you share publicly next week and happy to help spread the word however I can. Thank you! 🙏🏽

By the way, there were several discussions and lots of enthusiasm expressed about Hats Protocol at the most recent Optimism Fractal event. You can watch the [video](https://www.youtube.com/watch?v=jYcMpadnaZA) and search for hats in the transcript on the youtube UI if you’d like to hear the discussions about hats. 

@Rosmari will also soon publish the breakout room that she recorded where I think @wJacob shared a presentation about his work on the Optimism Fractal hats tree as well. Anyone who’s interested will be able to find it near the top of this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lk5Aavi98CqFj7ryM42bvbP) within the next few days. Last week he also shared a [presentation](https://youtu.be/luw4yz_kA3Y?si=BpeI52SxzCv7hc9m&t=868) about making a hats tree for DAO Coalition.

At the recent town hall event we didn’t get the chance to have a deep dive into the Hats Tree because we focused on the ORDAO/OREC app that @tadas is building (as you can see [here](https://youtu.be/jYcMpadnaZA?si=KS4v7J5os_05wRQU&t=3927)), but I think it would be excellent to have a more focused discussion about the Optimism Fractal Hats Tree and Hats Protocol at an upcoming Optimism Town Hall.

I am thinking about proposing the Optimism Fractal Hats Tree as the main discussion topic for the next Optimism Town Hall and it would be wonderful if any members of the Haberdasher Labs team and/or wider Hats community would like to speak at the event. In addition to showing off the Optimism Fractal Hats Tree, this town hall event could also feature an introduction to Hats Protocol, an overview of hats trees from other winners in the Hatathon, and an exploration of the future integrations of Optimism Fractal with Hats Protocol (including this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)).

@David or @spencer, would you and/or other leaders in the Hats community would be interested in speaking about Hats Protocol at an upcoming Optimism Town Hall? The Optimism Town Hall [event](https://lu.ma/optimismtownhall) occurs each Thursday at 18 UTC and we could schedule it for this week or a different week in the future if you’d like.

Of course everyone is also welcome to join the Optimism Fractal Respect Game an hour before the town hall (and I imagine you’d get lots of Respect for all the great things you’re building with Hats on Optimism) or you could just join for the town hall if you prefer. I’m curious to hear your thoughts about this and would be happy to adjust our plans according to your input. What do you think?

- 
    
    
    If you’re up for it and we schedule it in advance, then we could also create promotional messages to spread the word before the event and fun beautiful artwork illustrating the Optimism Fractal Hats Tree + Hats Protocol. As always the event will be recorded and we’ll produce a high quality video with show notes, which can serve as an educational resource that anyone can watch to learn more about Hats Protocol and the Optimism Fractal Hats Tree. 
    

## Congratulate Jacob

Congratulations and thanks again for all the help @Jacob, it was such a pleasure collaborating with you to create the Optimism Fractal Hats Tree! 

I’ll follow up in our DMs about splitting the rewards this week. Thank you for making the great [post](https://warpcast.com/jacobhomanics.eth/0x5e81fe45) about Optimism Fractal and Hats Protocol as well 🙏🏽🙌🏽

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%203.png)

[Quote tweet or respond to Jacob Homanics tweet](https://www.notion.so/Quote-tweet-or-respond-to-Jacob-Homanics-tweet-77e4f125eb50465b83b5424ccea32cff?pvs=21) 

- [ ]  respond to tweet
    - [ ]  Thank you for spreading the word and encouraging people to join, I’m glad you had a great time and are excited by the progress. I’m excited about it too and it was such a pleasure collaborating with you on the Optimism Fractal Hats Tree! Thanks again so much for all your help and congrats on co-winning the Mad Hatter grand prize!
    
- [ ]  quote tweet
    - [ ]  It’s amazing to hear this feedback about Optimism Fractal from such a smart and talented builder as @jacob. I’m pleased to announce that we are co-winners of the @HatsProtocol hatathon. I encourage everyone to listen to his advice and join the events :)

- 
    
    
    ![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%204.png)
    
    [https://x.com/JacobHomanics/status/1831774911767203931](https://x.com/JacobHomanics/status/1831774911767203931)
    
    ![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%205.png)
    
    ![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%206.png)
    

## Welcome Will

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%207.png)

Welcome Will, thanks for joining and congratulations to Let’s GROW on being a co-winner of the Mad Hatter! I explored the Let’s GROW DAO Tree and it seems very well organized, I’m looking forward to learning more and seeing how Let’s GROW will grow with hats! 

Let me know if you, Wasabi, and/or other Let’s GROW leaders would like to speak a bit about the Let’s GROW Hats Tree at an upcoming Optimism Town Hall event. It would be cool to see a presentation from the co-winners of the Mad Hatter  🤠

By the way the town hall events are scheduled for a half hour, but we could potentially extend it to a full hour if it would be helpful.

## Welcome Rosmari

Welcome @Rosmari, thanks for joining and making the great [tweet](https://x.com/RosmariDigital/status/1831929731811570140?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1831929731811570140%7Ctwgr%5E90e65685a37eaca25af67fd67a3dd8fc10ab606b%7Ctwcon%5Es1_c10&ref_url=https%3A%2F%2Fwww.notion.so%2Fedencreators%2F1daa7b3451a344c2947ccc04b48b1042%3Fv%3D472c609e6c034ff4af20d2e3c6eaac4ep%3D6b46cdfc045f4738a148bae35b9c0667pm%3DcshowMoveTo%3Dtrue) about Hats Protocol and Optimism Fractal. Special thanks for providing the much of the inspiration for the Fractalgram Certification and builder networking site on charmverse as well 😊

- 
    
    The ideas for the Fractalgram Certification and builder networking site were largely inspired by you, so thank for the inspiration as well 
    

[https://x.com/RosmariDigital/status/1831929731811570140](https://x.com/RosmariDigital/status/1831929731811570140)

## Welcome Patrick

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%208.png)

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%209.png)

Heart, like and retweet

Welcome Patrick and thank you for your contribution. That sounds awesome, I’m looking forward to seeing the MindMap with the Optimism Fractal Hats Tree and your breakdown interview with Jacob! 🙌🏽

- 
    
    
    Welcome Patrick and thank you for your contribution. That sounds great, I’m looking forward to seeing the Fractal MindMap and your interview with Jacob! 
    
    Welcome Patrick and thank you for your contribution. That sounds great, I’m looking forward to seeing the Fractal MindMap and your interview with Jacob! 
    

## Respond to Zeugh in Hats Chat

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%2010.png)

Thank you Zeugh :) I appreciate you reading about fractalgram and claiming the hats, including the Respect Game Leader. You’re always welcome to join whenever you can make it and I hope we’ll get the chance to connect again soon. By the way, I listened to you speaking on a recent Optimism call and am excited to see what you’re building with ENS! 

![image.png](Respond%20in%20hats%20telegram%20about%20mad%20hatter,%20town%20ha%206b46cdfc045f4738a148bae35b9c0667/image%2011.png)

- 
    
    
       Feel free to share the Let’s GROW hat tree here if you’d like. I think I remember you saying that it’s built on Optimism and it sounded quite inspirational at yesterday’s Respect Game, so I’d be curious to see it if you want to share 🌳