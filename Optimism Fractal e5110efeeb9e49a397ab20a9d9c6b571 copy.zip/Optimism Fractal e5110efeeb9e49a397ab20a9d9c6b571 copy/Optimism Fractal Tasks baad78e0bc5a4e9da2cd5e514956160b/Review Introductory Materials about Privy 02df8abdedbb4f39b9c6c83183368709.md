# Review Introductory Materials about Privy

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: In progress
Summary: http://privy.io/ is a platform that offers tools for developers to onboard users into the web3 ecosystem. It provides authentication flows, embedded wallets, and supports various authentication methods. Privy emphasizes security and ease of use, with customizable modals and deep web3 integrations. The platform recently raised $17 million in funding. It aims to make integrating web3 technologies into apps straightforward and user-friendly.
Created time: February 23, 2024 9:49 AM
Last edited time: March 10, 2024 8:33 PM
Created by: Dan Singjoy

## About

This page aims to provide an overview of Privy.

[Privy.io](http://Privy.io)  offers a suite of tools designed to help developers onboard users into the web3 ecosystem. It provides a simple library for adding authentication flows and embedded wallets to applications, aiming to make the process of integrating web3 technologies into apps as straightforward as possible. Privy supports a wide range of authentication methods, including email via one-time passwords (OTPs), and it integrates with popular web3 libraries like Wagmi and Ethers. This allows for easy scaling across all devices, wallets, and browsers, with the goal of delivering a seamless and user-friendly experience. The platform emphasizes security and ease of use, offering highly customizable modals, deep web3 integrations, and simple interfaces.

## To Do

- [ ]  organize this page

- [ ]  [Watch Videos and listen to podcasts about Privy. Consider Creating a Playlist](Watch%20Videos%20and%20listen%20to%20podcasts%20about%20Privy%20Co%20af675c3ad4564d66b7e0918cfcf32570.md) - this may be a better way to learn

## Meaning

1. **Private or Secret**: When someone is "privy to" information, it means they have been made aware of or allowed access to secrets or private knowledge that is not widely known or shared.

[https://twitter.com/privy_io/status/1760686451765997824](https://twitter.com/privy_io/status/1760686451765997824)

New privy [channel](https://warpcast.com/henri/0x7fba6916) on farcaster

[Research privy.io and pwa like unlonely app for  easy onboarding for optimism fractal fiand fractaljoy ](Review%20Introductory%20Materials%20about%20Privy%2002df8abdedbb4f39b9c6c83183368709/Research%20privy%20io%20and%20pwa%20like%20unlonely%20app%20for%20ea%2084e6cf57a41c478d89a19ec0481e4bf0.md)

![Untitled](Review%20Introductory%20Materials%20about%20Privy%2002df8abdedbb4f39b9c6c83183368709/Untitled.png)

two big announcements: new PWA mobile experience - no more downloading a standalone app & interact seamlessly with buying/using tokens on streams integrated with for wallet logins via email - now your non-web3 friends can join streams too 1/3

[Native mobile apps are optional for B2B startups in 2024](Review%20Introductory%20Materials%20about%20Privy%2002df8abdedbb4f39b9c6c83183368709/Native%20mobile%20apps%20are%20optional%20for%20B2B%20startups%20i%202d4a7829468845c1b3a7a80bae2f8625.md)

[Warpcast privy zora ](Review%20Introductory%20Materials%20about%20Privy%2002df8abdedbb4f39b9c6c83183368709/Warpcast%20privy%20zora%20a19b774afbac4c32ac28964b0cefbe9f.md)

### Funding

Privy recently raised about 17 million dollars

## Message to Optimystics, January 2024

Have you seen [Privy.io](http://Privy.io)?

I’ve heard it’s a great solution that enable simple signups with email to use EVM accounts. You can see some details in this [note](Review%20Introductory%20Materials%20about%20Privy%2002df8abdedbb4f39b9c6c83183368709/Research%20privy%20io%20and%20pwa%20like%20unlonely%20app%20for%20ea%2084e6cf57a41c478d89a19ec0481e4bf0.md) and an example of how it works in a livestreaming platform called [Unlonely.app](http://Unlonely.app). 

- 
    
    
    I’m not sure how secure it is so we’d want to be careful about important roles like council membership being mediated by privy, but it could help onboard people who aren’t familiar with using Web3 accounts or wallets. 
    
    This wouldn’t solve the issue we had this meeting with people who already have Optimism accounts, but we could reduce the likelihood of this kind of issue by learning how to double check on-chain during the meeting or using firmament…?
    

[https://twitter.com/privy_io/status/1753112738187133398](https://twitter.com/privy_io/status/1753112738187133398)

[/embedded wallets channel ](Review%20Introductory%20Materials%20about%20Privy%2002df8abdedbb4f39b9c6c83183368709/embedded%20wallets%20channel%2052f64e767c45412893a6f1c422023990.md)