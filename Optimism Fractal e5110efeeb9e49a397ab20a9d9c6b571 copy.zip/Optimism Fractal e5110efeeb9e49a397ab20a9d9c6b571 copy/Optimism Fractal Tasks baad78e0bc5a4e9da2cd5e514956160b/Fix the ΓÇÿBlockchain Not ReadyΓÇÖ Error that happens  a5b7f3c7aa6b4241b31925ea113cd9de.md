# Fix the ‘Blockchain Not Ready’ Error that happens when trying to submit results

Project: Optimize Optimism Fractal Web App, Fractalgram, and Fix Errors (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Optimize%20Optimism%20Fractal%20Web%20App,%20Fractalgram,%20an%201699ced1d9b243e4a375610e2222a983.md)
Status: Not started
Summary: Participants have reported a 'blockchain not ready' error when trying to submit consensus results, causing inefficiency and stress. Temporary solutions include disabling other wallet plugins for desktop usage and copying links from Telegram for mobile usage. A technical fix is being implemented.
Created time: April 1, 2024 5:13 PM
Last edited time: April 23, 2024 6:59 AM
Created by: Dan Singjoy

## Description

We’ve heard about this ‘blockchain not ready’ issue from many participants before and I’ve experienced it a few times as well.  It often prevents submission of consensus results and makes the meeting less efficient, while also sometimes making it stressful to submit consensus on time.

You can watch participants describe this in the video below. Jimi and Hodlon described this issue at [55:29](https://youtu.be/h2m9_7cgTow?si=kUZOWRTORvSwJofn&t=3328) in the 21st Optimism Fractal event. They talk about this for several minutes, with more important details at [56:32](https://youtu.be/h2m9_7cgTow?si=Rnc1a43-PNduHwEZ&t=3392).

[https://youtu.be/h2m9_7cgTow?si=kUZOWRTORvSwJofn&t=3328](https://youtu.be/h2m9_7cgTow?si=kUZOWRTORvSwJofn&t=3328)

## Potential Fixes

How do we fix this error so it doesn’t happen anymore?

### Temporary Solution Recommended to Hodlon for Desktop Usage

When Hodlon refreshed the main screen he got a [Fix the ‘Failed to Load Web3’ Error that happens when trying to submit results](Fix%20the%20%E2%80%98Failed%20to%20Load%20Web3%E2%80%99%20Error%20that%20happens%20w%20171fe01e35bc48a694eba1f00cf1198f.md), then when he continues and tries to submit then he gets the  At [57:27,](https://youtu.be/h2m9_7cgTow?si=2pYvtrYnewAEzjhZ&t=3447) Abraham said that he’s had similar issues when you have multiple wallet plugins in the browser and said that disabling other wallets could fix for this. 

This fixed the issue for Hodlon, but did not fix the issue for Jimi as he was using a mobile wallet. This may be related to the issue that Zeugh reported and documented, which you can see at [Fix the UX where it defaults only to Metamask and prevents using another wallet (and probably implement WalletConnect) ](Fix%20the%20UX%20where%20it%20defaults%20only%20to%20Metamask%20and%20%2064b5fee5641f49ffb27c3941a542e640.md) 

### Temporary Solution Recommended to Jimi for Mobile Usage

If you have the same issue in the future, I recommend copying the link from telegram and pasting it into the browser of your wallet application, instead of opening it directly from telegram. That always works for me and I think it would probably resolve the issue you were experiencing.

For the short-term until a technical fix is implemented, I created [Why am I getting an error while trying to submit consensus?](../Optimism%20Fractal%20FAQ%201ce16d6520064186b40f6ad1f211c5f3/Why%20am%20I%20getting%20an%20error%20while%20trying%20to%20submit%20c%207d6f4adc392540fc968def3428525d28.md) in the [](../Optimism%20Fractal%20FAQ%201ce16d6520064186b40f6ad1f211c5f3.md) and added the instructions above. I also added it to [Tips for dealing with errors while using Fractalgram](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Fractalgram%203d7832cdb4254335aba4d079470986dc/Tips%20for%20dealing%20with%20errors%20while%20using%20Fractalgr%20643b870d5f5045d9961b688063acedb3.md)