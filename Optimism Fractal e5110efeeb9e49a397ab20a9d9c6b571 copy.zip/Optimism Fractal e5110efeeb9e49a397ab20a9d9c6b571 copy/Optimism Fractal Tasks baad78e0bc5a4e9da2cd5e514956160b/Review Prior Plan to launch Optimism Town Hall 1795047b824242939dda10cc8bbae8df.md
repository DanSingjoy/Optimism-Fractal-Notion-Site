# Review Prior Plan to launch Optimism Town Hall

Project: Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)
Status: In progress
Task Summary: This task aims to review the prior plan for launching the Optimism Town Hall. The plan includes holding structured discussions each week and implementing a voting process on various platforms. Considerations are made for setting a structured cadence, encouraging participation in polls and discussions, and potentially renaming the planning sessions to align with the goals of the Optimism Fractal and the Optimism Collective.
Summary: The plan to launch Optimism Town Hall includes holding structured discussions each week, implementing a voting process on platforms like Snapshot, encouraging participation in polls and discussions, and considering renaming the Planning Sessions to align with the goals of Optimism Fractal and the Optimism Collective.
Created time: April 24, 2024 3:44 AM
Last edited time: July 15, 2024 1:10 PM
Created by: Dan Singjoy
Description: The plan to launch Optimism Town Hall includes holding structured discussions each week, implementing a voting process on snapshot, encouraging participation in polls and discussions, and considering renaming the Planning Sessions to align with the goals of Optimism Fractal and the Optimism Collective.

## Description

- [ ]  Hold structured discussions each week

- Related notes:
    - [Develop Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md)
    - [Plan Optimism Fractal Season 3](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md)
    
    - [ ]  Implement a voting process on snapshot (or tally, jokerace, etc) where participants can vote on the answers to each question throughout the week using their Respect
        - Consider setting up a structured cadence where there is say a 1 or 2 week cycle for each poll and discussion to help guide the discussions
            - Consider also setting a specific time/date that the discussion topic is decided so that we have enough time to promote the topic in advance and each person has time to prepare
            - There could also be voting on who’s response to hear first in the meeting, which could work well in a complementary poll if people have several days to prepare their responses
            - See [Develop Cagendas at Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)
            
        - I think we should encourage everyone in the collective to participate in the polls and discussions on the forum, even if they don’t participate in the weekly events.
            - This can be a way that inspires members of the collective to learn about Respect and inspire them to start participating in events
            - Even if they don’t participate in the events, it can still be very helpful for everyone since we’re providing structured event, forum posts, polls with democratic inclusive credibly neutral voting process, and video of discussions to facilitate/inspire discussions
            
        - Consider creating a separate post on the RetroPGF or General category of the forum that asks the question, invites people to the event, shares the video, shares a poll where everyone can signal their opinions, and shares the results of the previous polls that closed
            - [ ]  Consider creating a farcaster channel for this too where we can eventually use onchain integrations as described in [Explore and Create Integrations between Farcaster and Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md)
            
    - [ ]  Consider renaming the Planning Sessions into something that is more aligned with the goal of Optimism Fractal and the Optimism Collective
        - Similar to how we created RetroPitches last season maybe we should create RetroTalks, RetroJuries, Optimism Town Hall, Impact Jurors, Fractal Juries, Optimism Juries, Juryspect, Gov Love, Sunny Govy, Governance Covenance, Gov Gab, Gov Gathering, and/or Impact Sessions
    
    - [Make Promotion about how Optimism Town Hall helps Data Scientists](Make%20Promotion%20about%20how%20Optimism%20Town%20Hall%20helps%20%2003ed0682f73f439dabbbe706e5b8e19d.md)