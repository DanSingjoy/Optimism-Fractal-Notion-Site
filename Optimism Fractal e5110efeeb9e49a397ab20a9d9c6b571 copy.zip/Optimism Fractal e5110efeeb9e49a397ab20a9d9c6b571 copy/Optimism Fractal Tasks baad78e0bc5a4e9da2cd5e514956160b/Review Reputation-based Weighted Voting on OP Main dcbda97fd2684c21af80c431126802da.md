# Review Reputation-based Weighted Voting on OP Mainnet (TE Academy) and consider reaching out to collaborate on design of OPC and other auxiliary reputation tokens, and educational courses

Project: Create Auxiliary Respect Tokens for Optimism Collective (ie OPC) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Auxiliary%20Respect%20Tokens%20for%20Optimism%20Colle%20b78abde1bff54c499c648628e459c689.md), Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md)
Status: Not started
URL: https://gov.optimism.io/t/reputation-based-weighted-voting-on-op-mainnet-te-academy/7993?u=dansingjoy
Task Summary: This task aims to review and consider collaborating on the design of OPC and other reputation tokens, as well as educational courses, based on the concept of Reputation-based Weighted Voting on OP Mainnet. The page provides an overview of the project, including its objectives, the importance of reputation-based voting, and the potential benefits it offers to decentralized autonomous organizations (DAOs).
Summary: TE Academy is exploring Reputation-based Weighted Voting (RWV) as a new primitive for token-based decision-making in DAO governance. This experiment aims to make a voter's track record count in DAO decisions, using proofs of expertise and achievements to define voting weight. The program offers a cohort-based education program and invites community members to participate in the voting experiment. RWV can be applied to any DAO decision-making cases where expertise is required, and it complements 1token1vote and vote delegation. The results and voting algorithm will be available open-source.
Created time: May 17, 2024 10:16 AM
Last edited time: May 17, 2024 10:19 AM
Created by: Dan Singjoy

See the comments and videos in link above

Consider how this could also synergize with will’s workn and Farcaster graph and FractalJoy certifications and respect networks and higher order fractals 

[Review Kingfisher's Media Learn to Earn Program and consider how Will may be able to help with FractalJoy Courses- he knows alot about integrating technical solutions like EAS and charmverse to build educational institute](https://www.notion.so/Review-Kingfisher-s-Media-Learn-to-Earn-Program-and-consider-how-Will-may-be-able-to-help-with-Fract-17ffd46aa7744042b1f240d06c0f45fc?pvs=21) 

[Explore and Create Integrations between Farcaster and Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md) 

Any DAO’s growth depends on good decisions. At TE Academy, we’re exploring a new primitive for token-based decision-making: Reputation-based Weighted Voting – we will design a voting mechanism that makes reputation count, and run a voting experiment on the OP Mainnet.

Join us! Take part in the [TE Academy Study Season](https://tokenengineering.net/study-season/1/) - a free cohort-based education program starting on April 25.

Why Reputation-based Weighted Voting (RWV)?

![https://global.discourse-cdn.com/business7/uploads/bc41dd/optimized/2X/4/4794da8d126cffb70b91c3daf409159713d729ca_2_1380x862.jpeg](https://global.discourse-cdn.com/business7/uploads/bc41dd/optimized/2X/4/4794da8d126cffb70b91c3daf409159713d729ca_2_1380x862.jpeg)

The design space of token-based governance is huge. In DAO governance’s reality though, only a handful of primitives achieved significant adoption. 1token1vote links voting power directly to the number of tokens held. Vote delegation allows token holders to assign their voting rights to another party, enabling concentrated decision-making power based on trust.

There is a third class of voting mechanisms to complement these concepts: make a voter’s track record count in DAO decisions, and use proofs of expertise and achievements as a signal to define voting weight and decision-making power. In this experiment, TE Academy explores the potential of Reputation-based Weighted Voting in an educational project. Students will have the chance to go over the entire token engineering process and work on a case study with a real voting outcome - deciding on the winner of the first TE Academy fellowship with a $10K prize for the fellowship winner.

Over the past 3 years, TE Academy has established a system of NFT proofs to track individual community members’ achievements and the development of the sector overall. We’ve issued more than 1000 NFTs to students who’ve passed knowledge requirements and to researchers with significant contributions to the token engineering discipline. In our experiment, any community member will be eligible to vote - however, holding Token Engineering NFTs will increase a voter’s weight in this decision. No popularity contest!

We’ll account for:

- passed exams in the TE Fundamentals course (more than [4000 students enrolled](https://tokenengineering.net/explore/))
- sharing knowledge as a speaker at TE Academy events ([more than 120](https://www.youtube.com/@TE-Academy) over the last 3 years)
- contributions to our shared body of knowledge in the form of online learning materials (first [bachelor-level course in token engineering](https://tokenengineering.net/explore/))
- supporting students as study group host (in one of 45 study groups)
- and more.

**The Benefits**

Reputation-based Weighted Voting can be applied to any DAO decision-making cases where expertise is required to make good decisions. In RWV systems, voters are encouraged to sharpen their profile and become highly sought-after experts in their domain of decisions (e.g. Retro-Public Goods Funding, Risk Management). For a DAO’s collective, it’s an opportunity to establish incentives for decision-makers and grant voting power to those who were actively involved in good decisions.

Combined with 1token1vote and vote delegation, it’s a new building block to make decisions transparent, and robust against collusion, bribery, and economic attacks.

We offer this program as part of our public goods education, enabled by Optimism RetroPGF! **The results of this experiment, as well as the voting algorithm and a simulation engine, will be available open-source.**

Learn more about our program in [this presentation at the Optimism Demo Day 2](https://youtu.be/gQKKt755n6Y?si=XsTY2Iw_CaK2j4yU)!

Today, more than 4000 students are enrolled in TE Academy’s studying programs, and research initiatives. Currently, we are exploring token-based DAO decision-making via RWV, and [AI-Copilots for RetroPGF](https://gov.optimism.io/t/ai-copilots-for-optimism-retropgf/7636), our second initiative in collaboration with the Optimism Collective.

[Register for the Study Season](https://tokenengineering.net/study-season/1/), and learn how to design, verify, and implement Reputation-based Weighted Voting.

See you at TE Academy!