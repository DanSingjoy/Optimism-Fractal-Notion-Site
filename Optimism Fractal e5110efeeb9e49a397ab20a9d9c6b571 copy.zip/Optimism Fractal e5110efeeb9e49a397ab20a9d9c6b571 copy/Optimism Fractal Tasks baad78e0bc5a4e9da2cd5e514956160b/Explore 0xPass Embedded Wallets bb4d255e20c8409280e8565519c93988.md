# Explore 0xPass Embedded Wallets

Status: Not started
Task Summary: This task aims to explore the functionalities and capabilities of 0xPass Embedded Wallets. Created by Dan Singjoy, this project is currently in the early stages of development and not yet suitable for our specific use cases. For more information, you can visit https://0xpass.io/.
Summary: This document is about exploring 0xPass Embedded Wallets. However, there is no description provided, and it seems that the 0xPass/Passport Protocol is still in early development and not suitable for current use cases.
Parent-task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created time: March 18, 2024 6:01 PM
Last edited time: June 8, 2024 11:42 PM
Parent task: Research Embedded Wallet Solutions and Compare with Privy and Magic (Research%20Embedded%20Wallet%20Solutions%20and%20Compare%20wit%20f9382eeb4d354eefa5f59a33d00719dc.md)
Created by: Dan Singjoy

## Description

- 

## 0xPass / Passport Protocol

This seems very early in development and not ready for our use cases

![[https://0xpass.io/](https://0xpass.io/)](Explore%200xPass%20Embedded%20Wallets%20bb4d255e20c8409280e8565519c93988/Untitled.png)

[https://0xpass.io/](https://0xpass.io/)