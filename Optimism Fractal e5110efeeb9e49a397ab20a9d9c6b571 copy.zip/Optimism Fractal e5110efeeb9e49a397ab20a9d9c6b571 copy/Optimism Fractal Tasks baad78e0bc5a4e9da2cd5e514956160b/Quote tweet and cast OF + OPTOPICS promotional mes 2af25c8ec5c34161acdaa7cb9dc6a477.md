# Quote tweet and cast OF + OPTOPICS promotional message

Assignee: Dan Singjoy
Due: May 23, 2024
Project: Prepare for OF 27 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2027%20a3a902d398094d0b826538ac88183391.md)
Status: Done
Task Summary: This task aims to create a promotional message for the Quote tweet and cast OF + OPTOPICS project. The message will be created by Dan Singjoy and the task is assigned to him. The deadline for this task is May 23, 2024, and it has already been marked as done.
Summary: No content
Created time: May 23, 2024 9:14 AM
Last edited time: May 26, 2024 8:53 PM
Created by: Dan Singjoy

[https://x.com/optimystics_/status/1793080867457503701](https://x.com/optimystics_/status/1793080867457503701)

[https://x.com/optimystics_/status/1793080870171226276](https://x.com/optimystics_/status/1793080870171226276)