# Research Roles and Reputations System (from Jacob Homanics with ATX DAO)

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), Explore integrations with Roles and Reputations System (from Jacob Homanics with ATX DAO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20with%20Roles%20and%20Reputations%20Sy%20c85bbe3e9a8548bfb3ccf6a4aea29fde.md), Integrate Optimism Fractal notion page with Notion API and Pipedream (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20notion%20page%20with%20Notion%2071c1311213394726983236991c25e999.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: In progress
Task Summary: This task aims to provide a summary and introduction for the "Research Roles and Reputations System" page. The page discusses the integration of Roles and Reputations by Jacob Homanics with ATX DAO, highlighting its potential benefits for Optimism Fractal and other fractal communities. It includes links to video presentations, GitHub repositories, and contact details, offering further information and resources on the topic.
Summary: This document discusses the Research Roles and Reputations system proposed by Jacob Homanics with ATX DAO. The system aims to track an entity's trust and provide meaningful authorities and responsibilities. It offers a value proposition by solving problems related to entity trust and permissions. The solution is expected to be a source of growth for the Optimism ecosystem. The document also includes an example implementation in ATX DAO and potential integrations with Optimism Fractal.
Sub-task: Watch videos about Roles and Reputation and consider curating information (Watch%20videos%20about%20Roles%20and%20Reputation%20and%20consid%200f7c74b01fb54f2c9fd3f3dbfe94ab04.md)
Created time: January 12, 2024 10:11 PM
Last edited time: July 12, 2024 2:07 PM
Created by: Dan Singjoy
Description: This document discusses the Research Roles and Reputations System proposed by Jacob Homanics with ATX DAO. The system aims to track an entity's trust and provide meaningful authorities and responsibilities. It offers a value proposition for solving trust and permission-related problems and can be a source of growth for the Optimism ecosystem. The document also includes an example implementation in ATX DAO and potential integrations with Optimism Fractal.

## Overview

This document discusses research on Roles and Reputations from Jacob Homanics and it’s integration with [Hats Protocol](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md). It includes video presentations, GitHub repositories, and contact details. This tooling may be very helpful for Optimism Fractal and other fractal communities to improve the utility of Respect and easily assign roles based upon Respect earnings. The document provides links to further information and resources.

You can learn more about potential integrations with Optimism Fractal in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20with%20Roles%20and%20Reputations%20Sy%20c85bbe3e9a8548bfb3ccf6a4aea29fde.md).

**Table of Contents**

## Github Repositories and Resources

[https://github.com/ATXDAO/reputation](https://github.com/ATXDAO/reputation)

[https://github.com/ATXDAO/rep-and-roles-starter-kit](https://github.com/ATXDAO/rep-and-roles-starter-kit)

[https://hotmanics.github.io/rep-and-roles-docs](https://hotmanics.github.io/rep-and-roles-docs)

Here is the old Github Repository: https://github.com/atxdao/reputation-and-roles-monorepo

Here is a React Hooks [project](https://github.com/Hotmanics/use-hats) that he created to help developers implement custom Hats Protocol front-ends.

[https://x.com/homanics/status/1783949655555928504?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/homanics/status/1783949655555928504?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

![[https://gov.optimism.io/t/reputation-roles-milestone-tracking-atx-dao/7953/2?u=jacobhomanics](https://gov.optimism.io/t/reputation-roles-milestone-tracking-atx-dao/7953/2?u=jacobhomanics)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Untitled.png)

[https://gov.optimism.io/t/reputation-roles-milestone-tracking-atx-dao/7953/2?u=jacobhomanics](https://gov.optimism.io/t/reputation-roles-milestone-tracking-atx-dao/7953/2?u=jacobhomanics)

# Videos

## Presentation at Optimism Fractal 24

Here is a video clip of Jacob’s [presentation](https://youtu.be/pjQH394S4zc?si=jP9mbFiWm-UmGl9o&t=1546) during Optimism Fractal event 24 where he introduces his work with Roles and Reputations, Scaffold ETH, and other exciting projects. You can hear a brief overview of Roles and Reputations at [26:30](https://youtu.be/pjQH394S4zc?si=vCJCwA2TGJTSOXlT&t=1590) in the following video.

[https://youtu.be/pjQH394S4zc?si=jP9mbFiWm-UmGl9o&t=1546](https://youtu.be/pjQH394S4zc?si=jP9mbFiWm-UmGl9o&t=1546)

Starting at [25:33](https://www.youtube.com/watch?v=pjQH394S4zc&t=1533s) Jake discusses his contributions to the Scaffold ETH 2 repository for web3 dapp development. He talks about his Rep and Roles project for tracking onchain trust, which received an Optimism grant. Jake discusses his work on an NFT project focused on supporting creators, explaining its vision of properly onboarding artists into web3 and providing the benefits of smart contracts and NFTs.

## **Superchain Demo Day**

[https://www.youtube.com/live/WZMwNuQgtBE?si=rSbkcFIAHyxnw3tP&t=1159](https://www.youtube.com/live/WZMwNuQgtBE?si=rSbkcFIAHyxnw3tP&t=1159)

**Superchain Demo Day**

Starting at [19:19](https://www.youtube.com/live/WZMwNuQgtBE?si=b0h7XPiA3AP8xzvp&t=1159), Jacob demonstrated Roles and Reputations for 18 minutes in the Superchain Demo Day hosted by the Optimism Foundation on May 9th.

[Roles and reputations presentation at optimism demo day](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Roles%20and%20reputations%20presentation%20at%20optimism%20dem%20bc3a830a47524c6fb7167a9d38d9d452.md)

## Quick Deployment Demonstrations from Jacob

[https://youtu.be/-XbTq4sp37Q?si=zKsgFpb2uCrfWw1k](https://youtu.be/-XbTq4sp37Q?si=zKsgFpb2uCrfWw1k)

[https://youtu.be/2iJAzDnvnNY?si=dK3z5Gk2uD_szwlb](https://youtu.be/2iJAzDnvnNY?si=dK3z5Gk2uD_szwlb)

## BuidlGuidl Videos

[https://www.youtube.com/watch?v=1p0KQlVTFow&list=PLnVqcyNGbH01OAruHVSgTmOsykvmQdb3z&index=7&pp=iAQB](https://www.youtube.com/watch?v=1p0KQlVTFow&list=PLnVqcyNGbH01OAruHVSgTmOsykvmQdb3z&index=7&pp=iAQB)

### **Reputation Starter Kit**

April 26th, **Reputation Starter Kit: Jacob Homanics demonstrates the kit that developers can use to implement Reputation Tokens**

[https://x.com/homanics/status/1783933942199886218?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/homanics/status/1783933942199886218?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://youtu.be/peH2eFKvDxc?si=bcTEpV6TNhQDHtLV](https://youtu.be/peH2eFKvDxc?si=bcTEpV6TNhQDHtLV)

### **Scaffold NFT**

April 26th, **Scaffold NFT:** Jacob Homanics ****demonstrates Scaffold NFT, a flexible development tool for deploying NFT applications

[https://youtu.be/fQjn7B47FAM?si=kn3DQk5hhThYJqRd](https://youtu.be/fQjn7B47FAM?si=kn3DQk5hhThYJqRd)

### **ATX REP**

**Mar 27, 2024, ATX REP:** A method to track trust onchain, using ERC1155s, with decentralized distribution & management and permissionless authorities/responsibilities, using Hats Protocol.

[https://youtu.be/1TG_8Z1ctz8?si=7JwMVbXkERM0DA6t](https://youtu.be/1TG_8Z1ctz8?si=7JwMVbXkERM0DA6t)

### **Hats Demo**

**Mar 27, 2024, Hats Demo:** A method to track trust onchain, using ERC1155s, with decentralized distribution & management and permissionless authorities/responsibilities, using Hats Protocol.

[https://youtu.be/Ced555YbK2k?si=UGtlSmhWqN2-5l4p](https://youtu.be/Ced555YbK2k?si=UGtlSmhWqN2-5l4p)

### ERC404 NFTs

**Mar 27, 2024, Trash NFTs: J**acob Homanics demonstrates an interesting implementation of ERC 404, a new token standard that combines mechanics of ERC20 and ERC721 

# Documentation

[https://twitter.com/homanics/status/1780292923734560771](https://twitter.com/homanics/status/1780292923734560771)

[https://twitter.com/homanics/status/1782835822028271639?t=hVRuNOGefHQKF5UNCaDI2A](https://twitter.com/homanics/status/1782835822028271639?t=hVRuNOGefHQKF5UNCaDI2A)

![[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Untitled%201.png)

[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)

![[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Untitled%202.png)

[https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html](https://hotmanics.github.io/reputation-and-roles-monorepo-documentation/philosophy/reputation/reputation.html)

# Contact and Community

### Telegram Group

[https://twitter.com/homanics/status/1779946664125698507](https://twitter.com/homanics/status/1779946664125698507)

### Farcaster

[https://warpcast.com/~/channel/atxdao](https://warpcast.com/~/channel/atxdao)

[https://warpcast.com/hotmanics](https://warpcast.com/hotmanics)

# Older Research from August 2023-January 2024

Here is a tweet showing a roles and reputation system from ATX DAO. It’s seems like it could have similar to ours and they also created an open-source front end. The Optimism Grants Council approved a [proposal](https://app.charmverse.io/op-grants/page-23303127376120303) they made to build this a few months ago and it received the highest score from the reviewers of all applications. I’ve been trying to understand it ever since then and the videos above helps clarify a lot, it looks helpful for our use case…

Proposal to Optimism Grants Council: [https://app.charmverse.io/op-grants/page-23303127376120303](https://app.charmverse.io/op-grants/page-23303127376120303)

Google document with more details: https://docs.google.com/document/d/1tq3x8t2l5lIfdmCm7YbKDsNAucwrHGwXWXBo7cEIzuM/edit#heading=h.cvxuqwqztm7d

[https://hats-demo-day.vercel.app/](https://hats-demo-day.vercel.app/)

[Support](https://t.me/joinchat/KByvmRe5wkR-8F_zz6AjpA)

[Fork me](https://github.com/scaffold-eth/se-2)

[https://github.com/scaffold-eth/scaffold-eth-2](https://github.com/scaffold-eth/scaffold-eth-2)

![[https://twitter.com/hatsprotocol/status/1735351644219478187](https://twitter.com/hatsprotocol/status/1735351644219478187)](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Untitled%203.png)

[https://twitter.com/hatsprotocol/status/1735351644219478187](https://twitter.com/hatsprotocol/status/1735351644219478187)

## Text from Original Proposal

The following text was written in the original proposal to the Optimism Grants Council

- Select Parts of Original Proposal
    
    
    **Goal**
    
    The goal of this project is to become the open source bedrock upon which all sufficiently decentralized entities tackle the challenges of defining and assigning reputation & roles through a permissionless and decentralized system. By developing and launching the framework on Optimism, we incentivize other communities to adopt the same network.
    
    **What are you going to build?:**
    
    **Reputation & Roles**
    
    As it stands, there is currently no successful way to track an entity’s trust in relation to another in a completely onchain and clear way.  There are several solutions that are either too abstract or too complex to reach mass adoption. We are attempting to find the middle ground where the idea is simple to digest, meanwhile keeping the capability of adding complexity in places that require it.
    
    Reputation & Roles is a combination of a Dual-Token ERC-1155 Collection and an implementation of the Hats Protocol. The Dual-Token collection consists of a smart contract which can reward and track an entity’s trust with another’s. This allows for an entity to make contributions to another entity or participate in that entity’s events and be rewarded for doing so in a way that builds trust between both entities. Hats Protocol builds on top of the Dual-Token system to assign authority and responsibility based on the balance of Reputation Tokens. This allows for an entity to gain certain “powers” and become recognized for their efforts after building a certain level of trust with the other entity.
    
    **Reputation - Dual-Token ERC-1155 Collection**
    
    A decentralized way to gain and track trust through contributions from any discipline and attendance from in-person and online activities. This will be done completely onchain by creating a Dual-Token ERC1155 Collection. The two types of tokens are: Lifetime and Redeemable. Lifetime Tokens measure an entity’s longstanding trust with another entity. Redeemable tokens can be traded in for arbitrary rewards onchain and offchain. They are semi-soulbound and can only be transferred under specific circumstances (i.e. redemption or account transfers).
    
    ![Untitled](Ask%20and%20Answer%20Questions%20about%20Integrating%20with%20Ro%201d7979738a9f49bdb1deba384035553d/Untitled%201.png)
    
    **Roles - [Roles and Reputation](https://docs.google.com/document/d/1tq3x8t2l5lIfdmCm7YbKDsNAucwrHGwXWXBo7cEIzuM/edit#heading=h.cvxuqwqztm7d)**
    
    A utilization of the Reputation system. It builds on top of the [Hats Protocol](https://app.hatsprotocol.xyz/), **the backbone for decentralized work.** Hats empowers groups to get things done by delegating responsibilities to the right contributors, giving them the hard and soft authorities they need to do their work, and installing real-time accountability mechanisms to ensure people follow through. Our approach leverages the programmable nature of roles in Hats Protocol to automatically manage roles, responsibilities, and authorities based on an entity's balance of Reputation tokens.
    
    ![Untitled](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Untitled%204.png)
    
    **Monorepo**
    
    A public good consisting of an open sourced, modularized, and composable monorepo that will serve as a playground and jumping off point for builders and developers to customize and implement their own versions of Reputation & Roles. It will consist of a Foundry Toolkit project and a React Web Application.
    
    **Monorepo** - Foundry Toolkit
    
    The homeplace of the Reputation smart contract(s). It will also host a suite of other smart contracts pertaining to the interaction, deployment, and testing of the core onchain Reputation system. The project will be built out in a way where builders can make alterations or customizations to the Reputation smart contracts as they please.
    
    **Monorepo** - React Webapp
    
    A Create React App or NextJS application that utilizes several open sourced technologies to connect a Web3 Wallet and interact with localhost, testnet, and mainnet instances of the Reputation smart contracts by viewing the connected wallet’s tokens, other owners’ tokens, and  several other utility features. Builders will be able to use the complete webapp as their main source of frontend Reputation interactions by being able to easily deploy it to a web hosting service. Running in parallel, will be an npm package that can installed and added to any other React application. Through this package, will exist the core React code required to build a frontend for Reputation & Roles. The package consists of React components that display a connected wallet’s Reputation Tokens and utility functions (i.e. Delegation and Transfer function calls, Leaderboards, etc.).
    
    **Why is what you are going to build going to succeed?:**
    
    This idea draws inspiration from World of Warcraft, a game which at its peak had 12 million monthly subscribers at $15 USD/month. They implemented a Reputation system, where you could gain trust with a faction to gain rewards and authority/responsibility pertaining to the faction. New gear or quests would become unlocked, further strengthening the trust with the faction. They also had a Guild system where any number of players could group together and designate authority/responsibility to each other through a roles-based system. This led to incredibly successful organizations and groups where everyone’s roles were clearly defined and managed, and allowed for incredible feats to be obtained.
    
    We aim to take these game mechanics and push them into the Web3 ecosystem. Reputation & Roles is a conglomeration of both of the original ideas with the touch of Web3 (Removing centralization and adding decentralization and permissionless ideals).
    
    The monorepo makes it possible for anyone to spin up and deploy their own versions of these systems, that are easily interactable by builders AND users, which allows for the onboarding and adoption to become far easier.
    
    The aim is to build Reputation & Roles in a modular, composable, flexible, and expandable way so that it can fit into ANY ecosystem. This means any builder should have the ability to add/remove/change functionality where they see fit. For instance, DAOs are vastly different and range in complexity.  One DAO may want to create a simple Reputation system where all they do is track the number of tokens each member owns. Another DAO may want to create a system with multiple Roles based on Reputation, third party integrations, and other complex systems. The implementations of the systems and monorepo should be simple enough, but allow for complexity if required.
    
    **Why is what you are going to build novel? (You can think of novelty in one of two ways: either your project is meaningfully different from what others are building in the blockchain industry or you can describe how you are approaching a problem in a way unique from how others are approaching the same problem, provided that the unique aspect of the proposed solution is a key driver of the value created).**
    
    Our concept is novel in both ways mentioned in the question.
    
    1. Reputation & Roles is meaningfully different from other implementations because of its simplicity. Yes, many projects have tried to tackle the concept of reputation; however, they come with bells and whistles surrounding the core functionality. R & R is radically simple because blockchain is a radical concept - difficult enough to interact with, without extra features. We want R & R to be pure value, stripped of anything unnecessary, making it as easy as possible to onboard web2 users and everyday people while we improve the experience for crypto-natives.
    2. Our approach is unique because ATX DAO is, at most times, an in-person organization. This means that R & R needs to accommodate IRL experiences and be interoperable with the physical human experience. The way that this affects interactions, progress, conversations, and relationships will also have an effect on how R & R is implemented. It will make onchain Reputation tangible and lead to the development of unique systems. As to how this is done in a properly decentralized and permissionless way is yet to be determined. However we are confident that through development and research we will reach a conclusion that both developers and communities are satisfied with. It will most likely consist of a combination of onchain and offchain techniques.
    
    **Is your project likely to bring new builders to the Optimism ecosystem? If so, please describe how:**
    
    While it is true that this can be implemented on any EVM blockchain, we plan to incentivize builders to deploy on Optimism by creating a Reputation & Roles Factory smart contract ONLY on Optimism, where deploying instances of the project through the Factory will reward builders with OP tokens that were awarded as part of the requested funds of the grant.
    
    We plan to add Optimism branding anywhere that you see Reputation & Roles in the ATX DAO ecosystem. Two initial places we can see branding is being through our website and through reputation collection mechanisms.
    
    We hope that Optimism can be a long-term ecosystem partner for ATX DAO. Building R & R is a catalyst for a culture shift within the ATX DAO community, it will be a demonstration that building new applications is a viable way to contribute to the success of the organization. If Optimism enables this culture shift, Optimism will shape the builder culture itself.
    
    ATX DAO organizes in-person developer meetups, and we have yet to establish any loyalty to a specific ecosystem. Once R & R is completed and implemented, we will workshop it in these sessions and iterate on new ways to grow the project and build additional systems that can interact with it. All of this work would be done on Optimism, effectively making our developer meetups into Optimism meetups.
    
    We also plan to publicly recognize the Collective for their support through our social media channels. The fact that Optimism is the only ecosystem that we delegate to will bring authenticity to these communications. ATX DAO is an Optimism fan!
    
    **Is your project likely to improve the quality of developers in the Optimism ecosystem? If so, please describe how:**
    
    These systems are intended to contribute directly to the DAO ecosystem and the extended, but close Web3 ecosystem, which arguably consists of incredibly passionate builders and developers, the ones that intend to make a difference rather than a quick dollar. Moreso with Optimism holding those passions and pushing them even further.
    
    Additionally, it will help to make it easier to recognize the quality of developers in the Optimism ecosystem through the development of meritocratic reputation and governance structures.
    
    **Is your project likely to improve the commitment of developers in the Optimism ecosystem? If so, please describe how:**
    
    Developers will want to be committed as it will fulfill the innate desire to have one’s work recognized through the development of meritocratic reputation and governance structures. It helps to build trust around past contributions and allows for organizational structure to operate more effectively, and establishes reciprocal feedback loops which increase the commitment and quality of contributors by fairly recognizing them for their work.
    
    Additionally, since we are pushing for the Optimism ecosystem, then it will always be at the forefront of all conversations surrounding Reputation & Roles. Developers will look at ATX DAO as the prime example for implementation, thus will most likely deploy on Optimism. Through this, a similar effect will happen where the home for most successful ERC721s is still on Ethereum Mainnet, even with the wonderful advantages of L2s.
    
    **Describe whether you expect to deploy smart contracts on Optimism and, if so, how you expect users and developers to interact with those contracts:**
    
    ATX DAO’s smart contracts are already present on Optimism Mainnet. Thus, users and developers will interact with them through our website and developers additionally can interact with the monorepo.
    
    The monorepo will activate the ability for builders/implementers to interact with these smart contracts in many interfaces and environments, some even yet to be defined. We imagine websites, apps, and discord/other third party integrations.
    
    **Who are your founders?:**
    
    **NOTE: These are the founders of Reputation & Roles, not of ATX DAO**
    
    **Jesse Paterson** (@RealityCrafter) - Web3 Developer
    
    Jesse is a multidisciplinary UX Engineer with a background in both Front-End Engineering and Product Design. He has been building in the web3 space since joining Blockchain at Berkeley during its founding year (2016) and participating in the development of the world’s first undergraduate university-accredited blockchain course. He is a founding member of ATX DAO, a Local DAO working to unite Austin's web3 communities, empower artists and businesses to join the new digital economy, and educate government and policy makers.
    
    **Jacob Homanics** - Web3 and Video Game Developer
    
    Web3 Developer and Operator. Passionate about the concepts of DAOs, thus an active contributor to ATX DAO helping build smart contracts, websites, and handle operations. Also incredibly active in the Web3 ecosystem as a whole, supporting DeFi, NFTs, smart contracts, blockchains, and DApps. TechNERD in Optimism’s discord server helping close developer support tickets.  5+ years of experience building video games and working on game design concepts, along with 20+ years of active game playing experience including World of Warcraft, Runescape, Pokemon, Final Fantasy, and many many more.
    
    **What makes your founders well-positioned to accomplish your goals with this project (1-2 sentences on each)?:**
    
    Jacob is exceptional at understanding game mechanics and design through playing and making many video games. Additionally he is skilled in being able to operate in fast paced environments. Meanwhile he is super passionate about driving the success of Optimism and is contributing as a techNERD in Optimism’s discord to help developers solve issues/bugs.
    
    Jesse has been organizing online communities for cooperative projects with coordination across hundreds of players since 2012. He developed and iterated on the REP concept within ATX DAO and wrote the Roles and Reputation proposal. His experience with running communities and developing interfaces that are intuitive and easy to use will help inform the features and functionality of a complete well packaged reputation system.
    
     very nice proposal. Is this going to be composable? Let's say another developer's community wants to merge into this reputation system. How do you guys envision that sort of composability? Are you planning on using the attestation station tool somehow?
    
    The core system is incredibly composable and can be altered to fit the community’s specific needs. The only assumption with the Reputation Tokens is that they exist, there is effectively no standard to pull from. Acquiring 1200 Reputation Tokens with ATX DAO may display a different level of trust than acquiring 1200 Reputation Tokens with Optimism. The trust, authorities, responsibilities, thresholds, rewards, and benefits are implemented entirely by each individual community as they imagine them best for their community. This does introduce a level of confusion when comparing one system against the other and it would be up to the entity to realize the importance of the tokens in respect to where they have been implemented. We would love to dive deeper into this and get some feedback to mitigate confusion and complications. An entity could look at other successful implementations as example to pull inspiration from.
    
    As for the attestation station…We haven’t been familiar enough with the topic to really engage it with this product. However with our limited understanding, we can see the use for it in recognizing trusted token “distributors”. Another use case could be to further validate an entity’s rep tokens. When a distributor sends tokens somewhere, then they could make an attestation as well. “Tony.eth successfully merged a Pull Request and received 20 Reputation Tokens for doing so.” This would help clarify how an entity has obtained their tokens and validate that they came from a trusted source, further strengthening the trust or recognizing holes in an organization’s structures. There appears to be plenty of ways in which we could implement Attestations and we would be more than glad to explore the possibilities It also looks like the philosophy of the Attestation Station matches very closely to that of our philosophies: where we plan to create a completely open sourced, expansible, and flexible system for builders to go off of, a public good.. Additionally since Reputation & Roles is composable, then it could be possible to bake Attestations directly into an organization’s R & R systems.
    
    **Does your project solve a problem for the Optimism ecosystem?:**
    
    The problem doesn’t solve a problem specifically for the Optimism ecosystem, however it solves a problem for all of humanity.
    
    Look at this example:
    
    ATX DAO has 5000 Optimism Lifetime Tokens, meaning ATX DAO is heavily committed to Optimism.
    
    Someone from ATX DAO wishes to make a grant proposal, however they fear that since this is their first grant that they do not have a big name or have not built up enough trust in the Optimism ecosystem.
    
    This person also has 2000 ATX DAO Lifetime Tokens, meaning this individual is heavily committed to ATX DAO.
    
    Their fears are alleviated because there is a source of truth for their trust in the ATX DAO ecosystem because there is a source of truth for ATX DAO’s trust in the Optimism Ecosystem. Since ATX DAO is a trusted ecosystem, then the grantee immediately gains some level of trust from the Optimism Collective.
    
    **How does your proposal offer a value proposition for solving the above problem?:**
    
    Through Reputation & Roles you can now properly track an entity’s trust and provide them with meaningful authorities/responsibilities that are otherwise nonexistent in today’s society. This should become a staple, like being given a trophy or college degree.
    
    **Why will this solution be a source of growth for the Optimism ecosystem?:**
    
    The concept is intended for virtually any human to use these systems. Therefore, the number of active users on the systems are going to be incredibly vast and large. It solves several problems pertaining to entity trust and permissions by immediately making them clear and decentralized. entities can now have a clear display of their trust with any other given entity. Additionally, the roles solve the problem of permissioned power and authority.
    
    We believe that our core values and principles align nearly identically with the Optimism ecosystem. Thus, this concept will slide frictionlessly into the ecosystem.
    

- Example implementation in ATX from google doc
    
    
    # **ATX DAO : Roles & Reputation**
    
    ATX DAO now has over 200 members. We've reached the point where we should be able to further decentralize our operations and increase the agency of our member base. One of the ways that a DAO operates differently from standard centralized organizations is in how it grants agency to its members. Sufficiently decentralized DAOs should aim to enable the autonomy of their members through automated transparent systems rather than centralized administration.
    
    This proposed system will grant **Role** based permissions through **Reputation** tokens (REP).
    
    Reputation can be gained as a reward for contributing at the monthly Giving Circle, by hosting, attending, or volunteering at events, and through the team member rewards defined in project proposals.
    
    Once a member has accrued enough Reputation for a particular role, they can go to their [REP wallet on the member portal](https://members.atxdao.com/rep) and claim that role (through the [hats protocol](https://www.hatsprotocol.xyz/)). The associated hat token will then grant permissions based on the type of role it represents.
    
    **Role** - A title within the DAO that describes a member's contributions
    
    **Hat** - An ERC-1155 token that grants access to a set of DAO tooling permissions
    
    **Reputation** - A way to track contributions within the DAO entirely on-chain
    
    **Giving Circle** - A monthly event where DAO members can recognize and reward each other’s contributions. (By distributing 1000 USDC and 1000 REP)
    
    ## Permissions
    
    Platforms with access and administration rights that need to be distributed.
    
    - LinkedIn Admin
    - [Discord](https://discord.gg/gD3nrb74)
    - [Utopia](https://app.utopialabs.com/login)
    - Community Email (community@atxdao)
        - Luma Admin
    - [Gnosis Safe](https://app.safe.global/eth:0x407Cf0e5Dd3C2c4bCE5a32B92109c2c6f7f1ce23/home) Signer
    - [Charmverse](https://app.charmverse.io/atx-dao) Admin
    - [Charmverse](https://app.charmverse.io/atx-dao) Editor
    - REP Distributor
    - [Youtube Account](https://www.youtube.com/@atxdao)
    - [Github Team / Projects](https://github.com/ATXDAO)
    - Quicken*
    - Gilded*
    - [Calendar*](https://calendar.google.com/calendar/u/0/r?cid=Y19rNGgyMWg1aGoxMjd1c3ZuZjRsZ3Zia3ZkOEBncm91cC5jYWxlbmRhci5nb29nbGUuY29t)
    - [Snapshot](https://snapshot.org/#/atxdao.eth)
    - Domain Based Emails* (@atxdao.com)
    - [Twitter Account](https://twitter.com/ATXDAO)
    - [Instagram Account](https://www.instagram.com/atx.dao/)
    - *Access through gated document/application*
    
    ## Roles
    
    Each of these roles includes a threshold of REP that a member must reach in order to claim. Some of these roles include additional responsibilities and all are voluntary. Members are not required to assume a role once they reach the associated REP level. Roles and their associated permissions are also mutually exclusive - a member can only have one role at a time.
    
    **Permissions** - The tooling permissions granted to a role holder.
    
    **Initial Cohort** - Some of these roles have an initial cohort of members who fit the role due to past proposals and ongoing performance.
    
    - Permissions will be revoked for members who currently have access to the permissions tied to a role but are not included in the initial cohort
    - The initial cohort will be granted REP commensurate with the role.
    
    ### **Wardens** (5000 REP)
    
    *Responsible for critical DAO functions.*
    
    Wardens are contributors who tend to the regular critical operations of the DAO. They consistently devote time and energy to tending to the DAO’s needs without having the ability to “take a step back” from operations. Wardens are expected to manage urgent situations and core DAO infrastructure, be highly available for communications, are compensated monthly, and are held accountable by the community. They are expected to be transparent in their activities and available to teach DAO members about their work.
    
    Having this role indicates that the wearer has made substantial contributions to the DAO, to the point that they should get paid a stipend for their efforts.
    
    Wardens have built a history of substantial contributions to the DAO and serve such a crucial role to regular operations and progress towards the goals of the DAO that their work merits consistent compensation.
    
    Unlike the other roles which depend only on how much REP a member has accumulated, there is an additional requirement to be granted the Warden role. A multi-sig (simple majority) of all current DAO Stewards will need to approve new Wardens to allow them to wear the hat.
    
    Individuals that earn the Warden responsibility should not automatically expect to be compensated for the role. Any additional ongoing compensation for new Wardens must also be proposed and voted on by all Members, related to specific ongoing key business or social operations. Wardens receiving compensation are also expected to follow standard KYC practices. Should an eligible Warden not wish to dox themselves, the individual may elect to decline the Warden responsibility.
    
    **Permissions**
    
    - [Snapshot](https://snapshot.org/#/atxdao.eth) - Administration
    - Administrator Email (community@atxdao.com)
        
        The main email used as a recovery mechanism for lesser gated permissions.
        
    
    **Initial Cohort**
    
    *The initial Wardens have had their roles established via proposal.*
    
    ### **Stewards** (2500 REP)
    
    *DAO Leaders*
    
    Stewards embody the values of the DAO, understand how the organization operates, actively socialize and build relationships with the community, and facilitate the development of projects with other DAO members. Stewards are often leaders of current projects or successful completed projects and are not siloed by our three guilds. Stewards are encouraged to continue contributing in an impactful way to DAO projects and operations.
    
    Steward is a volunteer position, created with the intent to separate control of the treasury (through being a signer on the Safe) from those receiving direct payouts without community oversight (Wardens). Stewards can still receive Giving Circle payouts and have a paid position on a project, because these rewards have community oversight.
    
    As the face of the DAO from an organizational perspective, Stewards may be required to conform to KYC standards as we operate with other organizations.
    
    **Permissions**
    
    - REP Safe - Signer
    - [Gnosis Safe](https://app.safe.global/eth:0x407Cf0e5Dd3C2c4bCE5a32B92109c2c6f7f1ce23/home) - Signer
    - [Snapshot](https://snapshot.org/#/atxdao.eth) - Administration
    - [Discord](https://discord.gg/gD3nrb74) - Administration
    - Charmverse - Administration
    
    ### **Founder's Council** (1500 REP)
    
    The Founder's Council is the set of founding members who contributed to the DAO immediately following the Genesis membership round. They don't hold any special authority within the DAO, but are recognized for their belief in our mission and being the reason that we are here today.
    
    This is the only role that is not mutually exclusive with other roles. It is primarily an honorary title.
    
    ### **Contributors** (600 REP)
    
    *Regularly contributing to the DAO and being rewarded through the Giving Circle*
    
    Disciplines are a way for members to identify their specialization with a particular skill set and contribute to Guild projects. Organizing under disciplines helps identify members with the skill sets needed to complete Guild projects or improve operations.
    
    Following this proposal, a form will be available for members to apply for contributor status. The Stewards will review this list and grant the role and REP commensurate with the role to members with approved applications.
    
    **Permissions By Discipline**
    
    - Operations
        - Charmverse Moderation
        - Discord Moderation
    - Marketing and Events
        - [Twitter Account](https://twitter.com/ATXDAO)
        - [Instagram Account](https://www.instagram.com/atx.dao/)
        - Linkedin Admin Status
        - Marketing Email (marketing@atxdao.com)
            - [Youtube Account](https://www.youtube.com/@atxdao)
            - [Calendar](https://calendar.google.com/calendar/u/0/r?cid=Y19rNGgyMWg1aGoxMjd1c3ZuZjRsZ3Zia3ZkOEBncm91cC5jYWxlbmRhci5nb29nbGUuY29t) - Adding Events
    - Partnerships
        - Domain Based Email* (@atxdao.com)
    - Engineering
        - Github Team Member
    - Design
        - Figma Team Member
        
    
    ### **Active Members** (300 REP)
    
    *Participate in Community Activities & Events*
    
    - Charmverse Editor
    
    ### **Initiates** (20 REP)
    
    *New Members and Non-members*
    
    - Charmverse Viewers
    
    ## Reputation Control and Distribution
    
    There will be a Gnosis Safe on the polygon network with the same signers as the ATX DAO treasury Safe (the DAO Stewards). This REP Safe will have Admin, Minter and Soulbound Transferer rights over the REP token and will use those rights in accordance with ATX DAO Snapshot proposals.
    
    An Admin can pause smart contract interaction, grant/revoke other roles, and set max possible amount of tokens that can be minted within a single transaction. The likely actor(s) are a multi-sig/ledger explicitly with selected members of the DAO.
    
    A Minter can mint pairs of tokens and can transfer them to an address which has been granted the Distributor Role. The likely actor(s) are a multi-sig/ledger explicitly with selected members of the DAO.
    
    A Soulbound Transferer can send Soulbound tokens on behalf of an address to another address.
    
    ### Numeric Rationale
    
    **Warden** (Approximately 12 months of active and engaged membership)
    
    - Attended 40 minor events (400 REP)
    - Attended 10 major events (300 REP)
    - Submitted contributions to 6 giving circles (1200 REP)
    - Made 8 minor project contributions (1600 REP)
    - Made 3 major project contributions (1500 REP)
    
    (Total = 5000 REP)
    
    **Steward** (Approximately 6 months of active and engaged membership)
    
    - Attended 22 minor events (220 REP)
    - Attended 6 major events (180 REP)
    - Submitted contributions to 3 giving circles (600 REP)
    - Made 5 minor project contributions (1000 REP)
    - Made 1 major project contributions (500 REP)
    
    (Total = 2500 REP)
    
    **Contributor** (Approximately 3 months of active and engaged membership)
    
    - Attended 11 minor events (110 REP)
    - Attended 3 major events (90 REP)
    - Submitted contributions to 2 giving circles (400 REP)
    
    (Total = 600 REP)
    
    **Active Member** (Approximately 2 months of active and engaged membership)
    
    - Attended 7 minor events (70 REP)
    - Attended 1 major event (30 REP)
    - Submitted contributions to 1 giving circle (200 REP)
    
    **Initiate** (Approximately 3 months of active and engaged membership)
    
    - Attended 2 minor events (20 REP)
    
    ## Role Removal
    
    ### Bad Actors
    
    We will need a process for identifying and removing bad actors from their roles in the DAO.
    
    **Examples of Bad Actors**
    
    - A hacker who steals a NFT
    - Members who do something inappropriate like assault another member
        
        (verbally, physically, socially, etc...)
        
    
    **Removal Process**
    
    1. **Reporting**: Someone reports an issue to a DAO Steward or Warden.
    2. **Resolution**: The DAO Stewards privately vote on whether or not to remove the bad actor.
    3. **Removal**: Guild Guides use the REP Safe to remove all REP from an individual identified as a Bad Actor. This would also revoke all of their hats based permissions.
    4. **Override**: When the decision is publicized, the Guild Guides are responsible for creating a Snapshot proposal which states the rationale for removing the bad actor with a two week voting period to override the DAO Guide decision and reinstate the member with all of their REP.
    
    ### Inactivity
    
    In order to prevent a DAO shutdown in which the number of inactive signers on the Safe is greater than the active signers, we suggest a measure of activity for Stewards.
    
    **Activity Meter**
    
    Each Steward has an activity meter. It increases by 1 everyday and is reset to zero if the Safe interacts with their wallet in any way (they sign a transaction or are sent funds). If the activity meter reaches 90 then the user is considered inactive, their role as Steward is removed and the remaining Stewards are prompted to remove them from the Safe.
    

## Optimism Milestones

[Reputation & Roles Milestone Tracking - ATX DAO - 📢 Updates and Announcements / Grant Updates - Optimism Collective](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d/Reputation%20&%20Roles%20Milestone%20Tracking%20-%20ATX%20DAO%20-%20%20a4cddca998be4fa7b34c1dcd4c7d6182.md)

# Potential Integrations with Optimism Fractal

You can see a detailed analysis of potential integrations with Roles and Reputations at Optimism Fractal in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20integrations%20with%20Roles%20and%20Reputations%20Sy%20c85bbe3e9a8548bfb3ccf6a4aea29fde.md). Below you can also find tasks in this project with questions, benefits, and other information about potential integrations with Roles and Reputations. The highest priority in this project to is to answer questions about Roles and Reputations, which can be found in the first task below.

**Answer Questions about Integrating with Roles and Reputations:**

- See [Ask and Answer Questions about Integrating with Roles and Reputations](Ask%20and%20Answer%20Questions%20about%20Integrating%20with%20Ro%201d7979738a9f49bdb1deba384035553d.md)

**Use Cases and Benefits of Integrating with Roles and Reputations with Optimism Fractal:** 

- See [Describe how Roles and Reputations can benefit Optimism Fractal](Describe%20how%20Roles%20and%20Reputations%20can%20benefit%20Opt%2058f681b27cf341e2aefb9e9aac8354f3.md)

**Implementation for Optimism Fractal and Fractal Communities:**

- See [Define Roles and Create Organizational Structure for Optimism Fractal with Hats Protocol ](Define%20Roles%20and%20Create%20Organizational%20Structure%20f%20042f5b6aba70437b9273260a25d1a1b3.md)

**Message Abraham about Roles and Reputations:**

- See [Message Abraham about Jacob’s Work with Hats Protocol](Message%20Abraham%20about%20Jacob%E2%80%99s%20Work%20with%20Hats%20Proto%20afaac4f2463548479bbe379aff45972e.md)

### 

### Personal Notes

- I learned a lot about Roles and Reputations from the BuidlGuild videos and would like to document some of the learnings to make them more easily absorbable. Here are some interesting features:
    - The UI header automatically updates with new items based upon the Reputation holdings
    - The card, multi-card, mini, and other views are very interesting.
        - It’s inspiring to think about how Respect can be displayed in each of these views
        - The view of Respect as a card is also quite interesting. The Respect Game can become like a card game, which has been proven quite well in pokemon, magic the gathering, and many other card games
    - There are some websites that may be good to screenshot or explore
    - Each component of the front-end seems high configurable
    - [Consider implementing ERC 404 Token Standard for Respect](Consider%20implementing%20ERC%20404%20Token%20Standard%20for%20R%20c9cab7cc0ee54f71bca5ad3c2c1c7b18.md)
    - [Research and consider developing with scaffold.eth to build features and experiences for Optimism Fractal](Research%20and%20consider%20developing%20with%20scaffold%20eth%20fcb9e730ac514ca79e0db426c40dc3df.md)

I see lots of potential for Optimism Fractal to implement Roles and Reputations and I think it’s an amazing project that could synergize very nicely with the Respect Game. I really like the front-end UI, modular design, integrations with Hats Protocol, and all the documentation that you’re creating to help people better understand the project. It’s very aligned with the work that we’re doing at Optimism Fractal, so I’ve been thinking a lot about implementing Roles and Reputations into the apps that we’re developing and our integrations with Hats Protocol.1mth

One thing in particular that’s inspiring is how the front-end can enable interaction with roles and reputation in a gaming kind of experience. The front-end that you created reminds me of UI elements in a MMORPG, strategy civilization building game, or other other kinds of game with interactive menu screens. I think that this front-end for Roles and Reputations can make Hats Protocol more visually intuitive and easy to use, while also giving more meaning and utility to reputation tokens like Respect. Imbuing Respect with more meaning, utility, and accessibility is very important for Optimism Fractal and the apps we’re building for the Respect Game.