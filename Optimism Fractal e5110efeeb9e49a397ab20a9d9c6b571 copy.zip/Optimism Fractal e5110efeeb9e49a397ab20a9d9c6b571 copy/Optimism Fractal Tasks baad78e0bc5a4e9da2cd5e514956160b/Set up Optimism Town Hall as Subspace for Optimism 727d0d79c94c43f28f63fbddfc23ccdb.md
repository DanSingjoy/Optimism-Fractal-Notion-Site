# Set up Optimism Town Hall as Subspace for Optimism Fractal on Snapshot

Assignee: Dan Singjoy
Due: May 3, 2024
Project: Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md)
Status: Done
Task Summary: This task aims to set up Optimism Town Hall as a subspace for Optimism Fractal on Snapshot. The goal is to establish a dedicated space for discussions and decision-making related to Optimism Fractal within the broader Optimism community. With this setup, participants will be able to engage in meaningful conversations and contribute to the development and governance of Optimism Fractal.
Summary: The Optimism Town Hall has been set up as a subspace for Optimism Fractal on Snapshot. An error was fixed by signing out and signing in again.
Created time: May 20, 2024 4:04 PM
Last edited time: May 20, 2024 4:15 PM
Created by: Dan Singjoy

I think i just set it up properly. I set OF as the main space for OTH, and OTH as the subspace for OF

I fixed this error by signing out and signing in again

![Untitled](Set%20up%20Optimism%20Town%20Hall%20as%20Subspace%20for%20Optimism%20727d0d79c94c43f28f63fbddfc23ccdb/Untitled.png)