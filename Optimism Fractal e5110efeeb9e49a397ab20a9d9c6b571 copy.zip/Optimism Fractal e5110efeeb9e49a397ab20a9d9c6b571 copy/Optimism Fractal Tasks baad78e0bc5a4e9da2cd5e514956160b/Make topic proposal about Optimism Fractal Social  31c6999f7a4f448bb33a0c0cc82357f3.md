# Make topic proposal about Optimism Fractal Social Media at Optimism Town Hall

Project: Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md)
Status: Done
Task Summary: This task aims to create a topic proposal for the Optimism Fractal Social Media presentation at the Optimism Town Hall. The proposal will explore the concept of Optimism Fractal Social Media and its potential impact on fostering a positive and optimistic online community. The proposal will be presented by Dan Singjoy, providing a comprehensive overview of the topic.
Summary: No content
Created time: July 17, 2024 8:39 PM
Last edited time: July 17, 2024 9:50 PM
Created by: Dan Singjoy
Description: No content

## 🌐 Fractal Social Media

How can Optimism Fractal enhance social media?

Upvote this topic to explore the rich history of fractal social platforms, plans for an Optimism Fractal social media app, the potential for Respect on protocols like Farcaster and Lens, and how the Respect Game can empower the future of onchain social media networks. 

I recently created project with more details about Optimism Fractal social media, which you can see [here](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md).

![edencreators_phone_screen_with_sunflowers_below_it_and_the_sky__f65f19e7-0992-4e94-a781-1347d8f2b9e2.png](Create%20Topic%20Proposals%20for%20OF%2035%202fb1f588a23241b4baab19c66b018235/edencreators_phone_screen_with_sunflowers_below_it_and_the_sky__f65f19e7-0992-4e94-a781-1347d8f2b9e2.png)