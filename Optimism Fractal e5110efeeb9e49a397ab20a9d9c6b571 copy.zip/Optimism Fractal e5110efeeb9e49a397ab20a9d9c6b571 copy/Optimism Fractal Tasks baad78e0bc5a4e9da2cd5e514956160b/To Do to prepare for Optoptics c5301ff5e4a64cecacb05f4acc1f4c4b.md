# To Do to prepare for Optoptics

Project: Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md)
Status: Done
Task Summary: This task aims to prepare for Optoptics by organizing sections into subtasks, testing the snapshot feature, reviewing the first draft, creating a list of participants with over 100 respect, and discussing the plan with Rosmari. Completed by Dan Singjoy.
Summary: To prepare for Optoptics, organize sections into subtasks, test snapshot ranking, review the first draft, create a list of participants with over 100 respect, and discuss the plan with Rosmari.
Created time: May 20, 2024 3:58 PM
Last edited time: May 20, 2024 4:23 PM
Created by: Dan Singjoy

- [x]  organize the following sections below into subtasks in the optimism fractal notion project for cagendas
    - [x]  move/sync the different questions/answers into different tasks

- [x]  [Create and share registration poll for Optimism Fractal](Create%20and%20share%20registration%20poll%20for%20Optimism%20Fr%205ef25ba5510a4b5e80293ad927a26b48.md)

- [x]  test this to see if snapshot allows people can rank order just a few options even if there are many more options on the list
    - Participants can rank order the topics at any time to select the first topic. You’re welcome to rank order as many or as little options as you’d like. Put the topic that you

- [x]  review the first draft to see if there’s anything missing from the final version that i wanted to include
    - Find it [here](Create%20Introductory%20post%20for%20Optopics%20at%20Optimism%20%208a4b346168bb412b80d1674b5767263a.md) at the bottom of [Create Introductory post for Optopics at Optimism Town Hall](Create%20Introductory%20post%20for%20Optopics%20at%20Optimism%20%208a4b346168bb412b80d1674b5767263a.md)

- [x]  write a list before the event and show who has over 100 respect before starting so we know who to look for in zoom chat

- [x]  discuss the plan with rosmari and see if everything sounds good with her
    - [x]  ask; can she do the timer and counting of who has 100 respect during event?