# quote tweet and cast posts about OF 34 and EF 105

Assignee: Dan Singjoy
Due: June 17, 2024
Project: Prepare for OF 34 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2034%200c98b5f4f06240b688d1caf3b6038e9b.md)
Status: Done
Task Summary: This task aims to quote tweet and cast posts about OF 34 and EF 105. The page provides information about the assignment, including the creator, assignee, due date, status, and timestamps of creation and last edit.
Summary: No content
Created time: July 10, 2024 10:42 PM
Last edited time: July 12, 2024 11:30 AM
Created by: Dan Singjoy
Description: No content