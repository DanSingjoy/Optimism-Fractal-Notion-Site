# Highly recommended by Jesse Pollak on farcaster - Onchain Dreamers - Where dreams find their way.

Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
Status: Not started
Task Summary: This task aims to provide a summary and introduction for the page titled "Onchain Dreamers - Where dreams find their way." It showcases a global DAO of pioneers, builders, and creators who are united by the dream of expanding the future of the Onchain Economy on Base. The page highlights the benefits of joining the community, such as connecting with passionate creators, learning from industry leaders, accessing exclusive opportunities and funding, and contributing to the growth of the Onchain economy.
Summary: Onchain Dreamers is a global DAO focused on expanding the future of the Onchain Economy on Base. They offer opportunities for creators to connect, collaborate, and innovate together, guided by industry leaders. They also provide exclusive funding and support for ecosystem projects and contribute to the growth of the Onchain economy. Their pillars are community, equality, and liberty.
Created time: May 29, 2024 9:55 AM
Last edited time: June 3, 2024 6:27 PM
Created by: Dan Singjoy

[https://www.onchaindreamers.com/](https://www.onchaindreamers.com/)

[Benefits](https://www.onchaindreamers.com/benefits)[Manifesto](https://www.onchaindreamers.com/our-manifesto)[Vision](https://www.onchaindreamers.com/read-me)[FAQs](https://www.onchaindreamers.com/frequently-asked-questions)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231dbdc3d16f2cc97ff2c8_Frame%20770778.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231dbdc3d16f2cc97ff2c8_Frame%20770778.webp)

where dreams find their way

We are a global DAO of pioneers, builders and creators united by the dream of expanding the future of the Onchain Economy on Base. Powered by Onboard Protocol.

[Apply](https://www.onchaindreamers.com/apply)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231dbdacf4936897ba0334_Frame%20770769.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231dbdacf4936897ba0334_Frame%20770769.webp)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8e9657de5ebf67cc46_Frame%20770768.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8e9657de5ebf67cc46_Frame%20770768.webp)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8ee6689c471c973e4c_Frame%20770779.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8ee6689c471c973e4c_Frame%20770779.webp)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8e0fabe6fc853d3ad7_Frame%20770770.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8e0fabe6fc853d3ad7_Frame%20770770.webp)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8eff27ef939251c7fc_Frame%20770771.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8eff27ef939251c7fc_Frame%20770771.webp)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8ebddd1c6770102704_Frame%20770774.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66231f8ebddd1c6770102704_Frame%20770774.webp)

[https://www.notion.so'https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/663008fee36e9f4f9200e2aa_0429-poster-00001.jpg'](https://www.notion.so'https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/663008fee36e9f4f9200e2aa_0429-poster-00001.jpg')

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/662fb6a7096aed69f1e93882_Group%2095.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/662fb6a7096aed69f1e93882_Group%2095.webp)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/662fb6a7e2da3979bffe047c_Vector%2011.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/662fb6a7e2da3979bffe047c_Vector%2011.webp)

Onchain Dreamers… where dreams find their way.

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b89f8bd978ca0c3d493_Group%2041.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b89f8bd978ca0c3d493_Group%2041.webp)

## Join a global network of pioneers

Connect with passionate creators globally. Collaborate, learn, and innovate together. Push boundaries and build meaningful projects.

[Apply](https://www.onchaindreamers.com/apply)

## Benefit from the guidance of industry leaders

Learn from onchain builders through fireside chats, Q&As, and mentorship to navigate the industry's challenges and opportunities.

[Apply](https://www.onchaindreamers.com/apply)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b893dff4b69120fea13_Group%2042-1.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b893dff4b69120fea13_Group%2042-1.webp)

We empower you, so you can go and be whatever you want to be.

We empower you, so you can go and be whatever you want to be.

We empower you, so you can go and be whatever you want to be.

We empower you, so you can go and be whatever you want to be.

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b89cc507ec9bfe3082b_Frame%20770723.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b89cc507ec9bfe3082b_Frame%20770723.webp)

## Unlock exclusive opportunities and funding

Access curated grants, funding, and collaborations to support your ecosystem projects and ideas.

[Apply](https://www.onchaindreamers.com/apply)

## Contribute to the growth of the Onchain economy

Make an impact and contribute to the collective growth of the Onchain ecosystem.

[Apply](https://www.onchaindreamers.com/apply)

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b89735969c08bb336a3_Group%2042.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66226b89735969c08bb336a3_Group%2042.webp)

We empower you, so you can go and be whatever you want to be.

We empower you, so you can go and be whatever you want to be.

We empower you, so you can go and be whatever you want to be.

We empower you, so you can go and be whatever you want to be.

## Our Pillars

We stand for fairness, freedom, and shared success, as we fearlessly create our own future.

01

Community

We believe that true and lasting success is not found alone, but in the Collective. We only win when we win together.

02

Equality

We believe in leveling the playing field. No barriers. No gatekeepers. No matter what.

03

Liberty

We believe that those who create their own reality aren’t the people who accept the status quo, it’s the people who dare to challenge it.

![https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66228ffd46ccb8ed17688329_Join-us.webp](https://assets-global.website-files.com/662252c07cf7a1c3f4f7e576/66228ffd46ccb8ed17688329_Join-us.webp)

## Dare to dream and join us on the journey

[Apply](https://www.onchaindreamers.com/apply)