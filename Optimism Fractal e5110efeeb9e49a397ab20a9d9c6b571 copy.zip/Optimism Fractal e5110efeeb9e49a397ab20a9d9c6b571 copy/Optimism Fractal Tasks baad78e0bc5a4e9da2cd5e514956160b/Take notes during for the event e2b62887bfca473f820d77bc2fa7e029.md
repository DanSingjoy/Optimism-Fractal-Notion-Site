# Take notes during for the event

Project: Prepare for OF 28 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2028%2055526595a95345fd888501f23774c254.md)
Status: Not started
Task Summary: This task aims to provide a space for participants to take notes during the event. It was created by Dan Singjoy and is currently in the "Not started" status. The page allows for organized note-taking and serves as a valuable resource for capturing important information and insights.
Summary: No content
Created time: May 25, 2024 5:28 PM
Last edited time: May 25, 2024 9:29 PM
Created by: Dan Singjoy