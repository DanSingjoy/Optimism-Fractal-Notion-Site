# Review introductory notes about this project to create system for recording and publishing breakout groups

Project: Create System for Recording and Publishing videos of breakout groups (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20System%20for%20Recording%20and%20Publishing%20videos%20%20cd0e4f5b11f94662867b711f1592f66c.md)
Status: In progress
Task Summary: This task aims to review and create a system for recording and publishing breakout groups, as well as address questions regarding who would record the rooms, where and how they would be published, and what the long-term and short-term plans are. The page provides an overview of the project, including current practices and ideas for scaling and improving the process.
Summary: This document discusses the project to create a system for recording and publishing breakout groups. It mentions the current status of video recordings and sharing, proposes ideas for a more comprehensive system, and raises questions about who would record breakout rooms, where and how they would be published, and future plans. It also suggests using leads to scale the recording and sharing process, and explores options for publishing and storing videos.
Created time: July 17, 2024 8:31 PM
Last edited time: July 17, 2024 8:31 PM
Created by: Dan Singjoy
Description: This document discusses the project to create a system for recording and publishing breakout groups. It mentions the current status of recording and publishing videos, the idea of posting videos and notes in an organized system, and questions to consider for a more comprehensive system. It also suggests adding recording and sharing breakout rooms as a task for leads and the potential for producing videos and clips for each breakout group. The document raises questions about the best way to proceed and suggests alternative platforms for publishing and storing videos.

- Alex asked if videos of breakout rooms are recorded at the end of our 15th event. You can see a brief discussion about this [here](https://www.youtube.com/watch?v=BbqnBucgKHg&t=4960s)

- Currently the videos of Dan’s breakout group are published on YouTube and Rosmari’s previous breakout group are saved on google drive

- One of the main value propositions of Optimism Fractal is that it’s a great place to promote your work and we produce videos, but right now only one breakout room video is being produced and one is being recorded but not publicly shared

- Everyone is welcome to record their breakout rooms and share their video in the [Optimism Fractal](../../Optimism%20Fractal%20e5110efeeb9e49a397ab20a9d9c6b571.md) notion site or discord
    - One idea is that we could post the videos from each breakout group in [Weekly Contributions](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Weekly%20Contributions%201c90e50f1e23408080b41c562d0dcd0b.md). This would create an organized system that makes it easy to find videos and notes about each person’s contributions.
        - Yes this is a good idea

- To create a more comprehensive system where all videos are recorded and shared, there are some questions that we’d need to answer, such as:
    - who would record breakout rooms as Optimism Fractal grows
    - where and how they would be published
    - what we want to do
    
- We could add recording and sharing the breakout room as a task for leads. You can see the following draft project for more details about this  [Formalize and Request Leads in Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Formalize%20and%20Request%20Leads%20in%20Optimism%20Fractal%201fb1919236b64800a839d21cbecfa306.md).
    - This could allow us to scale to thousands of breakout groups while making videos for each room, which could be really interesting

- Eventually it could be great to produce the videos of each breakout group, as well as clips for each person’s presentations
    - It does take time to make a thumbnail, title, and YouTube description if we want to make it look nice
    - The respect game enables a very powerful video production and promotion process that will be increasingly helpful as we get more resources to produce videos
        - I shared some ideas about this last year at [EdenCreators.com/dams](http://EdenCreators.com/dams) and have thought a lot about how we could make many video clips from each fractal meeting.
    
- What is the best way to do this going forward?
    - What is the best short term plan?
    - What is the best long term plan?

- Where should videos be published and stored?
    - Right now our videos are all on google services, which isn’t independent
    - Eden on EOS published on IPFS instead of YouTube
    - Arweave, Zora, Glass Protocol, and Filecoin may be options

- This is an early draft project and will be updated soon. Feel free to edit or add to it as you see fit :)