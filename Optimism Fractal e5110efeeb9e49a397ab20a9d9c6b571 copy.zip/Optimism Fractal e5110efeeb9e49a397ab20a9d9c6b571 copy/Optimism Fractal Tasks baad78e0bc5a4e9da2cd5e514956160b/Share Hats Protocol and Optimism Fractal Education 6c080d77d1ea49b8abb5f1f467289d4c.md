# Share Hats Protocol and Optimism Fractal Educational and Communications Resources

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: No content
Created time: April 25, 2024 4:20 AM
Last edited time: April 25, 2024 4:21 AM
Created by: Dan Singjoy

## Description

## Share Hats Protocol and Optimism Fractal Resources

I added a link to this telegram group in the [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md) so that anyone looking at the Optimism Fractal notion site can find it. I’ll also add a new page called communication channels where I’ll add this group as well and I plan to share a link to this group in the Optimism Fractal discord development channel so any builders interested in exploring integrations can find it 

- [ ]  add to [Communication Channels](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Communication%20Channels%20a530be4a7458420785a6ca98ea7d182d.md)
- [ ]  post in OF Dev chat on discord
- [ ]  post on farcaster
- [ ]  add to [Education Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Education%20Hub%20225efc918f9f4644a39448be1eb3c7f0.md) once developments are more complete