# Review Hodlon’s Quest to integrate Hats Protocol with Optimism Fractal

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), Explore Integrations of Quests with the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Integrations%20of%20Quests%20with%20the%20Respect%20Ga%202a4d3601ec8c4f10b683a139862dd9e7.md)
Status: Not started
Task Summary: This task aims to review Hodlon's Quest for integrating Hats Protocol with Optimism Fractal. The objective is to evaluate the progress, challenges, and outcomes associated with this integration, ensuring a comprehensive understanding of the project's current status and future potential.
Summary: The document outlines a review of Hodlon’s quest to integrate Hats Protocol with Optimism Fractal, which is currently not started. It includes links to relevant quests and Discord messages for further information.
Created time: January 12, 2024 10:14 PM
Last edited time: September 11, 2024 11:04 AM
Created by: Dan Singjoy
Description: The document outlines a review of Hodlon's quest to integrate Hats Protocol with Optimism Fractal, created by Dan Singjoy. The quest is currently not started, and it includes links to relevant resources and Discord messages related to the integration efforts.

## Pretext

[Review ideas from Bitbeckers and Tadas about Quests](Review%20ideas%20from%20Bitbeckers%20and%20Tadas%20about%20Quest%20e06ecdbd38e34289a08f4da4fb7aaa0f.md) 

## Review Hodlon’s Quest

![[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)](Review%20Posts%20about%20Hats%20Protocol%20in%20Optimism%20Fract%20414959d259014507896f2894d27a054a/Untitled%208.png)

[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)

![[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)[https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056](https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056)](See%20how%20the%20Hats%20Protocol%20community%20is%20using%20Quest%202274fa76d3f1416a9a888af1001de546/Untitled.png)

[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)[https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056](https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056)

![[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)](Review%20Posts%20about%20Hats%20Protocol%20in%20Optimism%20Fract%20414959d259014507896f2894d27a054a/Untitled%207.png)

[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)

**Discord messages:**

[https://discord.com/channels/1164572177115398184/1186376309744619560/1193992790854619237](https://discord.com/channels/1164572177115398184/1186376309744619560/1193992790854619237)

**Hats Protocol protoDAO Season 1 Quests:** [https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)[https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056](https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056)

**Quest for** **Integrating Hats Protocol with Optimism Fractal:** [https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)