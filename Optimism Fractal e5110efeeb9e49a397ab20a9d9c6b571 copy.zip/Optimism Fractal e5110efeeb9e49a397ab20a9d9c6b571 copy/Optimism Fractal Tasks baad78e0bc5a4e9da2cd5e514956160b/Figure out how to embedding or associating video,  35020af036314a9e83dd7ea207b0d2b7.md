# Figure out how to embedding or associating video, promotional, and educational data in Optimism Fractal NTTs

Project: Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md), Build Optimism Fractal Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md)
Status: In progress
Summary: The document discusses the possibility of embedding or associating video, promotional, and educational data in Optimism Fractal NFTs. It suggests including links to videos and/or the website in the metadata of the NFTs, along with a brief description of Optimism Fractal. The document emphasizes the importance of simplicity and having a website for promoting the event.
Created time: December 30, 2023 5:51 PM
Last edited time: January 13, 2024 5:12 PM
Created by: Dan Singjoy

Would it be possible to include the link to the video and/or our website in the metadata of the NFT?

As well as a brief description of Optimism Fractal in the metadata?

Maybe best to keep it simple, though at least a website would be helpful for promoting the event so people can find it when browsing other’s links