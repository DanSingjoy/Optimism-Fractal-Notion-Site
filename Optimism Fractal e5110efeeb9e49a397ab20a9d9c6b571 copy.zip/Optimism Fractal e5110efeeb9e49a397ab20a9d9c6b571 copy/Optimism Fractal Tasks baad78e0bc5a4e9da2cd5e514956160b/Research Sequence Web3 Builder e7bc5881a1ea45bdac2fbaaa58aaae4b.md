# Research Sequence Web3 Builder

Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md)
Status: Not started
Task Summary: This task aims to provide a 2-4 sentence summary/intro for the Research Sequence Web3 Builder page. The Research Sequence Web3 Builder is a platform that allows users to create and customize their own decentralized applications (DApps) using Web3 technologies. With a focus on simplicity and accessibility, users can easily design and deploy their DApps without the need for extensive coding knowledge. Explore the features and capabilities of the Research Sequence Web3 Builder to empower your journey in the world of Web3 development.
Summary: This document provides information about the Research Sequence Web3 Builder. It includes the status, creation and last edited time, and links to the Sequence website's landing page, privacy policy, and terms of use.
Created time: May 1, 2024 11:42 AM
Last edited time: May 10, 2024 11:45 AM
Created by: Dan Singjoy

[https://sequence.build/landing](https://sequence.build/landing)

![share.png](Research%20Sequence%20Web3%20Builder%20e7bc5881a1ea45bdac2fbaaa58aaae4b/share.png)

Sequence uses cookies and similar technologies to provide you with personalized content, improve site performance, and conduct analytics. By using the Sequence website or other online services, you consent to the practices described in our [Privacy Policy](https://sequence.build/privacy) and [Terms of Use](https://sequence.build/tou).