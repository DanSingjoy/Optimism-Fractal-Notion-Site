# Explore integrations with Hats Protocol for educational course certifications

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: Explore integrating Hats Protocol with course infrastructure like Quest3 to enhance learning about fractals, specifically for FractalJoy Courses.
Parent-task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created time: March 18, 2024 7:21 PM
Last edited time: March 18, 2024 8:11 PM
Parent task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created by: Dan Singjoy

## Description

- Is it possible to connect Hats Protocol with some kind of course infrastructure such as Quest3 to facilitate learning about fractals?

- This could be helpful for FractalJoy Courses and [Formalize and Request Leads in Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Formalize%20and%20Request%20Leads%20in%20Optimism%20Fractal%201fb1919236b64800a839d21cbecfa306.md)