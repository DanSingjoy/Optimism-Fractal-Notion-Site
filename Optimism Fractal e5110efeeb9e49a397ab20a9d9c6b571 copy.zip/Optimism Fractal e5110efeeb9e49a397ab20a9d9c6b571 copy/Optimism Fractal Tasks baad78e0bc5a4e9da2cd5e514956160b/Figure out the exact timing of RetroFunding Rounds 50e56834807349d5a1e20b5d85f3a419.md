# Figure out the exact timing of RetroFunding Rounds

Project: Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md)
Status: Not started
Summary: No content
Created time: April 10, 2024 9:28 PM
Last edited time: April 10, 2024 9:29 PM
Created by: Dan Singjoy

## Description

- [ ]  figure out the exact length of RetroFunding listen again to jonas’ answer- i think he said 2.5 months but he provided more details about how it will be quicker and previously it was also 2.5 months
    - Each round will last about two and half months.
    - The amount of rewards for each round will be announced 8-12 weeks before its start.

- Optimism announced the next four rounds of RetroFunding (aka RetroPGF). More details in this [video](https://drive.google.com/file/d/1tEgcnEPWvb0IOVmHZEBt8w3ySK6Vj-sY/view?usp=sharing) and [recap](https://gov.optimism.io/t/optimism-community-call-recaps-recordings-thread/6937/33)