# Join Hats Protocol ProtoDAO

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: In progress
Task Summary: This task aims to facilitate participation in the Hats Protocol ProtoDAO by outlining the steps necessary to join the community. Members are required to sign the community agreement and claim their Hats Community Member hat, which grants access to exclusive communication channels like the Telegram group.
Summary: To join the Hats Protocol ProtoDAO, sign the community agreement and claim the Hats Community Member hat for access to the Telegram group. Consider discussing this in a Discord thread.
Created time: January 12, 2024 10:10 PM
Last edited time: September 26, 2024 5:06 PM
Parent task: Join Hats Community (Join%20Hats%20Community%208a1d178643654de0a1c8038fc3fb2ab3.md)
Created by: Dan Singjoy
Description: To join the Hats Protocol ProtoDAO, sign the community agreement and claim the Hats Community Member hat for access to the Telegram group. Consider discussing this in a Discord thread.

## Description

You can join here by signing our community agreement and (simultaneously) claiming the Hats Community Member hat, which comes with hat-gated permission to join the telegram: 

[https://community.hatsprotocol.xyz](https://community.hatsprotocol.xyz) 

- [ ]  Review community agreement

[https://twitter.com/hatsprotocol/status/1735691285321875541](https://twitter.com/hatsprotocol/status/1735691285321875541)

- Older Notes
    
    
    I’m thinking about joining the Hats ProtoDAO to join their telgram chat as Spencer explained in the presentation. 
    
    - [ ]  Consider if it makes sense to make a thread in discord about this