# Create Introductory post for Optopics at Optimism Town Hall

Project: Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md)
Status: Done
Task Summary: This task aims to create an introductory post for Optopics at the Optimism Town Hall. Optopics is an innovative consensus game designed to enhance discussions by allowing community members to propose, vote, and coordinate dynamic discussion topics during the event. It aims to optimize meeting time, empower community control, and foster structured yet flexible conversations.
Summary: This document is an introductory post for Optopics at the Optimism Town Hall. Optopics is an innovative consensus game designed to enhance discussions by allowing community members to propose, vote, and coordinate dynamic discussion topics during the event. It aims to optimize meeting time, empower community control, and foster structured yet flexible conversations. The post provides an overview of Optopics, its game rules, benefits, and encourages participation and feedback from the community.
Created time: May 19, 2024 9:35 AM
Last edited time: May 21, 2024 3:56 PM
Created by: Dan Singjoy

## Introduction

This task aims to create an introductory post for Optopics at the Optimism Town Hall. Optopics is an innovative consensus game designed to enhance discussions by allowing community members to propose, vote, and coordinate dynamic discussion topics during the event. It aims to optimize meeting time, empower community control, and foster structured yet flexible conversations.

**Table of Contents**

# Introductory Post

[Introducing OPTOPICS](Create%20Introductory%20post%20for%20Optopics%20at%20Optimism%20%208a4b346168bb412b80d1674b5767263a/Introducing%20OPTOPICS%20ef3bf6a9cc204ddfb0115b60af1c9d6e.md)

# Final Draft

## **Introducing Optopics**

Hello everyone! 

I'm thrilled to introduce **OPTOPICS**, an innovative consensus game crafted to enrich our discussions at Optimism Town Hall. OPTOPICS is a new Cagendas game mode that allows respected community members to propose, vote, and dynamically coordinate discussion topics during our events. 

OPTOPICS leverages [Respect](https://optimystics.io/respect) to make community events more efficient, enjoyable, and productive. This collaborative agenda game is designed to optimize our meeting time by providing a simple structure, facilitating more interactive conversations, and helping us focus on what’s most important to the community. It’s a fun way to organize events that taps into the wisdom of our community to more effectively grow Optimism Fractal and maximize our impact for the Optimism Collective. 

You can upvote the topic proposal to play Optopics in this [snapshot poll](https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff). If this topic proposal is approved, we’ll play Optopics according to the following rules during this week’s Optimism Town Hall:

## **Game Rules**

The game begins at 18:00 UTC at the Optimism Town Hall. The main dynamics of gameplay are oriented around suggesting topics, allocating votes on topics, and transitioning to different topics. 

### Suggesting and Voting on Topics

Optopics allows participants to easily suggest discussion topics then spread voting power across multiple discussion topics at any time.

- **Suggest topics:** Starting at 17 UTC on Monday, respected community members can suggest discussion topics in the new Optimism Town Hall channel in the Optimism Fractal discord. The topic can be very simple, like a quick question or just a few words. The topic could also be more complex with detailed information and links. Feel free to suggest any topic related to Optimism Fractal or the Optimism Collective.

- **Vote on Topics:** A poll will be created in the Optimism Town Hall snapshot space on Wednesday and all topics that were suggested in the Discord channel by 17 UTC on Wednesday will be included as options. You can allocate your Respect votes across as many topics as you’d like to influence the community’s agenda and the votes are weighted quadratically. Participants can change their votes at any point before or during the Optimism Town Hall to reflect their current interests.

### Moving to the Next Discussion Topic

During the event, respected participants can adjust their topic preferences in real-time to influence the discussion as the game progresses and move the group to the next topic with an optimistic topic transition system (which is inspired by optimistic rollup technology). 

- **Topic Transition Rules:**
    1. **Initiate Change:** Any well respected community member (defined as having at least 100 Respect) can propose to switch topics by typing ‘next topic’ in the chat, triggering a one-minute countdown.
    2. **Veto Option:** Any other well respected member can veto this by typing ‘same topic’ within the minute. If vetoed, neither the proposer nor the vetoer can make the same motion for the current topic.
    3. **Consensus Transition:** If there’s no veto, the discussion moves to the next highest-ranked topic on Snapshot.
    
- **Proposing New Topics:** If at least 51% of well-respected members agree, a new topic can be introduced and discussed immediately. Approval can be indicated by thumbs-up from respected members in the chat.

## **Benefits of Optopics**

Optopics enhances the original Cagendas game mode by providing structure for real-time interaction and flexibility during events. While the original Cagendas game allows the community to choose one topic before events, Optopics empowers participants to dynamically suggest and choose to discuss many topics throughout the event. This game mode makes participation easier by integrating topic suggestions within the Optimism Fractal Discord channel and enables the community to democratically create our agenda with Respect. 

The original Cagendas and Optopics game modes complement each other to organize discussions, with Optopics adding a layer of joyful interactivity that encourages continuous community input and adaptation. This approach aligns with the Optimism Collective's vision by promoting a participatory digital future where community insights directly shape discussions on the Superchain and can help us create profound benefits for all at Optimism Town Hall. You can learn more about the benefits, comparisons, and synergies with the original Cagendas game mode in [this page](Explain%20the%20benefits,%20similarities,%20differences,%20a%203a306fe5a4e44418bbdeeab7ab1b25a2.md).

## **Participation and Feedback**

If you support this initiative, please upvote this [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff) on Snapshot. Feel free to share any questions or comments, I’m eager to hear your thoughts and suggestions as we develop this game. Your participation and feedback is much appreciated. I’m looking forward to collaborating with you all as we create the future of collective decision-making and community coordination at Optimism Town Hall! 🔴 ✨

![optopics 2.png](Create%20Artwork%20for%20Optopics%201619b660f651444098ace70d075cde61/optopics_2.png)

![optopics 3.png](Create%20Introductory%20post%20for%20Optopics%20at%20Optimism%20%208a4b346168bb412b80d1674b5767263a/optopics_3.png)

# Second Draft

## **Introducing Optopics**

Hello everyone! I’m excited to introduce **Optopics**, a new collaborative community agenda game designed to enrich our discussions at Optimism Town Hall!

Optopics is a type of Cagendas game where respected community members can propose and rank topics to discuss at the Optimism Town Hall, then coordinate in real-time to determine discussion topics throughout the event. It’s crafted to provide structured conversations with an interactive experience that enables us to harness the wisdom of the crowd and  

Designed to provide structure to guide conversations with an interactive, engaging experience that allows us to cover multiple topics dynamically, tap into the wisdom of the crowd at live events, optimize our meeting time, and discuss what’s most important to the community and maximize our impact for the optimism collective

Optopics is a kind of Cagendas game designed to streamline meeting structures and enhance conversational dynamics by allowing participants to propose, rank, and discuss topics in a structured yet adaptable environment.

Optopics leverages the collective intelligence of our community, optimizing the efficiency and effectiveness of our discussions, ensuring they are productive and deeply impactful.

## **Benefits of Optopics**

- **Dynamic Participation:** Participants can propose and reorder discussion topics dynamically, ensuring the meeting adapts to the most relevant issues as they arise.

- **Empowered Community Control:** Respected community members can guide the flow of conversation, ensuring that discussions remain focused and meaningful.

- **Inspired by Optimism’s Technology:** The game mirrors the optimistic rollup design of the Optimism Superchain, allowing for swift topic transitions unless vetoed by other respected members, promoting a fast-paced and engaging discussion environment.

# First Draft

- [ ]  review this to see if there’s anything missing from the final version that i wanted to include

## Introducing OPTOPICS

I’m excited to present **Optopics**, a new consensus game to streamline and invigorate our discussions at the Optimism Town Hall. This innovative approach is designed to ensure that our conversations are both productive and reflective of the community's priorities.

Optopics aims to harness the collective wisdom of the community, enhancing both the efficiency and effectiveness of our discussions.

Optopics is an engaging game that allows community members to propose, rank, and discuss topics in a structured yet flexible environment.

 It's designed to optimize meeting time and tap into the diverse perspectives of our community.

providing a foundation for discussions that are not only productive but also deeply impactful.

a trailblazing method for collective meeting structures and conversational flow

Optopics is a type of Cagendas game where community members can propose and respectfully rank order topics to discuss at the Optimism Town Hall, then well respected community members can dynamically coordinate to determine when to move onto the next topic.

Designed to provide structure to guide conversations with an interactive, engaging experience that allows us to cover multiple topics dynamically, tap into the wisdom of the crowd at live events, optimize our meeting time, and discuss what’s most important to the community and maximize our impact for the optimism collective

trailblazing / pioneering in collective meeting structure and conversational flow

If this topic proposal is approved, we’ll organize the upcoming Optimism Town Hall according to the rules of Optopics:

## Leading up to the event

I’ll create a post in optimism fractal discord channel for optimism town hall at approximately 17 utc on Monday.

Anyone can write topics they’d like to discuss in the thread . I’ll add a few topics there . Search if snapshot has limit to answers in ranked choice poll. If so then add tule here that if we reach the limit of x topic proposals then the ranked choice poll will be built with answers based upon respect of proposers. Perhaps implement Max topic proposals per person or rule where each topic proposal reduced Respect voting power in this game by 50% to select topic proposals in the first place 

I’ll create a ranked choice poll on snapshot with all the topics that are proposed on Wednesday at approximately 17 UTC. 

Participants can rank order the topics at any time to select the first topic. You’re welcome to rank order as many or as little options as you’d like. Put the topic that you 

You’ll have approximately 2 days to propose topics, then approximately 1 day to vote on the order of topics before the game begins

## During the game:

### Overview

The game officially starts at 18 UTC at the start of the Optimism Town Hall. If there is any discussion from the prior Respect Game, this should be taken to the text chat as soon as possible to ensure we’ll have the.

Participants can withdraw their votes and vote again to change the order of the ranked choice at any point in the game to influence the order of discussion topic.

For the purpose of this game, a ‘well respected community member’ in the following rules is a community member who has earned at least 100 respect at Optimism Fractal events.

### Moving to the Next Topic

Well respected community members can decide to move onto the next topic with an optimistic topic proposal system where just one well respected community member can decide for the whole group to move onto the next topic, provided that no other well respected community members veto the decision within 1 minute. This is inspired by the optimistic rollup design of the Optimism Superchain. Here’s how it works in Optopics:

1. If a player with at least 100 respect writes ‘next topic’ in the zoom chat, then a 1 minute timer is started. Rosmari will start the timer whenever this happens
2. Any well respected community member can veto the proposal to move to the next topic and decide for the group to stay on the current topic 1 minute by writing ‘same topic’ in the zoom chat within 1 minute of the proposal to move to the next topic.  
    1. If a topic proposal has been successfully vetoed, then neither their community member who made the next topic proposal or vetoes the proposal can do so again on the current topic.
3. If no well respected community member vetos the proposal, then the group moves on to the next topic that is currently on the ranked choice voting list on Snapshot. 

### Proposing a New Topic in Real Time

The community can decide to immediately focus on discuss any topic (even if it’s not on the ranked order choice list) if at least 51% of well respected community members in attendance agree. This can be signaled by writing in the zoom chat and getting 3 thumbs up emojis from well respect community members. After a new topic proposal is approved, then participants can decide to move to the next topic on the snapshot list with the same system as above.

## Feedback

Please vote for this topic proposal if you’d like to try this game at the upcoming event and feel free to reach out with any questions or comments. I’m curious to hear your thoughts and appreciate your feedback. Note that this consensus game is early in development and the design may change based upon input and experience. There’s a lot of design space to explore in the future and potential improvements to provide better experiences. I hope to create a generalizable game that can increase the enjoyment, efficiency, and productivity of meetings for all and help facilitate the best possible decision-making - fair, fast, and fun.  I hope you’ll enjoy the game and look forward to playing Optopics with you all!