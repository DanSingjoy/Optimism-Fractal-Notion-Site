# Integrate ENS with Fractalgram

Project: Integrate Optimism Fractal with ENS (Ethereum Name Service) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20with%20ENS%20(Ethereum%20Name%2003fc813cc6744f87807695748158eed5.md)
Status: Not started
Summary: Integrating ENS (Ethereum Name Service) with Fractalgram would improve the user experience by making addresses easier to find and replacing 0x names with ENS names. The page could also benefit from removing unnecessary characters to reduce overwhelm for new participants. For more information, visit http://optimystics.io/fractalgram.
Created time: April 4, 2024 9:28 PM
Last edited time: April 4, 2024 10:31 PM
Created by: Dan Singjoy

- It currently doesn’t look great and often takes people a while to find their address which degrades UX

- It would look much better and be smoother with ENS names instead of 0x names here

- Related: [Optimystics.io/fractalgram](http://Optimystics.io/fractalgram)

## Example

![Untitled](Integrate%20ENS%20with%20Fractalgram%20f956817bf370436f908e78f4c31a9981/Untitled.png)

- It took me 2 minutes to find it

![Untitled](Integrate%20ENS%20with%20Fractalgram%20f956817bf370436f908e78f4c31a9981/Untitled%201.png)

![Untitled](Integrate%20ENS%20with%20Fractalgram%20f956817bf370436f908e78f4c31a9981/Untitled%202.png)

- lots of unneeded characters here that make the page overwhelming for new participants