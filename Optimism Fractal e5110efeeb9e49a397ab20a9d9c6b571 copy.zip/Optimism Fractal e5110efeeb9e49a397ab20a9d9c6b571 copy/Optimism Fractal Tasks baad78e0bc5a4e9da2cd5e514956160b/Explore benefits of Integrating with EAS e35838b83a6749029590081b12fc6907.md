# Explore benefits of Integrating with EAS

Due: May 3, 2024
Project: Explore and Create Integrations with Ethereum Attestation Service (EAS) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
Status: Not started
Task Summary: This task aims to explore the benefits of integrating with EAS (Ethereum Attestation Service) for Optimism Fractal. By leveraging EAS, Optimism Fractal can enhance transparency and verifiability of community contributions within the Optimism ecosystem. This integration enables seamless record-keeping and integration with other Ethereum applications, fostering a highly composable environment for the community.
Summary: Integrating with the Ethereum attestation service (EAS) can provide benefits to Optimism Fractal by enabling transparent and verifiable record-keeping of community contributions within the Optimism ecosystem. This allows for easy integration with other apps in the Ethereum ecosystem and facilitates composable data recording.
Created time: May 6, 2024 12:46 PM
Last edited time: May 6, 2024 12:46 PM
Created by: Dan Singjoy

# Benefits

### **How can EAS Help Optimism Fractal?**

The Ethereum attestation service can be instrumental in verifying and recording contributions made by Optimism Fractal community members within the Optimism ecosystem. It allows for transparent and verifiable record-keeping of actions such as Respect Games outcomes, governance participation, proposal submissions, or any specific contributions to community projects. The Ethereum Attestations Service can help Optimism Fractal and all communities playing the Respect Game to record data in a highly composable manner that can be easily integrated with other apps in the Ethereum ecosystem.