# Research Quests.com

Project: Explore Integrations of Quests with the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Integrations%20of%20Quests%20with%20the%20Respect%20Ga%202a4d3601ec8c4f10b683a139862dd9e7.md)
Status: Not started
Summary: Research http://quests.com/ is a project from Richie Bonilla's team, who previously founded Clarity. http://quests.com/ is a web3 collaboration tool. The document provides links to videos and an interview that explain Quests in more detail.
Created time: January 11, 2024 8:40 AM
Last edited time: February 18, 2024 10:31 AM
Created by: Dan Singjoy

## About

[Quests.com](http://Quests.com) is from Richie Bonilla’s team. He previously founded Clarity, which is a web3 collaboration tool. The videos and Rehash interview below explains Quests well

## Videos

[https://www.youtube.com/watch?v=kBY2cDfzzAU](https://www.youtube.com/watch?v=kBY2cDfzzAU)

[https://www.youtube.com/watch?v=7lW3GTh8xyI](https://www.youtube.com/watch?v=7lW3GTh8xyI)

[https://www.youtube.com/watch?v=diO6bm_4Yec](https://www.youtube.com/watch?v=diO6bm_4Yec)

[https://twitter.com/QUESTS__/status/1642920600485199873](https://twitter.com/QUESTS__/status/1642920600485199873)

[https://quests.com/](https://quests.com/)

[Respond to Peth about MetaGame Web3 Profile, LinkTree, Nimi, and Quests](https://www.notion.so/Respond-to-Peth-about-MetaGame-Web3-Profile-LinkTree-Nimi-and-Quests-5a49918becc5496291e4a0a2912f68fd?pvs=21)