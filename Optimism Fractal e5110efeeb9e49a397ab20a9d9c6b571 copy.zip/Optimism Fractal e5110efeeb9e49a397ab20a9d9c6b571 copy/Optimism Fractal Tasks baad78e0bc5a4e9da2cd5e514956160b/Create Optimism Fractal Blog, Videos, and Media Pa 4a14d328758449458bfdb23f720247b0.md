# Create Optimism Fractal Blog, Videos, and Media Pages/Database

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Create Promotions for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Promotions%20for%20Optimism%20Fractal%20fccca47c97dd47df8ffe81b9b5e60c01.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Create Optimism Fractal Blog (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Blog%201f971a58665c4309b674be21b5e183d6.md)
Status: In progress
Task Summary: This task aims to create a comprehensive online presence for the Optimism Fractal community through the development of a blog, videos, and media pages. By organizing and showcasing relevant content, we hope to enhance accessibility and collaboration among community members while promoting the rich resources available.
Summary: The project involves creating a blog, videos, and media pages for the Optimism Fractal, with a focus on collaboration and easy access to articles. Key tasks include merging content, establishing a media database, and transferring articles from Optimystics to the new platform, with a due date of July 31, 2024.
Created time: April 17, 2024 5:58 AM
Last edited time: August 9, 2024 10:29 PM
Created by: Dan Singjoy
Description: The project involves creating a blog, videos, and media pages for Optimism Fractal, with a focus on collaboration and accessibility. Suggestions include merging content, establishing a media database, and transferring articles from Optimystics to the new site. The due date for completion is July 31, 2024.

- [ ]  merge with [Update OF, EF, and Optimystics Videos Pages to work with databases](https://www.notion.so/Update-OF-EF-and-Optimystics-Videos-Pages-to-work-with-databases-f3c8a33c27984d2d87e669e42e9b0a8b?pvs=21)?

- Rosmari suggested creating a blog page where articles like [OptimismFractal.com/council](http://OptimismFractal.com/council) can be easily found without needing to be on the homepage

- We can make this a collaborative blog where articles like Hodlon’s Retrospective can also be featured, and perhaps we can use Hats Protocol as a way to manage these permissions

- This is a good idea. We should also create a videos page and blog page on the website to make it easier to see each of these

- We should keep the media page live and create a media database which includes both videos and blog posts as different properties in a multi-select, then put the linked view database on each page

- Blog articles to add:
    - council
    - retrospective
    - respect
    - respect game
    - …

- We should also copy over any other articles from optimystics to optimism fractal
    - find task to transfer parts from [[optimystics.io to optimism fractal we bsite