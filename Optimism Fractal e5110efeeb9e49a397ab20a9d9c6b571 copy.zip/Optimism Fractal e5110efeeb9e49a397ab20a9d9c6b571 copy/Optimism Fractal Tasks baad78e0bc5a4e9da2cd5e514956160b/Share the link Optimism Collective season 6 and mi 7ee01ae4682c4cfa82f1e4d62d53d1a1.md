# Share the link Optimism Collective season 6 and mission requests in Eden Fractal chat, tag Will, and Respond about broader EVM Ecosystem opportunities

Assignee: Dan Singjoy
Due: June 10, 2024
Project: Explore expansion of Fractals into broader EVM Ecosystem  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20expansion%20of%20Fractals%20into%20broader%20EVM%20Eco%20e4f9f052785e4114b18ac2148eb3067d.md), Explore Mission Opportunities in Optimism Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md), Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Done
Task Summary: This task aims to share the link to the Optimism Collective season 6 and mission requests in the Eden Fractal chat, as well as tag Will and respond about broader EVM ecosystem opportunities. The page also includes a summary of the Optimism Fractal event, discussions about expanding games into other EVM networks, and information about creating mission requests in Optimism Season 6.
Summary: This document discusses sharing a link to Optimism Collective season 6 and mission requests in Eden Fractal chat, expressing interest in broader EVM ecosystem opportunities, and providing resources about creating mission requests in Optimism Season 6.
Sub-task: Consider applying for ReFi Grant Program on Arbitrum (Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a.md)
Created time: June 13, 2024 3:22 PM
Last edited time: June 18, 2024 8:26 AM
Sub-tasks: Consider applying for ReFi Grant Program on Arbitrum (Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a.md)
Created by: Dan Singjoy

![Untitled](Share%20the%20link%20Optimism%20Collective%20season%206%20and%20mi%207ee01ae4682c4cfa82f1e4d62d53d1a1/Untitled.png)

![Untitled](Share%20the%20link%20Optimism%20Collective%20season%206%20and%20mi%207ee01ae4682c4cfa82f1e4d62d53d1a1/Untitled%201.png)

Looks awesome, thank you for sharing! 

I listened to your [presentation](https://youtu.be/JI0mreeaSgY?si=zAVsfJZb4iJygiLR&t=476) from last week’s Optimism Fractal event again today and really appreciate you sharing all the opportunities with us, as well as your work with Charmverse in helping to organize these grant programs and your recent educational initiatives with KingFisher’s Media.

We’re not bound by any kind of non-compete terms with Optimism and I think it’s a great idea to start expanding our games into other EVM networks like Arbitrum in the near future. I’m not sure if I’ll have time to pursue this grant with Arbitrum before the June 28th deadline but I made a note about it and review it again in the coming days. 

I’d be very grateful if you can let us know if this opportunity recurs or when other similar ones happen in the future. We’ll be in a better position to start applying for these kinds of grant programs in the coming months after some of our core infrastructure is more ready (such as the software that Tadas is building) and raising funding is a top priority for the fractal ecosystem. 

I also made a reminder to look into the newly announced community grant program on Polygon that you spoke about, which looks like it can be a nice opportunity to greatly expand and fund the growth of fractal decision-making games/processes…

As you requested at the end of the last Optimism Fractal event, here are some resources about the upcoming opportunity to create Mission Requests in Optimism Season 6.

This [forum post](https://gov.optimism.io/t/season-6-mission-request-creation-guide/8123) from the Optimism Foundation explains all the details about Mission Requests. I just realized that they changed the Mission Request system from last season so now it requires a sponsorship from the Grants Council or Feedback Commission, which includes about 20 people.   There will be a thread in the Optimism Governance forum where anyone can propose mission ideas for sponsorship. If you can get a sponsorship, then it is essentially like being able to design a where people can apply to achieve goals in order to receive funding from the Collective. This can be can be a great opportunity to fund all kinds of fractal, regenerative, or other kinds of initiatives that benefit Optimism.  

For more details, you can see this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md) that curates all things about Optimism Season 6 and this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md) with resources specifically about mission opportunities in Season 6.  As my [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x91b453b33a3cfe54a2abc3304c5bfe72aaf09291cd32aae3be36fc7ec07e6209) states, the deadline to create Mission Requests is June 27th and applications for missions open on July 18th. 

I also proposed Optimism Season 6 as a topic for this week’s Optimism Town Hall, so we could discuss it there as well (though the [Onchain Summer](https://www.base.org/onchainsummer) initiatives hosted by Base received the most upvotes so it will be the first topic discussed).

Optimism Mission Requests allow anyone to essentially design a grant program where people can apply to achieve goals in order to receive funding from the Collective, so it can be a great opportunity to fund all kinds of fractal, regenerative, or other kinds of initiatives that benefit Optimism.  

[Consider applying for ReFi Grant Program on Arbitrum](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a.md) 

- There’s 20k arb (which is about 18k usd) and there are a lot of questions to answer here

- Generally i think we should start pursuing these in the coming weeks and months after our foundations are laid well with optimism before branching out too quickly

- It will be alot easier to apply for this when:
    - our software is more ready
    - our processes are more refined
    - optimism fractal is larger
    - we have [Add Optimism Fractal notion workspace file to Optimism Fractal GPT](Add%20Optimism%20Fractal%20notion%20workspace%20file%20to%20Opti%206b32055a5c1d48afb1f62817c059e8fd.md) to be able to respond to these kinds of forms quickly
    

[https://x.com/CharmVerse/status/1801642679412855044](https://x.com/CharmVerse/status/1801642679412855044)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%201.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%202.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%203.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%204.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%205.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%206.png)