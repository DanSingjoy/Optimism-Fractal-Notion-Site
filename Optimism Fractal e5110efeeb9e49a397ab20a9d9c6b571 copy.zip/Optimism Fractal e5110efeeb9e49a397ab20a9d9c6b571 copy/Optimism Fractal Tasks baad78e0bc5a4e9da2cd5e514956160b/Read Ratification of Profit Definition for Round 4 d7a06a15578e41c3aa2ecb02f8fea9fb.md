# Read Ratification of Profit Definition for Round 4 - Citizens 👥 - Optimism Collective

Project: Integrate Optimism Fractal into the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20into%20the%20Optimism%20Colle%20b7f7b9296593434ab7f8a4fc1f4cd7b2.md), Help the Optimism Collective with Deliberative Processes and Impact Juries (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Help%20the%20Optimism%20Collective%20with%20Deliberative%20Pro%20dfaa054f83574db1b5ae9120d93f740c.md), Consider pioneering Impact Juries for the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Consider%20pioneering%20Impact%20Juries%20for%20the%20Optimism%2020e58c7a2c564548a148ece84b1ba470.md), Improve Processes for Impact Measurement and Evaluation in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Processes%20for%20Impact%20Measurement%20and%20Evalu%20538192791aa94cf4ac328c1571d17f40.md), Submit Respect and Respect Votes as Impact Metrics for Open Source Observer(OSO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Submit%20Respect%20and%20Respect%20Votes%20as%20Impact%20Metrics%2012ebf87ca05b40379c0f6a4266ffb847.md)
Status: Not started
URL: https://gov.optimism.io/t/ratification-of-profit-definition-for-round-4/8312
Task Summary: This task aims to present and ratify the profit definition for Round 4 of the Citizens within the Optimism Collective. It outlines the deliberative process undertaken by badgeholders to establish a standardized approach to calculating profit, ensuring that positive impact on the community is adequately rewarded.
Summary: The document discusses the ratification of a profit definition for Round 4 of Optimism's Retroactive Public Goods Funding. It outlines the impact of the bubble economy, the Plaza Accord, and Japan's economic policy changes. Key points include the introduction of a standardized profit calculation method, the categorization of past funding sources, and the voting process for badgeholders. The proposed formula for calculating awards is based on impact minus deductions from specific grant categories. Voting will occur from June 20-26, 2024, with a 51% approval threshold required for ratification.
Created time: August 11, 2024 2:17 PM
Last edited time: August 11, 2024 2:20 PM
Created by: Dan Singjoy
Description: The document discusses the ratification of a profit definition for Round 4 of Optimism's Retroactive Public Goods Funding. Key points include the impact of the bubble economy and the Plaza Accord on Japan's economy, the proposed formula for calculating awards based on impact minus deductions for past funding sources, and the results of a deliberative process involving badgeholders to define profit. Voting on the proposal will occur from June 20-26, 2024, with a 51% approval threshold required for ratification.

# Token House Call: July 2nd, 2024

Recording: [July 2 Token House Call recording.mp4 3](https://drive.google.com/file/d/1j9l4Fa6Irb-xpwv1mjtAyYR3hOBUpT0f/view?usp=sharing)

Alternate recording (includes Jing’s slides): [tl;dv - app](https://tldv.io/app/meetings/6696b5536446c60013e79fd0/)

Slides: [July 2nd, 2024 Token House call slides 1](https://docs.google.com/presentation/d/1-mUihrbtt7MsI4viyRPEhXKp1ksCDg4OdKWfZBVuDC4/edit?usp=sharing)

- Retro Funding 4 Profit formula will not be considered in voting.
- Badgeholder votes due for July 10th, some informal metrics sessions are happening in the badgeholder chat.
- [Retro Funding 5: Announcing Guest Voter Participation 1](https://gov.optimism.io/t/retro-funding-5-announcing-guest-voter-participation/8393):
    - A random sample of 90 existing Citizens together with 30 one-time
    guest voters will participate in the round. If you are a developer and
    you want to participate in voting for Retro Funding 5 submit an
    application [here](https://retrofunding.optimism.io/) by July 14th 2024.
- We had the leads of the Grants Council, Developer Advisory Board and Code of Conduct Council talking about their scope and goals for Season
6.
    - [Grants Council Charter](https://gov.optimism.io/t/grants-council-charter-season-6/8170) | [Grants Council Charmverse](https://app.charmverse.io/op-grants/grant-council-7295076095874495)  | [Grants Council Season 6 Calendar 3](https://app.charmverse.io/op-grants/calendar-s6-5937971055166664) | [Grants Council Operating Budget proposal 1](https://gov.optimism.io/t/season-6-grants-council-operating-budget-proposal/8171)
    - [Developer Advisory Board Charter and Operating budget 1](https://gov.optimism.io/t/zach-obront-developer-advisory-board-operating-budget/8141)
    - [Code of Conduct Council Nominations](https://gov.optimism.io/t/season-6-nominations-code-of-conduct-council/8118): the self-nomination submission deadline is extended until July 24th.
    CoCC Election Townhall will be hosted after the self-nomination period
    ends, around July 25th-30th. | [Code of Conduct Council Charter](https://gov.optimism.io/t/final-v2-code-of-conduct-council-operating-budget-re-scope-for-season-6-cycle-23b/8271)
- Mission Requests:
    - Grants Council and the Collective Feedback Commission mission request drafts are due for July 8th.
    - Grants Council will provide a suggested ranking of all mission requests by July 10th to go to vote.
    - Mission Requests must be completed and posted to the forum by July
    8th at 19:00 GMT. However, it is encouraged to post drafts to the forum
    as early as possible to incorporate any delegate feedback before the
    deadline.
    - Members of the Feedback Commission and or Grants Council may choose
    to sponsor ideas from any other community member. Post mission ideas in
    this [thread](https://gov.optimism.io/t/mission-request-sponsorships/8405)
    - Read [Season 6: Mission Request creation guide](https://gov.optimism.io/t/season-6-mission-request-creation-guide/8123) and [Suggested Mission Requests](https://gov.optimism.io/t/season-6-suggested-mission-requests/8107) for more info.

### Impact = profit

Optimism’s Retroactive Public Goods Funding (Retro Funding) has been built around the principle that positive impact to the collective should be rewarded as: ***Impact = profit.*** This principle serves as a North Star to motivate the creation of a more productive and sustainable ecosystem.

In previous Retro Funding rounds, each Citizen conducted their own assessment of impact and decided how to calculate profit by considering the past rewards received by projects and deducting that amount from impact to arrive at a final OP allocation. This non-standardized approach sparked [various debates 2](https://gov.optimism.io/t/the-role-of-vc-funding-in-retropgf/7342) within the community about whether external funding (e.g., VC funding, Optimism grants, or external grants) should be deducted from a project’s overall public goods funding reward.

### Round 4 Definition

In [Retro Funding 4: Onchain Builders 7](https://gov.optimism.io/t/retro-funding-4-onchain-builders-round-details/7988/3), a definition of profit will be universally applied to the retro round. Badgeholders will no longer need to calculate profit, but instead, a collective definition will be applied and subtracted from each voter’s assessment of impact as such:

> 
> 
> 
> ***Impact - Past transfers = Award in OP***
> 

The possible categories considered as Past Transfers are:

- Grants from Optimism
- VC funding
- Grants from other ecosystems
- Revenue.

All data collected on this categories in the Round 4 application process was for the timeframe of Jan 2023 - May 23rd, 2024.

### Deliberative Process

Over the past month, a randomly selected subset of badgeholders [experimented with a deliberative process 2](https://gov.optimism.io/t/experimenting-with-deliberative-processes-in-the-collective/8041) to determine this profit definition for Round 4. You can access the public documentation of this process below. **We encourage you to review this documentation so you have the full context to vote on this proposal.**

- **Session 1:**
    - [Pre-reading Info Kit 5](https://docs.google.com/document/d/1ozOsXETe13EarMG6Fk2yc_vfo4V6h4clnsWubyy3tyE/edit?usp=sharing)
    - The plenary session recording for Session 1 is unfortunately unusable
    - [Forum recap 2](https://gov.optimism.io/t/retro-funding-4-deliberative-process-on-the-definition-of-profit/8083/11)
- **Session 2:**
    - [Pre-reading Info Kit 1](https://docs.google.com/document/d/1kmVq4CvBrX6CcAzCYrhyh-ZDC1D7GIXGkEybGCMbVGs/edit?usp=sharing)
    - [Plenary session recording](https://missionspubliques.zoom.us/rec/share/jNWsFgSa4kiDyM7tTkK7N12W1DbPFqd_2pVU-JzEnnBozD9S_d3xabyv6pF2gyB2.hteAvKOlclO7MqB-) (doesn’t include breakout rooms) - Kenncode: 6R2W*ORW
    - [Forum recap 2](https://gov.optimism.io/t/retro-funding-4-deliberative-process-on-the-definition-of-profit/8083/12)
- **Session 3:**
    - [Pre-reading Info Kit 2](https://docs.google.com/document/d/1KC7EAAokxbH7N0YGHP6xVEXZKYCS9ZMa1LZubh8O8bs/edit?usp=sharing)
    - [Plenary session recording](https://missionspubliques.zoom.us/rec/share/Q_a-4y0Apsa4dgO4n9B9TV0F6fxpQeQOtTRwKqeF2zdZpJmWIsq6bULTR8aRIzjV.om91tDLiBmH8G8kl) (doesn’t include breakout rooms) - Kenncode: U1uN9!6L
    - [Forum recap 3](https://gov.optimism.io/t/retro-funding-4-deliberative-process-on-the-definition-of-profit/8083/15)

This [Miro board 3](https://miro.com/app/board/uXjVK-3OHHU=/?moveToWidget=3458764592049624735&cot=14) was used to collect input in all three sessions.

### Proposed Round 4 Profit Definition

### Vote 1

Participating badgeholders were asked to determine the profit definition taking into account **the specific category definitions and limitations on data collection as it applies practically in Round 4.** It is important to understand the nuance and complexity of the practical implementation of defining profit which are distinct from philosophical debates about inclusion or exclusion of each category. Two votes occurred during the deliberative process experiment. The first was on which categories to include in the profit definition. The results are below:

![https://europe1.discourse-cdn.com/bc41dd/original/2X/8/806c6126d64ecdd7c3f1fee0d7707c801f29945d.png](https://europe1.discourse-cdn.com/bc41dd/original/2X/8/806c6126d64ecdd7c3f1fee0d7707c801f29945d.png)

Based on the Collective’s standard 51% approval threshold, these results determined that a **deduction weight would only be applied only to Optimism Grants.**

### Vote 2

The second vote was on the deduction weight that should be applied to Optimism Grants, as broken into three sub-categories:

- Token House growth grants, which are passed on to end users
- Token House builders grants, which are locked for one year
- Foundation grants and Missions
- Past Retro Funding is not included as the evaluation period begins after the end of Round 3

The responses resulted in a proposed profit definition of Round 4 as outlined below:

![https://europe1.discourse-cdn.com/bc41dd/original/2X/6/61748caf93681e4a5dc3b8d00176734aec6604b2.png](https://europe1.discourse-cdn.com/bc41dd/original/2X/6/61748caf93681e4a5dc3b8d00176734aec6604b2.png)

A breakdown of votes is shown below:

![https://europe1.discourse-cdn.com/bc41dd/original/2X/f/f21b71e8eb16b812c77980a2ee85d8b38faeb039.png](https://europe1.discourse-cdn.com/bc41dd/original/2X/f/f21b71e8eb16b812c77980a2ee85d8b38faeb039.png)

### Ratification

If you wish to ratify the below definition, which will be globally and automatically applied to the voting result calculation in Round 4, please vote “Yes” on this proposal.

> 
> 
> 
> **Impact - ((10% * Token House Growth Grants) + (45% * Token House Builders Grants) + (25% * Foundation Grants)) = Award in OP**
> 

The OP amount deducted from the impact rewards will be returned to the Retroactive Public Goods Funding treasury.

If you do not wish to ratify this definition, a fallback definition proposed by the Foundation will be globally and automatically applied to the voting result calculation in Round 4 instead. This definition is:

> 
> 
> 
> **Impact = Award in OP**
> 

The deliberative process experiment surfaced the amount of complexity, nuance, and effort required to accurately define profit and the challenges in verifying self-reported profit data which is oftentimes not publicly disclosed. In light of these learnings, the Foundation believes it is premature to accurately calculate profit and instead proposes solely focusing on impact in Round 4. The fallback profit definition below, will be implemented if this proposal is not ratified.

**Voting will take place on [Snapshot 22](https://snapshot.org/#/citizenshouse.eth) and will run from June 20-26 at 19:00 GMT. Quorum will require 30% of badgeholders to cast a vote with an approval threshold will be 51% of votes cast.**

I will be voting Yes. This is actually a really tough call (and because of all the factors involved, difficult to analyze quantitatively), but I think the benefit of the discounts defined by this proposal is marginally greater than the drawbacks. That said, I would not be upset if the outcome of this specific vote was No.

I want to take this opportunity to articulate my current perspective on *Impact = Profit*, which is driving my evaluation of the present proposal as well as how I hope retro funding evolves over time.

### Primary principles

These are my primary principles:

1. A project’s *Impact* is the value it created for the Optimism Collective. It’s important that this be measure over a concrete time period *t*. Perhaps a better label would be *Impactt*.
2. A project’s *Profit* is the reward it receives for delivering that *Impact*. This should really be time-bound as well, ie *Profitt*.

In other words, *Impactt = Profitt*.

### Reward, not profit

I actually don’t think that “profit” is the right label. Profit is a net amount, e.g. *reward minus cost*. The amount of reward a project receives for delivering impact should not be a function of the cost incurred to delivery it. We want to promote efficient allocation of resources, and so we should not be explicitly covering the cost of delivering impact. If projects can deliver impact for less cost than the reward they (expect to) receive, then they will continue delivering it.

*Impactt = Rewardt*

### Revenue replacement

Instead, we’re looking for something that behaves more like revenue. Previously, [I’ve argued 1](https://spengrah.mirror.xyz/MMPx9GNZ0mHXgMsTuOmBsmpBnLt31faqIayrD2R1EGs) that the OP awarded to a given project is best understood as a form of replacement for the revenue that project would have generated if it had not been a public good. I still believe this is roughly correct.

The potential discounting of other funding sources that has been the topic of this deliberative process is a helpful frame for understanding what I mean.

We can express *Rewardt* — again, this is what is currently labeled as *Profitt* — as the sum of the various forms of rewards available to a project. I think the categories used in this deliberative process are pretty good for that purpose, with one exception:

- Grants from Optimism, which breaks down into
    - Token House Growth grants (*THGG*)
    - Token House Builders grants (*THBG*)
    - Foundation grants and missions (*FG*)
- Grants from other ecosystems (*OG*)
- Revenue (*REV*)
- Retro Funding awards (RFA)

That one exception is VC funding. I would broaden that category to any kind of investment with the expectation of economic return, not just investment which comes from venture capital funds. At its most basic, investment — including venture — is a the purchase of a claim of a project’s future profit in exchange for an injection of funds that are expected to help the project achieve said profit in the future. Investment itself is not a reward. When a project receives an investment, the stakeholders in that project expand to include the investors. Any profit the project receives — including OP from retro funding — naturally is (eventually) divided up among those stakeholders.

Without significant up front capital, many of the most important and impactful projects would not exist. It would be a huge shame if only organizations earning sufficient profit from other activities were able to contribute impactful ecosystem goods to the OP Collective.

### Retro Funding Awards

Another way to say this is that to maximize the amount of positive impact for the OP Collective, that impact needs to be incentivized — ie, rewarded — sufficiently and in proportion to the amount of impact. The total amount rewarded includes all forms of rewards, including grants from both Optimism and other ecosystems as well as revenue. Often — largely because of the market failure related to public goods — that impact goes under-rewarded. It is retro funding’s job to ensure projects are appropriately rewarded for the impact they deliver by topping up that amount with OP awards.

Mathematically, that looks like this — where A, B, C, D, and E are within the range {0 to 1}:

*Impactt = Rewardt = (A * THGGt) + (B * THBGt) + (C * FGt) + (D * OGt) + (E * REVt) + RFAt*

Which is equivalent to this:

*RFAt = Impactt - (A * THGGt) - (B * THBGt) - (C * FGt) - (D * OGt) - (E * REVt) + RFAt*

So, we need to figure out the correct values of A, B, C, D, and E. This deliberative process resulted in the following values:

- A = 10%
- B = 45%
- C = 25%
- D = 0%
- E = 0%

I believe A, B, C, and D (and likely E, to a degree) should be non-zero. So this proposal — while likely imperfect — is better than the alternative.

- E = 0%

I believe A, B, C, and D (and likely E, to a degree) should be non-zero. So this proposal — while likely imperfect — is better than the alternative.

[spengrah](https://gov.optimism.io/u/spengrah)

[Jun 20](https://gov.optimism.io/t/ratification-of-profit-definition-for-round-4/8312/10)

jackanorak:  **Builder grants** are to get a thing built. Critical milestones are there to show that the thing has been built and that there have been attempts to make the thing useful. If the critical milestones aren’t met, no payment. 
Benchmark milestones reflect actual impact, but you can whiff all the benchmarks and still get paid. Why? Because *builder grants aren’t compensation for impact*; they’re an ecosystem investment in the hope that stuff has an impact later on. For analogy: would a startup book investments as income? 

The main difference between a builder grant and an investment is that the grant expects a non-financial return while an investment expects a financial return. We can see how this makes a practical difference by looking at a hypothetical comparison between a) a builder grant and b) an investment, both of the same amount X, given by the Token House to the same project that delivers impact of amount Y.

Let’s say that they delivered more impact than they received, ie Y > X.

In A, the project receives X as a grant and delivers Y impact.

- If retro funding discounted builder grants (for simplicity at 100%), the project would receive (Y - X) award from retro funding. In total, it would receive Y reward for Y impact, satisfying the criterion of Impact = Profit.
- If retro funding did not discount builder grants, the project would receive Y award from retro funding. In total, it would receive X + Y reward for Y impact. That’s too much! Because retro funding is not unlimited, some other project would necessarily go under-rewarded for its impact.

In B, the project receives X as an investment and delivers Y impact.

- If retro funding discounted investments (for simplicity at 100%), the project would receive (Y - X) award. That’s too little! The project team may well decide that building for the OP ecosystem is not worth the trouble, and pivot to something else in order to generate a return for its stakeholders’ investment.
- If retro funding did not discount investments, the project would receive Y award. In total, its reward for delivering Y impact is also Y, satisfying the criterion of Impact = Profit. Note that Z goes back to the Token House.

jackanorak:  **Growth grants** *don’t even go to the teams*, a distinction that people need to fully internalize. I hope the implications of this fact are a little more obvious to the reader. 

Its true that the growth grants don’t go directly to the teams, but they are effectively subsidizing their marketing budgets. Certainly paying your users OP to execute transactions against your contract will result in greater sequencer revenue generated by your contract!