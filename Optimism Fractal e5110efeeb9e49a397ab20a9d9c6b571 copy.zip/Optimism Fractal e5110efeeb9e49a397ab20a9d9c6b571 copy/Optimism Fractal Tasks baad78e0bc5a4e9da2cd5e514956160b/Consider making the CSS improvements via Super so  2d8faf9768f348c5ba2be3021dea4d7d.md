# Consider making the CSS improvements via Super.so for the  Optimism Fractal Notion Community site

Status: Not started
Task Summary: This task aims to improve the CSS of the Optimism Fractal Notion Community site using http://super.so/. The goal is to enhance the website's appearance and branding as a community development site. However, there are currently several issues with using http://super.so/, such as missing functionalities and a less appealing design compared to Notion. Therefore, the effort to improve the site's appearance with CSS via http://super.so/ is currently deemed not worthwhile.
Summary: Consider using http://super.so/ for CSS improvements on the Optimism Fractal Notion Community site, but currently there are too many issues with using Super, such as the projects database not showing up and limited functionalities compared to Notion. It is suggested to focus on making the site look better and branding it as a community development site in the future.
Sub-task: Ask Cam from Super how to make the gallery database show two columns or one column with CSS (Ask%20Cam%20from%20Super%20how%20to%20make%20the%20gallery%20databas%20847f510f503949ce8e59bce3cd15629c.md)
Created time: June 4, 2024 12:12 PM
Last edited time: June 4, 2024 12:12 PM
Created by: Dan Singjoy
Description: Consider using http://super.so/ for CSS improvements on the Optimism Fractal Notion Community site, but currently there are too many issues with using it. The Super version doesn't look as good and lacks many functionalities present in Notion. It's not worth the effort to improve the site's appearance with CSS via Super at the moment.

## Consider making the CSS improvements via [Super.so](http://Super.so) for the  Optimism Fractal Notion Community site

- [x]  consider also asking about this now

Webpage:

[**Optimism Fractal**](https://optimismfractal.com/optimism-fractal-website-pages/optimism-fractal)

[Community Development Site](https://optimismfractal.com/optimism-fractal-website-pages/optimism-fractal)

Notion page:

[Optimism Fractal](../../Optimism%20Fractal%20e5110efeeb9e49a397ab20a9d9c6b571.md) 

[bit.ly/optimismfractalnotion](http://bit.ly/optimismfractalnotion) 

- Currently there are too many issues with using Super to improve the CSS
    - Most of the projects database isn’t showing up
    - Notion is more interactive and easier to use- many functionalities aren’t present in Super version
    - The Super version doesn’t look as good in many ways

Eventually it will be helpful to make the optimism fractal notion site look better and brand it more as a community development site than a notion site (similar to [optimism.io/contribute](http://optimism.io/contribute), but right now it’s not worth the effort to make it look better with CSS via super)