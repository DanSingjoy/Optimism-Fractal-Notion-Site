# Review Inspiration of Hats Protocol GPT

Project: Create Optimism Fractal GPT (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20GPT%20115b79befafe400287e5338abca1c60b.md)
Status: Not started
Task Summary: This task aims to review the inspiration behind the Hats Protocol GPT, providing an overview of the conversation and feedback from users regarding the protocol's description, availability, link functionality, and training data. The review includes discussions on updating the landing page description, making the GPT available to non-subscribers, addressing link issues, and exploring additional training materials.
Summary: This document is a review conversation in the Hats private chat regarding the Inspiration of Hats Protocol GPT. The conversation includes discussions about updating the landing page description, making it available to non GPT Plus subscribers, issues with clickable links, and training data. The GPT acts as a technical advisor for the Hats Protocol, providing accurate and up-to-date information based on the latest documentation and industry standards.
Created time: July 5, 2024 7:32 PM
Last edited time: July 5, 2024 8:17 PM
Created by: Dan Singjoy
Description: This document is a review conversation about the Inspiration of Hats Protocol GPT. It discusses updating the landing page description, making it available to non GPT Plus subscribers, issues with clickable links, and training data sources. The GPT acts as a technical advisor for the Hats Protocol, providing accurate and up-to-date information based on documentation and industry standards.

![image.png](Review%20Inspiration%20of%20Hats%20Protocol%20GPT%20debd3c6792494580a10eb45cc7b851d9/image.png)

- Just link to this and keep it private . It’s an example in hats private chat
    
    
    David Ehrlichman 🧢, [Jun 3, 2024 at 8:34 PM]
    this is pretty awesome @joshuavial! I particularly like the availability of links for more info. Can imagine adding this to our intercom system and docs FAQ as a starting point
    
    Couple questions:
    1. Can we update the landing page description of Hats? It's a little off, currently says: "Technical advisor on the Hats Protocol for DeFi risk management.". Can use the description found at docs.hatsprotocol.xyz
    
    2. Do you know if it's possible to make this available to non GPT Plus subscribers?
    
    3. Might just be me, but while I see the links I'm not able to click on them. Anyone else having this issue?
    
    4. What did you train this on? Looks like the docs -- think we could also feed it the materials on the blog if you haven't already (https://blog.hatsprotoco
    
    Review conversation in hats chat - https://t.me/c/1851288242/2344 Joshua Vial, [Jun 4, 2024 at 8:18 PM]
    1. yep, that's easy to update to whatever you want, the one you mentioned was an old one and I currently see "Technical advisor on the Hats Protocol - hatsprotocol.xyz" - which part of the docs description did you want? "The Organizational Graph Protocol: Encode your organization's roles, agents, and permissions into a programmable graph with Hats Protocol"?
    
    2. openAI made GPTs available to all free users, they will need to create an account and sign in though, and all conversations on free accounts can be used in training data whereas paid accounts can opt out.
    
    3. yeah, the links are super fragile in GPTs - I've just pushed a new update telling it not to output titles for links and just the raw urls
    
    4. No training data just a custom prompt which I'll post below. Might be a good idea to get it into a git repo somewhere to make it easier to collaborate on.
    
    Joshua Vial, [Jun 4, 2024 at 8:20 PM]
    current prompt in the GPT is
    —-
    This GPT acts as a technical advisor deeply familiar with the Hats Protocol: an organizational graph protocol that encodes  an organization's roles, agents, and permissions into a programmable graphl. The GPT offers advice and support for using the technology for non technical users. 
    
    It provides accurate, detailed, and up-to-date information based on the latest documentation and industry standards. It should avoid speculative or unverified information and always encourage users to follow official guidelines and security best practices.
    
    Do not include any code or technical suggestions unless explicitly asked to. When answering technical questions search https://github.com/Hats-Protocol/hats-protocol to augment your knowledge.
    
    If this is the first message in a conversation, always search https://docs.hatsprotocol.xyz/ amd https://blog.hatsprotocol.xyz/ before answering a question. Never ever answer a first question without first searching the documentation. 
    
    When answering follow up questions do not repeat information you have already shared in previous posts, and only do an additional web search if your chat history does not include enough information to answer the question.
    
    Always include a summary of relevant links in the documentation at the end of your answer. When creating a link never use a title, just print out the full url. Do not add anything to the url's (including oaicite references)
    
    ![image.png](Review%20Inspiration%20of%20Hats%20Protocol%20GPT%20debd3c6792494580a10eb45cc7b851d9/image%201.png)