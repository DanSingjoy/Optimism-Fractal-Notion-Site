# Add sign up form with onchain responses to indicate participant preferences regarding public or community database and shared information

Project: Implement onchain Optimism Fractal participant/contributor agreement (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Implement%20onchain%20Optimism%20Fractal%20participant%20con%206a8b18dff0c242f2bc58a6f260774939.md), Create Optimism Fractal Builders Site (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Builders%20Site%20b2364cd97d724ac78f2b7f30c2f476c2.md)
Status: Not started
Task Summary: This task aims to create a sign-up form that will gather on-chain responses from participants regarding their preferences for inclusion in a public or community database. By clearly outlining these preferences, we can enhance the clarity and functionality of tools such as the Optimism Builders Site and CRM for various use cases.
Summary: A sign-up form with on-chain responses is proposed to clarify participant preferences about public or community databases and shared information for the Optimism Fractal participant agreement. It may be created using http://deform.cc/ or similar tools, and additional helpful information or preferences should be considered for inclusion.
Created time: August 11, 2024 12:49 PM
Last edited time: August 11, 2024 12:52 PM
Created by: Dan Singjoy
Description: A sign-up form with on-chain responses is proposed to clarify participant preferences about public or community databases and shared information for the Optimism Fractal participant agreement. It suggests using http://deform.cc/ or a similar tool for implementation and encourages consideration of additional helpful information or preferences to include.

Consider adding something like this to the Optimism Fractal participant agreement. This could help provide clarity for Optimism Builders Site, CRM, or other use cases.

Perhaps it can be created with [deform.cc](http://deform.cc) or another tool so the responses to the questions regarding preferences are all onchain

![image.png](Add%20sign%20up%20form%20with%20onchain%20responses%20to%20indicat%2031dc334562b841598fff02d27ad5f3f6/image.png)

- [ ]  Consider what other info or preferences might be helpful to include here