# Prepare for meeting with Alex from Livepeer

Assignee: Dan Singjoy
Status: Done
Summary: This document is a preparation for a meeting with Alex from Livepeer. It includes discussions about the Livestreaming app, token gating access to premium streams, and the integration of Livepeer with other platforms. The document also mentions the possibility of making a proposal to the Optimism Collective for funding the development of an app and seeking assistance from the Livepeer team or community.
Parent-task: In v2, Consider recording, encoding and livestreaming integrations with Livepeer (In%20v2,%20Consider%20recording,%20encoding%20and%20livestream%207f9e5aff39d94b6c9fee1ca9f0999e32.md)
Created time: March 8, 2024 8:43 PM
Last edited time: April 24, 2024 4:40 AM
Parent task: In v2, Consider recording, encoding and livestreaming integrations with Livepeer (In%20v2,%20Consider%20recording,%20encoding%20and%20livestream%207f9e5aff39d94b6c9fee1ca9f0999e32.md)
Created by: Dan Singjoy

## Description

- [x]  send video to alex of zeos video

![Untitled](Prepare%20for%20meeting%20with%20Alex%20from%20Livepeer%202e70af1cf6cd44b6b4570b25b7c31d25/Untitled.png)

also maybe forward matthias message

bonfire

number 4 largest livestreaming app - core video performance plus cost savings 

token gating access to premium streams

unlonely minting video clips 

enabling a live streaming use case for an order of magnitude cheaper than AWS , etc

huddle01 is more user centric- it’s built on web3 

look at huddle01 first from user perpsective, then agora for 

agora is more developer focused and expensive and may be more flexible 

bonfigre

**lex Mexicotte**

3:58 PM

[https://docs.livepeer.org/developers/tutorials/token-gate-videos-with-lit#lit-protocol](https://docs.livepeer.org/developers/tutorials/token-gate-videos-with-lit#lit-protocol)

livepeer.studio

**Alex Mexicotte**

4:02 PM

[https://discord.gg/N3vESax8](https://discord.gg/N3vESax8)

[https://discord.gg/6XZqGa5C](https://discord.gg/6XZqGa5C)

if you want to do one to many use case, then you can either be beholden to twitch’s garden vs you can control every aspect of it but video is very expensive. Twitch foots the cost of the video, or do you create your own UX or pay a lot of money?

Livepeer is actively speaking with the farcaster and lens communities/teams on enabling frame integration

[https://docs.livepeer.org/developers/tutorials/token-gate-videos-with-lit#lit-protocol](https://docs.livepeer.org/developers/tutorials/token-gate-videos-with-lit#lit-protocol) . Lit protocol encrypted video on farcaster 

The free plan can get it going for a while

[livepeer.studio](http://livepeer.studio) 

![Untitled](Prepare%20for%20meeting%20with%20Alex%20from%20Livepeer%202e70af1cf6cd44b6b4570b25b7c31d25/Untitled%201.png)

[https://www.notion.so](https://www.notion.so)

Livepeer services 

DePin architecture

Video application from scratch

BonFire and Playground - creator economy bucket where creators can stay on tik tok and youtube etc, but also still have deeper connection with audience. It grants onchain access to video content and other helpful content based on gating access

**Alex Mexicotte**

3:34 PM

[https://huddle01.com/](https://huddle01.com/)

**Alex Mexicotte**

3:35 PM

[https://www.agora.io/en/](https://www.agora.io/en/)

**Alex Mexicotte**

3:46 PM

[https://www.unlonely.app/](https://www.unlonely.app/)

[https://live.space/](https://live.space/)

[https://www.minds.com/](https://www.minds.com/)

[https://playgroundapp.com/](https://playgroundapp.com/)

[https://bonfire.xyz/](https://bonfire.xyz/)

farcaster integration

## Prepare for meeting with Alex

- Thank you for reviewing the resources
    - This is correct about what we’re building
        - Albeit Vlad and Psinq and Matthias
    - Separate thing about the livestreaming tool
    - The app we built reminds him alot of [huddle01.com](http://huddle01.com) and [agora.io](http://agora.io), which is

- Livepeer can the help the most with one to many video of to
    - Livepeer doesn’t replace the

- What elements are

Separate app might be needed 

- Thanks again for all the help and answers
    - I love the sweater
    - Also spoke with Titan for a while and we had a great discussion with more details

- Curious to hear what you thought about the links

- The website says it just takes a few lines of code, but

- Frequently have people building fully functional apps in a weekend,
    - Developer could add a few lines of code

- We’re considering making a proposal to the Optimism Collective to fund the development of our app
    - Would anyone in the Livepeer team or community be interested in helping us build this?

- Let me know if/when there’s anything I can do to help

- [ ]  post in the general community for livepeer then can post a link about the bounty/mission in the livepeer discord
    - It’s not just the team but also the community and he think that people will likely be interested in helping

livepeer.studio

**Alex Mexicotte**

4:02 PM

[https://discord.gg/N3vESax8](https://discord.gg/N3vESax8)

[https://discord.gg/6XZqGa5C](https://discord.gg/6XZqGa5C)

- [ ]  send links to Psinq team
- [ ]  send link to matthias

- Consider asking if they can help us build it if we create a proposal where they can earn OP for doing so
- Or if anyone in their community could help
- Around how much time would it take to build this recording and livestreaming setup?

![Untitled](Prepare%20for%20meeting%20with%20Alex%20from%20Livepeer%202e70af1cf6cd44b6b4570b25b7c31d25/Untitled%202.png)

![Untitled](Prepare%20for%20meeting%20with%20Alex%20from%20Livepeer%202e70af1cf6cd44b6b4570b25b7c31d25/Untitled%203.png)

You may also be interested to know about the video processing development work that the lead developer of this WebRTC app (Matthias aka mschoenbeck) is doing to record and automatically publish each breakout room. You can see the following message for details about some of the work he is doing with video post-processing.

[https://t.me/EdenOSinfo/51579](https://t.me/EdenOSinfo/51579) 

Matthias also provided more details about this in the recording above and other messages in the group linked above. His solution seems somewhat similar to the kind of service that Livepeer provides and I think the software he built to do this is running on a centralized server, so I’m wondering if Livepeer could help him do this in a more efficient and decentralized manner. Matthias a very talented developer and I’d be happy to connect you with him if you think there’s some opportunity for collaboration

Hey Alex, it was great speaking with you yesterday. Thanks again for all the help, I really appreciate it and am looking forward to collaborating with Livepeer. You can see the video where I tested the Fractal app on the Antelope network here. Feel free to reach out with questions or let me know if there’s anything I can do to help!