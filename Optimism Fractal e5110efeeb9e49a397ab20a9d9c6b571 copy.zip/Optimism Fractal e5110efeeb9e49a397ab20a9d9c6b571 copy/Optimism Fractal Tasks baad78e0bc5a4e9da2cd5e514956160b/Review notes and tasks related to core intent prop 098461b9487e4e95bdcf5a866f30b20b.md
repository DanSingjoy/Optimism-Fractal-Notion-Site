# Review notes and tasks related to core intent proposal for Optimism Fractal

Assignee: Dan Singjoy
Due: June 13, 2024
Status: Done
Task Summary: This task aims to review notes and tasks related to the core intent proposal for Optimism Fractal. The document provides an overview of the proposal, including its creator, assignee, due date, and status. It also includes a to-do list and additional tasks related to updating the Optimism Fractal website with information about the Optimism Collective and Superchain.
Summary: This document discusses the core intent proposal for Optimism Fractal, which focuses on collective decision-making and improving governance within the Optimism Collective. It highlights the various ways Optimism Fractal is pioneering collective decision-making, its roots in fractal democracy, and its role in progressing towards decentralization. The document also mentions the opportunity for Optimism Fractal community members to earn funding through Retro Funding and emphasizes the value of optimizing collective governance. Additionally, it includes tasks related to sharing the proposal, improving the rationale, and updating the Optimism Fractal website with information about the Optimism Collective and Superchain.
Created time: June 10, 2024 1:53 PM
Last edited time: June 17, 2024 1:39 PM
Created by: Dan Singjoy

## To Do

- 
    1. Optimism Fractal is now pioneering collective decision-making in several different ways, including our [Council](https://optimismfractal.com/council) consensus process, more advanced software for granular decision making like [Respect Trees](https://optimystics.io/respect-trees), [Methods](Review%20Methods%20for%20Voting%20with%20Respect%20in%20Notion%20a%20b037b35cca164e52898682c5957aa1a2.md) for voting with Respect,  [RetroPitches](https://optimystics.io/retropitches), and topic discussion protocols and discussions at Optimism Town Hall amongst our vibrant community. The Optimystics originally set the current two core intents when Optimism Fractal was just about to start in last October and didn’t have nearly as much to offer regarding collective governance, but now Optimism Fractal has grown to a point where it has much more to offer and can make a significant impact on Optimism Collective governance.
    
    2. Optimism Fractal is rooted in [fractal democracy](https://fractally.com/blog/what-is-fractal-democracy), a governance process pioneered to bring true democracy that truly empowers people throughout society. As you can read in this [article](https://optimystics.io/blog/fractalhistory) about the History of Fractals, the goal of improving collective governance is deeply ingrained in the composition of Optimism Fractal. You can explore the article linked above to better understand lineage of how Optimism Fractal evolved from Eden Fractal, More Equal Animals, ƒractally, and hundreds of heroic builders who’ve committed countless hours to optimizing governance with the processes that we’re now pioneering at Optimism Fractal.
    
    3. The Optimism Collective is seeking to improve governance and make progress towards its core value proposition to provide resilient, decentralized, scalable compute. The first of the three intents ratified by the Collective in [Season 6](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md) is to progress towards decentralization.   As the intent ratification [article](https://gov.optimism.io/t/season-6-intents-ratification/8104) states, “This includes both technical and organizational decentralization – including work to improve upgrade processes, governance execution, the development ecosystem, and governance processes of the Collective.” The Collective is on a Path to Open Metagovernance where Optimism Fractal can increasingly play a more important role, which you can learn more about this in this [page](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20and%20Strategize%20to%20provide%20Optimism%20Collec%20ad36d53370ce43a18be5b0ff973a2052.md).
    
    4. The [6th round of Retro Funding](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861#retro-funding-6-governance-14) is focused on governance and Optimism Fractal community members will be more well-positioned to earn funding in this round when we are more clearly providing a positive impact in Optimism Collective governance. You can learn more how the Optimism Fractal can help you earn Retro Funding this in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md) and more about how we’re preparing Optimism Fractal for a successful RetroFunding round this season [here](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md).
    
    5. By adding a bit about optimizing collective governance in our core intent and repeating it throughout our messaging, we can more clearly convey the value that the Optimism Fractal community provides for the Collective and attract others who are also interested in improving collective decision-making.
    
- 
    
    
    **Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing collective decision-making on the Optimism Superchain.**
    

- 
    
    You can learn more about this in the future of optimism governance [article](https://optimism.mirror.xyz/PLrAQgE1EGRo7GRrFoztplFChnUZda4DFGW3dkQayxY) and the introductory page for the Optimism Collective.
    

- [x]  consider sharing with optimystics first for feedback
    - I could do this in the telegram chat, though i don’t think it’s necessary and probably better to just share it with active community members at the same time
    - I think it’s best to share it in the OF public chat and optimystics chat at the same time like Tadas did with his work, so we can have both channels open for discussion and the Optimystics are aware of the proposed change

- [x]  write the rationale better with the help of AI
    - [x]  consider how it should be formatted best
    - [x]  read about new intent in [Read and Curate Articles about Optimism Collective Season 6](Read%20and%20Curate%20Articles%20about%20Optimism%20Collective%20a3eec2c25e35412584ca825a0f590aac.md)

- [x]  Share this page with turquoise and Rosmari for feedback
    - I could also share it with Optimystics then and just let them know that I’m planning to share it publicly in the next few days. Would appreciate feedback

- [x]  Propose the core intents in Option 2: **Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance in the Optimism Collective and Superchain.**
    - [x]  Include a link to this page that has the general rationale, different options that weren’t proposed, and why these core intents were proposed
    - [x]  Propose this as a discussion topic for Cagendas as well
        - This way we can discuss it if we want or the council can just approve the proposal without discussion, but there is space to discuss it and get feedback
        - Perhaps it would be good to vote for it as well so there is more time for feedback rather than just approving it

- [ ]  read this article

[The Future of Optimism Governance](https://optimism.mirror.xyz/PLrAQgE1EGRo7GRrFoztplFChnUZda4DFGW3dkQayxY)

[Preparing Optimism for the Superchain future](https://optimism.mirror.xyz/9ZMwZjst9SQpzIgEd4gN42UDjATyK3ZRClPFx9oMPp8)

## Update the Optimism Fractal Website with Info about the Optimism Collective and Superchain

- [Update the Optimism Fractal Website with Info, Art, and Pages about the Optimism Collective and Superchain (Create OptimismFractal.com/superchain) ](Update%20the%20Optimism%20Fractal%20Website%20with%20Info,%20Art%20d9d7148605bd42b59afe329ac1017345.md)