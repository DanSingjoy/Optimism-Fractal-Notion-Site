# Fix the ‘Failed to Load Web3’ Error that happens when trying to submit results

Project: Optimize Optimism Fractal Web App, Fractalgram, and Fix Errors (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Optimize%20Optimism%20Fractal%20Web%20App,%20Fractalgram,%20an%201699ced1d9b243e4a375610e2222a983.md)
Status: Not started
Summary: The document discusses the 'Failed to Load Web3' error that occurs when trying to submit results. It mentions that disabling other wallet plugins in the browser can be a temporary solution for desktop usage. The issue has been experienced by multiple participants and has caused disruptions in meetings. Short-term fixes have been implemented, but a long-term solution is needed to prevent the recurrence of this issue.
Created time: April 1, 2024 5:12 PM
Last edited time: April 23, 2024 7:03 AM
Created by: Dan Singjoy

## Description

We’ve heard about this ‘blockchain not ready’ issue from many participants before and I’ve experienced it a few times as well. It often prevents submission of consensus results and makes the meeting more stressful and less efficient.

Hodlon described this issue at [56:32](https://youtu.be/h2m9_7cgTow?si=RpER58wCcLpL87Lu&t=3392) during Optimism Fractal’s 21st event. When Hodlon refreshed the main screen he got a [Fix the ‘Failed to Load Web3’ Error that happens when trying to submit results](Fix%20the%20%E2%80%98Failed%20to%20Load%20Web3%E2%80%99%20Error%20that%20happens%20w%20171fe01e35bc48a694eba1f00cf1198f.md), then when he continues and tries to submit then he gets the [Fix the ‘Blockchain Not Ready’ Error that happens when trying to submit results](Fix%20the%20%E2%80%98Blockchain%20Not%20Ready%E2%80%99%20Error%20that%20happens%20%20a5b7f3c7aa6b4241b31925ea113cd9de.md). 

You can in the video clip timestamped below:

[https://youtu.be/h2m9_7cgTow?si=2pYvtrYnewAEzjhZ&t=3447](https://youtu.be/h2m9_7cgTow?si=2pYvtrYnewAEzjhZ&t=3447)

### Temporary Solution Recommended to Hodlon for Desktop Usage

At [57:27,](https://youtu.be/h2m9_7cgTow?si=2pYvtrYnewAEzjhZ&t=3447) Abraham said that he’s had similar issues when you have multiple wallet plugins in the browser and said that disabling other wallets could fix for this. 

This fixed the issue for Hodlon, but did not fix the issue for Jimi as he was using a mobile wallet. This may be related to the issue that Zeugh reported and documented, which you can see at [Fix the UX where it defaults only to Metamask and prevents using another wallet (and probably implement WalletConnect) ](Fix%20the%20UX%20where%20it%20defaults%20only%20to%20Metamask%20and%20%2064b5fee5641f49ffb27c3941a542e640.md) 

## Related Notes

- It took about 10 minutes to resolve it in the middle of the meeting, which degrades the experience in the meeting

- This issue has also recurred in several other meetings

- How can we resolve this so that nobody has this issue again?

- Will we switch over to using the new Respect Game app instead of Fractalgram in the next month?
    - Will these issues continue to happen with the new Respect Game app?

## Short Term Fixes

For the short-term, I created [Why am I getting an error while trying to submit consensus?](../Optimism%20Fractal%20FAQ%201ce16d6520064186b40f6ad1f211c5f3/Why%20am%20I%20getting%20an%20error%20while%20trying%20to%20submit%20c%207d6f4adc392540fc968def3428525d28.md) in the [](../Optimism%20Fractal%20FAQ%201ce16d6520064186b40f6ad1f211c5f3.md) and added the following instructions. I also added it to [Tips for dealing with errors while using Fractalgram](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Fractalgram%203d7832cdb4254335aba4d079470986dc/Tips%20for%20dealing%20with%20errors%20while%20using%20Fractalgr%20643b870d5f5045d9961b688063acedb3.md)