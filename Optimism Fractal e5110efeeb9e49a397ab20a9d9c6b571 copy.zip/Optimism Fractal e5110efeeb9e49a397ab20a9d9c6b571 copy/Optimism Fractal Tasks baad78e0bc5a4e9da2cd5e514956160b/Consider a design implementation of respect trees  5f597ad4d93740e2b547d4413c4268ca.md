# Consider a design implementation of respect trees where community mints a new Respect1155 for OF or Retro Funding projects

Project: Create RetroPGF UI to sort applicants by Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20RetroPGF%20UI%20to%20sort%20applicants%20by%20Respect%2064ea936bf8714afbb84382bafe857662.md), Submit Respect and Respect Votes as Impact Metrics for Open Source Observer(OSO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Submit%20Respect%20and%20Respect%20Votes%20as%20Impact%20Metrics%2012ebf87ca05b40379c0f6a4266ffb847.md), Integrate Optimism Fractal and the Respect Game with RetroFunding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md), Explore and implement subround, subfractals, targeted respect games or quests for different goals  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20implement%20subround,%20subfractals,%20targe%20cb8248986d7044178d9d020fbb8f6ed5.md), Develop Respect Trees (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Respect%20Trees%207634364c688e44d0a1155ad4bd7fbdfa.md), Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md)
Status: Not started
Task Summary: This task aims to explore a design implementation of respect trees, where the community mints a new Respect1155 token for Open Funding or Retro Funding projects. The goal is to consider the use of different forms of respect for various respect tree applications, contests, or games. The page also emphasizes the importance of incorporating the respected trees brand into the chosen design.
Summary: Consider implementing a new Respect1155 for OF or Retro Funding projects, where the community mints respect and uses it for voting in respect trees. It is suggested to send a new form of respect for different uses, contests, or games. For example, sending retrofunding round 6 respect to governance project addresses based on attestation by the project creator. It is important to note that respect trees are a strong brand and any design should incorporate this brand.
Created time: June 17, 2024 9:13 AM
Last edited time: June 17, 2024 9:19 AM
Created by: Dan Singjoy

I’ve usually thought that Respect trees would use the same respect (Ie OPF) and just vote with it in respect trees

It may be worth considering sending a new form of respect for different kinds of respect trees uses, contests , or games 

Ie send retrofunding round 6 respect to governance projects addresses based on attestation made by creator of the project 

Also it’s worth noting and organizing elsewhere that respect trees are a really great brand and whatever design we ultimately choose should use this brand