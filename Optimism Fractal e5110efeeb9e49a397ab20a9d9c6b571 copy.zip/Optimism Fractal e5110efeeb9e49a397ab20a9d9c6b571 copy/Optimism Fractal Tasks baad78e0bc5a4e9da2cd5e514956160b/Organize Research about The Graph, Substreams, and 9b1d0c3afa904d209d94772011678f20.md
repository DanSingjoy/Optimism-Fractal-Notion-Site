# Organize Research about The Graph, Substreams, and Subgraphs

Project: Create Notion API integration that allows upvoting with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Notion%20API%20integration%20that%20allows%20upvoting%201bba7e8a0bda4237854946b51a32c98e.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md), Improve Visibility for Optimism Fractal Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md)
Status: In progress
Task Summary: This task aims to organize research and tasks related to The Graph, Substreams, and Subgraphs. The document provides an overview of these technologies, their benefits in enhancing Respectful Voting Systems, and references to top providers and resources for further exploration. The page is an early draft with valuable information that needs to be better organized in the future.
Summary: This document provides research and tasks related to The Graph, Substreams, and similar technologies. The Graph is a decentralized protocol for indexing and querying blockchain data, while Substreams enhance data processing efficiency. The integration of these technologies can improve Respect voting systems for Optimism Fractal by indexing data efficiently, providing real-time data feeds, and enabling modular development. Pinax and StreamingFast are mentioned as top providers on The Graph, and there are references to resources and videos for further exploration. This document is an early draft with a lot of helpful information that should be organized better in the future.
Sub-task: Organize prior notes about Cignals and Respect Voting Proposal (Organize%20prior%20notes%20about%20Cignals%20and%20Respect%20Vot%206fd3c83e969243b6bd172b40399a4dbe.md), Respond to Martin B from Pinax about Optimism (Respond%20to%20Martin%20B%20from%20Pinax%20about%20Optimism%20f8b1a4895c604b69ae19f11fd9015a78.md)
Created time: March 25, 2024 3:39 PM
Last edited time: May 7, 2024 7:02 AM
Created by: Dan Singjoy

## Description

This document provides research and tasks related to The Graph, Substreams, and similar technologies. The Graph is a decentralized protocol for indexing and querying blockchain data, while Substreams enhance data processing efficiency. The integration of these technologies can improve Respect voting systems for Optimism Fractal by indexing data efficiently, providing real-time data feeds, and enabling modular development. Pinax and StreamingFast are mentioned as top providers on The Graph, and there are references to resources and videos for further exploration. This document is an early draft with a lot of helpful information here that should be organized better in the future.

You can learn about The Graph at [TheGraph.com](http://TheGraph.com) and the resources below.

![[http://TheGraph.com](http://thegraph.com/)](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled.png)

[http://TheGraph.com](http://thegraph.com/)

**Table of Contents**

## What is The Graph and Substreams? And how can they improve Respect?

### **The Graph and Substreams Overview:**

The Graph is a decentralized protocol for indexing and querying data from blockchains, allowing developers to efficiently and effectively access blockchain data needed for their applications. It uses subgraphs, which are open APIs that developers can query with GraphQL.

Substreams, a part of The Graph's ecosystem, enhance this functionality by providing a way to process blockchain data in parallel, increasing the efficiency and speed of data processing. Substreams are built with Rust and can be deployed as WASM modules, making them highly efficient for data transformation tasks before loading the data into The Graph or other endpoints ([The Graph](https://thegraph.com/docs/en/substreams/)) ([The Graph](https://thegraph.com/blog/substreams-parallel-processing/)) ([The Graph](https://thegraph.com/blog/subgraphs-substreams-firehose-explained/)) ([Graph Hub](https://docs.thegraph.academy/the-graph-ecosystem/infrastructure/substreams)).

### **Utility of The Graph and Substreams in Enhancing Respectful Voting Systems:**

The Graph and Substreams can significantly enhance a voting system and the utility of a voting token by Indexing Respect Data Efficiently, providing Real-Time Data Feeds (that enables new kinds of expressive voting during community events), and offering Modular Development approach for composable functionalities. More details about these benefits are below:

1. **Indexing Voting Data Efficiently**: By leveraging Substreams, the data processing for voting can be handled more rapidly and in real-time, which is crucial during active voting periods where the latest data needs to be reflected instantly.

2. **Real-Time Data Feeds**: Substreams can provide real-time updates to subgraphs, ensuring that all interactions in the voting system are updated and accessible to users and applications without delays.

3. **Modular Development**: Developers can use existing substreams modules to build specific functionalities—like calculating vote totals, tracking token allocations, or generating analytical insights from voting data—without starting from scratch. This modular approach saves time and resources while allowing for a high degree of customization and optimization ([The Graph](https://thegraph.com/blog/substreams-parallel-processing/)) ([The Graph](https://thegraph.com/blog/subgraphs-substreams-firehose-explained/)).

By integrating these technologies, a voting system with Respect can become more dynamic, transparent, and scalable, supporting a wide array of decentralized decision-making processes effectively. These improvements can lead to a more engaging and functional voting mechanism within any decentralized community or platform.

## To Do

- [ ]  Organize the following page into more easily digestible chunks with tasks and information to review
- [ ]  Remove the sync of everything and just sync each section by itself to make it more modular

- There’s a lot of helpful information here that should be organized better
    - An outdated version of this site is live at [Substreams and The Graph](https://www.notion.so/Substreams-and-The-Graph-b574dd2afe204625bbfc5ab005b315ac?pvs=21) on Eden Creators Garden

## What is Pinax and StreamingFast?

We have close relationship with [Pinax.network](http://Pinax.network) and [StreamingFast.io](http://StreamingFast.io), which are two top providers on the Graph.

[https://twitter.com/PinaxNetwork/status/1773682262430699684](https://twitter.com/PinaxNetwork/status/1773682262430699684)

[https://twitter.com/PinaxNetwork/status/1780726273867649341](https://twitter.com/PinaxNetwork/status/1780726273867649341)

## Farcaster Frames and The Graph

[https://twitter.com/PinaxNetwork/status/1780575156819124648](https://twitter.com/PinaxNetwork/status/1780575156819124648)

## Review Pilot Use Cases with Voting with Respect in Google Spreadsheet

- [EdenFractal.com/53](http://EdenFractal.com/53)
- [EdenFractal.com/55](http://EdenFractal.com/55)
- [EdenFractal.com/56](http://EdenFractal.com/56)

## How to get the on-chain data to notion

- [ ]  ask developers again after i’ve created a demo with manually inputted data into notion

It seems like it should be very simple to get the data as its not much, though blockchains can be complex. It can be done manually easily and confirmed by weekly review and agreement (ie like each delegate or signatory agrees during weekly msig proposal or meeting in a minute). So it might not be necessary to automate this anytime soon and it’s better to focus more on getting it set up in notion than the blockchain integration

There are interesting ways to export the data from the blockchain which might be easy to do. These are good to explore and learn about in general and will be increasingly necessary to scale up the cignals app to many people in the long term. 

Some options that may help include:

- Pinax / The Graph
- Wharfkit
    - Could see blue papers
- Other SDKs and APIs?

# Firehose and Substreams

- [ ]  add this to a new page, prob call it substreams

- [ ]  ask vlad, tadas, or other developers who may be interested in helping with this- do you know a bit of rust?

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%201.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%202.png)

telegram chatbot

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%203.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%204.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%205.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%206.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%207.png)

### Pinax, StreamingFast, and The Graph

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%208.png)

[https://t.me/dfusece](https://t.me/dfusece)

![[https://t.me/dfusece/7074](https://t.me/dfusece/7074)](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%209.png)

[https://t.me/dfusece/7074](https://t.me/dfusece/7074)

[https://t.me/dfusece/7074](https://t.me/dfusece/7074)

[Substreams reach General Availability](https://streamingfastio.medium.com/substreams-reach-general-availability-48272f6e942e)

Most notably, the number of data sinks (or data loaders) have increased, thanks for the efforts of multiple teams:

- Pinax Network released: [Prometheus](https://github.com/pinax-network/substreams-sink-prometheus), [Winston](https://github.com/pinax-network/substreams-sink-winston), [CSV](https://github.com/pinax-network/substreams-sink-csv) file and a [Google Sheets](https://github.com/pinax-network/substreams-sink-sheets) sink!
- Messari is about to release a [Parquet files](https://parquet.apache.org/) sink, and together with the other files options made available now
provides ingestion into BigQuery, Clickhouse, Redshift and other large
scale MPP engines
- Edge & Node is about to release: [graph-node integration](https://github.com/graphprotocol/graph-node/pulls?q=is%3Apr+substreams+is%3Aclosed) for Substreams-based Subgraphs
- We, StreamingFast, released: [Postgres](https://github.com/streamingfast/substreams-sink-postgres), [Key/value store](https://github.com/streamingfast/substreams-sink-kv), [MongoDB](https://github.com/streamingfast/substreams-sink-mongodb), [CSV & JSON Files](https://github.com/streamingfast/substreams-sink-files)

Many thanks to those who have contributed to the ecosystem of tools, provided feedback or beta-tested the software this year:

- Pinax Networks, along with their contribution of multiple sinks, being the
first to host the Substreams runtime, and their ownership and
maintenance of a full blown Firehose integration for Antelope.

## Google Sheets + Antelope Substreams + Notion API

This can work now.

[https://www.youtube.com/watch?v=pv_t3p8t7dc&pp=ygUbZ29vZ2xlIHNoZWV0cyB0byBub3Rpb24gYXBp](https://www.youtube.com/watch?v=pv_t3p8t7dc&pp=ygUbZ29vZ2xlIHNoZWV0cyB0byBub3Rpb24gYXBp)

[https://www.youtube.com/watch?v=PPT9lEilKRQ&pp=ygUbZ29vZ2xlIHNoZWV0cyB0byBub3Rpb24gYXBp](https://www.youtube.com/watch?v=PPT9lEilKRQ&pp=ygUbZ29vZ2xlIHNoZWV0cyB0byBub3Rpb24gYXBp)

## dFuse

[https://dfuse.eosnation.io/](https://dfuse.eosnation.io/)

![[https://dfuse.eosnation.io/](https://dfuse.eosnation.io/)](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2010.png)

[https://dfuse.eosnation.io/](https://dfuse.eosnation.io/)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2011.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2012.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2013.png)

[https://dfuse.eosnation.io/](https://dfuse.eosnation.io/)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2014.png)

[https://docs.dfuse.eosnation.io/](https://docs.dfuse.eosnation.io/)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2015.png)

Watch this:

[https://www.youtube.com/watch?v=K-nhC2FCB5k](https://www.youtube.com/watch?v=K-nhC2FCB5k)

[https://substreams.streamingfast.io/](https://substreams.streamingfast.io/)

[https://substreams.streamingfast.io/concepts-and-fundamentals/benefits](https://substreams.streamingfast.io/concepts-and-fundamentals/benefits)

Watch this:

https://github.com/pinax-network/awesome-substreams

https://github.com/pinax-network/substreams-antelope

[https://github.com/pinax-network/substreams-antelope](https://github.com/pinax-network/substreams-antelope)

[https://github.com/pinax-network/substreams-antelope](https://github.com/pinax-network/substreams-antelope)

[https://docs.rs/substreams-antelope/latest/substreams_antelope/](https://docs.rs/substreams-antelope/latest/substreams_antelope/)

[https://github.com/pinax-network/firehose-antelope](https://github.com/pinax-network/firehose-antelope)

[https://github.com/pinax-network/firehose-antelope](https://github.com/pinax-network/firehose-antelope)

[https://github.com/pinax-network/awesome-substreams](https://github.com/pinax-network/awesome-substreams)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2016.png)

[https://www.youtube.com/watch?v=dzCbJ2fpckA](https://www.youtube.com/watch?v=dzCbJ2fpckA)

🔥Get ready to learn about Firehose and Substreams, two powerful tools for developers working with blockchain technology! In this workshop, Matthew Darwin of Pinax introduces these tools and explains why they are essential for processing and managing the massive amount of data that will come with the future of blockchain technology. 

🚀Firehose provides a scalable and stable interface for developers and indexers to handle this data more efficiently. It's currently available for several blockchains, including Ethereum, Solana, Near, Cosmos, and more. 

🎨Matthew also dives into the architecture of Firehose and introduces Substreams, a feature that allows developers to extract and transform specific data from blockchains in a more efficient and customizable manner. Substreams are composable, parameterizable, transformable, and parallelizable, and can be built on top of each other like Lego blocks. 

👨‍💻Overall, this workshop provides a comprehensive introduction to Firehose and Substreams and highlights their potential for revolutionizing the way developers work with blockchain technology. At Pinax, we're passionate about building tools and technologies that empower developers and accelerate innovation. 

Download all slides of the presentation as a PDF here:

[https://drive.google.com/file/d/1F5h1...](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbEF2VDk4NDdWYV96SUJuRlBqZWZXVEN4SGRFZ3xBQ3Jtc0tsdy1TMVlDM3dLNWhLcURVVkpMZm9NQ1VoWS1QRDJhMEZoLVBiTWVkbnZJOTFKMF9hWmprTTBDQ1lQNlNSXzl1SUtCVTFvM3JNSmIzUG9qbkFaSUp3T3ZfRXRhb2RDdzBNVFEyNGZrWEVNdFl3TnlRcw&q=https%3A%2F%2Fdrive.google.com%2Ffile%2Fd%2F1F5h1-1f-kO2zAJLbnn-D5ry-CHqSynnm%2Fview%3Fusp%3Dshare_link&v=dzCbJ2fpckA)

[103 Advocating for Firehose and Substreams.pdf](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/103_Advocating_for_Firehose_and_Substreams.pdf)

Originally this presentation was held for the Learning Series of The Graph Advocates.
If you're passionate about The Graph Protocol we highly recommend to get in touch with them and sign upop to join. -

[https://www.graphadvocates.com/](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbGU4RXVBcUJoRXVyVWl5djhURG5hQkxfM0ZxZ3xBQ3Jtc0trMVc3VDlGbnZHZUxBSVBGZHJRNkFNeGUtRlRMOFEwMTVWdFVTMUFYQUxoZE1jc2tBVk4tSFVfYmFPUG9CbW8zVjM4aV9NOC1tU2FiX0daNTN4SXlRYXdzSUdfT1lJUmFWMWFVZmhHRW1ZVlpJQVY4QQ&q=https%3A%2F%2Fwww.graphadvocates.com%2F&v=dzCbJ2fpckA)

🐦Connect with us on Twitter at

[https://twitter.com/PinaxNetwork](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqa0pJa2xhMGNpN3dBdGtDa0JGUFpiSEF0aWtTUXxBQ3Jtc0tsZ1VtMm1vSUlOR3BQWjVpZDdySmhENTBvUTNDLXFMWHNTdF94T192a095MkNjaXdsTENyaWlwcHFydnhrT192ZVJ5MUN1ZVd0Nm9RVmxCeE5rMk5acS1ZcEZHcVBTbXJubVZ6bjR5cllzcmZ5NTVwWQ&q=https%3A%2F%2Ftwitter.com%2FPinaxNetwork&v=dzCbJ2fpckA)

to stay up-to-date on our latest developments and get involved in the conversation. Don't miss out on this exciting opportunity to learn about the future of blockchain technology! 🔮

[https://pinax.network/](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqa3lDXzNGY0VxNHZFTFpfNGgtejJyX2hCWW9WUXxBQ3Jtc0trZUtHVi1naFdwVUx4YVFncDM1cDluRlMtVlo2b3MxV25kWWJPRTJlS21JUGNlR3FMc3NyVzNfN0FTNEloRlpuZ2NoZ09QSWpfOUlhZmtsMjUtVlNfNERMcm51a3R5RVpJSUpuUTFBenE2azVwYm1Xcw&q=https%3A%2F%2Fpinax.network%2F&v=dzCbJ2fpckA)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2017.png)

Pinax is EOS Nation

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2018.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2019.png)

EOS Canada built firehose and substreams

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2020.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2021.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2022.png)

non-developers can access substreams easily if it’s been built already

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2023.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2024.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2025.png)

different colors of boxes are different authors. boxes are substreams 

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2026.png)

substreams can export data in any format

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2027.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2028.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2029.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%202.png)

telegram chatbot

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%203.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%204.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%205.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%206.png)

![Untitled](Organize%20Research%20about%20The%20Graph,%20Substreams,%20and%209b1d0c3afa904d209d94772011678f20/Untitled%2030.png)

## Watch Videos about Substreams and the Graph Protocol

- 
    
    
    [https://www.youtube.com/watch?v=Nn6k7A-TjVE](https://www.youtube.com/watch?v=Nn6k7A-TjVE)
    

[https://www.youtube.com/watch?v=qWxffTKpciU](https://www.youtube.com/watch?v=qWxffTKpciU)

[https://www.youtube.com/@dfuse4326/featured](https://www.youtube.com/@dfuse4326/featured)

[https://youtu.be/fwLLolKvjHs](https://youtu.be/fwLLolKvjHs)

It seems like Pinax is using the Substreams tech created by streaming fast to export filterable data to google spreadsheets. They built a plugin and it seems like it works well. 

Discover the amazing potential of Substreams for Google Sheets in this detailed tutorial and demo. Learn how to access and analyze blockchain data such as token prices, transaction volumes, and on-chain activity, all within your favorite spreadsheet editor! This powerful tool offers customization, flexibility, and speed for a seamless experience. Stay tuned for future updates and developments, and join us in revolutionizing blockchain data analysis!

[0:00](https://www.youtube.com/watch?v=fwLLolKvjHs&t=0s)- Introduction

[0:29](https://www.youtube.com/watch?v=fwLLolKvjHs&t=29s)- Blockchain Data Use-Cases

[2:40](https://www.youtube.com/watch?v=fwLLolKvjHs&t=160s)- Advantages

[2:56](https://www.youtube.com/watch?v=fwLLolKvjHs&t=176s)- Demo

[6:41](https://www.youtube.com/watch?v=fwLLolKvjHs&t=401s)- Google Data Studio

[9:05](https://www.youtube.com/watch?v=fwLLolKvjHs&t=545s)- Project Next Steps

[10:07](https://www.youtube.com/watch?v=fwLLolKvjHs&t=607s)- Conclusion & Resources

[https://pinax.network/](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbHFmS2ZoSjNDUllueS1sZWVOLThaMGdfejVxZ3xBQ3Jtc0trRElmOXlLRXlLU091cFJfandXSU1weEZEVG90Q1lPYjhCUDdOMXpfNjlhaGZUUmNTbnBFWml0eGxMOVl3ZUlmaWFyRlVTQTFzTm5RcjE3eDdVYzNhN1FpeFlGajNoRVBKWXpDMmZHU0JYU1ZPWERiWQ&q=https%3A%2F%2Fpinax.network%2F&v=fwLLolKvjHs)

## Research into Pinax Network

Martin B is the CMO of Pinax, so it might make sense to reach out to him about this. Daniel Keyes is the CEO. Can see their twitter accounts and see its often what they post about

[https://twitter.com/daniel_keyes/status/1659904489296371715](https://twitter.com/daniel_keyes/status/1659904489296371715)

[https://twitter.com/volgeferhalten/status/1658775241617752068](https://twitter.com/volgeferhalten/status/1658775241617752068)

Yaniv is co-founder of The Graph, big deal:

[https://twitter.com/yanivgraph/status/1659636668679483392](https://twitter.com/yanivgraph/status/1659636668679483392)

[https://twitter.com/streamingfastio/status/1658924919114158083](https://twitter.com/streamingfastio/status/1658924919114158083)

## CSV file export from bloks and JSON Conversion

Bloks has can export csv files

perhaps vlad or other antelope devs can build JSON reciever software similar to how james mart built it 

[https://youtu.be/hyV71RJeuOI](https://youtu.be/hyV71RJeuOI)