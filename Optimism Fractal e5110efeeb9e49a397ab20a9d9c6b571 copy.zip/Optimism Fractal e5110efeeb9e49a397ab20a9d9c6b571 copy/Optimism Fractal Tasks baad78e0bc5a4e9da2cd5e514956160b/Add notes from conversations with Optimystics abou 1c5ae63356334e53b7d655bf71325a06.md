# Add notes from conversations with Optimystics about Optimystics Fractal and Eden Fractal on Base here

Assignee: Dan Singjoy
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
Status: Not started
Task Summary: This task aims to add notes from conversations with Optimystics about Optimystics Fractal and Eden Fractal on Base. The notes will provide insights and information about these projects, their status, and the people involved. It will be created and managed by Dan Singjoy, who is responsible for organizing and updating the information.
Summary: No content
Created time: May 16, 2024 10:13 AM
Last edited time: July 7, 2024 10:13 AM
Created by: Dan Singjoy
Description: No content

[Consider deploying Optimystics Fractal on Base](https://www.notion.so/Consider-deploying-Optimystics-Fractal-on-Base-2049e09a7b2749ae9f80b329749d53e1?pvs=21) 

[Respond in Optimystics Chat about deploying Eden Fractal on Base for the anniversary and Tadas’ Competition Article](https://www.notion.so/Respond-in-Optimystics-Chat-about-deploying-Eden-Fractal-on-Base-for-the-anniversary-and-Tadas-Comp-4a0001aa36a34028b810a7d2ec7f034e?pvs=21)