# Consider applying to EAS Fellowship - Ethereum Attestation Service

Project: Explore and Create Integrations with Ethereum Attestation Service (EAS) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
Status: Not started
Summary: Consider applying to the EAS Fellowship - Ethereum Attestation Service. They are looking for ambitious individuals to join the first batch and contribute to attestation technology. The fellowship offers opportunities for founders, mentors, judges, and partners. Applicants will have the chance to build solutions in various areas such as intellectual provenance, reputation systems, attested data markets, content authenticity, voting systems, audit verifications, undercollateralized lending, and RWA verifications. Read the FAQs for more information.
Created time: January 19, 2024 7:04 PM
Last edited time: March 22, 2024 7:56 PM
Created by: Dan Singjoy

[https://attest.sh/fellowship](https://attest.sh/fellowship)

# 

## Are you a good fit?

We're looking for ambitious people who want to change the world. Join the first batch of the Attestation Fellowship and be recognized as an early innovator and pioneer with attestation technology.

~15 mins to complete

### Founders

~20hrs per week

Build and scale alongside top ecosystem partners & mentors.

### Mentors

~2hrs per week

Share their expertise and grow reputations as attestation leader.

### Judges

3hrs @ Demo Day

Give feedback to early stage teams and decide whether to continue convos.

### Partners

~1hr / week

Nurture early stage teams and shape their growth trajectory.

[Ryan Yi](https://twitter.com/yiryan)

![Consider%20applying%20to%20EAS%20Fellowship%20-%20Ethereum%20Att%203966071cf83d40f991fd00772dbb39d4/ryanyi-avatar.jpg](Consider%20applying%20to%20EAS%20Fellowship%20-%20Ethereum%20Att%203966071cf83d40f991fd00772dbb39d4/ryanyi-avatar.jpg)

![Consider%20applying%20to%20EAS%20Fellowship%20-%20Ethereum%20Att%203966071cf83d40f991fd00772dbb39d4/eskender.png](Consider%20applying%20to%20EAS%20Fellowship%20-%20Ethereum%20Att%203966071cf83d40f991fd00772dbb39d4/eskender.png)

[Pranav Pandya](https://twitter.com/0xPranav)

![Consider%20applying%20to%20EAS%20Fellowship%20-%20Ethereum%20Att%203966071cf83d40f991fd00772dbb39d4/pranav.png](Consider%20applying%20to%20EAS%20Fellowship%20-%20Ethereum%20Att%203966071cf83d40f991fd00772dbb39d4/pranav.png)

## What will you build?

Attestations will help us build more trust online and onchain. We're looking for top innovators who want to solve some of the biggest challenges facing our world today.

### Intellectual Provenance

Verifying the origin of digital property, music, ideas, and much more.

### Reputation Systems

Decentralized reputations systems for social, finance, loyalty, knowledge, services.

### Attested Data Markets

Trusted oracle services and data marketplaces for humans and DePin.

### Content Authenticity

Attesting to the authenticity of the content we create, consume, and train on.

### Voting Systems

Fraud-proof voting systems for communities and governments.

### Audit Verifications

Services for attesting to financial audits and security audits.

### Undercollateralized Lending

Using attestations to build onchain credit and undercollateralized loans.

### RWA Verifications

Attesting to real world asset verifications and ownership.

## Read our FAQs for more detail.

Here's a quick list of FAQs. Join the Telegram group if you have more questions.

### What is the fellowship?

### Why does this fellowship exist?

### Why should I join as a founder?

### How long is the program, and when does it start?

### What will a typical week look like?

### Who should apply for the fellowship?

### Is this virtual or in-person?

### If I have an idea i've been working on should I still apply?

### When do applications close, how selective is the process?

### As a mentor or judge, what's expected of me?

[https://x.com/eas_eth/status/1748451874498617746?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/eas_eth/status/1748451874498617746?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)