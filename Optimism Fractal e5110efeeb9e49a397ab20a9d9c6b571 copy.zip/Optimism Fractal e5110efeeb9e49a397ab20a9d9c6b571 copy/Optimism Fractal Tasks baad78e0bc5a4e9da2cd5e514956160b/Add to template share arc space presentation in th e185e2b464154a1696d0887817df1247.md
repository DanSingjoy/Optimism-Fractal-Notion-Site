# Add to template: share arc space presentation in the chat after the event

Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Not started
Task Summary: This task aims to add the "Share Arc Space" presentation to the template and make it available for sharing in the chat after the event. The presentation, created by Dan Singjoy, is currently in the "Not started" status. The goal is to provide a brief summary or introduction for the page.
Summary: No content
Created time: June 6, 2024 2:44 PM
Last edited time: June 6, 2024 2:44 PM
Created by: Dan Singjoy