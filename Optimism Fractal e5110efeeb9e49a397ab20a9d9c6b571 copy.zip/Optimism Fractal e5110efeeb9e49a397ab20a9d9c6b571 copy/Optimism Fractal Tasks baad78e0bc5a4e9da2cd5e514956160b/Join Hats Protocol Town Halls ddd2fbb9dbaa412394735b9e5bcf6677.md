# Join Hats Protocol Town Halls

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: In progress
Task Summary: This task aims to engage community members in the Hats Protocol by facilitating town hall meetings. These gatherings will provide a platform for discussion, feedback, and collaboration among participants to enhance the project's development and implementation.
Summary: The document outlines the ongoing status of "Join Hats Protocol Town Halls," created by Dan Singjoy, but lacks specific details in the description section.
Created time: January 12, 2024 10:08 PM
Last edited time: September 26, 2024 5:06 PM
Parent task: Join Hats Community (Join%20Hats%20Community%208a1d178643654de0a1c8038fc3fb2ab3.md)
Created by: Dan Singjoy
Description: Join Hats Protocol Town Halls is currently in progress, created by Dan Singjoy, with no additional description provided.

## Description

[https://x.com/aragonproject/status/1737476627393610104?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/aragonproject/status/1737476627393610104?s=46&t=xP2VArgrZ3VqnY5S2s8WeQ)