# Research and apply for Base Ecosystem Fund

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Engage with the Superchain Ecosystem (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20the%20Superchain%20Ecosystem%201154f381dca749cb9730dae528c33571.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: In progress
Task Summary: This task aims to research and apply for the Base Ecosystem Fund. The page provides details about the fund, including information on how to request funding and recent investments made by the fund. It was created by Dan Singjoy and is currently in progress.
Summary: This document is about researching and applying for the Base Ecosystem Fund. It provides links to more information about the fund and related announcements.
Created time: May 20, 2024 9:11 PM
Last edited time: July 16, 2024 9:39 AM
Created by: Dan Singjoy
Description: Research and apply for the Base Ecosystem Fund, which has funded various projects. Details can be found in the provided links.

The Base ecosystem fund that funded paragraph

Details in [Explore base onchain summer 2 grants ](Explore%20base%20onchain%20summer%202%20grants%20cf8debbb404f402784c2359b8401497d.md) 

[](https://docs.google.com/forms/d/e/1FAIpQLSeiSAod4PAbXlvvDGtHWu-GqzGpvHYfaTQR2f77AawD7GYc4Q/viewform?pli=1)

![Untitled](Research%20and%20apply%20for%20Base%20Ecosystem%20Fund%20c6bf21fd18b04987807c884d51065199/Untitled.png)

![Untitled](Research%20and%20apply%20for%20Base%20Ecosystem%20Fund%20c6bf21fd18b04987807c884d51065199/Untitled%201.png)

[Request for Builders](https://base.mirror.xyz/lt3JR-mZ51q9eIOtGO36L3ZVzCTXmZVnbIiXz6crqzQ)

![Untitled](Research%20and%20apply%20for%20Base%20Ecosystem%20Fund%20c6bf21fd18b04987807c884d51065199/Untitled%202.png)

[Base Ecosystem Fund announces first six investments](https://base.mirror.xyz/yxd0L-FlWCto53pDaxIkEBdkgavvXJk4S3O_5-I33No)

[https://base.mirror.xyz/yxd0L-FlWCto53pDaxIkEBdkgavvXJk4S3O_5-I33No](https://base.mirror.xyz/yxd0L-FlWCto53pDaxIkEBdkgavvXJk4S3O_5-I33No)

[Base's 2024 Mission, Strategy and Roadmap](https://base.mirror.xyz/Ouwm--AtTIVyz40He3FxI0fDAC05lOQwN6EzFMD_2UM)

[Explore Base Ecosystem Fund](Research%20and%20apply%20for%20Base%20Ecosystem%20Fund%20c6bf21fd18b04987807c884d51065199/Explore%20Base%20Ecosystem%20Fund%208f0fa005141d4394ae0653e83fefe74e.md)