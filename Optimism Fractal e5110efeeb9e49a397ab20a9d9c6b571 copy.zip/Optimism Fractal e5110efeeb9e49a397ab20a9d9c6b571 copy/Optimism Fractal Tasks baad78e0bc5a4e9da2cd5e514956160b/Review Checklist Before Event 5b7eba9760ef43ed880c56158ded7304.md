# Review Checklist Before Event

Status: Not started
Task Summary: This task aims to provide a review checklist before an event. The checklist includes various steps such as starting the Zoom room early, checking audio and screen sharing functions, sending out promotional messages, and ensuring proper recording and permissions. The checklist also covers reminders, setup for lights and green screen, and assigning co-host roles. Created by Dan Singjoy, this checklist helps ensure a smooth and organized event preparation process.
Summary: Before the event, make sure to start the Zoom room early, do a sound check, turn off VPN, test screenshare function, check RAM and CPU usage, start a new meeting note, set up welcoming music and video, send out promotional messages, manually give recording permissions, allow recording on the easel, give screensharing permissions, make a co-host, check audio levels and screen size, remind people about next week's topics and recording breakout rooms, and set up lights and green screen correctly.
Created time: May 11, 2024 3:18 AM
Last edited time: July 25, 2024 9:29 PM
Created by: Dan Singjoy
Description: Before the event, make sure to start the Zoom room early, do a sound check, turn off VPN, test screenshare function, check RAM and CPU usage, start a new meeting note, set up welcoming music and video, send out promotional messages, manually give recording permissions, make sure the easel allows recording, give screensharing permissions, make a co-host, check audio levels and screen size, remind people about next week's topics and recording breakout rooms, and set up lights and green screen correctly.

- [ ]  Start zoom room at least 15 minutes earlier
    - [ ]  Do a sound check to ensure good audio output and input
    - [ ]  Turn off VPN to improve internet connection
    - [ ]  Test screenshare function in zoom
    - [ ]  Check activity monitor to make sure there is enough RAM and CPU
        - [ ]  close off his other opened tabs to save RAM
    - [ ]  Start a new meeting note and position the window for easy accessibility for notes during the meeting
    - [ ]  Set up welcoming music
    - [ ]  Set up welcoming video
    - [ ]  Send out promotional message
    - [ ]  Send out promotional message with Cagendas topic two days before event (this is probably better suited as a task in the project, whereas i think these other ones could just to do list blocks in the same page
        - [ ]  Consider the best way to organize this

- [ ]  manually give recording permissions to everyone who joins the event via zoom
    
    
    - [ ]  add it during the first few minutes when they join and before the presentation. don’t worry about giving it to everyone, just give it to whoever i can before starting the recording

- [ ]  make sure the ‘Before the Respect Game’ easel allowing people to record

- [ ]  Give everyone screensharing sharing permissions
- [ ]  Make Rosmari a co-host
- [ ]  Check audio levels
- [ ]  Check screen size for screen sharing
- [ ]  remind people about next week’s topics
- [ ]  remind people about recording the breakout room they’re in

- [ ]  turn on lights correctly

- [ ]  set up green screen correctly