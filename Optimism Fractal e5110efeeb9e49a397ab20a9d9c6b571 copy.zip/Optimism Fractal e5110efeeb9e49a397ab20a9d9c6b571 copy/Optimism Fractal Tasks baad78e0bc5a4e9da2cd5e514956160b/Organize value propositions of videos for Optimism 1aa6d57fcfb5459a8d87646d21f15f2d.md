# Organize value propositions of videos for Optimism Collective and Superchain

Project: Improve Optimism Fractal video production processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20video%20production%20processe%201ddaaa3c112a4449ab121ec9df944d9e.md)
Status: In progress
Task Summary: This task aims to organize and categorize the value propositions of videos for Optimism Collective and Superchain. It also includes plans for improving video production at Optimism Fractal and highlights the potential of the Respect Game to benefit creators in society. Additionally, it involves adding a transcript from June and incorporating it into video promotions to enhance their effectiveness.
Summary: The document discusses organizing value propositions of videos for Optimism Collective and Superchain. It mentions plans for improving video production at Optimism Fractal, providing more value for Superchain Builders, and the potential of the Respect Game to benefit creators in society.
Created time: July 17, 2024 8:37 PM
Last edited time: July 17, 2024 8:38 PM
Created by: Dan Singjoy
Description: The document discusses organizing the value propositions of videos for Optimism Collective and Superchain. It mentions plans for improving video production at Optimism Fractal, providing more value for Superchain Builders, and the potential of the Respect Game to benefit creators in society.

- [ ]  add transcript here from June and ask AI to summarize

- [ ]  add it to promotions as well to improve video promotions

our plans for improving video production at Optimism Fractal, how our videos can provide more value for Superchain Builders, and the wonderful potential for the Respect Game to benefit creators throughout society