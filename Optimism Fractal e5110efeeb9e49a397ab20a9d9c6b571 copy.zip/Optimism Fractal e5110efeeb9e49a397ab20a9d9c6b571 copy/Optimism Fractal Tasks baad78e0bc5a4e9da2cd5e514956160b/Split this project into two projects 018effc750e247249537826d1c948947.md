# Split this project into two projects

Due: May 3, 2024
Project: Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md)
Status: Not started
Task Summary: This task aims to split the project into two separate projects. It was created by Dan Singjoy and is due on May 3, 2024. The project status is currently marked as "Not started." The task was created on May 10, 2024, at 3:50 PM, and last edited on July 7, 2024, at 2:13 PM.
Summary: No content
Created time: May 10, 2024 11:50 AM
Last edited time: July 7, 2024 10:13 AM
Created by: Dan Singjoy
Description: No content

## Next Steps

This project is in an early stage of development. The next step is most likely to organize the tasks below and consider splitting this into two projects:

1. Build Optimism Fractal Development Hub 
2. Create Educational Resources for Builders

These are two distinct projects that each deserve their own space and creating two projects will enable the building of the development hub independently from the content within the hub. Currently many of the tasks below are relevant for the second project but not the first project. It’s also worth linking to other key resources in the project to build the development hub, such as funding opportunities, an introduction to Optimism Fractal tools, and developer resources in the wider EVM ecosystem.