# Review Discussions about Hats Protocol at Optimism Fractal

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: No content
Created time: February 17, 2024 10:14 AM
Last edited time: March 17, 2024 9:33 PM
Parent task: Review status, plans, and history of collaborations between Optimism Fractal and Hats Protocol (Review%20status,%20plans,%20and%20history%20of%20collaboration%2002671444172e45cf93be73e5b2359e5a.md)
Created by: Dan Singjoy

## Description

### Videos

We’ve discussed Hats Protocol in several Optimism Fractal events so far. You can see the videos, timestamps, and overviews of discussions from a few of these events below:

[Review Optimism Fractal Videos about Hats Protocol](Review%20Optimism%20Fractal%20Videos%20about%20Hats%20Protocol%200aaecbbd81bf4e1f8bd47753999f639f.md) 

### Chats

We’ve discussed Hats Protocol several times in the Optimism Fractal discord so far. You can see screenshots and links to the chats below:

[Review Posts about Hats Protocol in Optimism Fractal Discord ](Review%20Posts%20about%20Hats%20Protocol%20in%20Optimism%20Fract%20414959d259014507896f2894d27a054a.md)