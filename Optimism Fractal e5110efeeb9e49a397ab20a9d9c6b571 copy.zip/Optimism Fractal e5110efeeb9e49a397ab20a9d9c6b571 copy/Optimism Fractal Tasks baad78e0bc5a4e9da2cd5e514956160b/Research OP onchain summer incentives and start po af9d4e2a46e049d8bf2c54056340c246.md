# Research OP onchain summer incentives and start posting in onchain summer

Assignee: Dan Singjoy
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Build in Onchain Summer  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20in%20Onchain%20Summer%202f72405833b74c619c6921ffb12bc234.md)
Status: In progress
URL: https://x.com/optimism/status/1797657822328754573?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to research the onchain summer incentives and initiate posting relevant content in the onchain summer platform. The goal is to gather insights and effectively engage with the community regarding the incentives offered during this period.
Summary: Research onchain summer incentives for OP and begin posting about it, ensuring to use the hashtag Superchain. The task is currently in progress and was created by Dan Singjoy.
Created time: June 3, 2024 11:06 PM
Last edited time: August 22, 2024 2:59 PM
Created by: Dan Singjoy
Description: Research onchain summer incentives for OP and begin posting, ensuring to use the hashtag Superchain. The task is currently in progress and was created by Dan Singjoy.

[https://x.com/optimism/status/1797657822328754573?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/optimism/status/1797657822328754573?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[](https://warpcast.com/optimism/0xcfb5c0e0)

- Remember to hashtag Superchain