# Create OPTOPICS Poll on Snapshot for Optimism Town Hall #2

Assignee: Dan Singjoy
Due: May 22, 2024
Project: Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md), Prepare for OF 27 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2027%20a3a902d398094d0b826538ac88183391.md)
Status: Done
Task Summary: This task aims to create an OPTOPICS poll on Snapshot for the second Optimism Town Hall. The poll will allow community members to choose the topics they would like to discuss at the event. The topics were suggested in the Optimism Town Hall channel and will be voted on using Respect Votes, which are weighted quadratically.
Summary: This document is a poll created by Dan Singjoy for the Optimism Town Hall. The poll asks participants to choose the topic(s) they would like to discuss at the event and provides information about the OPTOPICS game.
Created time: May 22, 2024 10:35 PM
Last edited time: May 23, 2024 8:32 AM
Created by: Dan Singjoy

# **What topic would you like to discuss next at Optimism Town Hall?**

Choose the topic(s) that you'd like to discuss at today's event. Feel free to choose as many or few topics as you'd like and allocate different amounts of Respect to each topic according to your preference. Respect Votes are weighted quadratically, so each vote really counts!

As per the rules approved in this week's Cagendas [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff), below are all the topics which were suggested in the Optimism Town Hall channel in the Optimism Fractal discord server prior to Wednesday at 17 UTC. OPTOPICS is a new kind of Cagendas game that allows respected community members to suggest, vote, and dynamically coordinate discussion topics during our events. You can learn more about OPTOPICS in this [article](https://optimystics.io/optopics).