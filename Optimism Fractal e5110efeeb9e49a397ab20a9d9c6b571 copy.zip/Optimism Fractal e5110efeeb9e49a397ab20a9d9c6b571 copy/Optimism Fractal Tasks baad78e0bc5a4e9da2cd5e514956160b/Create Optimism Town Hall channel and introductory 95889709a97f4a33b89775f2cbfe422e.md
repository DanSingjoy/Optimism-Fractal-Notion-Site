# Create Optimism Town Hall channel and introductory post on the channel for Optopics

Due: May 3, 2024
Project: Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md)
Status: Done
Task Summary: This task aims to create the Optimism Town Hall channel and write an introductory post for Optopics. The post provides an overview of the Optimism Town Hall event, its purpose, and how community members can participate in discussions. It also introduces the concept of Cagendas, a consensus game used to organize discussion topics, and mentions the upcoming OPTOPICS game for optimizing meeting time.
Summary: This document is about the creation of the Optimism Town Hall channel and an introductory post for Optopics. The post provides information about the purpose of the channel, the use of social games for discussions, and the process of suggesting and voting on topics. It also includes links to relevant articles and proposals. The document concludes with a call to suggest topics and RSVP for the upcoming Optimism Town Hall event.
Created time: May 20, 2024 11:25 AM
Last edited time: May 23, 2024 12:38 PM
Created by: Dan Singjoy

Hey all! Welcome to the Optimism Town Hall channel!

Optimism Town Hall is a new weekly event and collaborative forum dedicated to hosting impactful, and respectful conversations about Optimism. This innovative event is pioneering interactive ways to optimize meeting time with fun social games that enable community members to prioritize topics, deliberate democratically, and form consensus on key issues by voting with onchain reputation tokens. 

This channel provides a place where we can suggest and discuss topics for Optimism Town Hall [weekly events](https://lu.ma/optimismtownhall) that occur after the Respect Game at Optimism Fractal. Everyone is welcome to suggest topics and join the events on Thursdays at 18 UTC to participate in deliberative discussions, pioneer the future of community coordination, and help lead the Optimism Collective. You can learn more about Optimism Town Hall in this [article](https://optimystics.io/optimismtownhall).

Feel free to share any thoughts here that related to Optimism here. I encourage you to RSVP for email reminders at the link above, invite friends, and feel free to reach out to get involved! If you’re not familiar with the town hall, read below to see how the events are organized with Cagendas games and how you can contribute to the discussions.

- 
    
    You can now RSVP for email reminders at the link above, explore below to learn more, and feel free to reach out to get involved!
    
    Optimism Town Hall is a collaborative forum for structured, respectful discussions about Optimism. This channel provides a place where we can suggest and discuss topics for Optimism Town Hall [weekly events](https://lu.ma/optimismtownhall) that occur after the Respect Game at Optimism Fractal. 
    

![optimism town hall proposal image final  wider 155.png](Create%20Optimism%20Town%20Hall%20channel%20and%20introductory%2095889709a97f4a33b89775f2cbfe422e/optimism_town_hall_proposal_image_final__wider_155.png)

After the first event of our third season, the Optimism Fractal [council](https://optimismfractal.com/council) approved a proposal to start playing a consensus game called Cagendas to organize discussion topics at Optimism Town Hall. 

Cagendas is a social coordination game for collaborative agenda setting that empowers community members to propose, discuss, and vote on topics with Optimism Fractal [Respect](https://optimystics.io/respect). You can see the game rules of Cagendas in the approved in the [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d) that are now used to organize Optimism Town Hall events below:

1. Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

2. Anyone who has earned Respect at Optimism Fractal can vote on
polls with their Respect to help determine the discussion topic for each weekly event.

3. Whichever poll has received the most votes in the Topic Poll by
Monday at 17 UTC will be the topic discussed during the week’s event
after the Respect Game.
    1. The poll for the topic proposal must end on Monday at 17 UTC (or
    earlier) to be eligible as a formal topic proposal for the week’s event.

You can learn more about Cagendas at Optimism Town Hall in this [article](https://optimystics.io/cagendas) and [announcement post](https://discord.com/channels/1164572177115398184/1164572177878765591/1239292948676477029) that was shared after the proposal was approved. In the article linked above you can also watch the videos of the past two events for more in-depth, visual overviews and community discussions about Cagendas.

![Untitled](Create%20Optimism%20Town%20Hall%20channel%20and%20introductory%2095889709a97f4a33b89775f2cbfe422e/Untitled.png)

This week I made a topic proposal to play a new Cagendas game called OPTOPICS at this week’s Optimism Town Hall, which can help optimize our meeting time by providing structure for real-time interaction and flexibility during events. OPTOPICS allows allows respected community members to easily suggest, vote, and dynamically coordinate discussion topics. You can learn more about OPTOPICS in this [article](https://optimystics.io/optopics).

Since the topic proposal to play Optopics was approved according to the rules of Cagendas, we’ll play OPTOPICS for the first time at the Optimism Town Hall this Thursday at 18 UTC. You can see the game rules for this week’s Optimism Town Hall event in this approved [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff). As per the game rules, anyone who has earned Respect at Optimism Fractal events can suggest a topic here in the Optimism Town Hall discord channel and all topic suggestions posted before 17 UTC today will be added to a Snapshot poll where we can allocate Respect votes across topics to discuss at the event. 

![thumbnail of 27 final.png](Create%20Optimism%20Town%20Hall%20channel%20and%20introductory%2095889709a97f4a33b89775f2cbfe422e/thumbnail_of_27_final.png)

If you’d like to suggest a topic, please write a title for your topic suggestion that is under 32 characters so we can easily add it to Snapshot. Feel free to include any additional links or information here that might help others prepare for the topic as well. 

I’ll start by suggesting four topics that I’m interested in discussing during this week’s Optimism Town Hall event:

- Introducing and Exploring OPTOPICS

- Reflecting on Optimism Town Hall

- Optimism Collective Season 6

- Engaging with Base

I’ll follow up with more details about each of these soon and will create a Snapshot poll that includes the topics shortly. Looking forward to hearing your topic suggestions!

---

---

---

## Prepare Presentation

- Introducing and Exploring OPTOPICS
    - [Optimystics.io/OPTOPICS](http://Optimystics.io/OPTOPICS)
    - [Develop OPTOPICS Cagendas Game for Optimism Town Hall Events](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md)
    
- Reflecting on Optimism Town Hall
    - [Optimystics.io/OptimismTownHall](http://Optimystics.io/OptimismTownHall)
    - [Develop Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md)
    
- Optimism Collective Season 6

- Engaging with Base

![thumbnail of 27 final.png](Create%20Optimism%20Town%20Hall%20channel%20and%20introductory%2095889709a97f4a33b89775f2cbfe422e/thumbnail_of_27_final.png)

![optimism fractal 25 promo image final copy.png](Create%20Optimism%20Town%20Hall%20channel%20and%20introductory%2095889709a97f4a33b89775f2cbfe422e/optimism_fractal_25_promo_image_final_copy.png)

- [ ]  consider updating the text to say Respect Game at 17 UTC and Town Hall at 18 UTC

### Suggesting and Voting on Topics

- **Suggest topics:** Starting at 17 UTC on Monday,
respected community members can suggest discussion topics in the new
Optimism Town Hall channel in the Optimism Fractal discord. The topic
can be very simple, like a quick question or just a few words. The topic could also be more complex with detailed information and links. Feel
free to suggest any topic related to Optimism Fractal or the Optimism
Collective.

- **Vote on Topics:** A poll will be created in the Optimism Town Hall snapshot space on Wednesday and all topics that were suggested in the Discord channel before 17 UTC on Wednesday will be included as options. You can allocate your Respect votes across as many topics as you’d like to influence the community’s agenda and the votes are weighted quadratically. Participants can change their votes at any point before or during the Optimism Town Hall to reflect their current
interests.

![optopics 2.png](Create%20Optimism%20Town%20Hall%20channel%20and%20introductory%2095889709a97f4a33b89775f2cbfe422e/optopics_2.png)

[https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff](https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff)

You can watch 

You can see the 

## **Game Rules**

The game begins at 18:00 UTC at the Optimism Town Hall. The main 
dynamics of gameplay are oriented around suggesting topics, allocating 
votes on topics, and transitioning to different topics.

### Suggesting and Voting on Topics

- **Suggest topics:** Starting at 17 UTC on Monday,
respected community members can suggest discussion topics in the new
Optimism Town Hall channel in the Optimism Fractal discord. The topic
can be very simple, like a quick question or just a few words. The topic could also be more complex with detailed information and links. Feel
free to suggest any topic related to Optimism Fractal or the Optimism
Collective.
- **Vote on Topics:** A poll will be created in the
Optimism Town Hall snapshot space on Wednesday and all topics that were
suggested in the Discord channel before 17 UTC on Wednesday will be
included as options. You can allocate your Respect votes across as many
topics as you’d like to influence the community’s agenda and the votes
are weighted quadratically. Participants can change their votes at any
point before or during the Optimism Town Hall to reflect their current
interests.

Feel free to add topics to 

[Create Topics for Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Topics%20for%20Optimism%20Town%20Hall%2069e19236e45d4dd8b0a4b7c6fc12ae19.md) 

[](../Optimism%20Town%20Hall%20Topics,%20v1%20cf5421ca0469466bbb57f9d5793cd773.md) 

I’ll propose some more topics here over the course of the next two days

I’ll also start it off with a few topics

Introducing Optopics:

Feedback, questions, and comments about Optimism Town Hall

Recapping the Optimism Foundation Announcements and Token House Call

If you haven’t done so already, I recommend joining both the Optimism Town Hall and Optimism Fractal snapshot spaces. You can do this by clicking Join in the top left corner of the screen. This makes it easier to find your spaces in the left side of the screen and receive notifications on Snapshot. 

![Untitled](Create%20Optimism%20Town%20Hall%20channel%20and%20introductory%2095889709a97f4a33b89775f2cbfe422e/Untitled%201.png)

- [ ]  test the subspace feature to make town hall a subspace- does that make it easier to see?