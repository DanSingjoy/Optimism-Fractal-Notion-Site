# Introduce the Fractal App chat on the OF Discord

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md), Explore Concepts of Sovereign Tokens, Intersubjective Consensus, ICP, and Firmament (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Concepts%20of%20Sovereign%20Tokens,%20Intersubject%20762925eb0d724c3aafa95e7fe2f2f811.md)
Status: In progress
Task Summary: This task aims to introduce the Fractal App chat on the OF Discord. It provides an overview of the project, including the creator, assignee, due date, and status. The page includes a description, a to-do list, and a post in the Discord chat to welcome participants and provide information about the current app and its status. It also mentions the inspiration and PRD behind the project, as well as other related discussions and collaborative approaches.
Summary: This document introduces the Fractal App chat on the OF Discord, providing an overview of the project and its goals. It includes a to-do list for organizing the introduction, adding messages and videos, and incorporating feedback. The document also highlights the current app and its status, as well as inspiration from discussions and PRDs. The collaborative approach and funding opportunities are emphasized, inviting developers and community members to contribute to the project. The document concludes with plans to share updates and feedback in the new Fractal App chat.
Sub-task: Post video and timestamps on Town Hall Channel about Optimism Fractal software (Post%20video%20and%20timestamps%20on%20Town%20Hall%20Channel%20abo%205315f4d7c13c4a41ba064a285d1c807b.md), Message Optimystics about the new fractal app chat in the Optimism Fractal (Message%20Optimystics%20about%20the%20new%20fractal%20app%20chat%2033648262e9174cffa5cbd69db58a1a0d.md), Screenshot and Respond in fractal app chat  (Screenshot%20and%20Respond%20in%20fractal%20app%20chat%20839c8102262b4cb1af3314f884427157.md)
Created time: April 16, 2024 5:40 AM
Last edited time: July 23, 2024 12:08 PM
Sub-tasks: Provide Feedback on the IC-Fractal App PRD by Hodlon and bitbeckers (Provide%20Feedback%20on%20the%20IC-Fractal%20App%20PRD%20by%20Hodl%20de10974833494578a5716b0c3f5ffc70.md), Message Optimystics about the new fractal app chat in the Optimism Fractal (Message%20Optimystics%20about%20the%20new%20fractal%20app%20chat%2033648262e9174cffa5cbd69db58a1a0d.md)
Created by: Dan Singjoy
Description: This document introduces the Fractal App chat on the OF Discord and provides a to-do list for organizing the introduction. The chat is dedicated to the collaborative development of a comprehensive fractal application for the Optimism Fractal community. The document also mentions the current app and status, inspiration from a discussion between Hodlon and Dan Singjoy, and the collaborative approach to development. The goal is to create a user-friendly platform that combines various tools and features for engaging with fractals. The document invites interested developers, creators, and community members to contribute to the project and mentions funding opportunities and related discussions.

## Description

## To Do

- [ ]  clean up the following and organize it into toggles or subtasks as needed

- [ ]  consider asking ai for help in organizing the introduction

- [ ]  add the message to joshua with videos regarding designs for respect game app to [Build Respect Game app](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md)

- [ ]  [Message Optimystics about the new fractal app chat in the Optimism Fractal](Message%20Optimystics%20about%20the%20new%20fractal%20app%20chat%2033648262e9174cffa5cbd69db58a1a0d.md)

- [ ]  See [Message Tadas about his new article regarding embracing competition in fractals in OF discord chat](https://www.notion.so/Message-Tadas-about-his-new-article-regarding-embracing-competition-in-fractals-in-OF-discord-chat-328809b269b64e06a8106e40f30ac013?pvs=21) and consider how to best include this here

## Post in Discord Chat

Hey all, welcome to the Fractal App chat!

I’m excited to introduce this new channel dedicated to the collaborative development of a fractal applications. This channel will serve as a central place to coordinate discussions about building a fractal application that helps Optimism Fractal and other communities to play the Respect Game and cooperate with Respect. 

## Current App and Status

You can learn about the current fractal software at [Optimystics.io/tools](http://Optimystics.io/tools) . The tools that we’ve been using for 8 months and have worked well enough so far, but needed improvements

Other ecosystems, software in three platforms

Everyone can also see an overview of some features for a design of a fractal app in this article, though this page hasn’t been updated in the past few months and is not exactly what we’re intending to build right now

## Inspiration and PRD

This channel was originally inspired by a discussion between @Hodlon and I during May 26th Optimism Fractal event, as you can see [here](https://youtu.be/-QbLQgOZKwk?si=Pi-Tiy2fO2svrUe9&t=3798). Hodlon and @Bitbeckers published a Product Requirement Document ([PRD](https://discord.com/channels/1164572177115398184/1164572177878765591/1227653926371725402)) for a decentralized fractal application last month and we discussed this in the video linked above. They are seeking feedback on the document and we spoke about this in the video linked above. I just organized some of my feedback and feedback from the on [this page](Provide%20Feedback%20on%20the%20IC-Fractal%20App%20PRD%20by%20Hodl%20de10974833494578a5716b0c3f5ffc70.md). 

I’ve been working to develop a fractal app with the Optimystics team for the past months and am planning to share our work here in the coming days, as well as feedback for Hodlon and Bitbeckers’ PRD. We’

## Tadas’ Optimism Fractal App

- [ ]  add parts that i wrote about about tadas’ software and town hall episode etc from eden fractal chat here
    - [ ]  also add the video from the Eden Fractal event where i introduced this and the discussion for the Eden Fractal anniversary event

For anyone who wants to dive in deeper to last week’s discussion about the next generation Optimism Fractal app and other topics, you can see all the pages that I screenshared during last week’s Optimism Town Hall [here](https://arc.net/space/783EE39C-C9D8-4FA7-A16E-E449286763DA).

## Abraham’s Building Front-end and Onchain Summer

- [ ]  add discussion with Abraham during onchain summer episode and link timestamp

## Collaborative Approach

- [ ]  add the text from response to peter hitnov and the development hub to this page and see what parts may be helpful to include

- [ ]  link to the development hub
    - [ ]  consider linking to projects for building fractal app and respect game app

I aim to foster a collaborative community-driven approach to the development of Optimism Fractal. 

Our vision is to have a thriving community of developers and creators working together to build this fractal application and grow the Optimism Fractal ecosystem.

The app is now nearly ready

Well positioned in EVM network effects

Software has been siloed in less active ecosystem for years

Ready for exponential growth and adoption

You can also see the earlier [messages](https://discord.com/channels/1164572177115398184/1164572177878765591/1227653926371725402) about this in the general channel.

The goal of this project is to create a user-friendly platform that combines various tools and features, making it easy for people to participate in the Optimism Fractal community and engage with fractals.

We invite all interested developers, creators, and community members to join the #fractal-app channel and contribute to the project in any way they can

Our vision is to have a thriving community of developers and creators working together to build this fractal application and grow the Optimism Fractal ecosystem. We'll also be exploring ways to fund and support these efforts, to ensure that everyone's contributions are fairly recognized and rewarded.

This channel is intended to help coordinate the development of a Fractal App that Optimism Fractal and other communities can use to play the Respect Game and cooperate with Respect. Feel free to share any thoughts here that are related to developing software to build a fractal app. 

This channel will be dedicated to the collaborative development of a comprehensive fractal application,

Hey everyone,
We're thrilled to announce the creation of a new channel called "fractal app" in the Optimism Fractal Discord server. This channel will be dedicated to the collaborative development of a comprehensive fractal application, based on a proposal submitted by Hodlon and BitBeckers.
The goal of this project is to create a user-friendly platform that combines various tools and features, making it easy for people to participate in the OptimFact community and engage with fractals.
We invite all interested developers, creators, and community members to join the #fractal-app channel and contribute to the project in any way they can. Whether you have ideas, skills, or resources to share, your input is valuable.
Feel free to contribute at your own pace, and don't hesitate to move the project forward independently if needed. We believe in the power of open-source collaboration and can't wait to see what we'll build together!
Join us in the #fractal-app channel and let's create something amazing!
Cheers,

Hello everyone,

 This channel, currently named "fractal app," will serve as a centralized space for documenting, discussing, and collaborating on the project.

The idea for this application stems from a proposal submitted by Hodlon and BitBeckers, which aims to combine various tools and features, such as running consensus games, creating proposals, and distributing respect tokens, into a single, user-friendly platform. The goal is to make it as easy as possible for people to participate in the OptimFact community and engage with fractals.

We invite all interested developers, creators, and community members to join us in this channel and contribute to the project in whatever way they can. Whether you have ideas, skills, or resources to share, your input is valuable and appreciated. We'll be using this space to share relevant documents, notion pages, and updates on the project's progress.

As we embark on this collaborative journey, we recognize that everyone has their own commitments and schedules. We encourage participants to contribute at their own pace and to not hesitate in moving the project forward independently if needed. The beauty of open-source collaboration is that we can all build upon each other's work and create something greater than the sum of its parts.

Our vision is to have a thriving community of developers and creators working together to build this fractal application and grow the Optimism Fractal ecosystem. We'll also be exploring ways to fund and support these efforts, to ensure that everyone's contributions are fairly recognized and rewarded.
Join us in the #fractal-app channel and let's build something amazing together!
Cheers,
The Optimism Fractal Team

You can watch us discuss plans to build an app for onchain summer at the end of the most recent Optimism Fractal video

 foster a collaborative community-driven approach to the development of Optimism Fractal. There’s a variety of projects in the notion site including very detailed projects to integrate with Hats Protocol that I update often with new tasks, ideas, and information. With this project and development strategy I’m aiming to inspire many people to contribute to the development of Optimism Fractal and Hats Protocol.

For context,  

Everyone can see  about the IC-Fractal App and the plan to coordinate the development of the fractal app in [this discussion](https://youtu.be/-QbLQgOZKwk?si=Pi-Tiy2fO2svrUe9&t=3798) from last week’s event.

Here is where I started drafting 

## Funding Opportunities

- [ ]  Consider including a part of this introduction about funding and including
    - [ ]  [Consider sending message to Optimystics team about Base Onchain Summer](https://www.notion.so/Consider-sending-message-to-Optimystics-team-about-Base-Onchain-Summer-958887abdd8b4d09bf13f70da72c4493?pvs=21)
        - [ ]  [Build with Base](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
    - [ ]  [Engage in Optimism Collective Season 6](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md)
        - [ ]  [Explore Mission Opportunities in Optimism Season 6](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md)
        - [ ]  [Integrate Optimism Fractal and the Respect Game with RetroFunding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md)

Optimism Missions, Base Funding Opportunities, RetroFunding, Octant, Gitcoin etc

## Share in the new fractal app chat

- [ ]  forward previous messages from general chat?
    - [ ]  Respond in general chat that i shared updates in the new #fractal-app chat?

- [ ]  share draft feedback to hodlon and bitbeckers

- [ ]  share draft projects for fractal app and respect game app

- [ ]  share link to timestamp with discussion here?

## Related

[Announce Developers Hub and share Superchain Console in Optimism Fractal Development Chat](Announce%20Developers%20Hub%20and%20share%20Superchain%20Conso%20ee7991abe3624708833839ffcc75a085.md) 

[Announce Optimism Fractal Development Hub and share resources in the Development Channel](Announce%20Optimism%20Fractal%20Development%20Hub%20and%20shar%20bf2c80fdf56c4c769771e1ad62928639.md) 

[Provide Feedback on the IC-Fractal App PRD by Hodlon and bitbeckers](Provide%20Feedback%20on%20the%20IC-Fractal%20App%20PRD%20by%20Hodl%20de10974833494578a5716b0c3f5ffc70.md)