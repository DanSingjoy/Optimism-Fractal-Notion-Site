# Plan and discuss ideas for Networking Site with Optimism Fractal community

Project: Create Optimism Fractal Builders Site (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Builders%20Site%20b2364cd97d724ac78f2b7f30c2f476c2.md)
Status: Not started
Task Summary: This task aims to plan and discuss innovative ideas for a networking site tailored to the Optimism Fractal community. The goal is to enhance connectivity and collaboration among community members, fostering a supportive environment for sharing knowledge and resources.
Summary: The document outlines a plan to discuss ideas for a networking site with the Optimism Fractal community, created by Dan Singjoy, with the status marked as not started.
Created time: September 25, 2024 1:56 PM
Last edited time: September 25, 2024 1:57 PM
Created by: Dan Singjoy
Description: A plan is in place to discuss ideas for a networking site with the Optimism Fractal community, created by Dan Singjoy, with the status currently marked as not started.

### Charmverse, Notion, and Hats

Me and Jacob Homanics created the [Optimism Fractal Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) that enables anyone who has earned Respect at Optimism Fractal weekly events to claim a Rookie Hat, which grants access to the Optimism Fractal charmverse [space](https://app.charmverse.io/optimismfractal/welcome-33440438705074915) and a new networking page for builders. 

Charmverse is an innovative web-based platform designed to help communities and teams collaborate, manage projects, and organize information. It combines tools for creating and managing tasks, documents, and discussions in a single space. Charmverse is particularly popular with decentralized autonomous organizations and onchain communities, as it supports governance features, token management, and community engagement. 

I’m considering to set up an Agreement Module that allows people to opt into showing their details publicly or privately in the Optimism Fractal notion and/or charmverse site. This could help promote each community member and help people better understand the talented builders in the Optimism Fractal community. We’d need to decide the best way to organize this to make it work well and I have some ideas that we could discuss.

You can learn more at [Charmverse.io](http://Charmverse.io) and see the Optimism Fractal Charmverse [here](https://app.charmverse.io/optimismfractal/welcome-33440438705074915).

[Dan Singjoy in Hats Protocol + Optimism Fractal](https://t.me/hatsprotocolandoptimismfractal/161)

[https://t.me/hatsprotocolandoptimismfractal/161](https://t.me/hatsprotocolandoptimismfractal/161)