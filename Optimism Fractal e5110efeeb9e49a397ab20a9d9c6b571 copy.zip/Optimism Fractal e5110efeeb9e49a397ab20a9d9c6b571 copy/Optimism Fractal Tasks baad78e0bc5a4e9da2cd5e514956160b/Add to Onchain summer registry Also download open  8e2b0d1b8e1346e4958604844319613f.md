# Add to Onchain summer registry. Also download open source font

Assignee: Dan Singjoy
Due: July 19, 2024
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md)
Status: Not started
Task Summary: This task aims to add the necessary information to the Onchain summer registry and download an open-source font. It is created and assigned by Dan Singjoy, with a due date of July 19, 2024. The task is currently marked as not started. For more information, you can check the https://x.com/jessepollak/status/1801045385580081585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ.
Summary: Dan Singjoy needs to add to the Onchain summer registry and download an open source font. The task is not started and is due on July 19, 2024. The task was created on June 13, 2024, and last edited on July 16, 2024. There is also a link provided.
Created time: June 13, 2024 7:56 AM
Last edited time: July 15, 2024 8:18 PM
Created by: Dan Singjoy
Description: Dan Singjoy has created a task to add to the Onchain summer registry and download an open-source font. The task is not started and is due on July 19, 2024. The task was created on June 13, 2024, and last edited on July 16, 2024. A link to a tweet is also provided.

[https://x.com/jessepollak/status/1801045385580081585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/jessepollak/status/1801045385580081585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/jessepollak/status/1801045385580081585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/jessepollak/status/1801045385580081585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)