# Consider adding older Notes

Project: Create Welcome Guide for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md)
Status: Not started
Task Summary: This task aims to consider adding older notes to the document titled "Consider adding older Notes." The task is created by Dan Singjoy and is currently marked as not started. The purpose is to review and potentially include specific notes in the document.
Summary: Consider adding older notes to the document.
Created time: May 21, 2024 9:59 AM
Last edited time: May 21, 2024 10:03 AM
Created by: Dan Singjoy

- [ ]  consider to add the following notes here:
    - [ ]  [Welcome guide - Eden Fractal](../../EC%20Tasks%201951af2e70bd4666850a3d112e65f7a8/Welcome%20guide%20-%20Eden%20Fractal%20d984f2a32a1d48c885a1b78b867b3cec.md)
    - [ ]  [Welcome guide - Eden Fractal](../../EC%20Tasks%201951af2e70bd4666850a3d112e65f7a8/Welcome%20guide%20-%20Eden%20Fractal%20d984f2a32a1d48c885a1b78b867b3cec.md)
    - [ ]  [Welcome](https://www.notion.so/Welcome-ad452ef3ddd54c25bea4090299b3c7ea?pvs=21)
    - [ ]  [Welcome Material](https://www.notion.so/Welcome-Material-d8802255307145b48be9695746da9261?pvs=21)
    - [ ]  [Create Eden Fractal game rules guide and welcome message templates ](https://www.notion.so/Create-Eden-Fractal-game-rules-guide-and-welcome-message-templates-551dae2ebe454c7aac9731e44517b0d4?pvs=21)
    - [ ]  [Fractaliens meeting - Welcome Guide](https://www.notion.so/Fractaliens-meeting-Welcome-Guide-9b75b4cff48b4044a3f813e0bfdc359e?pvs=21)