# Explore Karma GAP - Grantee Accountability Protocol

Project: Explore and consider integrating with Intersubjective, Pluralistic Measurement Systems (such as SourceCred, PlaceCred, Praise and Armitage) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20consider%20integrating%20with%20Intersubject%203469e1de3b1e4193bf6dae0c669093f8.md), Explore and consider integrating structured systems for collaborative project development (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20consider%20integrating%20structured%20system%20b5384ff7cc38427da1917f2509ef84c7.md)
Status: Not started
URL: https://gap.karmahq.xyz/
Summary: Karma GAP (Grantee Accountability Protocol) aims to address challenges in the crypto ecosystem's grant funding by providing a platform for tracking project progress, establishing reputation portability for grantees, and enabling the development of applications using structured data for evaluating grant impact and builder reputation.
Created time: May 2, 2024 10:59 AM
Last edited time: May 2, 2024 11:01 AM
Created by: Dan Singjoy

[https://twitter.com/karmahq_/status/1785294065677840402](https://twitter.com/karmahq_/status/1785294065677840402)

- Stay up-to-date on projects progress.
- Trigger payments based on milestone completion.
- Endorse projects, monitor fund usage and flag discrepancies.

![https://gap.karmahq.xyz/images/homepage-artwork.png](https://gap.karmahq.xyz/images/homepage-artwork.png)

Homepage artwork

### Communities using GAP

[Arbitrum](https://gap.karmahq.xyz/arbitrum)

[Gitcoin](https://gap.karmahq.xyz/gitcoin)

[Optimism](https://gap.karmahq.xyz/optimism)

[Public Nouns](https://gap.karmahq.xyz/public-nouns)

[Pokt](https://gap.karmahq.xyz/pokt)

[Glo Dollar](https://gap.karmahq.xyz/glodollar)

[Fractal Visions](https://gap.karmahq.xyz/fractal-visions)

[OpenCivics](https://gap.karmahq.xyz/opencivics)

### 100% ONCHAIN

## Why are we building this?

Annually, the crypto ecosystem issues grants amounting to millions of dollars. While this funding is crucial for ecosystem growth, it has also introduced a range of issues.

The Grantee Accountability Protocol (GAP) is designed to address these challenges by aiding grantees in building their reputation, assisting communities in maintaining grantee accountability, and enabling third parties to develop applications using this protocol.

### Limited Accessibility

Currently, it is challenging for grant teams and the community to easily access and track project progress and milestones, as information is scattered across forums and external links.

### Reputation Portability

Grantees who apply for grants from multiple organizations struggle to establish and carry their reputation consistently across the ecosystem. This is particularly difficult for individuals who are new to the ecosystem and need opportunities to showcase their work and build their reputation.

### Inadequate Data Structure

The absence of structured data that can be accessed in a permissionless manner hampers the development of applications and analytical tools for evaluating grant impact and builder reputation.