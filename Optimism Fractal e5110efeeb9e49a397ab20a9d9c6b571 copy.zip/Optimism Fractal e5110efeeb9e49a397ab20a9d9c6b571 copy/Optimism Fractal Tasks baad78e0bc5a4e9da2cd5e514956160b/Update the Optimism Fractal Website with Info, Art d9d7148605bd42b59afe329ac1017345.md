# Update the Optimism Fractal Website with Info, Art, and Pages about the Optimism Collective and Superchain (Create OptimismFractal.com/superchain)

Project: Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md), Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Create Documentation for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Documentation%20for%20Optimism%20Fractal%203ddb136554ea454b875ca8ec00d3900d.md)
Status: Not started
Task Summary: This task aims to update the Optimism Fractal website with information, art, and pages about the Optimism Collective and Superchain. The goal is to provide clarity to newcomers and refine presentations by explaining what Optimism is and linking to relevant resources. Additionally, the task includes considering artwork and strategizing the implementation timeline.
Summary: The document discusses updating the Optimism Fractal website with information, art, and pages about the Optimism Collective and Superchain. It suggests adding a section at the top of the website to explain Optimism, linking to http://optimism.io/join for the Collective, and creating a dedicated page for the Superchain. The document also proposes updating the core intents of Optimism Fractal to include optimizing collective governance. The proposed changes aim to provide more clarity, value, and refined messaging to the community and target audience.
Created time: June 9, 2024 9:58 AM
Last edited time: June 17, 2024 1:40 PM
Created by: Dan Singjoy

## Update the Optimism Fractal Website with Info about the Optimism Collective and Superchain

- I think there should be a section near the top of the website that explains what is Optimism, or what is the Optimism Collective and Superchain
    - This will help clarify Optimism for newcomers right from the start of the website and in my introductory presentations
        - This will provide more value to the collective, provide more clarity to viewers, and make my presentations more refined/efficient
    - It can link to [Optimism.io/join](http://Optimism.io/join) for the Collective
        - Alternatively/eventually it could link to [OptimismFractal.com/collective](http://OptimismFractal.com/collective) which provides details and links while keeping people on our website
    - What is the best link for the Superchain?
        - Should we make our own link like [OptimismFractal.com/superchain](http://OptimismFractal.com/superchain) and build a basic site that includes it, while keeping people on the website
        - We could also create [OptimismFractal.com/base](http://OptimismFractal.com/base) and so forth
    
- [ ]  Consider the artwork that we should create to illustrate our relationship with the Optimism Superchain
    - I think it makes sense for the OP moon, Base logo, and Ethereum logo to be in the top picture since these are our biggest target markets
    - I think it makes sense for us to create another picture near the top of the site
        - Perhaps this can have the logos of top superchain communities around the sunny flower in the sun

- [ ]  Consider the best strategy and timeline for this
    - Perhaps it makes the most sense to roll this out in 3-4 stages:
        1. Update homepage cover image
        2. Add a section near the top of the homepage that explains the superchain and collective, while simply linking to external sites
        3. Create pages for superchain and collective on OF website
        4. Create pages for Base, OP mainnet, etc on the OF website

## Proposal for Updating Optimism Fractal’s Core Intents

If this proposal is approved, the core intents of Optimism Fractal will be updated to include ‘optimize collective governance’. This intent will be updated on OptimismFractal.com and on social media. Everything else will remain the same in the intent as published on [OptimismFractal.com/details](http://OptimismFractal.com/details) except for the following change:

### Current Intent

**Optimism Fractal is a community dedicated to fostering collaboration and awarding public good creators on Optimism.**

### Proposed Intent

**Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing collective governance on Optimism.**

- 
    
    
    **Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing collective decision-making on the Optimism Superchain.**
    

**Option 2:**

**Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance in the Optimism Collective and Superchain.**

- This option could be better to clarify what is Optimism directly in the core intents
    - Our main target markets are the Optimism Collective leadership and Superchain communities like Base, so this could clarify to them exactly what we mean by Optimism
        - For example, the Base community might be more interested in joining if it specifically states Superchain than if it just states Optimism, because some people in the Base community might think that Optimism more so means the OP mainnet
        - We’ve already heard this feedback from CAC as well- he wasn’t sure what is Optimism but if we state Optimism Collective and Superchain right in the beginning then it makes it much easier for him to search it
    - On the other hand, just writing ‘Optimism’ does encapsulate this (albeit less clearly and directly) and is much shorter and simpler for a general audience.
        - Just stating Optimism is As this [article](https://optimism.mirror.xyz/9ZMwZjst9SQpzIgEd4gN42UDjATyK3ZRClPFx9oMPp8) states, Optimism is the Superchain and Collective. But most people haven’t read this article in the onchain space and almost nobody has heard of Optimism outside of the onchain ecosystem, so I think it’s better to be more specific here in the title
    - Generally I think that this option is probably better for now because it’s more important to optimize our messaging with our target audience right now than to optimize our messaging for a general audience
        - After we’ve established strong relationships with our target markets and grown Optimism Fractal to a more mature, independent state in the future, then I think it probably makes more sense to use a more general phrase like growing Optimism instead of the  Collective and Superchain
            - At this point we’ll have more of our own distribution, more people will be familiar with the meaning of Optimism in this context, and the poetry of growing Optimism will be able to shine more with the underlying support network of education

Option 3:

**Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing decentralized governance for the Optimism Collective and Superchain.**

- This option changes ‘in’ to ‘for’, which makes it more direct and of service to Optimism.
    - Generally I think that the word ‘in’ works very well to communicate with our target audience and works much better for communicating a general audience.
    - Overall I think ‘in’ makes more sense than ‘for’- it just seems like better grammar and doing these things ‘in’ Optimism naturally implies that it’s also ‘for’ Optimism
- It also prefixes governance with the word ‘decentralized’, which provides more specificity regarding the type of governance.
    - Alternatively we could use the word democratic or some other word
    - Generally I think it’s best to just keep it simple with optimizing governance- that implies that it has the features of decentralization, democracy, fairness, fast, fun, enjoyable, efficient, etc… and it keeps it shorter, which is helpful for both our target and general audience.

Option 4:

**Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing decentralized governance for the Optimism Collective and Superchain.**

## Rationale

I believe that this is a helpful change for a few reasons:

1. Optimism Fractal is now pioneering collective decision-making in several different ways, including our [Council](https://optimismfractal.com/council) consensus process, topic discussion protocols, more advanced software, and discussions at Optimism Town Hall amongst our vibrant community. The Optimystics originally set the current two core intents when Optimism Fractal was just about to start in last October and didn’t have nearly as much to offer regarding collective governance, but now Optimism Fractal has grown to a point where it can make a significant impact on Optimism Collective governance.
2. Optimism Fractal is rooted in fractal democracy, a governance process pioneered to bring true democracy that truly empowers people throughout society. fractally, eden fractal, fractal democracy article, more equal animals. history of fractals article. 
3. The Optimism Collective is seeking to improve . One of the three core intents of Season 6 is to progress towards decentralizion. future of optimism governance article
4. The 6th round of Retro Funding is focused on governance and Optimism Fractal community members will be more well-positioned to earn funding in this round when we are more clearly providing a positive impact in Optimism Collective governance.
5. By adding a bit about optimizing collective governance in our core intent and repeating it throughout our messaging, we can more clearly convey the value that the Optimism Fractal community provides for the Collective and attract others who are also interested in improving collective decision-making.

optimize collective decision-making

One thing that’s important to note is exactly what is Optimism. Some people might ask… what do you mean by on Optimism. You can see this [article](https://optimism.mirror.xyz/9ZMwZjst9SQpzIgEd4gN42UDjATyK3ZRClPFx9oMPp8) for an overview of Optimism and Superchain, including Base, OP Mainnet, Worldchain, Zora, Farcaster, and many others.

## To Do

- [x]  consider sharing with optimystics first for feedback
    - I could do this in the telegram chat, though i don’t think it’s necessary and probably better to just share it with active community members at the same time
    - I think it’s best to share it in the OF public chat and optimystics chat at the same time like Tadas did with his work, so we can have both channels open for discussion and the Optimystics are aware of the proposed change

- [ ]  write the rationale better with the help of AI
    - [ ]  consider how it should be formatted best
    - [ ]  read about new intent in [Read and Curate Articles about Optimism Collective Season 6](Read%20and%20Curate%20Articles%20about%20Optimism%20Collective%20a3eec2c25e35412584ca825a0f590aac.md)

- [ ]  Share this page with turquoise and Rosmari for feedback
    - I could also share it with Optimystics then and just let them know that I’m planning to share it publicly in the next few days. Would appreciate feedback

- [ ]  Propose the core intents in Option 2: **Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance in the Optimism Collective and Superchain.**
    - [ ]  Include a link to this page that has the general rationale, different options that weren’t proposed, and why these core intents were proposed
    - [ ]  Propose this as a discussion topic for Cagendas as well
        - This way we can discuss it if we want or the council can just approve the proposal without discussion, but there is space to discuss it and get feedback
        - Perhaps it would be good to vote for it as well so there is more time for feedback rather than just approving it

- [ ]  read this article

[The Future of Optimism Governance](https://optimism.mirror.xyz/PLrAQgE1EGRo7GRrFoztplFChnUZda4DFGW3dkQayxY)

[Preparing Optimism for the Superchain future](https://optimism.mirror.xyz/9ZMwZjst9SQpzIgEd4gN42UDjATyK3ZRClPFx9oMPp8)

## Update the Optimism Fractal Website with Info about the Optimism Collective and Superchain

- I think there should be a section near the top of the website that explains what is Optimism, or what is the Optimism Collective and Superchain
    - This will help clarify Optimism for newcomers right from the start of the website and in my introductory presentations
        - This will provide more value to the collective, provide more clarity to viewers, and make my presentations more refined/efficient
    - It can link to [Optimism.io/join](http://Optimism.io/join) for the Collective
    - What is the best link for the Superchain?

- [x]  add task to [Improve [OptimismFractal.com](http://OptimismFractal.com) Website (and Create Educational Resources)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md)
    - [Update the Optimism Fractal Website with Info, Art, and Pages about the Optimism Collective and Superchain (Create OptimismFractal.com/superchain) ](Update%20the%20Optimism%20Fractal%20Website%20with%20Info,%20Art%20d9d7148605bd42b59afe329ac1017345.md)
    

- I think there should be a section near the top of the website that explains what is Optimism, or what is the Optimism Collective and Superchain
    - This will help clarify Optimism for newcomers right from the start of the website and in my introductory presentations
        - This will provide more value to the collective, provide more clarity to viewers, and make my presentations more refined/efficient
    - It can link to [Optimism.io/join](http://Optimism.io/join) for the Collective
    - What is the best link for the Superchain?

- [x]  add task to [Improve [OptimismFractal.com](http://OptimismFractal.com) Website (and Create Educational Resources)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md)