# Review Notes about Improving Notion Inbox and Meeting workflows from July 2023

Status: In progress
Task Summary: This task aims to review and improve the Notion Inbox and Meeting workflows based on the review notes from July 2023. The goal is to enhance organization and efficiency in note-taking and ensure better utilization of features such as backlinking and page linking in Notion.
Summary: To improve Notion Inbox and meeting workflows, consider outlining agendas using databases, habituating the process, and setting up templates. Use roll ups or linked database views and watch videos about meeting notes in Notion. The current situation involves spending time organizing notes after meetings, and the benefits of refining the workflow include better utilization of backlinking and linking pages in Notion.
Parent-task: Review and organize subtasks: Start Using Database Templates to organize meeting notes and event preparation (Review%20and%20organize%20subtasks%20Start%20Using%20Database%20%20fa23af5ec1ed4a3b9ff1c576a4c27fb5.md)
Created time: April 2, 2024 10:00 AM
Last edited time: June 18, 2024 12:04 PM
Parent task: Review and organize subtasks: Start Using Database Templates to organize meeting notes and event preparation (Review%20and%20organize%20subtasks%20Start%20Using%20Database%20%20fa23af5ec1ed4a3b9ff1c576a4c27fb5.md)
Created by: Dan Singjoy

## Description

## Test and Automate this process

- [x]  Try outlining our agenda using database from the start rather than just a text page

- If this works well then habituate doing this more in the future and probably set up a template for meetings like this
    - See [July 29th](https://www.notion.so/July-29th-3e73a176b5da496287baa500eed1b4e8?pvs=21) for our first try of this

- Consider using roll ups or linked database view
    - It could maybe be a linked database of Inbox added here to each meeting note?
    - Then we could decide if it should go into projects, wiki, or elsewhere
    - Ideally each note could have a ‘date created’ Property, which can then be filtered and viewed.
        - I think this would be good and am not sure how high of a priority is it
        - Thoughts?

Consider watching videos about meeting notes in notion

Consider trying template for meetings notes and reviewing our project about this 

## Current Situation and Problem

- I spend much of my time writing notes in meetings then organizing them afterwards. Currently I don’t have a button for a new meeting. I’ve been writing some notes in [EC Meeting Notes and Meeting Workflow](https://www.notion.so/EC-Meeting-Notes-and-Meeting-Workflow-3fba4c1074d144a8a7a54905ff86e248?pvs=21) and others in my inbox or projects and tasks database. Then I need to reorganize them later. My current workflow doesn’t doesn’t create unique pages in ‘inbox 2’ and I haven’t organized all the notes by page in a database yet, so I think this offers large benefits to be more organized and time efficient

## Benefits of Refining Meeting Notes Workflow

- The Notion backlinking feature can work better when notes are quickly sorted into their own pages

- The notion feature for linking pages with [[ ]] works so much better with this workflow design for meeting notes