# Consider creating a weekly promotional post that includes Calendar of this week’s events every monday

Status: Not started
Task Summary: This task aims to create a weekly promotional post that includes a Calendar of this week's events every Monday. The post will be created by Dan Singjoy and will provide information about recurring events such as Eden Fractal on Wednesdays at 16 UTC and Optimism Fractal on Thursdays at 17 UTC. Joining these events will be a great opportunity to connect with the community and explore new experiences.
Summary: Consider creating a weekly promotional post that includes a calendar of events for the week, with Eden Fractal on Wednesdays at 16 UTC and Optimism Fractal on Thursdays at 17 UTC. Join http://lu.ma/edenfractal and https://lu.ma/optimismfractal for more information.
Created time: June 17, 2024 1:42 PM
Last edited time: June 17, 2024 1:43 PM
Created by: Dan Singjoy

Everyone is welcome to join [Eden Fractal](http://lu.ma/edenfractal) every Wednesday at 16 UTC and [Optimism Fractal](https://lu.ma/optimismfractal) on Thursdays at 17 UTC. I'd love to see you all again sometime soon ✨

[lu.ma/optimystics](http://lu.ma/optimystics) 

[](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Events%20ea9e175f88f5452f9bd834bbabcab0a4/Optimism%20Fractal%20Events%20Calendar%209fe995ccda1b492daae39353c5452549.md) 

[Create Calendar of Events for Optimism Collective](Create%20Calendar%20of%20Events%20for%20Optimism%20Collective%206f142fcf13744f73bf57b2cf7d454160.md) 

optimism town hall