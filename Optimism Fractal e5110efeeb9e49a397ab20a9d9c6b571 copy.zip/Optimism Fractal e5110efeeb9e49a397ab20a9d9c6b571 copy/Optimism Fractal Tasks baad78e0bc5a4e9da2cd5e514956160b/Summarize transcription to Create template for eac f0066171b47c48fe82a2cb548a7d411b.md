# Summarize transcription to Create template for each Optimism Fractal event

Assignee: Dan Singjoy
Due: June 4, 2024
Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Done
Task Summary: This task aims to create a template for each Optimism and Eden fractal event, streamlining event preparation and ensuring consistency. The templates will include pre-built tasks, such as preparing presentations and checklists, to save time and mental energy. Additionally, personalized event preparation projects will be implemented to tailor the preparation process to individual roles and responsibilities, encouraging collaboration and continuous improvement.
Summary: To optimize event preparation for Optimism Fractal events, the following steps are recommended: 1) Create event templates for each type, including pre-built tasks, and host them on a public Notion site. 2) Implement a pre-event checklist to ensure smooth execution and automate the preparation process. 3) Develop a breakout room preparation task with guidelines for community engagement and growth. 4) Experiment with personalized event preparation using individual tasks tailored to each team member's role.
Created time: May 10, 2024 3:05 PM
Last edited time: June 5, 2024 9:46 PM
Created by: Dan Singjoy

# Summary: Optimizing Fractal Event Preparation

## 1. Create Event Templates

- Develop templates for each Optimism and Eden fractal event
- Host templates on the public Notion site
- Include pre-built tasks with templates

### Key Points

- Streamlines event preparation
- Saves time and mental energy
- Ensures consistency across events

### To-Do

- Design and create templates for each event type
- Incorporate tasks and checklists into templates
- Upload templates to the public Notion site

## 2. Pre-Event Checklist

- Rosemary and I will join 15 minutes early for each event
- Go through the pre-event checklist together
- Ensure proper screen sizing, audio quality, and other technical aspects

### Key Points

- Ensures smooth event execution
- Promotes collaboration and communication
- Automates the preparation process

### To-Do

- Develop a comprehensive pre-event checklist
- Automate the checklist process as much as possible
- Remind each other to follow the checklist, especially in the beginning

## 3. Breakout Room Preparation

- Create a task for preparing the breakout room presentation
- Include a summary of contributions and achievements
- Develop guidelines for being good hosts and growing the community

### Key Points

- Enhances the breakout room experience
- Encourages community engagement and growth
- Provides a framework for future hosts

### To-Do

- Create a task template for breakout room preparation
- Develop a set of host guidelines for community growth
- Invite new members to Discord and ensure they have Telegram and ETH

## 4. Personalized Event Preparation

- Use the same project to prepare for each event (e.g., Optimism Fractal 27)
- Each person has their own tasks to prepare for the event
- Experiment with this approach to optimize event preparation

### Key Points

- Tailors event preparation to individual roles and responsibilities
- Encourages collaboration and accountability
- Allows for continuous improvement and experimentation

### To-Do

- Implement personalized event preparation projects
- Assign tasks to each team member based on their role
- Evaluate the effectiveness of this approach and iterate as needed

- Transcript
    
    so I'm going to summarize some of the things we've talked about so far..  So in summary as quickly and concisely as I can, the most recent topic that we just discussed is the idea of of creating a template for each event, for each Optimism fractal event and for each Eden fractal event and so forth. This could be in the public chat or rather the public Notion site, and it can have several different tasks that are pre-built with templates. One of the tasks can be for preparing my presentation at the beginning of the episode, and that can include all the links that I usually share, which makes it easier and saves brain power bring those up. Another one of those is the checklist. So Rosemary and I are going to join 15 minutes early to each event and we're going to go through the checklist. I'm going to work as best I can to automate that and be able to do it just like basically like brushing my teeth like habituated making sure that my screen is sized correctly and that the audio is good and or Rosemary should also do the same too. And then we're also gonna, especially in the beginning, I think that we should just remind each other to do the best of our ability as we're getting this automated set up working. So we'll both be here 15 minutes early. So we'll both go over the checklist together and make sure that we're both well set up with our audio and video and screen-sharing and so forth. And so that'll be one of the tasks in that project. and that'll all be built in a template with a checklist for every event. And then there'll also be a checklist for, or there'll also be another task for preparing for the breakout room. And that will include your presentation for the breakout room of your contributions and what you did. And then it'll also include other things like basically being good hosts and helping to grow the community by doing things like inviting the people to Discord if there's new people, and also to make sure they have a Telegram account and they have ETH in their account and so forth. So you can send it to them. And then these can also be created into kind of like a host guidelines or something like that, that others could also use to do a similar thing. Another idea I had there was that we could eventually use the same project to prepare for each event, like prepare for optimism Fractal 27, for example. and then we could just have our own tasks built in there where each person has their own tasks to prepare in the event. So that might be a cool thing to experiment with.