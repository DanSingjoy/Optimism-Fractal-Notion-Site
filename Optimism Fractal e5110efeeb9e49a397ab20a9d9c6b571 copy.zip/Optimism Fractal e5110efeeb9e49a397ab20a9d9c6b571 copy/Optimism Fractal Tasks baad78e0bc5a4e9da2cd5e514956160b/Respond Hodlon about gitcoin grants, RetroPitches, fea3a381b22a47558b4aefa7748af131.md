# Respond Hodlon about gitcoin grants, RetroPitches, and GG20 Pitch Sessions in Shill Projects channel

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Create Topics for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Topics%20for%20Optimism%20Town%20Hall%2069e19236e45d4dd8b0a4b7c6fc12ae19.md)
Status: Not started
Task Summary: This task aims to respond to Hodlon regarding Gitcoin grants, RetroPitches, and GG20 Pitch Sessions in the Shill Projects channel. The page includes information about the task creator, assignee, due date, status, and related links. It also mentions the interest in playing RetroPitches and participating in public goods pitch sessions during the upcoming GG21 season.
Summary: The document is a response to Hodlon about Gitcoin grants, RetroPitches, and GG20 Pitch Sessions in the Shill Projects channel. The author mentions donating to a grant for Kingfishers Media and expresses interest in RetroPitches and public goods pitch sessions for the upcoming GG21 season.
Created time: May 12, 2024 1:57 AM
Last edited time: July 23, 2024 12:08 PM
Created by: Dan Singjoy
Description: The document is a response to Hodlon about Gitcoin grants, RetroPitches, and GG20 Pitch Sessions in the Shill Projects channel. The author mentions donating to a grant for Kingfishers Media and expresses interest in RetroPitches and public goods pitch sessions for the upcoming GG21 season.

![Untitled](Respond%20Hodlon%20about%20gitcoin%20grants,%20RetroPitches,%20fea3a381b22a47558b4aefa7748af131/Untitled.png)

Thanks for sharing. I only vonated to Will’s grant for Kingfishers Media this season, which was the first time that I’ve donate on Gitcoin. I checked out the projects you shared and they look interesting, looking forward to learning more about them. It would bee cool to play [RetroPitches](https://optimystics.io/retropitches) or do [public goods pitch session](https://optimystics.io/exploringretropitches#block-04b76705fb994cc6846e1411d7dbf873) in the upcoming GG21 season and we could propose the topic for an Optimism Town Hall

- [ ]  add Retropitches 3  to exploring retropitches

Related: 

- [Respond to Will T about Let’s Grow in Eden Fractal chat](https://www.notion.so/Respond-to-Will-T-about-Let-s-Grow-in-Eden-Fractal-chat-ce2686dbda6e4641a00ac7ca59582196?pvs=21)
- [Respond to Will T in Eden Fractal and Optimism Fractal telegram chats about Let’s Grow Live broadcasts for livestream ](https://www.notion.so/Respond-to-Will-T-in-Eden-Fractal-and-Optimism-Fractal-telegram-chats-about-Let-s-Grow-Live-broadcas-88273bd248df4e7887b32a77ea0731cb?pvs=21)