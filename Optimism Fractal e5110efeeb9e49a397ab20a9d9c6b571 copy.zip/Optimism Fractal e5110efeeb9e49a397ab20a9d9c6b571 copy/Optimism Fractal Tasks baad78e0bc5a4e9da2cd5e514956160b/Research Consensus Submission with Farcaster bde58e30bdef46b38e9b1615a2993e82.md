# Research Consensus Submission with Farcaster

Project: Explore and Create Integrations between Farcaster and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md)
Status: Not started
Summary: To submit a research consensus with Farcaster, sign in or enable consensus submission via a frame. This process may be easier than using a normal optimism account.
Created time: February 8, 2024 3:02 PM
Last edited time: February 15, 2024 7:58 PM
Created by: Dan Singjoy

- Sign in with Farcaster or enabling consensus submission via a frame
- This could be easier than a normal optimism account?