# make discord post inviting everyone to join office hours after event and follow up with gene

Assignee: Dan Singjoy
Due: July 16, 2024
Project: Develop Fractal Office Hours Event (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Fractal%20Office%20Hours%20Event%2043de4896b2f043919ac06fbadd6fcfda.md), Prepare for OF 34 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2034%200c98b5f4f06240b688d1caf3b6038e9b.md)
Status: Done
Task Summary: This task aims to create a Discord post inviting everyone to join office hours after an event and follow up with Gene. The post will be created by Dan Singjoy, with a due date of July 16, 2024. The task status is marked as done.
Summary: Dan Singjoy has created a task to make a Discord post inviting everyone to join office hours after the event and follow up with Gene. The task is assigned to Dan Singjoy and is marked as done.
Created time: July 3, 2024 6:25 PM
Last edited time: July 15, 2024 8:15 PM
Created by: Dan Singjoy
Description: Dan Singjoy created a task to make a Discord post inviting everyone to join office hours after an event and follow up with Gene. The task was assigned to Dan Singjoy and was marked as done. The task was created on July 3, 2024, at 10:25 PM and was last edited on July 16, 2024, at 12:15 AM.

- [ ]  first create event
    - [ ]  [Create event for Office Hours on Optimystics Luma Calendar](https://www.notion.so/Create-event-for-Office-Hours-on-Optimystics-Luma-Calendar-7c65891b49584d9b96ce3bd05e8abc2c?pvs=21)

Yes, these mission requests are for Season 6. I was previously mistaken about the date of mission requests and they must be approved by July 8th (not June 27th) for Optimism Season 6. Apologies for any confusion.

We had a great conversation about missions and mission requests during last week’s Optimism Town Hall last week that I think you’d be interested to watch. You can watch the town hall segment about Optimism Season 6 starting [here](https://youtu.be/d8QCL5b4aoU?si=golvwdo8dIGNNP2r&t=3642) and a discussion with details about mission requests that I’m planning to create to support Optimism Fractal at [1:13:30](https://youtu.be/d8QCL5b4aoU?si=ccqnsrDrBz43VrlP&t=4410).

I’ve been thinking about this a lot since last week’s event and now have a better understanding of some mission requests that may be helpful to create. I’d be happy to discuss these ideas in more detail at tomorrow’s town hall if there’s interest as I think they could fit within the approved topic of Helping the Superchain and there is a limited window of opportunity with only five days remaining for members of the Grants Council or Feedback Commission to sponsor a mission request.

I’m also planning to host a brief office hours meeting right after the town hall tomorrow for anyone who would like to discuss this or other topics related to Optimism Fractal in more detail. A few community members have suggested meeting outside of the normally scheduled events over the past couple weeks and I think the office hours meeting can help serve this function. I’ll try to follow up with more details about this before this week’s Optimism Fractal event. 

 Perhaps it would also be helpful to have a working group meeting about this sometime in the next few days. We could also discuss it during the town hall is it fits within the topic of helping the superchain.

Consider also inviting Gene. Will, Gene, Abraham, Tadas, Eric, and others might be interested in collaborating in this initiative. Perhaps Gene could offer valuable perspective about this with his experience in the collective. And each other could also offer valuable insights and skills, while being aligned to work hard of building this. That could help a lot to build a team around this rather than try to do it all myself in the next week. 

It’s much better if the application could be done asap so the 20 feedback commission and grants council members have time to review it and understand it, then approve it before the 8th. 

Perhaps this could also become part of the conversation at this week’s town hall, since it fits into the more general topic of helping the superchain. it is a strategy to do mission request now in next week so that we can gain these beenfits from the foundation directly

In addition, there are also 

I could share some documents with more about this soon. I think i have the design well understood for both of these mechanisms . Briefly mentioned some of these ideas during the last town hall event at x timestamp. 

I’ve also done a lot of research over the past six months into setting up a legal entity to facilitate these rewards in a compliant manner that protects participants from legal liabilities.  I can share a project about this with a lot more details, but it could be a significant obstacle that may take months to set up. Therefore my strategy is to create mission requests before season 

- [ ]  link video and timestamp
    - Rosmari is planning to also produce this town hall episode as it’s own video independently of the Respect Game to make it easier for people to learn about Optimism Season 6.

[Review Notes about Optimism Missions And Organize Plans in this task](https://www.notion.so/Review-Notes-about-Optimism-Missions-And-Organize-Plans-in-this-task-aebd4a1f3ed14515bb857c0c64a45d8e?pvs=21) 

[Organize ideas to Create Mission Request Proposals to enable compliant funding and distribution powers for Optimism Fractal participants (and eden fractal)](https://www.notion.so/Organize-ideas-to-Create-Mission-Request-Proposals-to-enable-compliant-funding-and-distribution-powe-930e7779eb294ce6b417dda37e5dbf82?pvs=21) 

After the event I came up with some ideas for creating mission requests that could allow participants to directly earn funding by participating in Optimism Fractal events in proportion to their Respect and another mission request that could enable Optimism Fractal community members to vote on allocating funding via OREC (optimistic respect based execution)