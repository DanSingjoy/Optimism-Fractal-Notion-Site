# Research trustful from blockful

Project: Create Auxiliary Respect Tokens for Optimism Collective (ie OPC) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Auxiliary%20Respect%20Tokens%20for%20Optimism%20Colle%20b78abde1bff54c499c648628e459c689.md)
Status: Not started
Task Summary: This task aims to research and develop Trustful, a cross-community reputation aggregator designed to break down reputation silos. By allowing users to import or create reputation badges, Trustful seeks to enhance the usability of reputation across various communities, ultimately promoting trust and engagement in digital interactions.
Summary: Trustful is a cross-community reputation aggregator developed by Blockful, allowing users to create and import reputation badges for use across various communities. It addresses issues in existing reputation systems by focusing on contextual reputation and expertise. The platform will launch MVPs on Optimism and Stellar, featuring an easy-to-use badge issuer and a Scorer interface for creating reputational scores. Support for Trustful is encouraged through public goods funding and community engagement.
Created time: June 21, 2024 9:35 PM
Last edited time: August 21, 2024 9:35 AM
Created by: Dan Singjoy
Description: Trustful is a cross-community reputation aggregator developed by Blockful, allowing users to create and import reputation badges for use across multiple communities. It aims to address issues in existing reputation systems by focusing on contextual trust and expertise. The platform will launch MVPs on Optimism and Stellar, featuring an easy-to-use badge issuer and a Scorer interface for creating reputational scores. Trustful is open source and seeks community support through public goods funding.

[https://warpcast.com/zeugh/0x1e2b3898](https://warpcast.com/zeugh/0x1e2b3898)

Meet Trustful, [/blockful](https://warpcast.com/~/channel/blockful) cross-community reputation aggregator! 🌟 I'm excited to announce our first MVPs after a long time in the research table!

It’s time to break the reputation silos.

mirror.xyz

[3recasts](https://warpcast.com/zeugh/0x1e2b3898/recasts)·

[1quote](https://warpcast.com/zeugh/0x1e2b3898/quotes)·

[6likes](https://warpcast.com/zeugh/0x1e2b3898/reactions)

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0x0d3a221a)

Trustful lets users import or create reputation badges, making them usable across multiple communities. It's open source, built in public, and will be available to be used by anyone with a wallet on [@optimism](https://warpcast.com/optimism) or Stellar Network

1reply

·

2likes

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0xe217ace4)

Over the last year, Blockful contributors have explored various approaches to reputation, from historical developments to modern web3 solutions, to build a unique concept for digital community trust.

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0xcbb11a0f)

Trustful's usability is based on three elements: - Statement Badges - Reputational Scorers - Reputation Badges You can read more about them in the mirror article above!

[https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/d8bca371-4f10-4849-bb2f-b0af00ac9800/rectcontain3](https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/d8bca371-4f10-4849-bb2f-b0af00ac9800/rectcontain3)

Cast image embed

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0xaf750d5e)

Existing solutions often reward communicators over other contributions and ignore the contextual nature of trust, leading to frustration and low engagement. Trustful addresses these issues by focusing on contextual reputation and the interplay between trust and expertise.

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0xf4119f55)

With an easy-to-use badge issuer UI, Trustful allows users to create Statement Badges from scratch or import them from systems they already use, enabling them to be considered in new contexts.

[https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/60698146-dd4d-4632-2ee5-34c9edb38c00/rectcontain3](https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/60698146-dd4d-4632-2ee5-34c9edb38c00/rectcontain3)

Cast image embed

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0xddd8709e)

The Scorer interface lets anyone create their own Reputational Scorer or choose one from the list. We'll have more news on the Scorer mechanics soon, but enough spoilers for now 🤫

[https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/069fd3db-987c-4854-fb0a-9f006ef30500/rectcontain3](https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/069fd3db-987c-4854-fb0a-9f006ef30500/rectcontain3)

Cast image embed

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0xf5aad2ab)

🗳️ Trustful is participating in [@octant](https://warpcast.com/octant) Epoch 4 of Public Goods Funding! Show your support by sharing this cast and voting for us here [snapshot.org#/octantapp.e...](https://snapshot.org/#/octantapp.eth/proposal/0x91b8b02e7eba7dff9e05b4d5018d74ee2efdf7789942ce862401d0df45659348). Your vote helps us continue building this as an open tool for dece... Show more

Snapshot

snapshot.org

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0x3e8124f4)

🚀 We're launching MVPs on Optimism and Stellar! The OP version will debut at [@zuvillage](https://warpcast.com/zuvillage) Georgia in July, focusing on creating Statement Badges. The Stellar version will import badges from Stellar Quests and use those to create reputation scores based on developer expertise

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0xb4a57a56)

To stay up to date on updates, you can follow our BRAND NEW channel [/blockful](https://warpcast.com/~/channel/blockful) here on FC or follow blockful's Mirror (link in the first cast) You can also watch our repo, or keep an eye out for new issues to help us build it :)

[https://wrpcd.net/cdn-cgi/image/anim=false,fit=contain,f=auto,/https%3A%2F%2Fopengraph.githubassets.com%2F9089259d442f916afe9e4bdd02857d48cc5d00ebaf03dddb8211e6577805e360%2Fblockful-io%2Ftrustful-zuzalu-contracts](https://wrpcd.net/cdn-cgi/image/anim=false,fit=contain,f=auto,/https%3A%2F%2Fopengraph.githubassets.com%2F9089259d442f916afe9e4bdd02857d48cc5d00ebaf03dddb8211e6577805e360%2Fblockful-io%2Ftrustful-zuzalu-contracts)

GitHub - blockful-io/trustful-zuzalu-contracts

github.com

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[7h](https://warpcast.com/zeugh/0x446f5f3e)

I want to shout out to partners who inspired, validated, and improved our ideas: [@ecf](https://warpcast.com/ecf), [@qj](https://warpcast.com/qj) and [@zuvillage](https://warpcast.com/zuvillage) [@manu](https://warpcast.com/manu) (and all blockravers <3) [@anke](https://warpcast.com/anke) + [/stellar](https://warpcast.com/~/channel/stellar) [@bap](https://warpcast.com/bap) + [/eas](https://warpcast.com/~/channel/eas) [@nicnode](https://warpcast.com/nicnode), [@owl](https://warpcast.com/owl) and [@lottopgf](https://warpcast.com/lottopgf) Blockscience Lauro Gripa Gitcoin Passport Karma3 Labs We're finally going to MVPs, and they're better because of eac... Show more

Show more

[kbc - q/dau@kbc](https://warpcast.com/kbc)

·

[4h](https://warpcast.com/kbc/0x08c6fec5)

oh, bookmarking this to read it properly tomorrow! 3200 $DEGEN

1reply

·

1like

[Zeugh@zeugh](https://warpcast.com/zeugh)

·

[4h](https://warpcast.com/zeugh/0x5f4f24f4)

Appreciate the tip fren! Pretty sure there's a lot of common ground for us to cover with super powering communities