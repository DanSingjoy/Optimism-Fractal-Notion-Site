# Explore integrations between Hats Protocol, Paragraph and Zora

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: The integration between Hats Protocol, Paragraph, and Zora can be beneficial for on-chain media strategy, allowing respected individuals to access token-gated material and providing benefits to creators of OF-related content.
Parent-task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created time: March 18, 2024 8:08 PM
Last edited time: March 18, 2024 8:10 PM
Parent task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created by: Dan Singjoy

## Description

- This could be helpful for [Posting OF Videos on ZoPa and Farcaster Frames](https://www.notion.so/Posting-OF-Videos-on-ZoPa-and-Farcaster-Frames-fa76145963d14a57b68d6d2cdaffde4e?pvs=21) and onchain media strategy, whereby people who have earned respect can see token gated material (such as videos or articles minted)  or where people who have minted OF related content get benefits