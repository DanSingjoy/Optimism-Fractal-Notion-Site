# [Proposal] Gitcoin’s Citizen Grants program - 📜 Proposals - Gitcoin Governance

Project: Explore collaborations with Gitcoin (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20collaborations%20with%20Gitcoin%2000254f7125fb44c198ecbc3bf4809642.md)
Status: Not started
URL: https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470
Task Summary: This task aims to provide an overview and proposal for Gitcoin's Citizen Grants program, which includes three pillars: Citizens Retro, Citizens Innovate, and Citizens Forward. The program focuses on fostering innovation, community participation, and proactive funding within the Gitcoin ecosystem. The proposal outlines the program's objectives, mechanics, submission process, evaluation criteria, and the roles and responsibilities of the Grants Council, Program Manager, and Gitcoin Stewards.
Summary: This document is a discussion about the proposal for Gitcoin's Citizen Grants program. The participants express excitement and support for the program, highlighting the importance of community empowerment, funding impactful projects, and measuring outcomes. Some concerns are raised about the funding amount and workload, as well as the decision-making process. Overall, there is broad support for the proposal and anticipation for its positive impact on the Gitcoin community.
Created time: July 29, 2024 9:26 AM
Last edited time: July 29, 2024 9:27 AM
Created by: Dan Singjoy
Description: This document is a discussion about the proposal for Gitcoin's Citizen Grants program. The participants express excitement and support for the program, highlighting the importance of community empowerment, funding impactful projects, and measuring outcomes. Some concerns are raised about the funding amount and the workload on core contributors. Amendments are made to the proposal based on feedback. The proposal is now live for voting on Snapshot. Overall, there is broad support for the program and enthusiasm for its potential impact on the Gitcoin community.

# TLDR

- Gitcoin is launching its Citizen Grants program, split into Citizens Retro (Retroactive Funding), Citizens Innovate (Citizen Proposals) and Citizens Forward (RFPs), to foster innovation and community participation.
- The Citizens Innovate and Citizens Forward programs will be launched as a 6-month pilot project, with the Citizens Retro aspect being run as a separate initiative.
- Citizens Innovate uses GCPs – ideas from community members on actionable steps towards Gitcoin’s objectives, while Citizens Forward uses RFPs coming from internal teams with budgets for DAO-wide goals. Proposals are evaluated for alignment with Gitcoin’s intents, impact, feasibility, and sustainability.
- Gitcoin has set key Essential Intents, such as Network Effects, Community First, and Financial Longevity, guiding the proposal priorities and focusing on aspects like product adoption, community engagement, and financial health.
- The GCP submission process follows a structured monthly cycle, including proposal submission, community feedback, and voting by a pre-selected Grants Council, with no cycle in December and a cap of three proposals per individual per quarter.
- **This proposal is to request funds to run a pilot of the Citizens Innovate aspect of the program**

# Introduction

Gitcoin firmly believes that grants programs are a key lever for ecosystem growth. In order to bootstrap further innovation at Gitcoin and leverage the awesome power of its community, Gitcoin will be formally spinning up its pilot **Citizen Grants Program**.

Think of this as Gitcoin’s own grants program focused not on funding specific causes, but rather growing its own ecosystem. The Citizen round was the first iteration of this - retroactive funding for community members working to expand the Gitcoin ecosystem. This “new” program is going to expand beyond just retroactive funding and will also include opportunities for *proactive funding* for community members, not using QF as a funding mechanism but rather more of a “direct grants” style of funding.

In the future, more grants-awarding experiments will be introduced to continue innovating on novel ways to effectively allocate capital to develop the Gitcoin ecosystem.

![https://gov.gitcoin.co/uploads/db4391/optimized/2X/a/ac97356c3577aa54d6d5a896756ae85884829e6a_2_1380x776.png](https://gov.gitcoin.co/uploads/db4391/optimized/2X/a/ac97356c3577aa54d6d5a896756ae85884829e6a_2_1380x776.png)

## Program Pillars

- **Citizens Retro:** Having already run 2 rounds and being [recently approved to run 2 more 46](https://gov.gitcoin.co/t/gcp-017-gitcoin-citizens-retroactive-funding-round/17215), our retroactive rewards program focuses on rewarding Citizens retroactively for their contributions to the Gitcoin ecosystem. Participants must meet eligibility criteria in order to participate.
- **Citizens Innovate:** Community-led ideas on achieving the DAO’s goals. Proposals take the form of GCPs (described in detail below).
- **Citizens Forward:** DAO-led initiatives calling for Citizen contributions. Similar to RFPs, budgeted DAO workstreams can allocate parts of their budgets toward specific projects they’d like to see created/built/fulfilled on.

## A Brief Insight into Mechanics

- **Essential Intents:** Think of Essential Intents as our North Stars – a medium-term objective or a direction we want to head in. While the destination might be clear, the paths to get there could be many. That’s where the collective wisdom of our community comes in.
- **Gitcoin Citizen Proposals (GCPs):** Ideas emerging from one or more community members on tangible steps we can take to achieve our Essential Intents. They’re specific, actionable, and time-bound initiatives that guide us in our journey toward our objectives.
- **Request for Proposals (RFPs):** Ideas emerging from Workstream Leads that they are willing to fund (with their DAO-approved budgets) in order to achieve workstream or DAO-wide goals.
- **Grants Council:** A collection of high-context internal DAO contributors (typically Workstream leads) who (for now) get ultimate decision rights on which GCPs to fund.

# Motivation

- Gitcoin Grants has always supported incredible causes outside of Gitcoin (OSS, Climate, DeSci, etc.) but has never had its own round/program to grow its own ecosystem
- Gitcoin has an incredible base of individuals who are hungry to contribute to its success
- A framework for what community members can work on has never been clearly articulated by the DAO along with funding to support such initiatives
- Now that Gitcoin’s products are built and in the market, there is more clarity around what potential projects would be most high value for Gitcoin to fund
- Gitcoin is a firm believer that grants programs are one of the best ways to grow one’s ecosystem–this program is our conviction of that belief

# Citizens Retro

This regularly-occurring round will fold into the larger Citizens Grants program purview, solidifying it as a regular initiative of the DAO. This program will continue to run as is. Program details will not be outlined in this governance forum post. Those unfamiliar with this initiative can [read about it in the most recent proposal 46](https://gov.gitcoin.co/t/gcp-017-gitcoin-citizens-retroactive-funding-round/17215) and find out more by following the [Gitcoin Citizens account on Twitter 22](https://twitter.com/gitcoincitizens).

# Citizens Innovate

This initiative involves Gitcoin community members proposing their own ideas for accomplishing the DAO’s goals. Approved ideas will receive funding to do the work outlined in the initial proposal.

## How to submit a Proposal

If you’re interested in submitting a Gitcoin Citizen Proposal (GCP), you may do so by posting a completed GCP to either the governance forum or to a specific area within Grants Stack [TO BE CONFIRMED].

## Guidance on GCPs

Community members wishing to submit GCPs should use the template provided in the [Citizen Grants website (WIP) 55](https://www.notion.so/6cf45c8501c3430eae3791434bcafb87?pvs=21). You can also review a sample proposal on the [Citizen Grants website (WIP) 55](https://www.notion.so/6cf45c8501c3430eae3791434bcafb87?pvs=21).

- GCPs should attempt to follow the outline in the template, though adhering 100% to it is not necessary and will not be penalized when being assessed.
    - Submissions must also provide any necessary background information to support the feasibility of the proposal.
- Please be as specific as possible in defining your measures of success and KPIs
    - Allows the Grants Council to accurately measure your progress and later accurately measure the project’s impact.
- GCPs must outline requested resources and provide a rationale for the budget
- GCPs will be evaluated based on their alignment with Gitcoin’s Essential Intents, potential impact, feasibility, and sustainability.
- Both individuals and teams are encouraged to submit their own GCPs.

Each GCP will be reviewed by the Grants Council and be given a response within 10 business days.

In an ideal future state, this function will be decentralized either to a council of external contributors or to Gitcoin Stewards, with ultimate decision rights sitting within the community.

## Other Considerations

- All approved project owners must KYC with Gitcoin to receive rewards.
- GCP grants are awarded in the form of GTC governance tokens, streamed to the project over the course of the proposed project timeline.
    - Exact payout details will be confirmed on a project-by–project basis based on milestones and outputs.
- An individual may be involved in the submission of a maximum of three GCPs per period.
    - For example, one individual can submit either 1 proposal by themselves and 2 proposals as part of a team for a total of 3 proposals. Alternatively they can submit 2 proposals by themselves and 1 proposal as part of a team for a total of 3 proposals.
- Projects that require cash upfront in order to execute may make that request, that request subject to the approval of CSDO.
    - Upfront cash requests may not be more than 25% of the total project cost.
- GCPs should have a clear due date and do not span more than 2 seasons (6 months).
- Funds earmarked for GCPs do not need to be spent unless the projects applying are meeting the needs of the DAO.
- Excess funds at the end of the 6-month pilot will be returned to the DAO treasury should the pilot program not be considered a sucess
- If a grant recipient fails to meet a pre-defined critical milestone, they may be subject to the grant clawback mechanism built into the original contract.

## Grant Clawback Mechanism

Every grant awarded to a GCP has a clawback mechanism. Since most grants will have a payout that comes only after work is performed, the Grants Council reserves the right to withhold payment should there be a failure to execute on critical milestones, as defined by proposers and documented publicly.

Project owners are encouraged to be in communication with the Program Manager should they anticipate missing a deliverable at the agreed upon time. If they do communicate in advance and their Grants Council representative agrees, there is no need to proceed with the process below.

### The process:

1. A representative from the Grants Council or the Program Manager will give a warning to the Project Owner, giving 1 week for them to hit their agreed upon milestone.

*Note: The next step happens if either i) the project owner fails to hit their milestone within 1 week or ii) if this is the 2nd time the project owner misses a critical milestone without prior communication*

1. The grant council votes on the investigation and outlines its rationale behind clawback based on the data presented
2. An appeal process may be launched by the Project Owner by contacting the Program Manager a) An investigation will be conducted by the Governance Coordinator , facilitated by the Program manager, with both the Project Owner and the Grants Council to collect all pertinent information. b) Information will all be posted into Snapshot and the community will vote whether or not to repeal the decision or to allow it. c) The decision of this vote is final and binding. d) Should the decision be repealed, the entire incident will essentially be “stricken from the record” and the project should proceed as if nothing has happened. e) New deadlines should also be resubmitted to the Grants Council and posted on the Governance Forum by the Project Owner.

## Gitcoin Intents

Gitcoin’s recent [Essential Intents 11](https://gov.gitcoin.co/t/discussion-community-feedback-on-gitcoin-s-essential-intents-for-2023-2024/16657) play into this initiative and will dictate which proposals are the highest priority to Gitcoin.

Essential Intents have been set by the [CSDO team 4](https://manual.gitcoin.co/governance-processes/csdo) in October 2023 in consultation with Gitcoin Stewards. Essential Intents are reviewed and reset (approximately) every 18 months.

All GCPs must align with at least one Essential Intent. Essential Intents each have their own individual budget.

### Intent 1: Network Effects

Gitcoin is increasingly focused on attaining one thing: traction for its products. With this newly adopted intent, we are shifting from a focus on “Protocol Adoption & Grants Program Success” to prioritizing product adoption as the cornerstone for generating network effects and ecosystem growth.

**This is Gitcoin’s most important intent.**

Measurements:

- Number of new users of our products
- Growth rate of product adoption
- Number of novel use cases for any of our products
- Amount of investment secured from new partnerships

Example Proposals:

- Contributions around market research collection
- Reporting on competitive landscapes or market trends
- Plugins, add-ons, or integrations with Gitcoin products
- Usability reviews, UX/UI audits
- Product demo initiative
- Real-time dashboard of useful aspects of Gitcoin
- Projects that support sybil defense efforts during a Grants Round

Proposed budget: 250,000 GTC

### Intent 2: Community First

Community is at the core of what Gitcoin is. It’s all about encouraging active participation, effective governance, and widespread adoption of Gitcoin’s initiatives and platforms. Gitcoin’s aim with this intent is to create an environment where community members feel empowered to actively contribute to Gitcoin’s evolution.

Measurements:

- '# of community members committing to Gitcoin repos
- '# of new Passports with GTC staking
- '# of communities running their own grants round

Example GCPs:

- Educational resources
- Product-focused hackathons or conferences
- Specific marketing efforts aimed at growing a community of value aligned Gitcoiners
- Passport Identity Staking boosting initiative
- NFT series to highlight grantee impact stories

Proposed budget: 50,000 GTC

*Note: This category is the most broad of the Intents and is done deliberately to allow proposals to new, innovative ideas. **It is important that suggested ideas are economically driven** and that there is an ability to measure ROI as a result of the efforts. Ideas tied to this Essential Intent are the least likely to be approved by the Grants Council.*

### Intent 3: Financial Longevity

With an expanded footprint, one of Gitcoin’s main aims is to ensure its financial health, adapting to any market dynamics. Revenue generating opportunities, cost saving activities and token utility initiatives are all fair game when it comes to ensuring that Gitcoin is economically sustainable, allowing it to fulfill its vision of a world shaped by community-led positive change.

Measurements:

- Amount of revenue generated through the use of its products
- Amount of costs saved
- Number of novel token utility use cases

Example Missions:

- Establishment of new partnerships
- Potential integrators engagement
- Feedback on investment opportunities

Proposed budget: 150,000 GTC

## Roles & Responsibilities

### The Grants Council

The initial council will comprise 3 DAO members. These members are high-context individuals that have a deep understanding of Gitcoin and its current priorities. This includes:

- [@meglister](https://gov.gitcoin.co/u/meglister), Grants Stack WS Lead
- [@Viriya](https://gov.gitcoin.co/u/viriya), MMM WS Lead
- [@owocki](https://gov.gitcoin.co/u/owocki), Co-founder and memelord

After the initial 6 month pilot, there will be a public re-evaluation of whether or not to proceed with the same individuals or if the job will be passed along to other DAO members/Citizens. Also up for discussion is the size of the Grants Council. Factors that will help make this decision include (but are not limited to):

- Amount of work required to review applications
- Capacity given other responsibilities
- Desire to continue in the role

The Grants Council will decide which projects to fund. The council will work with the Program Manager for publishing its decisions as well as a brief explanation for all decisions.

The Grants Council will also be responsible for determining when to halt a project’s stream should they violate program rules or misuse funds. All reports of violations will be evaluated by the Grants Council. It will require 2 out of 3 council members to vote in favor of halting the stream for a stream to be stopped. Streams can also be halted via a DAO snapshot vote should the DAO disagree with the Grants Council’s judgment.

The Grants Council does not need to spend the entire Citizen Innovate budget should they feel there are not enough quality applications.

**Grants Council Responsibilities:**

- Approving/rejecting GCPs
- Provide public reasoning for all funding decisions made
- Determining when to halt a project’s stream should they violate program rules or misuse funds
    - Will be determined by majority rules vote

**Removing Council Members**

Should the DAO feel a member or members of the council are not fulfilling their duty they may remove them using a snapshot vote.

Anyone with sufficient voting power can initiate a Snapshot poll to remove Grants Council member(s). Should the poll receive a majority “remove” vote, the Grants Council member(s) will be immediately removed.

Should this occur there will then be a week-long application process where replacement Grants Council members can apply via the forum. This will be followed by a Snapshot vote to elect replacement member(s).

### Program Manager

The Program Manager will be responsible for coordinating between all parties involved to ensure the program runs smoothly. They will be available to answer any questions the DAO has regarding the program and will publish monthly reports so the community understands the status of the program. The Program Manager will have no input into which projects receive funds. However, they will be responsible for handling any operational tasks that arise throughout the program.

The Program Manager for the pilot of this project will be [@rohit](https://gov.gitcoin.co/u/rohit). Should the DAO feel Rohit is not fulfilling his duties as program manager, they may remove him using a snapshot vote. An emergency Snapshot vote will then be used to elect a replacement program manager.

In the long term, this position will be decided by the DAO. However, because the program is intended to get up and running as soon as possible, it will rely on Rohit’s services given his proven track record at Gitcoin over the last year and his experience and familiarity with Gitcoin’s goals and objectives.

**Responsibilities**

- Creating a rubric that all projects will be judged against (to be approved by the Grants Council)
- Initial screening of applications to ensure they meet minimum eligibility requirements
- Tracking approved projects
- Ensuring projects properly communicate their progress
- Flagging potential rule violations to the Grants Council for potential action
- Ensure monthly submission cycles are followed
- Coordinate the KYC process
- Coordinate streams between multisig and projects
- Advise promising projects on how to improve their application prior to getting in front of the Grants Council
- Creating and publicizing a submission cycle for applicants to follow

### Gitcoin Stewards

This program is designed to reduce the large burden Stewards would face having to vote on a large number of proposals, while keeping approved proposals as aligned as possible with Gitcoin’s Essential Intents. While the Grants Council will be responsible for decision making around what proposals to fund, the Gitcoin Stewards will still retain the final say in many aspects of this proposal.

Stewards will retain the following powers:

- Ratify all additional roles included in this proposal
- Remove any position holder via a snapshot vote should the delegates feel they are not fulfilling their responsibilities
- Veto any funding decision made by the council

## Multisig

A dedicated 3/5 multisig for Citizens Innovate will be established to hold funds. Funds held in the multisig are explicitly banned from usage in DAO governance, including delegation.

The multisig will include a clawback capability so the DAO can retrieve funds if the multisig violates the agreement.

Signers will be:

- Grants Council member 1: [@meglister](https://gov.gitcoin.co/u/meglister)
- Grants Council member 2: [@owocki](https://gov.gitcoin.co/u/owocki)
- Grants Council member 3: [@Viriya](https://gov.gitcoin.co/u/viriya)
- Program Manager: [@CoachJonathan](https://gov.gitcoin.co/u/coachjonathan)
- Gitcoin Chief of Staff: [@deltajuliet](https://gov.gitcoin.co/u/deltajuliet)

## Eligibility Requirements

Projects that received grants funding during a Gitcoin Grants round are eligible to receive Citizens Innovate funding. Additionally, receiving funding from this pilot program does not prohibit projects from applying for funding during a Gitcoin Grants.

### Additional eligibility requirements

- Grantees must outline a spending plan, provide a pro forma, and state the grant’s objective.
- Grantees are expected to not encourage or partake Sybil attacks against the forum to sway community opinion.
- Grantees must agree to KYC with the Gitcoin Foundation to receive funds.
- Grantees must apply using the approved program application template

By streaming grant payments, the multisig will be empowered to hold grantees accountable to their proposals by halting fund streaming for any of the following reasons:

## Submission cycles

Submission cycles will be introduced after program launch to make it easier for the Grants Council to batch review and approve applications. The program manager will be responsible for sharing this information publicly.

- Any use of funds not explicitly described in the grantee’s application.

## What a successful program looks like

We have not yet run a program like this and it is difficult to find what other grants programs consider a “success” in terms of programs. To keep things simple, the following metrics will be measured and looked at as a community as to whether or not to continue the pilot beyond the 6-months:

- Number of applications
- Number of selected GCPs (indication that these are quality applications)
- Success of projects hitting milestones and KPIs
- Feedback collected from funded projects about the process
- Feedback collected from Grants Council about their view on the success of this program in meeting DAO-wide goals

# Citizens Forward

This initiative is composed of pre-defined projects (RFPs) that Workstreams (with approved budgets) request assistance with.

## About Gitcoin RFPs

RFPs are pre-specified by Workstreams and are supported by workstream budgets. Workstreams will have the final decision as to which individual/team will complete each RFP. While GTC token holders will not vote on RFPs directly, GTC token holders will have 1) the ability to vote for/against each worktream’s budget request (every 3-12 months) and 2) visibility into all RFP applications (hosted on Grants Stack and linked to from within the Citizen Grants website).

## How to apply for an RFP

If you’re interested in applying to an RFP, you may do so by submitting your application on Grants Stack [LINK COMING SOON] before the submission deadline. Make sure your application is complete and answers all the qualifying questions.

A representative from the appropriate workstream will aim to announce the selected proposal within 10 business days of the submission closing. The Workstream is not under the obligation to select a winning proposal should none of the proposals meet the criteria or the quality of application being looked for.

# Communication

Citizen Grants program updates will be shared via our Governance Forum, DAO Digest newsletter, monthly Steward Sync, and [Citizens Twitter account 22](https://twitter.com/gitcoincitizens). We can also explore hosting a regular monthly call held every month for the project teams to share progress and answer any questions (should there be interest in this).

For Citizens Innovate, the frequency and format of project updates should be detailed within each GCP.

# Future Citizen Grants Program Elements

**Partnership Fund:** The purpose of the Partnerships Fund is to reward Gitcoin Community members for creating unique funding opportunities on behalf of Gitcoin.

**Citizens Experiments:** This fund is intended to serve as a home for Gitcoin to run novel grants-related experiments.

For example:

- What does a grants program using conviction voting look like?
- What does a QV round look like where only participating projects can vote on projects other than their own?

All experiments will be rigorously documented, with learnings shared publicly afterward for the entire ecosystem to glean insights from. Experiments will last for varying amounts of time and the funds value will change for each experiment.

Parameters for each experiment, including the funding mechanism, eligibility criteria of projects, etc. will be outlined and selected by CSDO. CSDO may also delegate the responsibility of running this experiment to external parties.

Experiments may be run by DAO Core Contributors or by Citizens.

# Steps to Implement

- Citizens Retro is already underway and does not require approval.
- **Citizens Innovate will require approval of this proposal in order to release funds from the treasury into a Citizens Innovate multisig.**
- Citizens Forward will not require Steward approval for setting up the program, only for releasing funds to Workstreams looking to set up RFPs (done through formal Workstream budget requests).
- Community feedback is welcome and appreciated (especially if there are any gaps in the logic of how this program will be administered).

# Voting Options

- Fund the Citizens Innovate pilot with 450,000 GTC
- Don’t fund the Citizens Innovate pilot
- Abstain
1. If the Project Owner does not agree with the outcome, the community can vote via Snapshot. This way, voters can access high-context information from the Grant Council, Program Manager, and Project Owner for an informed choice.
2. That decision is then final and binding.

[Viriya](https://gov.gitcoin.co/u/Viriya)

[Jan 24](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/4)

Really excited about this proposal. It adds structure and clarity to some already existing frameworks while doubling-down on a community-centric focus.

I agree with Owocki’s point on community empowerment and progressive decentralization. I think this program will be essential in creating momentum in our community and innovation work.

One thing that I’m super mindful of is that our grants program offers less in overall dollars than, say, Arbitrum or OP. I know we have some passionate community members so my point might be mute but less amount of funding may create less excitement around our program. I am interested to see how much initial engagement it gets.

I think focusing on funding fewer, really impactful projects for larger portions of the grant pools might be a way to incentivize high-quality builders to this program.

[b3n](https://gov.gitcoin.co/u/b3n)

[Jan 24](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/5)

Great proposal! Having an RFP mechanisms like “Citizens Forward” is a great way to activate community contributions while staying credibly neutral.

[jengajojo](https://gov.gitcoin.co/u/jengajojo)

[Jan 26](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/6)

Glad to see the scope of grants iniitiaitve expanded to more mission aligned areas. Since the core contributors will be doing most of the lift, I do wonder if there is too much on everyone’s plate and if this may distract folks on focusing on their main roles.

[vporton](https://gov.gitcoin.co/u/vporton)

[Jan 28](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/7)

It looks like that the limit to accomplish the Innovate member initiative in 6 months is directly directed against [[Proposal] Gitcoin killer app 6](https://gov.gitcoin.co/t/proposal-gitcoin-killer-app/17347) that I proposed to be complete in 410 days and would like to do as a part of Innovate program (and also an Experiment of new funding distribution).

I consider completing this project in 6 months impossible.

Due to this, I consider 6 months limit unacceptable.

[rohit](https://gov.gitcoin.co/u/rohit)

jengajojo

[Jan 28](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/8)

CoachJonathan:  The Program Manager will be responsible for coordinating between all parties involved to ensure the program runs smoothly. 

This is a valid risk. The program manager will have to be creative in removing friction on both ends of the spectrum, protecting the time of the core contributors in the process while enabling quality participation from the community. This will require working on the demand side to ensure a healthy backlog of DAO needs that can be curated into clear RFPs and liaising with the community to elevate potential ideas with a direct traceability with Essential Intents as GCPs

[Sov](https://gov.gitcoin.co/u/Sov)

rohit

[Jan 31](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/9)

As the lead of the Grants Ops team at Gitcoin, along with our partnerships, I support the Citizen Grants Program initiative. The approach laid out here will lead to fostering community participation and innovation through Citizens Retro, Innovate, and Forward programs.

I am excited to see the impact of this pilot project and the positive changes it will bring to our community

[meglister](https://gov.gitcoin.co/u/meglister)

[Jan 31](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/10)

I’m excited about this initiative and look forward to serving on the grants council. We’ve recently released Allo v2 and are migrating Grants Stack to use the new protocol, which represents a huge opportunity for community contributions to our grants products! I’d love to submit some “ideas for builders” as part of this – not RFPs but gathering some ideas and community feedback that could serve as inspiration for potential grantees.

As a self-titled finances nerd, I also want to note that this is a pretty large budget request. I’d love to see a plan for returning funds if the program proves ineffective. In the future I think that budget requests over a certain amount should come with some analysis of the impact on treasury/runway and proposed ROI.

[rohit](https://gov.gitcoin.co/u/rohit)

[Jan 31](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/11)

meglister:  I’d love to submit some “ideas for builders” as part of this – not RFPs but gathering some ideas and community feedback that could serve as inspiration for potential grantees. 

This is great! This can also be an awesome input to Citizens preparing for the upcoming Retro QF Citizens Round.

[CoachJonathan](https://gov.gitcoin.co/u/CoachJonathan)

[Feb 1](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/12)

Based on the comments above, I’ve made a few amendments to the proposal before taking this to a vote:

rohit:  Two suggestions here:  
• Since the Program Manager is accountable for overseeing the deliverable schedule, we might need another hat to investigate the appeal to keep the process neutral. This could be conducted by the Council Member closest to the work, facilitated by data gathering from the Program Manager and Project Owner. 
• The governance surface of the community votes for a grant clawback right after the investigation feels larger than what might be necessary. For example, here is an interim step before the vote can be deemed necessary:  

Added these in.

Viriya:

I haven’t added this to the proposal but would love for our Grants Council and applicants to take note.

jengajojo:  I do wonder if there is too much on everyone’s plate and if this may distract folks on focusing on their main roles. 

Point taken, and after evaluating my capacity as program manager, I’m recommending [@rohit](https://gov.gitcoin.co/u/rohit) start as Program Manager for the time being. He has been contributing to Gitcoin for almost a year and has more than proven his competence and reliability as a regular contributor at MMM. Aside from being a wonderful, curious and competent person, he comes to us from years of experience working in a fast-paced environment and within complex project at Deloitte. I’m confident that he will take this program where it needs to go. He will also be diligently tracking the hours he spends working on this project in an attempt to help us scope this role for the possibility of decentralizing it in the future.

meglister:  I’d love to see a plan for returning funds if the program proves ineffective. 

I totally agree and realize I didn’t include this in my initial proposal, so I have added it in and will restate it here:

- Funds do *not* need to be spend if there are no solid applications coming in
- Any funds not spent during the pilot will be returned to the treasury

[krrisis](https://gov.gitcoin.co/u/krrisis)

[Feb 1](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/13)

Thanks for the detailed proposal.

Some random thoughts that came up while reading through + checking comments:

- The fact that Gitcoin is interested in adopting the Citizens name for its wider ecosystem funding program shows that we’ve been doing a good job over the past two rounds with our Citizens Rounds, and this makes me proud.

CoachJonathan:  Community members wishing to submit GCPs should use the template provided in the [Citizen Grants website (WIP)](https://www.notion.so/6cf45c8501c3430eae3791434bcafb87?pvs=21) . You can also review a sample proposal on the [Citizen Grants website (WIP)](https://www.notion.so/6cf45c8501c3430eae3791434bcafb87?pvs=21) . 

- I’m not finding this sample proposal + the temp website for citizens innovate refers to apply through Seagrants for a GCP but this links back to the homepage of the gov forum. WIP I guess but just flagging.

CoachJonathan:  Each GCP will be reviewed by the Grants Council and be given a response within 10 business days. 

CoachJonathan:  In an ideal future state, this function will be decentralized either to a council of external contributors or to Gitcoin Stewards, with ultimate decision rights sitting within the community. 

To show an openness to this projected ideal future and to keep the DAO spirit alive in this pretty centralized current state of the DAO I would recommend having a few members of the Steward council involved in the decision making process. Starting with the current setup consolidates and leads to further centralization imo and an even higher workload for the same small group of people, which is a central point of failure. I made earlier proposals on involving Stewards more here. I know it’s not the way in which Gitcoin is evolving atm, so this is just for the record & consideration.

Happy to read that rohit will take some work off of everyone’s plate!

CoachJonathan:   
• All approved project owners must KYC with Gitcoin to receive rewards.  

I wonder if this is really necessary as you are rewarding in GTC tokens only? For full time people this makes sense, for occasional contributors who wish to stay anonymous this is not very inviting.

CoachJonathan:  clawback mechanism. 

- 
    
    great and even crucial to have this, but …it may seem like a detail but if at all possible I’d recommend a less aggressive, hostile and less corporate term here. You could eg go with reclaim or recovery mechanism?
    
- 
    
    I’m okay with the name Citizens Retro for our rounds, in the sense that we were already calling them Citizens Retroactive Funding Rounds anyway, Citizens Retro Rounds are even catchier.
    
- 
    
    I like that GCPs are now an acronym for Gitcoin Citizens Proposals
    

No further comments, this is a solid proposal with an appropriate budget & security built in. It will contribute to making our DAO more porous (again) so I will be voting yes.

[CoachJonathan](https://gov.gitcoin.co/u/CoachJonathan)

[Feb 2](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/14)

This proposal is now live on Snapshot for voting: [Snapshot 15](https://snapshot.org/#/gitcoindao.eth/proposal/0xacddec4a65a36541eacacd04319011981bec422ed3650db725a82e7dd7aa181e)

[umarkhaneth](https://gov.gitcoin.co/u/umarkhaneth)

[Feb 2](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/15)

I’m in broad support of this proposal. I love to see the emphasis on funding citizens, especially to proactively pursue larger projects. I also love the emphasis on measuring outcomes, and I know [@rohit](https://gov.gitcoin.co/u/rohit) will crush as a PM on this.

CoachJonathan:  Citizens Retro
 This regularly-occurring round will fold into the larger Citizens Grants program purview, solidifying it as a regular initiative of the DAO. 

We should talk more about this…The citizens retro round is a GCP-funded, bottoms-up initiative that did not come from CSDO. As I’ve said before, I’m not necessarily against folding into a larger strategy but think it requires some more discussion. I hope this is not a trend that all GCPs will follow? Builders can build until it’s successful and CSDO unilaterally decides to fold it into their plans without being clear about what that means.

There seems to be a tension between wanting to fund bottoms-up work and exerting top-down control on where funding goes that we as an organization still need to resolve. I have mixed views on the decision to appoint a Grants Council to decide what bottoms-up work to fund. Why is this preferable?

To me it seems this is an extra governance mechanism wrapping around an existing token-voting GCP process (which we trust for decisions as big as funding our workstreams). With that said, I don’t think you could assemble a better roster of informed decision makers than the assembled council and I know they will make great calls. I also hope the v2 of this program experiments with more decentralized ways to make decisions.

Overall, I support and am excited for this project!

Here are some high-quality citizens previously funded I think could benefit from Citizens Innovate and am tagging for visibility:

- [@davidgasquez](https://gov.gitcoin.co/u/davidgasquez) Grants Data Portal
- [@eleventh19](https://gov.gitcoin.co/u/eleventh19) Web3 Grants Reporting
- [@Joel_m](https://gov.gitcoin.co/u/joel_m) Next Gen QF
- [@ccerv1](https://gov.gitcoin.co/u/ccerv1) Data Analytics (and now OSO)

[Viriya](https://gov.gitcoin.co/u/Viriya)

[Feb 5](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/16)

umarkhaneth:  The citizens retro round is a GCP-funded, bottoms-up initiative that did not come from CSDO. As I’ve said before, I’m not necessarily against folding into a larger strategy but think it requires some more discussion. I hope this is not a trend that all GCPs will follow? Builders can build until it’s successful and CSDO unilaterally decides to fold it into their plans without being clear about what that means. 

I think this is a great call out [@umarkhaneth](https://gov.gitcoin.co/u/umarkhaneth) – It’s something that I know has been on [@deltajuliet](https://gov.gitcoin.co/u/deltajuliet)’s mind and we want to build a strategy that will be meaningful for all parties of any bottoms-up initiative we’re funding.

One thing I think is important wrt to treasury governance/funding always-on projects is that it’s preferable if it’s aligned with the strategic direction of the DAO’s goals. The DAO has historically been really bad at context building for contributors outside of a core team; it’s also really hard to hold initiative leaders accountable if they are not funded as a workstream/always-on initiative. I would love you (or anyone else) to share ideas on how we might solve for this bc it’s something that I’m going to be focusing my efforts on this year as I help steward the Ecosystem Collective.

I think the intention of folding the Citizen’s Retro round into this program is to not fund it as a GCP anymore but rather have a thin-workstream/always-on funding and link it more closely with the Grants Labs team’s objectives.

[IsokeyX](https://gov.gitcoin.co/u/IsokeyX)

[Feb 7](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/17)

very interesting thats good idea i cast my vote on the positive side of it…its better for a project to have community at heart then,a project is a best give out to community is like a project is showcases his good and positive conduct towards community and improving its project and allowing it to create completion in the market, this may also help in improving infrastructures…LFG

[kempsterrrr](https://gov.gitcoin.co/u/kempsterrrr)

[Feb 7](https://gov.gitcoin.co/t/proposal-gitcoin-s-citizen-grants-program/17470/18)

Developer DAO voted yes on this proposal. We believe empowering and incentivising community members to experiment is table-stakes for unlocking innovation in DAO/decentralised communities. We look forward to socialising this programs/opportunities within our community to cross-pollinate talent and ideas to help advanced Gitcoin’s mission.

- [[UPDATE] Gitcoin and DeveloperDAO Partnership in 20241](https://gov.gitcoin.co/t/update-gitcoin-and-developerdao-partnership-in-2024/17423/5)

### New & Unread Topics

| Topic | Replies | Views | Activity |
| --- | --- | --- | --- |
| [Gitcoin Passport S21 Business Unit Budget Proposal](https://gov.gitcoin.co/t/gitcoin-passport-s21-business-unit-budget-proposal/17634)   [📜 Proposals](https://gov.gitcoin.co/c/governance-proposals/5) |  | 1.5k | [Feb 13](https://gov.gitcoin.co/t/gitcoin-passport-s21-business-unit-budget-proposal/17634/8) |
| [[Proposal] Passport Season 20 & 21 Budget Request](https://gov.gitcoin.co/t/proposal-passport-season-20-21-budget-request/16765)   [📜 Proposals](https://gov.gitcoin.co/c/governance-proposals/5) |  | 2.0k | [Nov '23](https://gov.gitcoin.co/t/proposal-passport-season-20-21-budget-request/16765/22) |
| [[GCP 017] Gitcoin Citizens Retroactive Funding Round](https://gov.gitcoin.co/t/gcp-017-gitcoin-citizens-retroactive-funding-round/17215)   [📜 Proposals](https://gov.gitcoin.co/c/governance-proposals/5) [community](https://gov.gitcoin.co/tag/community)[contributors](https://gov.gitcoin.co/tag/contributors)[citizens](https://gov.gitcoin.co/tag/citizens) |  | 2.5k | [Jan 9](https://gov.gitcoin.co/t/gcp-017-gitcoin-citizens-retroactive-funding-round/17215/38) |
| [[Proposal] Lower GTC Voting thresholds on and off chain](https://gov.gitcoin.co/t/proposal-lower-gtc-voting-thresholds-on-and-off-chain/16764)   [📜 Proposals](https://gov.gitcoin.co/c/governance-proposals/5) |  | 2.7k | [Feb 13](https://gov.gitcoin.co/t/proposal-lower-gtc-voting-thresholds-on-and-off-chain/16764/18) |
| [[PASSED] Gitcoin (Grants Lab) x Wonderland Partnership](https://gov.gitcoin.co/t/passed-gitcoin-grants-lab-x-wonderland-partnership/18618)   [📜 Proposals](https://gov.gitcoin.co/c/governance-proposals/5) |  | 1.1k | [May 8](https://gov.gitcoin.co/t/passed-gitcoin-grants-lab-x-wonderland-partnership/18618/12) |

### Want to read more? Browse other topics in [📜 Proposals](https://gov.gitcoin.co/c/governance-proposals/5) or [view latest topics](https://gov.gitcoin.co/latest).

I’m in broad support of this proposal. I love to see the emphasis on funding citizens, especially to proactively pursue larger projects. I also love the emphasis on measuring outcomes, and I know [@rohit](https://gov.gitcoin.co/u/rohit) will crush as a PM on this.

CoachJonathan:  Citizens Retro
 This regularly-occurring round will fold into the larger Citizens Grants program purview, solidifying it as a regular initiative of the DAO. 

We should talk more about this…The citizens retro round is a GCP-funded, bottoms-up initiative that did not come from CSDO. As I’ve said before, I’m not necessarily against folding into a larger strategy but think it requires some more discussion. I hope this is not a trend that all GCPs will follow? Builders can build until it’s successful and CSDO unilaterally decides to fold it into their plans without being clear about what that means.

There seems to be a tension between wanting to fund bottoms-up work and exerting top-down control on where funding goes that we as an organization still need to resolve. I have mixed views on the decision to appoint a Grants Council to decide what bottoms-up work to fund. Why is this preferable?

To me it seems this is an extra governance mechanism wrapping around an existing token-voting GCP process (which we trust for decisions as big as funding our workstreams). With that said, I don’t think you could assemble a better roster of informed decision makers than the assembled council and I know they will make great calls. I also hope the v2 of this program experiments with more decentralized ways to make decisions.

Overall, I support and am excited for this project!

Here are some high-quality citizens previously funded I think could benefit from Citizens Innovate and am tagging for visibility:

- [@davidgasquez](https://gov.gitcoin.co/u/davidgasquez) Grants Data Portal
- [@eleventh19](https://gov.gitcoin.co/u/eleventh19) Web3 Grants Reporting
- [@Joel_m](https://gov.gitcoin.co/u/joel_m) Next Gen QF
- [@ccerv1](https://gov.gitcoin.co/u/ccerv1) Data Analytics (and now OSO)

I’m in broad support of this proposal. I love to see the emphasis on funding citizens, especially to proactively pursue larger projects. I also love the emphasis on measuring outcomes, and I know [@rohit](https://gov.gitcoin.co/u/rohit) will crush as a PM on this.

CoachJonathan:  Citizens Retro
 This regularly-occurring round will fold into the larger Citizens Grants program purview, solidifying it as a regular initiative of the DAO. 

We should talk more about this…The citizens retro round is a GCP-funded, bottoms-up initiative that did not come from CSDO. As I’ve said before, I’m not necessarily against folding into a larger strategy but think it requires some more discussion. I hope this is not a trend that all GCPs will follow? Builders can build until it’s successful and CSDO unilaterally decides to fold it into their plans without being clear about what that means.

There seems to be a tension between wanting to fund bottoms-up work and exerting top-down control on where funding goes that we as an organization still need to resolve. I have mixed views on the decision to appoint a Grants Council to decide what bottoms-up work to fund. Why is this preferable?

To me it seems this is an extra governance mechanism wrapping around an existing token-voting GCP process (which we trust for decisions as big as funding our workstreams). With that said, I don’t think you could assemble a better roster of informed decision makers than the assembled council and I know they will make great calls. I also hope the v2 of this program experiments with more decentralized ways to make decisions.

Overall, I support and am excited for this project!

Here are some high-quality citizens previously funded I think could benefit from Citizens Innovate and am tagging for visibility:

- [@davidgasquez](https://gov.gitcoin.co/u/davidgasquez) Grants Data Portal
- [@eleventh19](https://gov.gitcoin.co/u/eleventh19) Web3 Grants Reporting
- [@Joel_m](https://gov.gitcoin.co/u/joel_m) Next Gen QF
- [@ccerv1](https://gov.gitcoin.co/u/ccerv1) Data Analytics (and now OSO)