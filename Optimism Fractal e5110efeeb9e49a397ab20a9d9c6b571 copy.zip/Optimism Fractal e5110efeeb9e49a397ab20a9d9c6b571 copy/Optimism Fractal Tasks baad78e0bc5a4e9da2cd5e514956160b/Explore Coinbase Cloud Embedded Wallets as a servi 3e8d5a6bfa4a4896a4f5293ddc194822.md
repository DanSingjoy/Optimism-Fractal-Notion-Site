# Explore Coinbase Cloud Embedded Wallets as a service and Compare with Privy

Status: Not started
Task Summary: This task aims to explore Coinbase Cloud Embedded Wallets as a service and compare it with Privy. The page provides an overview of Coinbase's Wallet as a Service SDK and highlights the potential benefits of choosing a larger development company like Coinbase. The page also includes relevant links for further information.
Summary: This document discusses Coinbase's Cloud Wallet as a Service SDK and compares it with Privy. Coinbase offers a Wallet as a Service SDK as part of their cloud services, highlighting the benefits of working with a larger company committed to the Superchain with Base. The document includes links to learn more about Coinbase's offerings.
Created time: March 18, 2024 5:59 PM
Last edited time: June 8, 2024 11:42 PM
Parent task: Research Coinbase Developer Platform (Research%20Coinbase%20Developer%20Platform%2060c4fa44c72f48a5a60a2d3cb11ba1f0.md)
Created by: Dan Singjoy

## Description

- 

## Coinbase Cloud Wallet as a Service SDK

Coinbase offers a [Wallet as a Service SDK](https://www.coinbase.com/cloud/products/waas?utm_source=lolp&utm_medium=cloud&utm_campaign=walletslearnmore) as a part of their wider portfolio of [cloud services](https://www.coinbase.com/cloud). There might be some benefit in going with a much larger development company with more resources and the fact that they are committed to the Superchain with Base,.

![[https://www.coinbase.com/cloud/products/waas?utm_source=lolp&utm_medium=cloud&utm_campaign=walletslearnmore](https://www.coinbase.com/cloud/products/waas?utm_source=lolp&utm_medium=cloud&utm_campaign=walletslearnmore)](Explore%20Coinbase%20Cloud%20Embedded%20Wallets%20as%20a%20servi%203e8d5a6bfa4a4896a4f5293ddc194822/Untitled.png)

[https://www.coinbase.com/cloud/products/waas?utm_source=lolp&utm_medium=cloud&utm_campaign=walletslearnmore](https://www.coinbase.com/cloud/products/waas?utm_source=lolp&utm_medium=cloud&utm_campaign=walletslearnmore)

![Untitled](Explore%20Coinbase%20Cloud%20Embedded%20Wallets%20as%20a%20servi%203e8d5a6bfa4a4896a4f5293ddc194822/Untitled%201.png)

![[https://www.coinbase.com/cloud/products#wallets](https://www.coinbase.com/cloud/products#wallets)](Explore%20Coinbase%20Cloud%20Embedded%20Wallets%20as%20a%20servi%203e8d5a6bfa4a4896a4f5293ddc194822/Untitled%202.png)

[https://www.coinbase.com/cloud/products#wallets](https://www.coinbase.com/cloud/products#wallets)

![[https://www.coinbase.com/cloud](https://www.coinbase.com/cloud)](Explore%20Coinbase%20Cloud%20Embedded%20Wallets%20as%20a%20servi%203e8d5a6bfa4a4896a4f5293ddc194822/Untitled%203.png)

[https://www.coinbase.com/cloud](https://www.coinbase.com/cloud)

[15k but beta it looks like](Explore%20Coinbase%20Cloud%20Embedded%20Wallets%20as%20a%20servi%203e8d5a6bfa4a4896a4f5293ddc194822/15k%20but%20beta%20it%20looks%20like%20b8107551ab434f53bf009d931a5cf397.md)