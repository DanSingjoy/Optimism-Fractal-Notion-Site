# Convey how Optimism Fractal’s core intents benefit the Optimism Collective’s intents

Project: Create systems, goals, and metrics to measure the success of Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20systems,%20goals,%20and%20metrics%20to%20measure%20the%20%2013e1391306f94511bf83c98ff58ecca8.md), Research and Strategize to provide Optimism Collective with the most value possible (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20and%20Strategize%20to%20provide%20Optimism%20Collec%20ad36d53370ce43a18be5b0ff973a2052.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md)
Status: Not started
Task Summary: This task aims to convey how the core intents of Optimism Fractal benefit the overall intents of the Optimism Collective. By examining the relationship between these two entities, we can understand how Optimism Fractal contributes to the collective's goals and objectives.
Summary: No content
Created time: June 13, 2024 9:37 PM
Last edited time: June 13, 2024 9:38 PM
Created by: Dan Singjoy

- [ ]  review discussion with Eric towards the end of EF 30
    - [ ]  transcribe and summarize