# Integrate ENS with Optimism Fractal Webapp

Project: Integrate Optimism Fractal with ENS (Ethereum Name Service) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20with%20ENS%20(Ethereum%20Name%2003fc813cc6744f87807695748158eed5.md)
Status: Not started
Summary: The goal is to integrate ENS (Ethereum Name Service) with the Optimism Fractal web app to improve user-friendliness by displaying ENS names instead of 0x addresses.
Created time: April 4, 2024 9:28 PM
Last edited time: April 4, 2024 10:30 PM
Created by: Dan Singjoy

- The current web app can be found at [https://optimismfractal.web.app/](https://optimismfractal.web.app/)

- It’s currently not very user friendly looking with the 0x addresses and ENS names would be great here

## Example

![Untitled](Integrate%20ENS%20with%20Optimism%20Fractal%20Webapp%2029615b0bc95e4296b5d3681f274a0820/Untitled.png)