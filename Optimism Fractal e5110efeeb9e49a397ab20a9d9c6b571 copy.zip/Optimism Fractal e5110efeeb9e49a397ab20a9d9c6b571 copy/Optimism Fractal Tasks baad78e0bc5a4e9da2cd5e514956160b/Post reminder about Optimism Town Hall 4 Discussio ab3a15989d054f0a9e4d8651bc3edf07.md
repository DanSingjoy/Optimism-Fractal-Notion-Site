# Post reminder about Optimism Town Hall 4 Discussion Topic Proposals on gov forum

Assignee: Dan Singjoy
Due: May 31, 2024
Status: Done
Task Summary: This task aims to post a reminder on the government forum about the Optimism Town Hall 4 Discussion Topic Proposals. The reminder encourages participants to review the proposals, vote for topics, and submit their own suggestions. The topic with the most votes will be the main discussion topic for the event, providing an opportunity for community members to contribute to Optimism Collective governance.
Summary: This document is a reminder about the Optimism Town Hall 4 Discussion Topic Proposals. Participants are encouraged to vote for topics and propose new ones. The topic with the most votes will be the main discussion topic for the event. The current proposals include reflections on Optimism Fractal and Optimism Town Hall, Base Onchain Summer, and Optimism Collective Season 6.
Created time: June 2, 2024 4:12 PM
Last edited time: June 3, 2024 12:46 PM
Created by: Dan Singjoy

Hey all, 

This is a friendly reminder that you can see the the topic proposals in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth), vote for any topics you’d like to discuss at this week’s event, and feel free to propose any other topic that you’d like to discuss. 

As per the rules of [Cagendas](https://optimystics.io/cagendas), whichever topic has the most votes in Monday at 17 UTC will be the main discussion topic for this week’s event. This is an opportunity to share your thoughts and help lead Optimism Collective governance. 

The topic proposals that have been submitted for this week’s Town Hall are:

[🌻 Reflections on Optimism Fractal and Optimism Town Hall](https://snapshot.org/#/optimismtownhall.eth/proposal/0x9ad4a8e331bdd71f7ab64ea45fbfc4f4cc4d3ff0647162f62b019acf33b6fe1f)

[🔵 Base Onchain Summer](https://snapshot.org/#/optimismtownhall.eth/proposal/0x872636ba6ebdf15c6704e912703797434b9afcaa9669bcbb91000c477702214f)

[🔴Optimism Collective Season 6](https://snapshot.org/#/optimismtownhall.eth/proposal/0x91b453b33a3cfe54a2abc3304c5bfe72aaf09291cd32aae3be36fc7ec07e6209)

I’m looking forward to hearing everyone’s thoughts and hope to see you at this week’s events!