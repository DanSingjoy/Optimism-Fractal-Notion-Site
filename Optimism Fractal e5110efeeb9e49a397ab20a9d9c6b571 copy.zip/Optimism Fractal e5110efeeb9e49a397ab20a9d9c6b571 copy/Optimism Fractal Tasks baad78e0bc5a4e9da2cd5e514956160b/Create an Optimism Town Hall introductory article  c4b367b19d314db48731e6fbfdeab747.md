# Create an Optimism Town Hall introductory article for the Optimism Collective and decide places to promote

Assignee: Rosmari, Dan Singjoy
Due: August 7, 2024
Project: Create Promotions for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Promotions%20for%20Optimism%20Town%20Hall%20f0d644b3dbb8453e9413b33e03b0228b.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Create and Execute Promotional Strategy for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20and%20Execute%20Promotional%20Strategy%20for%20Optimi%20ea86a4b0098f48da970a5a108ec02544.md)
Status: In progress
Task Summary: This task aims to create an introductory article for the Optimism Town Hall in the Optimism Collective. It also involves deciding on the places to promote the article, such as Paragraph and Mirror. The article will be created by Dan Singjoy and the assigned team members are Rosmari and Dan Singjoy.
Summary: This document outlines the tasks and brainstorming for creating an introductory article for the Optimism Town Hall and deciding on places to promote it. The tasks include strategizing where to post the article, reviewing draft posts, and reviewing prior posts for reference. The article will include information about the upcoming town hall event, the proposal to implement Cagendas, and how to propose topics for discussion. The document also mentions promoting the event on platforms like Paragraph and Mirror, as well as using Boosts for promotion.
Created time: May 14, 2024 1:22 PM
Last edited time: July 15, 2024 8:07 PM
Created by: Dan Singjoy
Description: This document is an in-progress article for an Optimism Town Hall introductory post. It includes brainstorming tasks, a review of draft posts, and a plan to write the post and related tweets. The article discusses the importance of promoting the event on platforms like Paragraph and Mirror, and mentions the Boosts feature as a way to generate interest. The document also references prior posts and proposes reusing certain content. Overall, the document outlines the steps needed to create and promote the Optimism Town Hall event.

# Brainstorming on Tasks - Dan

## Strategize

- [x]  figure out where to post it

- [x]  review [Consider places to Promote Optimism Town Hall #2](Consider%20places%20to%20Promote%20Optimism%20Town%20Hall%20#2%209d8abd2cfae340f8939b295f919d1ec7.md)
    - Perhaps Rosmari can research this then provide a suggestion then we discuss this as a team
    
- [ ]  Consider if this task linked above should be merged with this one or if we should create a project for promoting this town hall instead of just a task
    - I created a project template for promoting each Optimism Town Hall event, which you can find in the project templates section of [Projects](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2.md)
    - You can find more thoughts related to this in [Create and Execute Promotional Strategy for Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20and%20Execute%20Promotional%20Strategy%20for%20Optimi%20ea86a4b0098f48da970a5a108ec02544.md)

- [ ]  Consider if it should also be promoted on Paragraph or Mirror
    
    
    - The first Town Hall events might be a good opportunity to start posting on Paragraph and Zora
    - We could also potentially use the Boosts to promote the first few episodes of Optimism Town Hall
        - The promotion for Boost lasts another 2.5 weeks, so we could boost the first few town halls and this could be a great way to make a big splash to promote the event really well
            - More details can be found here:
                - [Read article about Boosts OP Promotion and consider boosting posts on Zora](Read%20article%20about%20Boosts%20OP%20Promotion%20and%20conside%20a76b903cbcea454ea38e2357dd38e005.md)
                - [Boost.xyz](http://Boost.xyz)
        - This would also give us a good opportunity to test out a lot of this things we’ve been discussing with regards to ZoPa without needing to also decide on promoting an entire earlier season of Optimism Fractal right now
            - [Research and create plan for onchain content publications](https://www.notion.so/Research-and-create-plan-for-onchain-content-publications-7534706e17ee455cbd62ab32ba56aff4?pvs=21)
            - Related Notes
                - [Start using paragraph . High recommendation ](https://www.notion.so/Start-using-paragraph-High-recommendation-478e7cb748cb497483da6c8519773753?pvs=21)
                - [Boost on X: "Paragraph is now supported on Boost Protocol Anyone can incentivize any target wallet to collect a mint on @paragraph_xyz and earn crypto rewards on clients like @boostinbox_. https://t.co/utOiAReCs0" / X](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Research%20and%20Test%20Boost%20xyz%20adada5184ec24d39bee8836effe3b9d3/Boost%20on%20X%20Paragraph%20is%20now%20supported%20on%20Boost%20Pro%2000b443ed9a7946819def5f8c2662edd6.md)
                - [Paragraph frame referral ](https://www.notion.so/Paragraph-frame-referral-8419abb2ba2043da875a9aed99c9d54a?pvs=21)
                - [Research paragraph and Farcaster integrations with gm Farcaster ](https://www.notion.so/Research-paragraph-and-Farcaster-integrations-with-gm-Farcaster-3fb1bd41e92a4cb7ac7b10afa7c79808?pvs=21)
                - [[paragraph
        - I think it would be quite simple to post it on paragraph and deploy the boost
        - I think this is most likely a good idea… what do you think?

## Review Draft Posts made by ChatGPT

- 
    
    
    - [ ]  review the draft posts that may be relevant
        - [ ]  [Write brief summary of Cagendas and Optimism Town Hall](Write%20brief%20summary%20of%20Cagendas%20and%20Optimism%20Town%20%20efaf6e048b9e469e806b920679b03566.md)
        - [ ]  [Write Blog Post(s) to introduce Optimism Town Hall to the Optimism Collective and explain how it relates to Optimism Fractal](Write%20Blog%20Post(s)%20to%20introduce%20Optimism%20Town%20Hall%200138ffc8ae61469cbca2409795046331.md)
        - [ ]  [Write a blog post about how cagendas and optimism town hall benefit the optimism collective](Write%20a%20blog%20post%20about%20how%20cagendas%20and%20optimism%20%20a02a41c4fd7c4e13a60ebdaea1324639.md)
            - [ ]  [Write a blog post about how you can help lead Optimism Collective governance at Optimism Town Hall](Write%20a%20blog%20post%20about%20how%20you%20can%20help%20lead%20Opti%20dc5674a52871442eaf38b49c45a36349.md)
        - [ ]  [Write Blog Post(s) introducing cagendas at optimism town hall](Write%20Blog%20Post(s)%20introducing%20cagendas%20at%20optimis%20d112b4eb379c4325ae466c67bb06c7d6.md)
        - [ ]  [Write Promotional Message to introduce Optimism Town Hall to the Optimism Collective and more general audience](Write%20Promotional%20Message%20to%20introduce%20Optimism%20To%20d251f83a0cf64e59b7dc6619158e8f0e.md)
        - There may also be other drafts that are relevant in the project for [Create Promotions for Optimism Town Hall](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Promotions%20for%20Optimism%20Town%20Hall%20f0d644b3dbb8453e9413b33e03b0228b.md)
        
    

## Review Prior Posts

### Governance post announcing Cagendas and some of OTH

- [x]  review Dan’s [post](https://gov.optimism.io/t/optimism-fractal-season-3/8095/2?u=rosmari) on the governance forum and consider which parts should be copied and pasted or added in this post
- It may be good to reuse much of this

- Post
    
    Hey optimists! Thanks for the great event on Thursday, it was amazing seeing everyone and a wonderful way to start season 3 of Optimism Fractal!
    
    I’m pleased to announce that the proposal to implement Cagendas after the Respect Game at weekly events was approved by the Optimism Fractal [council](https://optimismfractal.com/council). This means that we’ll host the first Optimism Town Hall event this upcoming Thursday at 18 UTC following our weekly Respect Game and a topic for the event will be chosen on Monday at 17 UTC according to the rules in the proposal. We’ll also repeat this process at weekly events going forward until some other change is proposed and approved with our community’s consensus [process](https://optimismfractal.com/details#block-e42fb7c2317c49bb92fc4165c01b20ae). I appreciate all the thoughtful feedback shared during the event and the votes in support of the proposal.
    
    To kick off the first town hall, I just created a [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0xa35337aff287c57648a2dfe3e5d5f44053d9677606fbd26b5b9b7b2bd7e19505) called *Exploring Optimism Town Hall and Cagendas.* At this event, I’d like to share a brief presentation that provides a more in-depth overview of the potential benefits, next steps, and rationale of these new initiatives. The material for this topic can be found in the [introductory post](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md), which includes links to projects with more details about Optimism Town Hall, Cagendas, Optimism Fractal Season 3, and the value that these initiatives can provide for the Optimism Collective. We’ll have an open discussion after the presentation and I’d love to hear more feedback about this topic, so please feel free to share any thoughts here in the chat or at the upcoming town hall event.
    
    As per the rules approved in the proposal, anyone who has earned [Respect](https://optimystics.io/respect) at Optimism Fractal can propose a different topic to discuss after this week’s Respect Game event by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth). Anyone who has earned Respect at Optimism Fractal can vote on these polls with their Respect to help determine the discussion topic for each weekly event and whichever topic proposal received the most votes by Monday at 17 UTC will be the topic discussed during the upcoming Town Hall event. If you want to propose a topic, make sure to set your topic proposal poll to end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event. Feel free to propose any topic that is related to Optimism Fractal or the Optimism Collective.
    
    For anyone who missed last week’s event, I recommend watching the video to see all the great things that happened in our first episode of Optimism Fractal Season 3. We discussed this proposal to start playing Cagendas at Optimism Town Hall in the first 10 minutes and the last 15 minutes of the event, as you can see [here](https://youtu.be/-QbLQgOZKwk?si=1HWE2baRjbiY_lH5&t=4507). In addition there were also outstanding contributions in the Respect Game, awesome discussions with talented newcomers, and a very interesting conversation about collaborating to build the upcoming Optimism Fractal app.
    
    I encourage everyone to register for our weekly Optimism Town Hall [event](https://lu.ma/optimismtownhall) and invite friends who are interested in Optimism. If you’re not yet familiar with Optimism Fractal, we invite you to explore [OptimismFractal.com](http://optimismfractal.com/), join our weekly events, and feel free to reach out with any questions. I’m looking forward to seeing all the topics that the community will propose this season and excited to see you at our 26th event on Thursday! Thank you!
    

Next steps: 

- [x]  copy and paste into [Promote OTH 1](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Promote%20OTH%201%203de5089a487a4e3ba2aba5d2fa5c8115.md)

### Introductory post of Cagendas and OTH

- [x]  Review the introductory post about Cagendas and OTH
    
    [https://www.notion.so/edencreators/Introducing-Cagendas-and-Optimism-Town-Hall-3be08af1fc734845942d75e24cbdd864?pvs=4](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md)
    

### Retro Pitches Announcement posts in Optimism Governance and Tweets

- [x]  Consider reviewing our introductory post and tweets for RetroPitches and copy/pasting how we worded it to promote both the Respect Game as part of the Optimism Town Hall promotion
    - We can also review our posts about Optimism Fractal from the time of RetroPitches and re-use that language about how we promoted RetroPitches in Optimism Fractal Promotions and start using that for each OF promotion going forward as well

### Posts

[***Introducing RetroPGF Pitch Games!*** 

Hey all! We’re thrilled to announce RetroPGF Pitch Games, aka RetroPitches!](https://www.notion.so/Introducing-RetroPGF-Pitch-Games-Hey-all-We-re-thrilled-to-announce-RetroPGF-Pitch-Games-aka-Re-3a5e7524728d47acad2802d160e8ef5a?pvs=21)

[✨✨✨Introducing RetroPGF Pitch Games! Gov Thread ✨✨✨Hey all! We’re thrilled to announce RetroPGF Pitch Games, aka RetroPitches! 🌞](https://www.notion.so/Introducing-RetroPGF-Pitch-Games-Gov-Thread-Hey-all-We-re-thrilled-to-announce-RetroPGF-Pitch-G-fb8a39afe54543e3a746364c0cbd5e55?pvs=21) 

### Tweets

[](https://www.notion.so/6b7c5fff034a4b6b815b6da43355e01f?pvs=21) 

## Write Post

- [ ]  consider using one of the drafts as a starting point and taking parts from the others or refining as you see fit
    - Consider asking Chat GPT to refine or provide a new version in the original chat, which can be found at the top of this page: [Add ChatGPT Convo about Optimism Town Hall and Cagendas to Notion and Organize into Tasks](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Add%20ChatGPT%20Convo%20about%20Optimism%20Town%20Hall%20and%20Cag%20b390b514353d415fa9e158362e18c31c.md)
    - Feel free to also start drafting other promotional messages as you read and refine them. For example, at the airport we discussed posting promotional messages in different Optimism Governance forum topics in the coming weeks to increase the visibility and distribution of our promotions.
        - There is a new task for [Create a blog post, summary, and promotional post about how Optimism Town Hall helps citizens](Create%20a%20blog%20post,%20summary,%20and%20promotional%20post%20%206818c067923f476db31691f57a51ed17.md) that is intended to create a post in the citizens category, which is on the homepage of the forum and only has two topics right now

- [ ]  consider- it’s probably good to link to dan’s post on the governance forum which provides more details about the town hall and also links to it the Optimism Fractal event

## Write Tweets and Casts that link to the Introductory post