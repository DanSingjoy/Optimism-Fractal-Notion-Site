# Set up automated discord reminder to register for the council

Due: June 24, 2024
Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md), Explore deeper integrations between Optimism Fractal and Discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Optimism%20Fract%20337d632e686e44e68cd899e6e12e05f3.md), Improve optimism fractal discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20optimism%20fractal%20discord%20f0810fb48cfc4a08b49fc433c1ebaffb.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Task Summary: This task aims to set up an automated Discord reminder for registering for the council. Created by Dan Singjoy, the reminder is due on June 24, 2024. The task is currently marked as not started and includes instructions to ask the AI for guidance on setting up the reminder using Discord. Alternatively, the task suggests setting up a manual template but emphasizes the benefits of learning how to automate the reminder through Discord.
Summary: To set up an automated Discord reminder to register for the council, ask AI for instructions. Alternatively, consider setting it up manually using a template, but learning how to do it through Discord's automated reminder feature is recommended for better efficiency and the potential to share other helpful messages.
Created time: June 6, 2024 2:38 PM
Last edited time: June 6, 2024 2:44 PM
Created by: Dan Singjoy

- [ ]  ask ai how to set this up with discord

- alternatively i could set this up in template to do it manually, but its better jus to learn how to do it via discord automated reminder
    - This could also share other helpful logistical or promotional messages