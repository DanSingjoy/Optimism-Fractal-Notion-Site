# Respond to Jorge in fractally chat about Optimism Fractal

Assignee: Dan Singjoy
Due: April 29, 2024
Project: Explore opportunities for collaboration and community engagement to expand our reach, educate about Optimism Fractal, and promote the Respect Game   (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20opportunities%20for%20collaboration%20and%20commun%20dc057e22dba746aeab00fce108cd9a9a.md), Engage and build relationships with leaders in fractal communities (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20and%20build%20relationships%20with%20leaders%20in%20fra%20d03dec56536a4ffbb16a6c0b88c65239.md)
Status: Done
Task Summary: This task aims to respond to Jorge in the Fractally chat about Optimism Fractal. It provides an update on the project, including the creator, assignee, due date, and status. The message encourages Jorge to attend events and highlights the importance of their expertise in fractal democracy for Optimism Fractal.
Summary: This document is a response to Jorge in the Fractally chat about Optimism Fractal. It discusses retro funding opportunities, the role of Optimism Fractal in supporting the community, and the potential for growth and collaboration within the fractal network.
Created time: May 8, 2024 11:54 AM
Last edited time: May 14, 2024 4:16 PM
Created by: Dan Singjoy

![[https://t.me/gofractally/11231](https://t.me/gofractally/11231)](Respond%20to%20Jorge%20in%20fractally%20chat%20about%20Optimism%20%204812aa11118946d798e382f7b1f50043/Untitled.png)

[https://t.me/gofractally/11231](https://t.me/gofractally/11231)

Thanks for watching and sharing the feedback! It would be great to see you at the events and your expertise in fractal democracy would be much appreciated at Optimism Fractal 🙏🏽

I encourage everyone to watch the most recently released [episode](https://youtu.be/5FeRMLjw0yY?si=QyWprCE7z67z29Pq) to learn more about funding opportunities with Optimism Fractal. You can find timestamps of this discussion [here](https://youtu.be/5FeRMLjw0yY?si=bks4xqP6W-2q-v6u&t=3421) and feel free to reach out with any questions :)

![optimism fractal 22 thumbnail draft.png](../%F0%9F%90%99%20Optimism%20Town%20Hall%20Topics%20and%20OPTOPICS%20Database%206415ae101d154bf8a3c1b25d218295d5/%F0%9F%8C%9E%20RetroFunding%20Round%206%20106074f5adac80d8be83e2ac939cda48/optimism_fractal_22_thumbnail_draft.png)

**OF 22: Retro Funding Optimism Fractal**

How can Optimism Fractal help you earn Retro Funding? We measure each other’s impact in the Collective, then help public goods creators to profit by growing Optimism and contributing to Optimism Fractal  🧑🏽‍🌾 📏 🔴

- timestamp
    
    [55:10](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3310s)
    
    - Dan ends the respect game and begins the upcoming planning session, mentioning the Retro funding opportunities that Optimism Fractal can help with
    
    [56:20](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3380s)
    
    - D
    
    [55:10](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3310s)
    
    - Dan ends the respect game and begins the upcoming planning session, mentioning the Retro funding opportunities that Optimism Fractal can help with
    
    [56:20](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3380s)
    
    - Dan shares presentation on planning session, provides an overview of the different Retro funding categories that are coming up, including Onchain Builders, OP Stack, Governance, and Dev Tooling
    
    [58:09](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3489s)
    
    - Dan discusses how Optimism Fractal can help people earn Retro funding by promoting their work, providing opportunities for collaboration and community engagement, and contributing to Optimism Fractal itself
    
    [58:57](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3537s)
    
    - Will gives his understanding on next cycle of retroPGF funding which launches in May
    
    [59:22](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3562s)
    
    - Dan replies to Will, shares screen to blog post shared by optimism foundation. First round is on chain builders, gives details.
    Shares other retro funding focuses. OP stack, governance, Dev tooling. Gives details. mentions possibilities of optimism fractal contributors retro funding applications.
    
    [56:26](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=3386s)
    
    - Dan shares his screen of ways to possibly gain funding. gives examples and details. Mentions all open projects that optimism fractal has on Notions page. Earn funding by helping Optimism
    
    [1:07:00](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=4020s)
    
    - The group continues the discussion on RetroFunding opportunities and Optimism Fractal's role in supporting the community
    
    [1:09:55](https://www.youtube.com/watch?v=5FeRMLjw0yY&t=4195s)
    
    - Dan shares screen from previous retro funding, optimism fractal held retro pitches after respect games to help promote those trying to help optimism

- [ ]  consider linking to rosmari’s post in gov forum?

Share all of the below or a shortened version? I think it’s better to share just share the message above for now and then  share this soon as we have better resources to share, such as our article about how you can earn funding with optimism fracfal 

## Draft message to share with Fractally chat and FractalJoy network

At Optimism Fractal we’re creating a way to help community members earn from the upcoming retro funding round about governance and play a leading role in Optimism Collective governance, which is planning to allocate billions of dollars to public goods and is well positioned for exponential growth with millions of people joining in the Superchain along with top initiatives like world chain from ai and Jade

The stage is set to attract hundreds of talented developers and communities leaders to adopt fractals in the largest network

There is a huge opportunity for fractals to grow with more fertile environment, funding opportunities, and alignment then ever. This can be very helpful for Upscale and all other fractals as well. The more that experienced fractal members can participate and rally together in the coming months, the better we’ll all do individually and the more benefit that we’ll be able to create for all with fractals

### Consider also sharing with Upscale, AWF, and other fractals

## ailexai

 i should just thumbs up and save other messages for ailexai for another time

![Untitled](Message%20the%20Fractally%20chat%20about%20opportunities%20wit%200b79837ae7344c7d95d3aac49c119b7f/Untitled.png)

thumbs up

[Respond to Ailexai’s past messages in the Fractally Chat](https://www.notion.so/Respond-to-Ailexai-s-past-messages-in-the-Fractally-Chat-6063eebed6d44545a41be0532ad7e751?pvs=21)