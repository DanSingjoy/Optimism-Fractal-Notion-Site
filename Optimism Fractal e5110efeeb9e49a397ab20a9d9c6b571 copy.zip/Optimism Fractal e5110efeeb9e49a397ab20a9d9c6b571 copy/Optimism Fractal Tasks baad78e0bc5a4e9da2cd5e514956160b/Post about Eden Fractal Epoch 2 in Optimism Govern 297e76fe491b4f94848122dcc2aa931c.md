# Post about Eden Fractal Epoch 2 in Optimism Governance Forum

Project: Prepare for Optimism Fractal 37 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20Optimism%20Fractal%2037%2021c5f2f7dfe14e57ab1fe2e1bfec7978.md)
Status: In progress
Task Summary: This task aims to discuss the creation of a new thread for Eden Fractal Epoch 2 in the Optimism Governance Forum. It will address the potential benefits and timing of the post, considering the upcoming Respect Games and the current state of the Eden Fractal initiative.
Summary: The discussion in the Optimism Governance Forum revolves around whether to create a new thread for Eden Fractal Epoch 2. Key points include the potential benefits of timely posting versus waiting for better alignment with the Respect Games, and the decision to possibly share a short post in the existing Optimism Fractal thread while planning a more detailed introduction for later.
Created time: August 12, 2024 8:57 PM
Last edited time: August 12, 2024 9:08 PM
Created by: Dan Singjoy
Description: The discussion on Eden Fractal Epoch 2 in the Optimism Governance Forum considers whether to create a new thread or post within the existing Optimism Fractal thread. Key points include the timing of the post related to the start of Epoch 2 and the upcoming RetroFunding round, the potential impact of posting now versus later, and the need to clarify the value proposition for the audience.

- [ ]  should we create a new thread for Eden Fractal Epoch 2?
    - I think this is probably a good idea if we have the time to do so. What do you think?
        - Much of it is already written and now may be a good time to do it with Epoch 2 starting and the RetroFunding round about Governance coming soon
        - There’s also a decent argument to saving it for later since there’s no respect games yet, the website hasn’t been updated recently, it would take some time and we don’t want to dilute the attention to Optimism Fractal too much
        - Eden Fractal could help support OF though and we’re already making posts about Eden Fractal, so the posts could potentially have a larger impact if we also post them here. However, that would take additional time and might not be worth it
        - Maybe it makes the most sense to save the full thread for after the Respect Games start and we have a better introduction? Yes, the audience probably wont’ care about it being Epoch 2 so much and are more interested in how it can help them, so we can wait until that value proposition is more clear

- [ ]  consider- should we post in the same thread as optimism fractal?
    - Should we post something like this short post or the longer post below?
        - I think it probably makes sense to share something like the short version below in the Optimism Fractal thread for now since it shows how it supports OF, then save the more focused introduction to Eden Fractal for a future week when we have more time to plan it out well
    

## Short Post

![EF 104 promotional image.png](Post%20about%20Eden%20Fractal%20in%20OF%20chat%205dd685a1fb1b428585288110bcbe9d5c/EF_104_promotional_image.png)

You’re also welcome to join as we step into Epoch 2 of Eden Fractal on Wednesday, August 14th!

We’ll start with a recap of the [Epoch 2 proposal](https://www.notion.so/Introducing-Eden-Fractal-Epoch-2-4eaaf4268f5a4dd79e58aa4d70451fae?pvs=21), provide updates on software development, and have an open discussion on our goals and plans for this epoch. Eden Fractal is transitioning into it’s next phase to help Optimism Fractal as much as possible and you can find more details about this week’s event in this post. We invite community members to share what they’ve been working on, help shape the future of fractal consensus processes, and participate to optimize collective decision-making throughout society.

You can register to join all three events on our [events calendar](https://lu.ma/optimystics). As always, you can learn more and watch all the videos from past seasons at [Optimystics.io](http://Optimystics.io). Looking forward to seeing you at the events!

![fractal events presented by Optimystics2.png](Post%20about%20Eden%20Fractal%20in%20OF%20chat%205dd685a1fb1b428585288110bcbe9d5c/fractal_events_presented_by_Optimystics2.png)

## Longer Post

Hey friends,

I hope you've all enjoyed the summer break! I’m excited to reconvene this Wednesday as we step into Epoch 2 of Eden Fractal. This marks an important transition in our journey and we'd love your input on shaping our path forward. For our first session back, I suggest that we have a discussion about planning our second epoch. Here's what you can expect:

- **A recap of the [Epoch 2 proposal](https://www.notion.so/Introducing-Eden-Fractal-Epoch-2-4eaaf4268f5a4dd79e58aa4d70451fae?pvs=21)**: We'll briefly revisit the original Epoch 2 proposal to refresh our collective memory, set the stage for our next steps, and explore any new feedback or ideas that have since emerged.

- **Updates on software development**: While I hoped to start playing Respect Games on Base at the start of Epoch 2, the tools aren't yet fully ready. I can provide updates on the progress and we can discuss potential interim activities.

- **Open discussion on our goals and plans:** This is your chance to share thoughts, ideas, and aspirations for Epoch 2. What do you hope to achieve? What challenges do you foresee? How can we best actualize our vision?

- **Updates from community members:** Each participant can share what they’ve been up to over the break and how Eden Fractal can help achieve their goals. What can Eden Fractal do to help you in this epoch?

I'm excited to hear your thoughts and share some exciting updates. This is a crucial time for Eden Fractal and your input is appreciated. Join us on Wednesday to reconnect, plan our second Epoch, and help shape the future of fractal decision-making processes!

![EF 104 promotional image.png](Post%20about%20Eden%20Fractal%20in%20OF%20chat%205dd685a1fb1b428585288110bcbe9d5c/EF_104_promotional_image.png)