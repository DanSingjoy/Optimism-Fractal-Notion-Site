# Create discord introductory post for Optopics at Optimism Town Hall

Due: May 3, 2024
Project: Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md)
Status: Done
Task Summary: This task aims to create a discord introductory post for Optopics at Optimism Town Hall, introducing an innovative consensus game mode designed to enhance discussions and community coordination at Optimism Fractal. The post provides an overview of Optopics, its features, and encourages community members to participate and support this initiative.
Summary: Introducing Optopics, an innovative consensus game for enriching discussions at Optimism Town Hall. Optopics enhances the original Cagendas game mode by providing structure and flexibility for real-time interaction, facilitating more interactive conversations, and focusing on community priorities. Upvote the topic proposal to play Optopics at this week's Optimism Town Hall. Reminder about Cagendas rules and registration poll for the next week's Optimism Fractal Council.
Created time: May 19, 2024 9:52 PM
Last edited time: May 20, 2024 3:55 PM
Created by: Dan Singjoy

Hello everyone! I'm thrilled to introduce **Optopics**, an innovative consensus game crafted to enrich our discussions at Optimism Town Hall. Optopics is a new Cagendas game mode that allows respected community members to propose, vote, and dynamically coordinate discussion topics during our events. 

Optopics enhances the original Cagendas game mode by providing structure for real-time interaction and flexibility during events. This collaborative agenda game is designed to optimize our meeting time by providing a simple structure, facilitating more interactive conversations, and helping us focus on what’s most important to the community. It’s a fun way to organize events that taps into the wisdom of our community to more effectively grow Optimism Fractal and maximize our impact for the Optimism Collective with Respect.

Please [see the introductory post](Create%20Introductory%20post%20for%20Optopics%20at%20Optimism%20%208a4b346168bb412b80d1674b5767263a/Introducing%20OPTOPICS%20ef3bf6a9cc204ddfb0115b60af1c9d6e.md) for more details and [upvote the topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x62a7071a811de41ae293f18d6bc7650262442aecbf94acc7e711c4fe301683ff) to play Optopics at this week’s Optimism Town Hall if you support this initiative. Feel free to share any questions or comments, your participation and feedback is much appreciated. I’m looking forward to collaborating with you all to create the future of collective decision-making and community coordination at Optimism Fractal!

![optopics 2.png](Create%20Artwork%20for%20Optopics%201619b660f651444098ace70d075cde61/optopics_2.png)

## Reminder about Cagendas Rules

**Reminder**: As per the recently approved [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d) to implement Cagendas, anyone who has earned Respect at Optimism Fractal can make a different topic proposal to discuss after this week’s Respect Game event by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth) before Monday at 17 UTC. Alternatively you can also suggest topics with the Optopics game proposed above. You can see the rules for Cagendas in the proposal above and feel free to propose any topic that is related to Optimism Fractal or the Optimism Collective.

## Council Registration Poll

Here is the [registration poll](https://snapshot.org/#/optimismfractal.eth/proposal/0x567ccccf98f41759f90a8758d087a418e14ba94aba6555931bfb9dc06e75fa4d) for the next week’s Optimism Fractal Council. I updated the text in the poll with a link to OptimismFractal.com/council that shows more details about our community’s consensus process. In exciting news, this is the first week where we’ve had a full council with 6 sages. Big thanks to the Optimism Fractal councilors for the participation and support! 🙏🏽 🧙🏽‍♂️ 

- [ ]  update the text of the registration poll to include:
    
    
    Respond to this proposal if you'd like to participate on the next Optimism Fractal Council.
    
    If you are selected for the Council you’ll have the opportunity and responsibility to help make decisions and express community opinions for Optimism Fractal.
    
    You can see how the council works at [OptimismFractal.com/details](http://optimismfractal.com/details) and learn more about the council in this [article](https://optimismfractal.com/council).
    

- This is the first week where we’ve had a full council with 6 sages 🧙🏽‍♂️