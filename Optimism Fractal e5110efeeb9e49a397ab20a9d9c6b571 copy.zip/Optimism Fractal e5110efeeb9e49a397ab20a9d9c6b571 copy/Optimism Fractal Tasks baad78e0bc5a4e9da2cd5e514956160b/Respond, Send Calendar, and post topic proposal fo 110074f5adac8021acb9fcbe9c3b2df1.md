# Respond, Send Calendar, and post topic proposal for Create Agenda for Optimism Town Hall with David Ehrlichman

Assignee: Dan Singjoy
Due: April 28, 2024
Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Create Topics for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Topics%20for%20Optimism%20Town%20Hall%2069e19236e45d4dd8b0a4b7c6fc12ae19.md)
Status: Done
Task Summary: This task aims to organize and prepare for the Optimism Town Hall with David Ehrlichman. It includes responding to communications, sending calendar invites, and proposing discussion topics to ensure a productive and engaging event.
Summary: A calendar invite was sent for the Optimism Town Hall with David Ehrlichman, and discussion topics are being drafted for the event. Feedback on additional topics is welcomed.
Created time: September 29, 2024 11:30 AM
Last edited time: September 30, 2024 9:05 AM
Sub-tasks: Create Topic Proposal for OF 44 and Agenda for Optimism Town Hall with David Ehrlichman (Create%20Topic%20Proposal%20for%20OF%2044%20and%20Agenda%20for%20Opt%20dce6f714064a4a158952d89582b48940.md)
Created by: Dan Singjoy
Description: A calendar invite for the Optimism Town Hall with David Ehrlichman has been sent, and discussion topics are being drafted for the event. Feedback on additional topics is welcomed.

![image.png](Respond,%20Send%20Calendar,%20and%20post%20topic%20proposal%20fo%20110074f5adac8021acb9fcbe9c3b2df1/image.png)

Ok great! Yes I just sent a calendar invite to your email. Looking forward to seeing you then!

I started drafting some discussion topics for the event [here](Create%20Topic%20Proposal%20for%20OF%2044%20and%20Agenda%20for%20Opt%20dce6f714064a4a158952d89582b48940.md). Feel free to let me know if you have anything else in mind or would prefer to discuss something different :)

[Create Topic Proposal for OF 44 and Agenda for Optimism Town Hall with David Ehrlichman](Create%20Topic%20Proposal%20for%20OF%2044%20and%20Agenda%20for%20Opt%20dce6f714064a4a158952d89582b48940.md) 

 

![image.png](Respond,%20Send%20Calendar,%20and%20post%20topic%20proposal%20fo%20110074f5adac8021acb9fcbe9c3b2df1/image%201.png)