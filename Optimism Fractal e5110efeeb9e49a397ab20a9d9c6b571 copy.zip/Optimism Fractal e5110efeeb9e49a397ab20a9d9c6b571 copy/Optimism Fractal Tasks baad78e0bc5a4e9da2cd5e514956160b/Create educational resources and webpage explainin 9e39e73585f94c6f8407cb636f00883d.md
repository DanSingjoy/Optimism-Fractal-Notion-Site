# Create educational resources and webpage explaining Optimism Fractal’s Consensus Process (OptimismFractal.com/council)

Project: Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Create branding and educational resources for decision-making consensus games (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20branding%20and%20educational%20resources%20for%20deci%20188c45e0a1dc4773bd8202133ced6eb7.md), Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md), Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md), Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md), Build Optimism Fractal Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md), Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md)
Status: Not started
Task Summary: This task aims to create educational resources and a webpage that explains the Consensus Process of Optimism Fractal. The resources and webpage will provide an in-depth understanding of how the consensus process works and its importance within Optimism Fractal. Anyone interested in learning about this process and contributing to the creation of educational resources is welcome to participate.
Summary: This task aims to create educational resources and a webpage explaining Optimism Fractal's consensus process. The resources will be curated from existing materials and contributions from the community. The webpage will serve as a guide for anyone interested in learning about Optimism Fractal and the Respect Game. Feedback and collaboration are welcome.
Sub-task: Curate Resources about Fractal Consensus Processes (Curate%20Resources%20about%20Fractal%20Consensus%20Processes%200a5de9b0ab6c43618640eaba4b22ef9b.md)
Created time: April 6, 2024 5:36 PM
Last edited time: June 10, 2024 12:02 PM
Created by: Dan Singjoy

## Description

This task aims to facilitate the creation of webpages and educational resources about Optimism Fractal’s consensus processes. It includes resources that you can review to learn about this that we may want to curate in the resources and webpages. Anyone can share their thoughts or contribute towards creating educational resources about our consensus processes here.

- More details
    
    
    This is part of a series of tasks in the project [Improve [OptimismFractal.com](http://OptimismFractal.com) Website (and Create Educational Resources)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md). This project aims to coordinate a collaborative community-driven creation of the website and various tasks are included for pages on the website. The first step of creating these webpages is to create educational resources in the notion page. This involves reviewing and curating the most helpful parts of related resources that have been created over the past few years, as well as creating original material. 
    
    These pages can serve as an educational guide to anyone interested in learning about Optimism Fractal and the Respect Game. We’d greatly appreciate help from anyone who is interested in learning and/or creating these educational resources. Enjoy!
    

## Related Resources to Review and Curate

- I recently created a page at [OptimismFractal.com/council](http://optimismfractal.com/council) where everyone can learn how the council works. It’s a work in progress, I’d appreciate feedback and welcome collaboration.

- We can edit this page at [Council](../../OptimismFractal%20com%20c238e1244229466ba8b7753b74104b6f/Optimism%20Fractal%20Website%20Database%20f636c69e7a3a4435a2163516c9e87249/Council%200840241379934557a26d89958c4cf445.md). If you’d like permission to . I’m considering the best way to allocate permissions for pages on the website like this and would appreciate your input.

- [Education Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Education%20Hub%20225efc918f9f4644a39448be1eb3c7f0.md)

## Related Projects

- [Develop Optimism Fractal’s Consensus Processes](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md)

- [Create branding and educational resources for decision-making consensus games](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20branding%20and%20educational%20resources%20for%20deci%20188c45e0a1dc4773bd8202133ced6eb7.md)

## To Do

- [ ]  consider also making pages for /governance , /consensus, etc

- [ ]  Consider to include [Create educational resources about the history of Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20about%20the%20history%20of%20%20fdcb0d490a9a41ce95992d8947236df6.md) and other more general educational resources that may be helpful for builders