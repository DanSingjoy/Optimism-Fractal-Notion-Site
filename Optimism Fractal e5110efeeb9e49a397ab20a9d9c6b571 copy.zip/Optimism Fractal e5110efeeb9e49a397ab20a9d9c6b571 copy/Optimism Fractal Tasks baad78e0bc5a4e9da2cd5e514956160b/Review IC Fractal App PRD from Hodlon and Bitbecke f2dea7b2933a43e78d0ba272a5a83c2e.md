# Review IC Fractal App PRD from Hodlon and Bitbeckers

Due: May 3, 2024
Project: Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: Not started
Task Summary: This task aims to review the IC Fractal App Product Requirement Document (PRD) provided by Hodlon and Bitbeckers. The PRD outlines the purpose, scope, features, and assumptions of the IC-Fractal application, which is designed to serve as a decentralized platform for the Optimism Fractal community. It includes features such as the Respect Game, proposal submission and voting, and sub-rounds, all aimed at fostering community engagement and collaboration.
Summary: This document is a review of the IC Fractal App PRD. The purpose of the IC-Fractal application is to provide a decentralized platform for the Optimism Fractal community to run the Respect Game, distribute Respect Tokens, propose and vote on community topics, and integrate with Shutter. The application will also allow for the running of "sub-rounds" to distribute per-initiative tokens. Features include the Respect Game, proposals, sub-rounds, game rules, and various user stories and requirements.
Created time: May 9, 2024 6:11 AM
Last edited time: May 9, 2024 6:14 AM
Created by: Dan Singjoy

![[https://discord.com/channels/1164572177115398184/1164572177878765591/1227653926371725402](https://discord.com/channels/1164572177115398184/1164572177878765591/1227653926371725402)](Review%20IC%20Fractal%20App%20PRD%20from%20Hodlon%20and%20Bitbecke%20f2dea7b2933a43e78d0ba272a5a83c2e/Untitled.png)

[https://discord.com/channels/1164572177115398184/1164572177878765591/1227653926371725402](https://discord.com/channels/1164572177115398184/1164572177878765591/1227653926371725402)

[https://hackmd.io/@Hodlon/HknNpzgeC](https://hackmd.io/@Hodlon/HknNpzgeC)

[IC-Fractal PRD - HackMD](https://hackmd.io/@Hodlon/HknNpzgeC)

- 
    
    
    IC-Fractal PRD
    
    [Try   HackMD](https://hackmd.io/?utm_source=view-page&utm_medium=logo-nav)
    
    # 
    
    # ICFractal Product Requirement Document
    
    ### 
    
    ### Purpose
    
    The
     IC-Fractal application is meant to provide a sufficiently decentralized
     platform on which the Optimism Fractal community can run the Respect 
    Game, distribute Respect Tokens, and propose and vote on community 
    topics all in one place.
    
    All
     actions and resulting outcomes are transparent and timestamped for all 
    community members to see. This product aims to combine [Fractalgram](https://github.com/Optimystics/fractalgram), the [OP Fractal frontend](https://github.com/Optimystics/op-fractal-frontend) and [Multichain Voting](https://github.com/bjoernek/multi_chain_voting) (an alternative to Snapshot that uses [ICP](https://internetcomputer.org/basics)) into one application, with the additional integration of [Shutter](https://shutter.network/).
    
    The
     application will also allow for the running of "sub-rounds" to 
    distribute per-initiative tokens to track contributions to unique 
    initiatives, for the use of internally distributing grant funds or other
     communities reputation tokens.
    
    ### 
    
    ### Scope
    
    - The application allows members to run the weekly Respect Game and distribute Respect Tokens to the winners.
    - The application allows for sub-rounds of the Respect Game to be run.
    - The application allows members to opt into the council, submit proposals, and vote on those proposals.
    - The application allows for the execution of code upon the conclusion of votes, when applicable.
    - The application will contain a basic stated outline of the games rules.
    
    ### 
    
    ### Assumptions and Dependencies
    
    - Assumption that it's simple enough to build something that distrubtes OPF tokens
    automagically and not manually like it's currently done.
    - Fractalgram is currently built for use with Telegram only, and because of that there might not be much to fork besides the logic.
    - Assumption that Shutter will be simple to implement into the multi chain voting
    app we're forking. Shutter on its face seems like the best solution, but there might also be alternative tools for ensuring provably shielded
    voting into the multi chain voting app.
    - The "Sub-rounds" feature is not currently something being done right now by the community in any other way, and could turn out to be a non-valuable feature. Some more research should be done to see if this is something
    Optimism Fractal would use if built.
    - It has been mentioned in the past that Tadas has been working on a
    solution similar to the one proposed here but it is unknown what state
    it is in or how far along it is. In this way, moving forward with an
    application like this could lead to redundant work being done to solve
    the same problem.
    - "Admin" in this document is currently the Optimystics team but is intended to
    be transferrable any entity, such as a DAO or OPF token holders as a
    whole.
    - "Lead" is one person designated in a breakout group that is responsible for keeping time, ensuring votes are cast, etc.
    - Assumption that Zoom will still be used for the audio/visual component of weekly
    meetings instead of this application. Breakout rooms aren't natively
    supported on Discord but are possible with the use of bots or 3rd party
    apps.
    - Backend runs on Internet Computer
    
    ### 
    
    ### Features
    
    ### 
    
    ### Respect Game
    
    - Sign-in with OP account.
    - Facilitator initiate a Respect Game round.
    - Users check-in to that week's Respect Game round with Facilitator approval.
    - Break into even, provably random groups of not more than six people each (for ex, if there are 6 people, one group of 6, if there are 10 people, two groups of 5, etc)
    - Consensus ranking run directly within the UI (what Fractalgram currently does)
    - Group validates their round and each member validates the results onchain.
    - Admin can set amount of time for group to submit onchain validation (currently 2 hrs).
    - Admin can set the number of rounds that can be run per week (currently 1 week).
    - Results of each round are submitted onchain.
    - OPF tokens are distributed to the top ranked contributors as per the Respect Game rules.
    
    ### 
    
    ### Proposals
    
    - OPF holders make proposals.
    - OPF holders view proposals.
    - Two categories of proposals, "soft" and "executable". Executable proposals execute code.
    - OPF holders (non-council members) can vote on propsals, and the vote is weighted by the amount of their OPF tokens.
    - Council members can vote on proposals, and the vote is weighted by the amount of their OPF tokens.
    - Votes are shielded, and results only revealed after the voting ends.
    - Admin can set the quorum for all proposals.
    - Admin can set length of time of voting window for all proposals.
    - The outcome of voting is displayed in two ways, as non-council members and council members.
    - The outcome of voting is displayed in two ways, in linear and quadratic totals.
    - The votes are determined using Council members votes only.
    
    ### 
    
    ### Sub-Rounds
    
    - Can choose unique token ticker.
    - Creator of the Sub-round is designated the Facilitator.
    - Sub-rounds persist in the UI alongside main game.
    - Facilitator can close the sub-round after the project has concluded.
    - Sub-round specific proposals are grouped for the sub-round.
    
    ### 
    
    ### Game Rules
    
    - A page stating the current basic rules of the game.
    - Rules can be updated via the proposal process.
    
    ### 
    
    ### Misc
    
    - All OPF holders can register for weekly council with one click.
    - Current council members are clearly displayed somewhere in the UI.
    - Admin can choose the number of council members (currently six).
    - Each OPF holder can signal their desire to act in the Lead role by checking a box. Leads are chosen at random for that week based on how many members join the game that week. OPF holder can uncheck the box at any time
    before the round starts to opt out of being chosen as a Lead.
    
    ### 
    
    ### User Stories and Requirements
    
    - As a non-technical user wishing to seek social consensus with the group I
    want to be able to choose to submit a proposal categorized as "soft".
    - As a technical user wishing to execute code I've written I want to be able to choose to submit a proposal categorized as "executable".
    - As a non-council member I want to be able to propose and vote on topics in order to signal my opinion, and to see how aligned the council and
    non-council members are on individual proposals.
    
    ### 
    
    **Success Metrics**
    
    Last changed by
                     
                
    
                
                    
                        
    
    ---
    
    [Hodlon](https://hackmd.io/@Hodlon)
    
    ·
    
    move fast stay comfy
    
    24
                        
                    
                    
                        
                            
                        [](https://hackmd.io/@Hodlon/HknNpzgeC#)37
                        
    
                        
                            
                        [](https://hackmd.io/@Hodlon/HknNpzgeC#)
    
    ---
    
    ### Read more
    
    [**idunno DAO**
    Hardened, reasonably private and decentralised onchain organisation.May 2, 2024](https://hackmd.io/@Hodlon/r1mlfeuxA?utm_source=preview-mode&utm_medium=rec)
                
                    [**Optimism Fractal S1 Retro**
    Optimism FractalJan 15, 2024](https://hackmd.io/@Hodlon/H1lNc_DOa?utm_source=preview-mode&utm_medium=rec)
    
    ---
    
    Published on  [**HackMD**](https://hackmd.io/)
    

## Feedback

Also see [Introduce the Fractal App chat on the OF Discord](Introduce%20the%20Fractal%20App%20chat%20on%20the%20OF%20Discord%20fa5e2a3793fd45f2bbfab68567a1c625.md) 

###