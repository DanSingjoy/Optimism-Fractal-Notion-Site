# Respond to Nuno about Corrupted Pigs?

Assignee: Dan Singjoy
Due: May 29, 2024
Project: Interact on Optimism Fractal Discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Interact%20on%20Optimism%20Fractal%20Discord%206db8fc968f104b6cadc39a71b8f1b843.md)
Status: Archived
Task Summary: This task aims to respond to Nuno regarding the topic of Corrupted Pigs. It provides a summary/introduction for the page, including information about the creator, assignee, due date, status, and relevant links.
Summary: This document is a response to Nuno regarding Corrupted Pigs. It provides links to the Twitter account and website of Corrupted Pigs, but there is no additional content or information.
Created time: May 14, 2024 9:56 PM
Last edited time: June 1, 2024 10:32 PM
Created by: Dan Singjoy

See links:

 [https://twitter.com/CorruptedPigs](https://twitter.com/CorruptedPigs)

[https://corruptedpigs.com](https://corruptedpigs.com/)

![Untitled](Respond%20to%20Nuno%20about%20Corrupted%20Pigs%204da1c3abf1e64dc59e90d3e0d37ecd79/Untitled.png)