# Consider and/or Ask ChatGPT how to create a better workflow using ChatGPT to make titles and descriptions with episode transcripts

Project: Refine Process for Creating Optimism Fractal Show Notes and Complementary Materials for Videos (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Refine%20Process%20for%20Creating%20Optimism%20Fractal%20Show%20%20c45abeadcb3d4a0fa61cfc0ca4017471.md), Improve Optimism Fractal video production processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20video%20production%20processe%201ddaaa3c112a4449ab121ec9df944d9e.md)
Status: Not started
Task Summary: This task aims to explore ways to create a more efficient workflow using ChatGPT for generating titles and descriptions with episode transcripts. The goal is to automate and streamline the process, potentially leveraging custom GPT models or the Chat GPT API. The page, created by Dan Singjoy, discusses the need for improvement and suggests exploring options like MacWhisper for a more tailored solution.
Summary: This document discusses the idea of creating a better workflow using ChatGPT to generate titles and descriptions with episode transcripts. The author suggests refining the workflow and explores the possibility of using a custom GPT or the Chat GPT API to automate the process. They also mention trying to set it up in Notion AI and inquire about the version used. The suggestion of using MacWhisper, which has a customizable prompt section, is also mentioned.
Created time: June 3, 2024 12:08 PM
Last edited time: June 17, 2024 4:21 PM
Created by: Dan Singjoy

- update- i think rosmari got a lot better at this while making descriptions for EF 90-102
    - [ ]  ask her if it would be helpful to refine this workflow at this time or if it’s good enough for now

Rosmari types the prompts manually sometimes and perhaps this could be more efficient.

Could we set up a custom GPT that provides all the answers to this at once without her needing to manually type or remember the prompts?

Or use the Chat GPT API for this?

- Maybe we can set up a GPT for this like [https://chatgpt.com/g/g-bn5YVfflG-hats-protocol-advisor](https://chatgpt.com/g/g-bn5YVfflG-hats-protocol-advisor)

We tried setting this up in notion ai in database but it didn’t work as well with GPT 3.5, but now it might work better

Does notion ai use 3.5 or 4o?

Perhaps we should do it all in MacWhisper- it has prebuilt prompt section that you can customize