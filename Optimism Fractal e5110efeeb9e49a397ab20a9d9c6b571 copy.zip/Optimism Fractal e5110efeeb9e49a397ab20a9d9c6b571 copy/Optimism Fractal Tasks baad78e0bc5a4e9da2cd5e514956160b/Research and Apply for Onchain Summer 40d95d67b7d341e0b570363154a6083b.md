# Research and Apply for Onchain Summer

Due: June 17, 2024
Project: Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: In progress
Task Summary: This task aims to research and apply for the Onchain Summer Buildathon. Created by Dan Singjoy, the page provides information about the buildathon, including key dates and sponsored tracks. It encourages builders to create innovative onchain solutions in various fields and offers a chance to compete for a share of 200 ETH in prizes.
Summary: The document provides information about the Onchain Summer Buildathon, including key dates and sponsors. It also mentions resources and links for further support. The key takeaway is that the speaker needs to prioritize making applications for the On-chain Summer, including base play, optimistic tools, Privy, and Wallet Connect, as the applications are due tomorrow.
Created time: June 1, 2024 8:04 PM
Last edited time: June 30, 2024 12:22 PM
Created by: Dan Singjoy

## Introduction

The page curates resources about the Base Onchain Summer Buildathon, which occurs throughout June and allows you to compete for a share of 200 ETH in prizes across eight sponsored tracks. Backed by major sponsors like Stripe, Shopify, and Farcaster, this global online hackathon encourages builders to create innovative onchain solutions in payments, commerce, gaming, social, and more. Key dates include the kickoff on May 31st, application deadline on June 17th, and submission deadline on June 30th. 

You can learn more in the resources below and in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md).

**Table of Contents**

## Further Support

If you need further support, we recommend checking the Onchain Summer Buildathon [schedule](https://onchain-summer.devfolio.co/schedule).  If there are any immediate questions, check Base’s [Discord](https://discord.gg/buildonbase) in either ‘Onchain Summer’ channel and/or in your specific buildathon track channel.

## Key Links

### Base

[Base.org](http://Base.org) 

[Base](http://base.org/)

### Onchain Summer

[Join the Onchain Summer Buildathon](https://base.mirror.xyz/iYQH5yxgH976gUmrYfoeyVpe5SJtiR8r2t10Psr1_-U)

[Onchain Summer II is Coming](https://base.mirror.xyz/HoH9cZVi8CMdvxVUNjvOzceUPVQcVZvvkf8ZbCOVOco)

[Onchain Summer Buildathon | Devfolio](https://onchain-summer.devfolio.co/)

### BaseCamp

[Introducing BaseCamp 001: onchain–offgrid](https://base.mirror.xyz/GL6dd2CfZuG3dVd_jZAZJLjYP8h7NRk0falVV6O7RqQ)

## Tools

[Research Coinbase Developer Platform](Research%20Coinbase%20Developer%20Platform%2060c4fa44c72f48a5a60a2d3cb11ba1f0.md) 

## Videos

[https://www.youtube.com/watch?v=Cb3BR-Q1vJM&t=13s](https://www.youtube.com/watch?v=Cb3BR-Q1vJM&t=13s)

[https://twitter.com/base/status/1796587985263264245](https://twitter.com/base/status/1796587985263264245)

### Workshops

[https://www.youtube.com/watch?v=AtuVAzseWB0](https://www.youtube.com/watch?v=AtuVAzseWB0)

### Discussion about Base at Optimism Fractal

[https://www.youtube.com/watch?v=08pMPx6MLnc&t=4412s](https://www.youtube.com/watch?v=08pMPx6MLnc&t=4412s)

## Tweets

[https://twitter.com/jessepollak/status/1791141221043150938](https://twitter.com/jessepollak/status/1791141221043150938)

[https://twitter.com/ljxie/status/1796657139760423303](https://twitter.com/ljxie/status/1796657139760423303)

[https://twitter.com/jessepollak/status/1796669836090871820](https://twitter.com/jessepollak/status/1796669836090871820)

[https://twitter.com/jessepollak/status/1796699034700374059](https://twitter.com/jessepollak/status/1796699034700374059)

- More
    
    
    [https://twitter.com/eas_eth/status/1796632476988936640](https://twitter.com/eas_eth/status/1796632476988936640)
    
    [https://twitter.com/jessepollak/status/1796648389284925759](https://twitter.com/jessepollak/status/1796648389284925759)
    

[https://x.com/0xaneri/status/1791206489870434490?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/0xaneri/status/1791206489870434490?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/0xaneri/status/1791206489870434490?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/0xaneri/status/1791206489870434490?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

## Related Project

[Build with Base](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md) 

## **On-Chain Summer**

The speaker needs to prioritize making the on-chain summer applications, which are due tomorrow. They want to make applications for base play, optimistics tools, Privy (with Vlad), and Wallet Connect (with Abraham). Videos like Optin facto and base play could be included in the applications. On-chain summer is also a good discussion topic for this week's event.

**Key Points**:

- On-chain summer applications are a priority and due tomorrow.
- Potential applications include base play, optimistics tools, Privy, Wallet Connect, and videos.
- On-chain summer is a good discussion topic for this week's event.

Audio at [Review Notes about Optimism Missions And Organize Plans in this task](https://www.notion.so/Review-Notes-about-Optimism-Missions-And-Organize-Plans-in-this-task-aebd4a1f3ed14515bb857c0c64a45d8e?pvs=21)