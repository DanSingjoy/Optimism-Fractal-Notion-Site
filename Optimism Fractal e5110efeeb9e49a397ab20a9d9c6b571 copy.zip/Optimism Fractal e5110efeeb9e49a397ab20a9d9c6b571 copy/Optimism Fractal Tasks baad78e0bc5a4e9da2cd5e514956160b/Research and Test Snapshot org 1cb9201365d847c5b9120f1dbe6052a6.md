# Research and Test Snapshot.org

Project: Develop Optimism Fractal’s Consensus Processes (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Fractal%E2%80%99s%20Consensus%20Processes%2067a68c4867db4394bf3b0a3b3c918c1f.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Done
Task Summary: This task aims to provide a snapshot of the research and testing conducted for http://snapshot.org/. It includes information about its creation, status, and a description of its contents. The page also includes a to-do list that has been organized and completed.
Summary: Research and Test http://snapshot.org/ by Dan Singjoy is a document that has been organized into tasks, as indicated by the completed to-do list item of organizing the notes.
Sub-task: Consider Snapshot as a Front-End or Bundle of Code for Firmament (Consider%20Snapshot%20as%20a%20Front-End%20or%20Bundle%20of%20Code%20779857e7c67b438c8617df237cd8adb3.md)
Created time: January 21, 2024 11:02 PM
Last edited time: June 3, 2024 9:13 AM
Created by: Dan Singjoy

## Description

**Table of Contents**

## To Do

- [x]  Organize these notes
- organized into tasks in [Explore deeper integrations between Optimism Fractal and Discord](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Optimism%20Fract%20337d632e686e44e68cd899e6e12e05f3.md)