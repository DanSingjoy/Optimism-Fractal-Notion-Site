# Develop Impact Jury App with custom prompts

Project: Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md), Submit Respect and Respect Votes as Impact Metrics for Open Source Observer(OSO) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Submit%20Respect%20and%20Respect%20Votes%20as%20Impact%20Metrics%2012ebf87ca05b40379c0f6a4266ffb847.md), Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Research and Strategize to provide Optimism Collective with the most value possible (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20and%20Strategize%20to%20provide%20Optimism%20Collec%20ad36d53370ce43a18be5b0ff973a2052.md)
Status: Not started
Task Summary: This task aims to develop an Impact Jury App that allows game creators to ask questions and share a link for people to play the game. The app will enable users to publicly see the answers and results through a unique URL. It also explores the integration of EAS schema for Respect Games and discusses the implementation of features like textbox options and embedding answers in the app.
Summary: This document outlines the development of an Impact Jury App that incorporates custom prompts for Respect Games. The app aims to provide a platform for game creators to ask questions, share game links, and allow users to publicly view answers and results. Technical implementation details include integrating with EAS for Respect Game results, considering branding options, and discussing the inclusion of an optional text field. The document also mentions fixing web app errors, enabling privy sign-in and account abstraction, and adding a tutorial. Overall, the app aims to open new use cases and enhance the experience of playing targeted Respect Games.
Created time: May 9, 2024 6:20 AM
Last edited time: May 16, 2024 12:49 PM
Created by: Dan Singjoy

## Intro

This task aims to develop an Impact Jury App and incorporating a feature where game creators can ask questions and share a link for people to play the game. The app will also allow users to publicly see the answers and results through a unique URL.

# Rationale

- In addition to leading discussions with these kinds of Impact Juries at Optimism Fractal events, we can also provide tooling to make it easy for anyone in the collective to also run their own impact juries and async respect games with our The Respect Game app.
    - Additionally it may be helpful to coordinate impact juries and respect games on a weekly cadence alongside Optimism Fractal events, so people can participate in async Respect Games with the same topic as Optimism Fractal even if they don’t participate in the event
    - See [Plan Optimism Fractal Season 3](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md) for more details about this plan

- More details
    
    
    ### More Details
    
    [Upcoming Retro rounds and their design](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861)
    
    ![Untitled](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c/Untitled.png)
    
    [https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861)
    
    ![Untitled](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c/Untitled%201.png)
    
    ![Untitled](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c/Untitled%202.png)
    
    [https://gov.optimism.io/t/collective-intents-season-5/6883](https://gov.optimism.io/t/collective-intents-season-5/6883)
    
    ![Untitled](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c/Untitled%203.png)
    
    ![Untitled](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c/Untitled%204.png)
    
    [https://twitter.com/carl_cervone/status/1772862669168468132](https://twitter.com/carl_cervone/status/1772862669168468132)
    
    - [ ]  curate discussions about impact jurors
    - [ ]  curate related discussions from community members who are asking for this kind of value add
    
    [See carls emphasis and bolder point here - Upcoming Retro rounds and their design](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c/See%20carls%20emphasis%20and%20bolder%20point%20here%20-%20Upcomin%208f981dee44074400ad7ecd518c68b610.md)
    
    [Review lefteris response and make notes - he asked several good questions and shared critical feedback that’s widely agreed upon for improvement. We should provide solutions to the problems he identifies and hold discussions about some of the questions . Upcoming Retro rounds and their design](Curate%20Rationale%20and%20Benefits%20of%20Plan%20for%20Implemen%20f0d4118ea1b74c018c35bcc3b58d2a4c/Review%20lefteris%20response%20and%20make%20notes%20-%20he%20asked%20a6e542f8c78345ab96b5a75c4f6d7fe1.md)
    

## Value Proposition with Emitting Events Implementation

- How much value would this app provide with the current contract structure of emitting events?
    - [x]  Ask Tadas - Is it possible to see the rank order from the event that is emitted? If so, how?
        - [x]  review video about this first to see if he answered it
        - Yes I just reviewed the video where Tadas explains this [here](https://youtu.be/dU7Whneo5yI?si=e8iieaFL-zmOC_Ux&t=194) and he explains that you can see the ranks submitted by each account in the Input Data section of the transaction
            - The notes in this toggle were written before realizing this and are probably not relevant now that you can see the ranks in the Input Data field
                
                
                - Currently I think you’d be able to see if there is consensus from the event emission, but the event emission does not show the rank order
                - This is unlike EOS where you can easily see the order of rankings and appears to be a significant downside of our current contract design
                    - It makes it difficult/impossible to do things like check the rankings of past events or determine the ranks that each person made
                    - It also makes it difficult to implement the shared consensus algorithm that James Mart introduced because it doesn’t show. How was Vlad planning to do this?
                        - Maybe i’m missing something here. I think the main issue that Vlad identified with this was that there would need to be back-and-forth communication between the chain and server, so maybe he knows the solution to see the ranks from the event emission
                        - If not, does it make sense for us to redesign this to make it easier to see rankings from event emissions? Perhaps by emitting more events or something?
                - If it’s not possible to view the rankings, the app can still value provide value and be good enough to test here and help us earn retro funding. The onchain data would only show the amount of consensus and perhaps could be manually linked to information shown the web app, but it wouldn’t show the rankings. This is not ideal and doesn’t show that much useful data, but it still shows some useful data and seems sufficient for earning retrofunding with legitimate transactions then can always be improved later
                
        - However, it is still not easy to see the ranks for each transaction. How could we display the ranks in a way that makes them easier to see?
            - It would make the app more useful for the Optimism Collective and others in the future, especially for this kind of Respect Game where the question is not just “How did you contribute to x”, but rather “what is your answer to x?”
                - Making this easier to parse and read would enable people to more easily see connections between the people’s ranks and their responses, which would be valuable for different kind of Respect Games
                - How could we implement this?

# Define Technical Implementation of Impact Jury App

### EAS Integration for Respect Game Results of Game Prompt

- What if we integrate with EAS and we create a schema for the Respect Game?
    - If we integrate with an EAS schema for the Respect Game where each address is included along with their level, then would this make it easier to see the rankings of each game?
    - Schema Design:
        - The schema could include the addresses for level 1-6
        - It could also potentially include the question/prompt, community, and answer from each participant
    - More details:
        - [Explore and Create Integrations with Ethereum Attestation Service (EAS)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
        - [Follow up with Nestor about EAS](Follow%20up%20with%20Nestor%20about%20EAS%20c1659c98cbf6450185be4eb7e3f1aa69.md)
        - [Attest.sh](http://Attest.sh)

### Branding

Should the app be named impact juries or more generally? It is basically an app that facilite respect games answering a specific question in the app. Similar to fractalgram but easier to use, all in one app, and with instructions on the app and a place to answer and that you can share links with a premade question 

It could be at respect game xyz or new kind of url

We could get impact jury xyz specifically and brand it like this because this is what the optimism foundation wants and would likely be a positive ROI for us to promote it as such. 

If the url is respect game then the game/process introduced to the Optimism Collective could be Impact Jury

### Is it always good to have an option text field in Respect Games?

- One potential issue is that many respect games don’t require a box to answer any questions, but I think it’s almost always helpful to have one as an option but we just never have before.
    - For example, we could use that box to send to the optimism fractal weekly contributions database so people can easily share their work in one place without requiring someone to add it manually.
        - That would be great and always useful to have either for an answer to a question like what is the mission (as we did database in Eden fractal) or what did you do to help (in which case they could submit links to promote their work or text overview).
    - This could also improve upon the async version of Optimystics fractal respect game we’re playing. Rather than sharing our work in notion than linking in telegram, there could be one place in the app where you can submit what you did and then it goes to notion

- I think that it’s usually good to have this kind of textbox and never a really bad thing to have it. In some cases it’s super helpful and needed to unlock new gameplay styles. In some cases it’s helpful to enhance gameplay. In some cases it could be confusing, but I think that the confusion can be basically eliminated by communicating it well (ie do you want to add anything here (optional)). Eventually there could be a checkbox that game creators could click to show this field or not, but for now adding the field would be a big plus

For example during Optimism Fractal this field could say ‘do you want to share any links or contributions here? (optional). this will be added to [Weekly Contributions](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Weekly%20Contributions%201c90e50f1e23408080b41c562d0dcd0b.md) “

### Product Requirements

- Fix the web app errors
    - [ ]  see [Fixing Web App Errors](https://www.notion.so/Fixing-Web-App-Errors-057183e60cf247dbbebc5cb27dc19988?pvs=21)
    
- Enable privy sign in and account abstraction to pay for

- include a tutorial in the web app that walks people through it

- add a section where a game creator/host can ask a question, then share a link for people to play the game answering that question

- allows people to publicly see the answers and results in a unique URL
    - Perhaps when they click submit it also submits form to Notion to include the responses in the table. [Tally.so](http://Tally.so) is open source and could be embedded?
    - Yes it can be embedded well. Is it open source?
        - It does not look like it is open source, but embedding it in the app might work
    - Another option may be deform and charmverse, though that might be more than needed for now
        - The charmverse integration could be much appreciated by the Optimism Collective since it’s much more resilient, decentralized, and home-grown than notion
        - Deform does not appear to be open source and doesn’t look like it can be embedded, so it doesn’t look like a feasible solution to integrate into the app right now
        - They did just raise 5 million dollars so maybe they will introduce this functionality soon
    - We could also host the answers in the web app on AWS or our own server
    - We could also research to see if there are other open-source alternatives to tally that could be built into the app and add the answers to a notion or charmverse table

- If the final two features could work with EAS then that would be great and might make it simpler

## Rationale

- The Optimism Foundation announced that they intend to experiment with [Impact Juries](https://gov.optimism.io/t/upcoming-retro-rounds-and-their-design/7861#experiment-1-impact-juries-9) in the next two rounds of Retro Funding. The idea of Impact Juries is to sort badgeholders into small groups dedicated to evaluating a specific set of applications and employing sortition to scale citizenship
    - They say that this kind of qualitative process can be helpful for ‘upstream’ fund allocation decisions like governance and OP-stack, but it can also be helpful for ‘down stream’ fund allocation decisions like Onchain Builders and Dev Tooling. Subjective measurement assessment can always be helpful and we can show this by demonstrating it during the onchain builders round.

- We can provide what the Optimism Foundation and many people in the collective are seeking regarding impact juries, focused discussions about impact measurement, spaces to foster discussion and collaboration about impact evaluation, educational content to help improve governance

- In doing so we can position Optimism Fractal as a leading community for the governance of the Optimism Collective. We have great experience with the foundational concept of Impact Juries and are well positioned to lead in this way

- We can position ourselves to earn a lot from RetroFunding round 4 and provide opportunities for everyone in the Optimism Fractal community to create an impact in the collective by sharing their opinions about Optimism governance in Optimism Fractal events/discussions

- See [Message with tadas about the proposal for Optimism Fractal seasons ](Message%20with%20tadas%20about%20the%20proposal%20for%20Optimism%2089a0e71eb0964de8bab3ad6ec3a39e83.md)and the other tasks in [Create seasonal structure for Optimism Fractal](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md)  for more details about the rationale behind this seasonal structure for Optimism Fractal

### Benefits

This can provide the following benefits:

- Some of the benefits were related to Optimism RPGF 4, which has now passed

- Open new use case that makes it easier to play different kinds of targeted respect games