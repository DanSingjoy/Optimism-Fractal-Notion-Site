# Research berry labs mobile app and notifications for snapshot

Project: Improve notification and provenance system for optimism fractal notion site via discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20notification%20and%20provenance%20system%20for%20opt%202bd6ce3108b64785a23f1bba8557407f.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md), Create ways for community members to vote with Respect (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20ways%20for%20community%20members%20to%20vote%20with%20Res%20e2651299e2fa42a89fbc0601f17594c1.md)
Status: Not started
URL: https://x.com/snapshotlabs/status/1769857715143385127?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to research Berry Labs' mobile app and notifications for Snapshot. The page provides an overview of the status, URL, and creation/editing timestamps related to the research. It also includes checkboxes for incomplete tasks and two links for further research on Goverland and mobile Snapshot usage.
Summary: No content
Created time: May 7, 2024 3:50 AM
Last edited time: May 7, 2024 3:50 AM
Created by: Dan Singjoy

[https://x.com/snapshotlabs/status/1769857715143385127?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/snapshotlabs/status/1769857715143385127?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[Research goverland for mobile snapshot usage ](Research%20berry%20labs%20mobile%20app%20and%20notifications%20f%20fb029fb67fdc479199198f6110304003/Research%20goverland%20for%20mobile%20snapshot%20usage%204ea29ac53a2049229aafe9fdd4febdbf.md)