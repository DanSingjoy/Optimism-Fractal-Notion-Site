# Review and Create Project Template Design

Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Not started
Task Summary: This task aims to review and create a project template design for efficient event preparation. It includes tasks such as reviewing a checklist before each event, preparing an intro presentation with relevant links, and organizing breakout room materials. The goal is to create templates that can be easily customized for each new event, ensuring a smooth and consistent process.
Summary: Create a project template design that includes tasks for reviewing a checklist before each event, preparing an intro presentation with links for each topic, preparing for breakout rooms with contribution presentations, lead/host guidelines, and notes for other's presentations. Each task should be a template with prefilled information for each new event. Provide a brief explanation of game rules at the beginning of each event, with detailed rules available through a shared Welcome Guide.
Created time: June 5, 2024 9:01 PM
Last edited time: June 5, 2024 9:03 PM
Created by: Dan Singjoy

- The below are early notes and may be outdated
    - [ ]  add check marks to each to signify if i already added them

The template should include tasks for the following:

- Review checklist before each event

- Prepare intro presentation
    - This should include links for each topic i present
        - These links can also be shared in a Welcome Guide

- Prepare for breakout room
    - Contribution presentation
    - Lead/host guidelines
    - Notes for other’s presentations
    

Each of these tasks should also be templates, so much of it should be prefilled for each new event.

 I'll provide a brief explanation of the game rules at the beginning of each event, but detailed rules will be available through a [Welcome Guide](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md) shared in the chat. This ensures that all participants can refresh their memory on the game rules as needed.