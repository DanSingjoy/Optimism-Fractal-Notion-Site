# Consider how to best present Cagendas and OPTOPICS in the screenshare during event

Assignee: Dan Singjoy
Status: Not started
Task Summary: This task aims to explore different ways to effectively present Cagendas and OPTOPICS during a screenshare event. The page discusses various methods, including using pinned tabs, picture-in-picture mode, browser extensions, and operating system features. It also addresses the possibility of having a persistent tab/window visible over a Zoom screenshare, allowing both the shared screen and the floating tab/window to be visible simultaneously.
Summary: To present Cagendas and OPTOPICS effectively during a screenshare event, it is suggested to have the order of topics visible at all times. While sharing the monitor to the side is an option, it is not ideal. Split screen in Arc can work for some tabs but not for persistent topics. Currently, it is not a high priority as only a few topics are discussed per event. However, trying Hover over chrome extensions and reviewing the end of the ChatGPT conversation may be worth exploring. Additionally, there are methods like pinning tabs, using Picture-in-Picture mode, browser extensions, and split view in Arc browser to keep specific tabs or windows persistently visible. These methods can be useful for both videos and regular web pages. To have a persistent tab or window visible over a Zoom screenshare, specific tools and settings can be used, such as floating browser windows, JavaScript bookmarklets, operating system features like DeskPins or Always on Top utilities for Windows, and apps like Helium or Afloat for Mac. Zoom's advanced screen sharing options, including sharing a portion of the screen, can also be combined with floating window tools for a seamless experience.
Created time: May 27, 2024 9:29 PM
Last edited time: May 27, 2024 9:33 PM
Created by: Dan Singjoy

- It’d be nice for both participants and viewers to be able to see the order of topics at all times or very easily throughout the event

- This can be achieved by sharing monitor to the side, but this isn’t ideal because then I’d be looking away from people and on smaller screen to the side

- Split screen in Arc can work for some tabs, but isn’t practical for a persistent topics as it would require many duplicate tabs

- Overall it’s not a big priority now. We only discuss a few topics per event right now so this isn’t needed at the time and isn’t work further research at the moment

- It might be worth trying the Hover over chrome extensions and see if these are shared in
    - [ ]  Review the end of chatgpt conversation about this below

- [ ]  Find related note about this and merge

Is there any way to make a tab/window persistently show up over different tabs in the corner in an arc browser window?

ChatGPT

Yes, there is a way to make a tab or window persistently show up over different tabs in the Arc browser. Arc browser includes a feature called "Pinboards" which allows you to pin tabs to a specific side of your screen. Here's how you can do it:

1. **Pin a Tab**: You can pin a tab by right-clicking on the tab and selecting "Pin Tab." This will move the tab to the sidebar and keep it open persistently.
2. **Use Picture-in-Picture (PiP)**: For videos, you can use the Picture-in-Picture mode, which pops out the video into a small, always-on-top window. Right-click twice on a video and select "Picture-in-Picture" from the context menu.
3. **Use Extensions**: There are browser extensions available that allow you to create a persistent floating window. Extensions like "Always on Top" can be useful for this purpose. Once installed, you can pop out any tab and keep it floating on top of other windows.
4. **Utilize Split View**: Arc browser supports split view, where you can open two tabs side-by-side. This can be useful if you want to keep one tab always visible while working on another.

Here is a step-by-step guide for using the pinning feature in Arc browser:

1. **Pinning a Tab:**
    - Open the tab you want to pin.
    - Right-click on the tab.
    - Select "Pin Tab" from the context menu.
    - The tab will move to the sidebar and remain open persistently.
2. **Using Picture-in-Picture:**
    - Navigate to a video you want to keep open.
    - Right-click on the video twice to open the full context menu.
    - Select "Picture-in-Picture."
    - The video will pop out into a small, always-on-top window.
3. **Using Extensions:**
    - Install an extension like "Always on Top" from the Chrome Web Store.
    - Follow the extension's instructions to create a floating window from a tab.

These methods should help you keep a specific tab or window persistently visible while you browse other tabs in the Arc browser.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Can picture in picture work with a regular page and not a video or audio?

ChatGPT

The standard Picture-in-Picture (PiP) feature in most browsers, including Arc, is typically designed for video content. However, there are a few methods to achieve a similar effect with a regular web page:

### **Using Browser Extensions**

There are browser extensions that allow you to create a floating, always-on-top window for any web page. Here are some extensions that can help:

1. **"Always On Top"**
    - This extension can create a floating window that stays on top of all other windows.
    - You can install it from the Chrome Web Store.
    - After installation, you can use the extension to create a floating window for any tab.
2. **"Picture-in-Picture Extension (by Google)"**
    - While primarily designed for videos, you can use this extension to pop out any element as a floating window.
    - Install it from the Chrome Web Store and experiment with its capabilities to see if it fits your needs.

### **Using JavaScript Bookmarklets**

You can use a JavaScript bookmarklet to create a floating window for any web page. Here's a simple example:

1. Create a new bookmark in your browser.
2. Edit the bookmark and replace the URL with the following JavaScript code:
    
    ```jsx
    javascriptCopy code
    javascript:(function(){
        var newWin = window.open(location.href, "Floating Window", "width=500,height=400");
        newWin.focus();
    })();
    
    ```
    
3. Click this bookmark when you want to create a floating window of the current page.

### **Using Operating System Features**

On some operating systems, you can use built-in features to keep a window always on top. For example:

- **Windows**: Use utilities like "DeskPins" or "Always on Top" to pin a window on top.
- **Mac**: Use apps like "Helium" or "Afloat" to keep a window always on top.

### **Example Steps for Using "Helium" on Mac:**

1. Download and install Helium from the Mac App Store.
2. Open Helium and navigate to the web page you want to keep on top.
3. Adjust the transparency and size of the Helium window as needed.
4. The Helium window will float on top of all other windows.

These methods should help you achieve a floating, always-on-top window for any web page in the Arc browser or any other browser.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Would any of these work with zoom screenshare so you can see a window via screenshare and a tab over the window via screenshare?

ChatGPT

To have a persistent tab or window visible over a Zoom screenshare, allowing both the shared screen and the floating tab/window to be visible simultaneously, you can use specific tools and settings. Here's how you can achieve this:

### **Method 1: Using Picture-in-Picture Extensions or Floating Windows**

1. **Use a Floating Browser Window:**
    - **Browser Extensions:** As previously mentioned, you can use extensions like "Always on Top" to create a floating window for any web page. This floating window will stay on top of other windows, including during a Zoom screenshare.
    - **Steps:**
        1. Install the "Always on Top" extension from the Chrome Web Store.
        2. Use the extension to create a floating window of the tab you want to be persistently visible.
        3. Start your Zoom meeting and share your screen.
        4. Ensure that the floating window is positioned over the shared screen area.
2. **Using JavaScript Bookmarklets:**
    - You can create a bookmarklet to pop out a tab into a separate, movable window as described before.
    - This new window can then be positioned over the shared screen area during the Zoom call.

### **Method 2: Using Operating System Features**

### **For Windows:**

1. **DeskPins or Always on Top Utilities:**
    - **DeskPins:**
        1. Download and install DeskPins.
        2. Use DeskPins to pin the floating window on top.
    - **Always on Top Utility:**
        1. Download and install a utility like "Always on Top."
        2. Use the utility to keep the floating window on top.

### **For Mac:**

1. **Helium or Afloat:**
    - **Helium:**
        1. Download and install Helium from the Mac App Store.
        2. Open the desired webpage in Helium and adjust its transparency and size.
        3. Helium will stay on top of other windows, including during screen sharing in Zoom.
    - **Afloat:**
        1. Download and install Afloat.
        2. Use Afloat to keep the desired window on top.

### **Method 3: Using Zoom's Built-In Tools**

1. **Use Zoom's Advanced Screen Share:**
    - **Share Portion of Screen:**
        1. In Zoom, click on "Share Screen."
        2. Select "Advanced" at the top of the window.
        3. Choose "Portion of Screen."
        4. Resize and move the green frame to fit around the window you want to share.
        5. The floating window created by extensions or utilities can be positioned within the shared portion or overlaid as needed.

### **Combining Methods**

For a seamless experience, you might combine the use of a floating window tool (like Helium or DeskPins) with Zoom’s advanced screen sharing options. Here’s how:

1. **Set up the floating window using Helium (Mac) or DeskPins (Windows).**
2. **Start your Zoom meeting and select the advanced screen sharing option to share a portion of your screen.**
3. **Adjust the floating window and shared screen portion so both are visible and positioned as desired.**

By using these methods, you should be able to have a tab or window persistently visible over a Zoom screenshare, allowing you to keep important information accessible during your presentation or meeting.