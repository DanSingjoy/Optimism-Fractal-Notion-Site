# Curate Highest quality EAS Signals

Project: Explore and Create Integrations with Ethereum Attestation Service (EAS) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)
Status: Not started
Task Summary: This task aims to curate the highest quality EAS (Emergency Alert System) signals. The goal is to identify and select the most reliable and accurate signals to ensure effective communication during emergency situations. The curated signals will help prioritize public safety and minimize potential risks.
Summary: No content
Created time: May 1, 2024 11:06 AM
Last edited time: May 6, 2024 12:29 PM
Created by: Dan Singjoy

[https://x.com/kristoferlund/status/1783106444839035180?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/kristoferlund/status/1783106444839035180?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/kristoferlund/status/1783106444839035180?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/kristoferlund/status/1783106444839035180?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)