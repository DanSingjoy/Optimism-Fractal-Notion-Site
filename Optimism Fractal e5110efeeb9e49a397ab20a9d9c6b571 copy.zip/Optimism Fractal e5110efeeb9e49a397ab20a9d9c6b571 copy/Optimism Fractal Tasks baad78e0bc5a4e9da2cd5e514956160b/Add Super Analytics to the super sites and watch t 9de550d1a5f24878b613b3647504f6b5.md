# Add Super Analytics to the super sites and watch the video

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Create Optimism Fractal Promotional Strategy (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Promotional%20Strategy%2092bfd89b01294e988511fe6e4f03f526.md)
Status: Not started
Task Summary: This task aims to add Super Analytics to the super sites and watch the video. Created by Dan Singjoy, this task provides instructions on how to enable and utilize Super Analytics, a user-friendly analytics tool for website traffic. The page also highlights the benefits of Super Analytics, including a beautiful dashboard and data-driven decision-making capabilities.
Summary: Super Analytics is a user-friendly analytics tool for Super sites, providing a beautiful dashboard to learn about website traffic and make data-driven decisions. It offers unique visitor data, total sessions, bounce rate, referral sources, and more. Pricing starts at $10/month for 10,000 page views. Watch the walk-through video and follow the steps to enable Analytics on Super sites.
Created time: May 19, 2024 9:17 AM
Last edited time: July 23, 2024 12:07 PM
Created by: Dan Singjoy
Description: Super Analytics is a user-friendly analytics tool for Super sites, providing a beautiful dashboard to learn about website traffic and make data-driven decisions. It offers features such as unique visitors, total sessions, bounce rate, and more. To get started, log in to Super, enable Analytics, and confirm payment. Pricing starts at $10/month for 10,000 page views. Watch the walk-through video and read the guide for more information.

[https://super.so/blog/super-analytics-is-here](https://super.so/blog/super-analytics-is-here)

[https://www.youtube.com/watch?v=ACiSkeIE74g](https://www.youtube.com/watch?v=ACiSkeIE74g)

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/5000ccbb-6a03-4836-8ef3-12fc7745b13f/cover/w=3840,quality=90,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/5000ccbb-6a03-4836-8ef3-12fc7745b13f/cover/w=3840,quality=90,fit=scale-down)

### **We're so excited to Introduce Analytics for Super sites, one of our biggest and most requested features to date!**

With Super Analytics you get access to a beautiful new dashboard that helps you learn more about your website traffic–enabling you to optimize content and make data-driven decisions.

Unlike Google Analytics, which can be complex, Super's analytics is user-friendly, making adapting and usage a breeze!

### **Getting started**

1. [Log in to Super](https://app.super.so/signup)

2. Open your site and go into the **new Analytics page in the sidebar**

3. Enable Analytics and confirm the payment

*Please note: It can take a couple of hours or more before Super Analytics will start displaying your data, [learn more here.](https://help.super.so/en/articles/8217262-how-long-does-super-analytics-take-to-gather-data?_gl=1*1373x3k*_ga*MTI4MjEwNTg0MS4xNjgyMzYxODY3*_ga_NENDP1G4R6*MTY5MTQ4NzgxNy4xNDQuMC4xNjkxNDg3ODE3LjYwLjAuMA..)*

### **Analytics pricing**

Super Analytics starts at just **$10/m for 10,000 page views** and you can enable it on as many sites as you want for no extra cost! Pricing tiers are based on the combined page views of all your analytics enabled sites and when you reach a higher tier, your billing will adjust automatically. [Click here](https://s.super.so/analytics-pricing) to learn more about Analytics pricing tiers.

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/c2836db4-acb0-488b-905d-b1857513f6bb/analytics-site/w=2048,quality=90,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/c2836db4-acb0-488b-905d-b1857513f6bb/analytics-site/w=2048,quality=90,fit=scale-down)

### **What's included**

With Super Analytics you get access to an incredible suite of data including: Unique visitors, Total sessions, Total views, Bounce rate, Visit duration, Views per visit, Sources, Referrers, Outbound links, Pages, Country/city, device/OS, browsers, date and time heat-maps.

Read [our guide here](https://s.super.so/analytics-guide) to learn more about getting started, why Analytics is important, and what data is included.

### **Watch our walk-through video**

## Make data-driven decisions today

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/207a3cf2-d5c6-4ce1-8c04-391194c060c9/footer-cta/w=3840,quality=90,fit=scale-down](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/207a3cf2-d5c6-4ce1-8c04-391194c060c9/footer-cta/w=3840,quality=90,fit=scale-down)