# Fix the UX where it defaults only to Metamask and prevents using another wallet (and probably implement WalletConnect)

Project: Optimize Optimism Fractal Web App, Fractalgram, and Fix Errors (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Optimize%20Optimism%20Fractal%20Web%20App,%20Fractalgram,%20an%201699ced1d9b243e4a375610e2222a983.md)
Status: Not started
Task Summary: This task aims to fix the UX issue in the web app where it defaults only to Metamask and prevents the use of other wallets like Zerion. It also suggests implementing WalletConnect to allow users to choose alternative wallets and enhance the user experience. The integration of WalletConnect with http://privy.io/ is explored, highlighting its compatibility and benefits in the decentralized web ecosystem.
Summary: The task aims to fix the UX issue where the web app only accepts Metamask as the default wallet and suggests implementing WalletConnect for improved user experience and the ability to choose other wallets. WalletConnect is an open protocol that securely connects decentralized applications (DApps) and mobile wallets through QR code scanning or deep linking. It enhances security, compatibility, user experience, cross-platform functionality, and session management. Integrating WalletConnect with Privy allows for easy sign-in with various wallets. WalletConnect is recommended to fix the UX issue and enable seamless interaction with DApps.
Created time: April 4, 2024 9:04 PM
Last edited time: June 8, 2024 11:30 PM
Created by: Dan Singjoy

## Description

- The task aims to fix the UX issue where the web app only accepts the default wallet is Metamask instead of other wallets like Zerion. It also suggests considering the implementation of WalletConnect.

- The UX should be improved to allow users to choose a wallet other than Metamask and we should probably implement WalletConnect, which integrates nicely with Privy.io.

## 1 minute video from Zeugh

- Zeugh had this issue in OF 22 then recorded and shared this video after

[Screen Recording 2024-04-04 at 15.04.03.mp4](Fix%20the%20UX%20where%20it%20defaults%20only%20to%20Metamask%20and%20%2064b5fee5641f49ffb27c3941a542e640/Screen_Recording_2024-04-04_at_15.04.03.mp4)

![Untitled](Fix%20the%20UX%20where%20it%20defaults%20only%20to%20Metamask%20and%20%2064b5fee5641f49ffb27c3941a542e640/Untitled.png)

## What is WalletConnect?

WalletConnect is an open protocol that facilitates secure communication and connection between decentralized applications (DApps) and mobile wallets through QR code scanning or deep linking. It's designed to work with any Ethereum and smart contract blockchain, providing a user-friendly way to connect a blockchain wallet to a DApp without exposing private keys or seed phrases.

[https://walletconnect.com](https://walletconnect.com/)

![[https://walletconnect.com](https://walletconnect.com/)](Fix%20the%20UX%20where%20it%20defaults%20only%20to%20Metamask%20and%20%2064b5fee5641f49ffb27c3941a542e640/Untitled%201.png)

[https://walletconnect.com](https://walletconnect.com/)

Here's a breakdown of how WalletConnect enhances the user experience in the decentralized web:

1. **Security**: It maintains high security by ensuring that your wallet's private keys never leave your device. Communication happens over encrypted channels, keeping transactions secure.
2. **Compatibility**: WalletConnect is blockchain-agnostic, meaning it supports various blockchains, primarily focusing on Ethereum-compatible ones. This wide compatibility makes it a versatile tool for users and developers alike.
3. **User Experience**: By simply scanning a QR code or following a deep link, users can securely connect their mobile wallet to a DApp on a desktop or another device. This process removes the need for manual entry of sensitive information, streamlining the interaction.
4. **Cross-Platform**: WalletConnect is not tied to any specific wallet or DApp, enabling users to connect any supported wallet to any compatible DApp, enhancing interoperability within the decentralized ecosystem.
5. **Session Management**: It allows for the creation of secure and interactive sessions between wallets and DApps. Users can approve or reject transactions and messages directly from their mobile devices, giving them full control over their digital assets.

WalletConnect has become a critical component in the decentralized finance (DeFi) and wider blockchain ecosystem, facilitating a seamless, secure, and user-friendly way for users to interact with DApps across various devices.

## Benefits

- WalletConnect would likely fix some or most of the issues identified in [Optimize Optimism Fractal Web App, Fractalgram, and Fix Errors](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Optimize%20Optimism%20Fractal%20Web%20App,%20Fractalgram,%20an%201699ced1d9b243e4a375610e2222a983.md)

- This would enable easy sign in with mobile and desktop via QR code, as well as many other wallets
    - See [Fix the UX where it defaults only to Metamask and prevents using another wallet (and probably implement WalletConnect) ](Fix%20the%20UX%20where%20it%20defaults%20only%20to%20Metamask%20and%20%2064b5fee5641f49ffb27c3941a542e640.md) for an example
    - WalletConnect was recommended by a developer named Zeugh in the video he recorded in the link above

## Integrating WalletConnect with Privy

Does privy work with walletconnect? Can you add walletconnect as an option when signing in with privy?

Yes, Privy does work with WalletConnect. WalletConnect is an essential part of the connector infrastructure that Privy has built for its users. It was created to simplify the process for developers to integrate a wide variety of wallets, ensuring that users can connect to apps with any wallet they choose. This makes WalletConnect an invaluable tool within Privy's ecosystem ([Privy | Onboard all your users to web3](https://www.privy.io/blog/wallet-interoperability)).

Additionally, the Privy platform allows for the configuration of your own WalletConnect project ID through its settings. This is an optional step and is only necessary if you wish to use your own project ID instead of the default provided by Privy ([Privy Docs](https://docs.privy.io/guide/dashboard/settings)).

## Related Tasks and Solutions

[Integrate WalletConnect into Respect Game Web App and Fractal App Via Privy](Integrate%20WalletConnect%20into%20Respect%20Game%20Web%20App%20%20af6e27cd16254cf38c28eb73138c91fe.md)