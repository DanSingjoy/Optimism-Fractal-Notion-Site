# Explore opportunities for automating council permissions with Hats Protocol

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: On Pause
Task Summary: This task aims to explore opportunities for automating council permissions using Hats Protocol. By integrating this technology with the Optimism Fractal governance model, we hope to streamline the management of council roles based on Respect scores and election outcomes, ultimately enhancing the efficiency of our governance processes.
Summary: The document discusses exploring automation of council permissions using Hats Protocol within the Optimism Fractal governance model. It highlights the need for a solution that updates permissions based on Respect scores or election results on the EVM, while also mentioning the challenges of building on-chain due to the current off-chain consensus process. The project has a strong use case and demand, but the team has paused this initiative to focus on other priorities.
Sub-task: Respond to Hodlon in Discord about automatically changing council with Hats Protocol (Respond%20to%20Hodlon%20in%20Discord%20about%20automatically%20c%20dd8cd582a4ce47c69a5904ef7d0f3b20.md), Consider solutions to automatically change MSIG (Consider%20solutions%20to%20automatically%20change%20MSIG%204780f863b84b4e0484ccb321e177aceb.md)
Created time: March 17, 2024 9:07 PM
Last edited time: September 26, 2024 5:08 PM
Sub-tasks: Review OREC article from Tadas (Review%20OREC%20article%20from%20Tadas%200789e605d5694d178660f36c921a859d.md), Review Dan’s Feedback about OREC (Review%20Dan%E2%80%99s%20Feedback%20about%20OREC%204c36bf9cbc7c49ac8c84f471cb5774f6.md)
Created by: Dan Singjoy
Description: The document outlines the exploration of automating council permissions using Hats Protocol in conjunction with the Optimism Fractal governance model. It discusses the need for a solution to update permissions based on Respect scores or election results and highlights the demand for their applications. However, the Optimystics team decided to prioritize other projects before pursuing automation, due to challenges in building on-chain solutions for the current off-chain consensus process.

## Description

- You can learn about the Optimism Fractal governance model [here](https://optimismfractal.com/details) and see this [page](https://optimystics.io/respectgame) for more details about the Respect Game that underpins our consensus process. You might be interested to check out the [fractal app](https://optimystics.io/fractal-app) that members of our team have built that automates council permissions based upon Respect earned during weekly events. This article above also includes other unique features.

- This fractal app is built on another Web3 software stack and we’ve been looking for a solution to automatically update the permissions for a council based upon Respect scores or election results on the EVM. I’m especially interested in a solution that composes nicely with Hats Protocol as we’ve also been exploring many other integrations with Hats in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md) and it’d be great to automatically configure many roles based upon [Respect](https://optimystics.io/respect) earned at Optimism Fractal events.

- We have a strong use case that’s inspired hundreds of builders for the past three years and there’s huge demand for our apps, but we need help developing our EVM [toolset](https://optimystics.io/tools) and would greatly appreciate help with automating/delegating council permissions.

Note: The Optimystics discussed this in March of 2024 and decided  to focus on other priorities before automating council permissions since much of the current [consensus process](https://optimismfractal.com/details) is currently offchain and it seems like it would be difficult to build onchain 

- Spencer sent the following message in the Hats Protocol + Optimism Fractal telegram chat

![Untitled](Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55/Untitled.png)

![Untitled](Explore%20opportunities%20for%20automating%20council%20permi%20eb4618799b5249ac9da86f6bd4fe5f3f/Untitled.png)

## Related

[OREC](https://www.notion.so/OREC-14acfb1d475f4c6ea40c8fb2bd022d9a?pvs=21) 

[Respond to Chaselb about Automated Councils with Hats Protocol and Optimism Fractal](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Respond%20to%20Chaselb%20about%20Automated%20Councils%20with%20H%2024d555bf47ac448abc5e693e6bedda8e.md) 

[Research Chaselb and his work on the automatically updating council with Hats Protocol](../../Optimystics%20Tasks%209c8f4934e402463895c95df067c1cb5d/Research%20Chaselb%20and%20his%20work%20on%20the%20automatically%20a38e5e5c784748bdaa15a80d3a881c55.md) 

[Review OREC article from Tadas](Review%20OREC%20article%20from%20Tadas%200789e605d5694d178660f36c921a859d.md) 

[Review Dan’s Feedback about OREC](Review%20Dan%E2%80%99s%20Feedback%20about%20OREC%204c36bf9cbc7c49ac8c84f471cb5774f6.md) 

[Review Automated councils with Hats Protocol ](Explore%20opportunities%20for%20automating%20council%20permi%20eb4618799b5249ac9da86f6bd4fe5f3f/Review%20Automated%20councils%20with%20Hats%20Protocol%20122a26f940f34c4abf65a142cdd9a95f.md)