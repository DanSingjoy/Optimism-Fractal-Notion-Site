# Create task template to create meeting notes during each OF event

Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: In progress
Task Summary: This task aims to create a task template for creating meeting notes during each OF event. The template will serve as a standardized format for documenting important discussions and decisions made during meetings. By using this template, participants will have a consistent and organized way to record and refer back to meeting details.
Summary: No content
Parent-task: Review and organize subtasks: Start Using Database Templates to organize meeting notes and event preparation (Review%20and%20organize%20subtasks%20Start%20Using%20Database%20%20fa23af5ec1ed4a3b9ff1c576a4c27fb5.md)
Created time: April 2, 2024 9:59 AM
Last edited time: June 18, 2024 8:30 AM
Parent task: Review and organize subtasks: Start Using Database Templates to organize meeting notes and event preparation (Review%20and%20organize%20subtasks%20Start%20Using%20Database%20%20fa23af5ec1ed4a3b9ff1c576a4c27fb5.md)
Created by: Dan Singjoy

## Description

-