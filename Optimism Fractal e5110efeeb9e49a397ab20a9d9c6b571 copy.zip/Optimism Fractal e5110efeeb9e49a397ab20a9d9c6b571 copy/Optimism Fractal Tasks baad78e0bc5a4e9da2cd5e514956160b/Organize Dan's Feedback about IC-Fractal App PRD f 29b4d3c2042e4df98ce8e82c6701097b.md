# Organize Dan's Feedback about IC-Fractal App PRD from Hodlon and bitbeckers

Assignee: Dan Singjoy
Due: July 31, 2024
Status: Not started
Task Summary: This task aims to organize and document Dan's feedback about the IC-Fractal App PRD from Hodlon and bitbeckers. The feedback includes general notes, questions, and considerations regarding the project's goals, the use of ICP, expanding beyond Optimism, cross-chain solutions, Shutter Network integration, and more.
Summary: This document organizes and documents Dan's feedback about the IC-Fractal App PRD from Hodlon and bitbeckers. The feedback includes general notes, questions, and considerations regarding the project's goals, the use of ICP, expanding beyond Optimism, cross-chain solutions, Shutter Network integration, and more. Dan provides insights on various topics such as the plan and goals of the project, the use of ICP, expanding to other networks, cross-chain solutions, and the integration of Shutter Network.
Created time: June 23, 2024 10:24 AM
Last edited time: July 15, 2024 8:07 PM
Parent task: Provide Feedback on the IC-Fractal App PRD by Hodlon and bitbeckers (Provide%20Feedback%20on%20the%20IC-Fractal%20App%20PRD%20by%20Hodl%20de10974833494578a5716b0c3f5ffc70.md)
Created by: Dan Singjoy
Description: This document organizes and documents Dan's feedback about the IC-Fractal App PRD from Hodlon and bitbeckers. The feedback includes general notes, questions, and considerations regarding the project's goals, the use of ICP, expanding beyond Optimism, cross-chain solutions, Shutter Network integration, and more.

## Introduction

This page organizes and document Dan's feedback about the IC-Fractal App PRD from Hodlon and bitbeckers. The feedback includes general notes, questions, and considerations regarding the project's goals, the use of ICP, expanding beyond Optimism, cross-chain solutions, Shutter Network integration, and more.

**Table of Contents**

## Original Messages

![[https://hackmd.io/@Hodlon/HknNpzgeC](https://hackmd.io/@Hodlon/HknNpzgeC)](Ask%20Optimystics%20for%20feedback%20about%20ICP-Fractal%20PRD%2014c8f353887245ad9160ce5a3feb1d78/Untitled.png)

[https://hackmd.io/@Hodlon/HknNpzgeC](https://hackmd.io/@Hodlon/HknNpzgeC)

![Untitled](Ask%20Optimystics%20for%20feedback%20about%20ICP-Fractal%20PRD%2014c8f353887245ad9160ce5a3feb1d78/Untitled%201.png)

## General Notes

- This section has recent feedback, written in late June.

- Thanks again for creating the PRD, I really appreciate it and apologize for the delayed response. I’ve thought a lot about the IC-Fractal App PRD over the past months and wanted to respond with detailed feedback much sooner, but the past few months have been very hectic and it took some time to organize the feedback.
    
    
    - I shared an [update](Review%20and%20Respond%20to%20Hodlon%20about%20Hats%20Contributi%20ede1b147525948b6a4c82818cbf962df.md) with Hodlon in April saying that I was aiming or planning to provide feedback over Spring Break, but i didn’t get the chance to do so amongst all the other responsibilities

- I discussed the the PRD with Tadas and Vlad at an Optimystics development team call for soon after the PRD was released. You can see a summary of the discussion [here](Summarize%20conversation%20with%20Optimystics%20and%20questi%204d8f7289657b452bb9342bd758854438.md). I could also ask Tadas and Vlad if they’d mind if share a video clip of our discussion if it’d be helpful for you to hear the full conversation.
    - The impression that I got from the Tadas and Vlad is that they really appreciate the PRD and are interested in collaborating, but they didn’t understand some aspects and needed to focus more on their development path before widening focus on the features outlined in the PRD.
        - In other words, I think that the foundations of the fractal software needed to be restructured before we could focus on more ambitious projects like researching the use cases of ICP, enabling private voting with Shutter, or building an app that integrates the voting interface in the same place as the Respect Game voting.
            - All of these sound like excellent ideas, but first we needed to focus on other more infrastructural tasks like defining the Respect token standard, fixing wallet login errors, enabling automated Respect distribution, enabling decentralized contract execution, and generally refactoring the code to make it easier for others to implement the Respect Game in their community or organization.
        - Now that Tadas is almost finished building a [next generation fractal software](https://t.me/edenfractal/1/4549) that fixes these issues and provides a more stable foundation to build upon, I’m exciting to soon start focusing more on additional features and comprehensive fractal app designs like the IC-Fractal PRD

- One of my projects has been to move some projects that i’ve been managing project to develop a fractal app in the internal Optimystics site to the public Optimism Fractal site so you can see what we’ve been working on so far and we’ll be able to better collaborate.
    - So far I’ve started to do this in [Build Respect Game app](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Respect%20Game%20app%20f7d756ae47ac41d48cf90ef3ad50a6cb.md) and [Build Optimism Fractal App](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md), but I still need to organize many more notes here. I’ll do so as soon as possible, but it’s not the highest priority right now and there’s a lot we can build without having such projects in the public notion site.
    - I’ve put a lot of work into these projects, tasks, and notes over the past month and they provide a lot of helpful resources. But they aren’t a core part of the overall development at this stage and it may time a while till i get the time to organize them properly. There’s no need to wait for them to be organized better to start developing anything.

- I started writing some feedback and questions below about the IC-Fractal app and will refine them in the near future

## To Do

- [ ]  organize and refine the questions and feedback below

- [ ]  consider posting these directly HackMD page

## General Questions

- What is your plan? What is your goal? Do you plan to build it or to contribute to a community discussion about it?

- Any way that I can help?

## Internet Computer

How exactly does this help? 

Why use ICP?

Is ICP too centralized?

Will ICP allow same level of integration with Optimism?

![Untitled](Organize%20Dan's%20Feedback%20about%20IC-Fractal%20App%20PRD%20f%2029b4d3c2042e4df98ce8e82c6701097b/Untitled.png)

## Multichain or Focus on Optimism

I’m not very familiar with ICP. I love the idea of increasing independence by enabling respect on more networks, but optimism is giving more funding and opportunities

Is it worth expanding beyond Optimism at this point (and reducing eligibility for RetroPGF) or better to maximize transactions on the Superchain? I think option 2 is better for now, though i like option 1 in the long term for more independent options

### ICP or Other Solutions?

If we do want cross-chain soon, then is it better to use Layer 0 or another solution?

Hodlon and Weston had [conversation](https://discord.com/channels/1164572177115398184/1164572177878765591/1186388980426612876) about Layer 0 Optimism Fractal chat that may be relevant to this discussion.

How about using Psibase instead like James Mart described in [Explore Concepts of Sovereign Tokens, Intersubjective Consensus, ICP, and Firmament](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Concepts%20of%20Sovereign%20Tokens,%20Intersubject%20762925eb0d724c3aafa95e7fe2f2f811.md)?

## Snapshot, Multichain Voting, and Other Solutions

Would using the multichain voting make it less dynamic and useful and feature rich than snapshot? Snapshot works well and just earned alot from retropgf. It has many functionalities that can be helpful for Respect Trees and other things. https://github.com/bjoernek/multi_chain_voting

Would ICP make it difficult for us to experiment with other protocols like Psibase?

Should we use Tally cross-chain governance solution instead?

- 
    
    You’d need a cross-chain account. Or yes you can replicate the tree in both places.
    
    Gnosis Guild has a solution for this using Zodiac modules and Connect (e.g. [https://unlock-protocol.com/blog/crosschain-connext-safe](https://unlock-protocol.com/blog/crosschain-connext-safe))
    
    Tally also just launched a new cross-chain governance solution [https://x.com/tallyxyz/status/1777368941007933839](https://x.com/tallyxyz/status/1777368941007933839)
    

## Shutter Network Integration

I know Loring Harkness from the Shutter Network. He participated at Optimism Fractal during our [tenth event](https://optimismfractal.com/10) and shared great enthusiasm and appreciation for our work. He reached out to me a few months ago expressing interest in implementing the Respect Game in the Shutter DAO, though I told him that we were limited in our ability to help implement it outside of Optimism Fractal at the time and we haven’t spoken since then. I can reach out to him again if it’d be helpful.  Coincidentally, Shutter is also working with a different coordination app that is called fractal which I learned by reading an [article](https://discord.com/channels/1164572177115398184/1164572177878765591/1225405735635128402) that Hodlon shared in the Optimism Fractal chat a few months ago. 

Gabriel Novak has also been working with Shutter and reported that he helped launch a [shutterized Optimism testnet L2](https://blog.shutter.network/shutterized-op-stack-testnet-shop-now-live-on-sepolia/) during an Optimism Fractal Respect Game. This marks the availability of a Shutterized encrypted mempool for the OP Stack, aiming to prevent front-running and provide a censorship-resistant trading environment. You can watch Gabriel provide more detailed overview about this in his [presentation](https://youtu.be/OGh897p1RNQ?feature=shared&t=773) during Optimism Fractal’s 31st event.

[https://blog.shutter.network/shutterized-op-stack-testnet-shop-now-live-on-sepolia/](https://blog.shutter.network/shutterized-op-stack-testnet-shop-now-live-on-sepolia/)

## Optimystics

You can see more of Dan’s feedback in a summary of a conversation with the Optimystics on [this page](Summarize%20conversation%20with%20Optimystics%20and%20questi%204d8f7289657b452bb9342bd758854438.md).