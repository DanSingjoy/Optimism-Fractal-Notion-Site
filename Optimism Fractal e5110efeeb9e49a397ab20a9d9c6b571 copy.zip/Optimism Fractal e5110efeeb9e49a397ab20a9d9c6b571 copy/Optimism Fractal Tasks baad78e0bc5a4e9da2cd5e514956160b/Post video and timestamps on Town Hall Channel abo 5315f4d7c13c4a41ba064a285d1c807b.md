# Post video and timestamps on Town Hall Channel about Optimism Fractal software

Assignee: Dan Singjoy
Project: Introduce Fractal App Discord Chat (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Introduce%20Fractal%20App%20Discord%20Chat%201cbcaa65ced54fe0977b4bf1eb73f7d1.md), Develop Fractal App Discord Chat (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Fractal%20App%20Discord%20Chat%209705bf9759ca4b16a74aa291c3de9b3b.md), Improve optimism fractal discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20optimism%20fractal%20discord%20f0810fb48cfc4a08b49fc433c1ebaffb.md)
Status: Not started
Task Summary: This task aims to post a video and timestamps on the Town Hall Channel about the Optimism Fractal software. The software offers advanced features for collective decision-making on the EVM platform, revolutionizing decentralized computing. Created by Dan Singjoy, the software holds immense potential to optimize decision-making processes in society.
Summary: The post is about the upcoming Optimism Fractal software, which aims to optimize collective decision-making on the EVM platform. It provides links to a repository showcasing the concept and implementation, an introduction video, and a more detailed overview of the software in development. The author believes that this software will bring immense benefits and hopes to implement fractal decision-making processes in society.
Created time: June 4, 2024 11:05 PM
Last edited time: June 17, 2024 2:01 PM
Parent task: Introduce the Fractal App chat on the OF Discord (Introduce%20the%20Fractal%20App%20chat%20on%20the%20OF%20Discord%20fa5e2a3793fd45f2bbfab68567a1c625.md)
Created by: Dan Singjoy

- [ ]  find the tweet and consdier posting this now to

The upcoming app can offer profoundly helpful features that were previously unimaginable and empower all communities with advanced software to optimize collective decision-making on the EVM, the leading platform for decentralized computing. You can see the concept and implementation in this [repository](https://github.com/sim31/fractal/tree/concept-for-of28-1/concepts/apps/of2), watch Tadas give an [introduction](https://www.youtube.com/watch?v=CsTqPS4HHsw&t=428s) to the software during last week’s Optimism Fractal Respect Game, and watch a more detailed [overview](https://youtu.be/CsTqPS4HHsw?si=7Q_z8EkZnEGmfhI_&t=3698) of the software in development during the Optimism Town Hall.

I believe that this software will create immense benefits for all and am excited to see how it will help us implement fractal decision-making processes throughout society in Eden Fractal’s third year!