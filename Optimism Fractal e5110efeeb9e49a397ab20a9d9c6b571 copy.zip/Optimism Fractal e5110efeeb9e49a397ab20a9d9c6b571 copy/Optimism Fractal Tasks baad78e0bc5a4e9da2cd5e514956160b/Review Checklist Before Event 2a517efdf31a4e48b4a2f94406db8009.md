# Review Checklist Before Event

Due: May 3, 2024
Status: Not started
Task Summary: This task aims to provide a review checklist before an event, covering various aspects such as presenting and creating a presentation in advance. The checklist is created by Dan Singjoy and includes specific items to consider for a successful event.
Summary: This checklist is for a presentation before an event. It includes reminders to zoom in or use boosts for screen sharing, choose an impactful opening image, and create the presentation in Arc ahead of time.
Created time: May 11, 2024 2:50 AM
Last edited time: May 27, 2024 12:14 PM
Created by: Dan Singjoy

🌻

- [ ]  Start zoom room at least 15 minutes earlier
    - [ ]  Do a sound check to ensure good audio output and input
    - [ ]  Turn off VPN to improve internet connection
    - [ ]  Test screenshare function in zoom
    - [ ]  Check activity monitor to make sure there is enough RAM and CPU
    - [ ]  Start a new meeting note and position the window for easy accessibility for notes during the meeting
    - [ ]  Set up welcoming music
    - [ ]  Set up welcoming video
    - [ ]  Send out promotional message
    - [ ]  Send out promotional message with Cagendas topic two days before event (this is probably better suited as a task in the project, whereas i think these other ones could just to do list blocks in the same page
        - [ ]  Consider the best way to organize this

## Presenting

- [ ]  remember to zoom in your screen or use boosts to only show the most helpful parts

- [ ]  think about the best image to open the presentation

- [ ]  create presentation in Arc in advance