# Explore integrations with telegram and hats protocol

Status: Not started
Summary: Explore integrations with Telegram and Hats Protocol. Spencer mentioned that using Guidxyz and Collabland for this is relatively easy. The question is whether Hats Protocol can gate specific categories, channels, or topics in a chat.
Parent-task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created time: March 19, 2024 11:56 AM
Last edited time: March 19, 2024 11:58 AM
Parent task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created by: Dan Singjoy

## Description

- Spencer said that it is pretty trivial to use Guidxyz and Collabland for this
    - Can Hats Protocol token gate specific categories, channels, or topics in a chat?