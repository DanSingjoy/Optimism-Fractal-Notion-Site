# See how the Hats Protocol community is using Quests

Project: Explore Integrations of Quests with the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Integrations%20of%20Quests%20with%20the%20Respect%20Ga%202a4d3601ec8c4f10b683a139862dd9e7.md), Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: In progress
Summary: This document provides information about how the Hats Protocol community is using Quests. It includes links for Hats contributors, submission processes, and joining the Hats Community. The Hats protoDAO Season 1 Quests aim to create and steward organizational primitives for roles and explore the use of the protocol to solve real problems.
Parent-task: Research Hats Protocol (Research%20Hats%20Protocol%201e39ddc584504459a14433038c9f414c.md)
Created time: February 18, 2024 9:47 AM
Last edited time: March 17, 2024 9:36 PM
Parent task: Research Hats Protocol (Research%20Hats%20Protocol%201e39ddc584504459a14433038c9f414c.md)
Created by: Dan Singjoy

## Description

![[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)[https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056](https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056)](See%20how%20the%20Hats%20Protocol%20community%20is%20using%20Quest%202274fa76d3f1416a9a888af1001de546/Untitled.png)

[https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X](https://quests.com/q/01HHZ7WXZ62GSE2RC373GCHM7X)[https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056](https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056)

### **Hats Protocol protoDAO Season 1 Quests**

[https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056](https://quests.com/q/01HASXRVGXV2FAHWM8FCEMT056)

Links For Hats Contributors:
- First time submitting a Hats contribution? Check out the submission process here:

[https://app.charmverse.io/hats-protocol/how-to-submit-a-contribution-for-protorep-consideration-23301472932733813](https://app.charmverse.io/hats-protocol/how-to-submit-a-contribution-for-protorep-consideration-23301472932733813)

- Linked a Quest to this one? Formally submit your contribution here:

[https://hatsprotocol.deform.cc/contribution/](https://hatsprotocol.deform.cc/contribution/)

Join the Hats Community here:

[https://hatsprotocol.deform.cc/community/](https://hatsprotocol.deform.cc/community/)

Hats Protocol Season 1 Overview:
The Hats protoDAO exists to 1) create and steward the best possible organizational primitive for roles, and 2) explore and curate the vast design space of how to use the protocol to solve real problems.

## Related Projects

[Explore Integrations of Quests with the Respect Game](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Integrations%20of%20Quests%20with%20the%20Respect%20Ga%202a4d3601ec8c4f10b683a139862dd9e7.md) 

[Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)