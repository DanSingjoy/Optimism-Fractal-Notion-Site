# Share Fractal Office Hours event for this Wednesday

Assignee: Dan Singjoy
Due: July 8, 2024
Project: Develop Fractal Office Hours Event (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Fractal%20Office%20Hours%20Event%2043de4896b2f043919ac06fbadd6fcfda.md)
Status: Done
Task Summary: This task aims to create a 2-4 sentence summary/intro for the "Fractal Office Hours" event page scheduled for this Wednesday. The event provides a casual space for discussions about fractal communities, the Respect Game, and related matters. Participants are encouraged to join, share their thoughts, ask questions, or simply listen to the conversation. The event will be followed by Builder Office Hours hosted by the Optimism Foundation, offering builders an opportunity to discuss Optimism with contributors.
Summary: Fractal Office Hours event has been scheduled for this Wednesday at 16-16:30 UTC. The event provides a casual space for discussions about fractal communities, the Respect Game, and related matters. It will be followed by Builder Office Hours hosted by the Optimism Foundation. Zoom link and details can be found in the provided link.
Created time: July 21, 2024 9:37 AM
Last edited time: July 23, 2024 10:50 PM
Created by: Dan Singjoy
Description: Fractal Office Hours event is scheduled for this Wednesday at 16-16:30 UTC. It provides a space for discussions about fractal communities, the Respect Game, and related matters. The event will be followed by Builder Office Hours hosted by the Optimism Foundation. Zoom link and details can be found in the provided link.

- [ ]  share in:
    - [ ]  optimism fractal
    - [ ]  eden fractal
    - [ ]  fractally
    - [ ]  fractaljoy

## Optimism Fractal

Hi all,

I just scheduled a [Fractal Office Hours](https://lu.ma/td91fodf) event for this Wednesday at 16-16:30 UTC. This event provides a casual space for discussions about fractal communities (such as Optimism Fractal), the Respect Game, and related matters. You’re welcome to join and share your thoughts, ask questions, or listen to the conversation. If there’s sufficient interest then I can host another similar event during Optimism Fractal’s summer break.

The event will be immediately followed by Builder Office Hours hosted by the Optimism Foundation, which provides a place for builders to discuss Optimism with contributors at the Foundation. You can find the zoom link and more details in the link above. Hope to see you there :)

## Eden Fractal

Hi all, hope you’re enjoying the summer break!

I just scheduled a [Fractal Office Hours](https://lu.ma/td91fodf) event for this Wednesday at 16-16:30 UTC. This event provides a casual space for discussions about fractal communities (such as Eden Fractal and Optimism Fractal), the Respect Game, and related matters. You’re welcome to join and share your thoughts, ask questions, or listen to the conversation. If there’s sufficient interest then I can host another similar event in the next couple weeks.

The event will be immediately followed by Builder Office Hours hosted by the Optimism Foundation, which provides a place for builders to discuss Optimism with contributors at the Foundation. You can find the zoom link and more details in the link above. Looking forward to seeing you there :)

## Fractally

Hi all,

As previously mentioned, I just scheduled a [Fractal Office Hours](https://lu.ma/td91fodf) event for this Wednesday at 16-16:30 UTC. This event provides a casual space for discussions about fractal communities (such as Optimism Fractal and Eden Fractal), the Respect Game, and related matters. You’re welcome to join and share your thoughts, ask questions, or listen to the conversation. If there’s sufficient interest then I can host another similar event in the next couple weeks.

The event will be immediately followed by Builder Office Hours hosted by the Optimism Foundation, which provides a place for builders to discuss Optimism with contributors at the Foundation. You can find the zoom link and more details in the link above. Looking forward to seeing you there :)

## FractalJoy

Hi all,

As we previously discussed, I just scheduled a [Fractal Office Hours](https://lu.ma/td91fodf) event for this Wednesday at 16-16:30 UTC. This event provides a casual space for discussions about fractal communities (such as Optimism Fractal and Eden Fractal), the Respect Game, and related matters. You’re welcome to join and share your thoughts, ask questions, or listen to the conversation. If there’s sufficient interest then I can host another similar event in the next couple weeks.

The event will be immediately followed by Builder Office Hours hosted by the Optimism Foundation, which provides a place for builders to discuss Optimism with contributors at the Foundation. You can find the zoom link and more details in the link above. Looking forward to seeing you there :)

## Previous Notes

I'm planning to schedule a Fractal Office Hours event this Wednesday at 16-16:30 UTC, which will be followed by an Optimism Foundation office hours for builders. I might also host another office hours event during the Optimism Fractal summer break if there's sufficient interest. I'll make the event page and share a link here soon.

- [ ]  create event page for a new event called fractal office hours

- [ ]  review previous message

- Does it make sense to host the first Office Hours event this week or next week? yes
    - might it be too overwhelming and too many people joining in the first builders office hours with maxwell? no
    - i think its probably best to get it started this week and there likley wont be too many people joining
    - yes definitely promote it

[Prepare for Optimism Office Builder Office Hours meeting with Maxwell ](../../EC%20Tasks%201951af2e70bd4666850a3d112e65f7a8/Prepare%20for%20Optimism%20Office%20Builder%20Office%20Hours%20m%203ee01402ba1b4f978104c1f23c6a5618.md) 

[Optimism Foundation Builder Office Hours](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Events%20ea9e175f88f5452f9bd834bbabcab0a4/Optimism%20Fractal%20Events%20Calendar%209fe995ccda1b492daae39353c5452549/Optimism%20Foundation%20Builder%20Office%20Hours%2098d38cdf68e742db8824dd445002b8b7.md)