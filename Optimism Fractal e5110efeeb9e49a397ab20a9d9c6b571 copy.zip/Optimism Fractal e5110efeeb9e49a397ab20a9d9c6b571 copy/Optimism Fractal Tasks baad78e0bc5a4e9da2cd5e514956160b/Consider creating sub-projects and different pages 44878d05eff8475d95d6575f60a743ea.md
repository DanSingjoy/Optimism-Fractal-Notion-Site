# Consider creating sub-projects and different pages of documentation for different funding opportunities

Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Not started
Task Summary: This task aims to suggest the creation of sub-projects and different pages of documentation for different funding opportunities. By organizing the projects and providing clarity about various funding sources, it becomes easier to navigate and understand the available options. The subprojects can focus on different aspects such as the Base Ecosystem Fund, Coinbase Ventures, Optimism Missions, RetroFunding, Gitcoin, Octant, Fractal Clients, and more.
Summary: Consider creating sub-projects and different pages of documentation for different funding opportunities. This will provide more clarity and organization, allowing for better management of various funding sources. Examples of potential subprojects include Base, Optimism Missions, RetroFunding, Gitcoin, Octant, Fractal Clients, and more.
Created time: June 23, 2024 12:19 PM
Last edited time: June 23, 2024 12:19 PM
Created by: Dan Singjoy

## Funding Opportunities

- I think that I should also organize the projects below to provide more clarity about the various funding sources
    - For example, maybe there should be subprojects for [Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md) and they can be about:
        - Base
            - Base Ecosystem Fund
            - Coinbase Ventures
                - Explained during OF 30
        - Optimism Missions
        - RetroFunding
        - Gitcoin
        - Octant
        - Fractal Clients
        - Etc

### Related Projects and Tasks

[Create [OptimismFractal.com/funding](http://OptimismFractal.com/funding) to show how Optimism Fractal can help people earn RetroFunding and other funding](Create%20OptimismFractal%20com%20funding%20to%20show%20how%20Opt%2045915c303ab94868b62bc2124430da06.md) 

[Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)