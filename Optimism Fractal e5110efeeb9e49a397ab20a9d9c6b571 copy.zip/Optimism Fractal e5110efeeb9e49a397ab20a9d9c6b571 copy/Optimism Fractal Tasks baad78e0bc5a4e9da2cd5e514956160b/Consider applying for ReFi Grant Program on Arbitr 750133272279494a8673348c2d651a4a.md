# Consider applying for ReFi Grant Program on Arbitrum

Project: Explore expansion of Fractals into broader EVM Ecosystem  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20expansion%20of%20Fractals%20into%20broader%20EVM%20Eco%20e4f9f052785e4114b18ac2148eb3067d.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)
Status: Not started
Task Summary: This task aims to provide information and guidance on applying for the ReFi Grant Program on Arbitrum. Created by Dan Singjoy, the page outlines the current status of the application process and highlights the importance of having a solid foundation before pursuing the grant. The page also mentions the need for readiness in terms of software, processes, and a growing sense of optimism.
Summary: Consider applying for the ReFi Grant Program on Arbitrum once the software is more ready, processes are more refined, and optimism is higher. The grant offers 20k arb (about 18k USD) and requires answering several questions.
Parent-task: Share the link Optimism Collective season 6 and mission requests in Eden Fractal chat, tag Will, and Respond about broader EVM Ecosystem opportunities (Share%20the%20link%20Optimism%20Collective%20season%206%20and%20mi%207ee01ae4682c4cfa82f1e4d62d53d1a1.md)
Created time: June 17, 2024 2:27 PM
Last edited time: June 17, 2024 2:39 PM
Parent task: Share the link Optimism Collective season 6 and mission requests in Eden Fractal chat, tag Will, and Respond about broader EVM Ecosystem opportunities (Share%20the%20link%20Optimism%20Collective%20season%206%20and%20mi%207ee01ae4682c4cfa82f1e4d62d53d1a1.md)
Created by: Dan Singjoy

- There’s 20k arb (which is about 18k usd) and there are a lot of questions to answer here

- Generally i think we should start pursuing these in the coming weeks and months after our foundations are laid well with optimism before branching out too quickly

- It will be alot easier to apply for this when:
    - our software is more ready
    - our processes are more refined
    - optimism fractal is larger
    - we have [Add Optimism Fractal notion workspace file to Optimism Fractal GPT](Add%20Optimism%20Fractal%20notion%20workspace%20file%20to%20Opti%206b32055a5c1d48afb1f62817c059e8fd.md) to be able to respond to these kinds of forms quickly
    

[https://x.com/CharmVerse/status/1801642679412855044](https://x.com/CharmVerse/status/1801642679412855044)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%201.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%202.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%203.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%204.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%205.png)

![Untitled](Consider%20applying%20for%20ReFi%20Grant%20Program%20on%20Arbitr%20750133272279494a8673348c2d651a4a/Untitled%206.png)