# Test JokeRace

Project: Research JokeRace for Cagendas and OPTOPICS  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20JokeRace%20for%20Cagendas%20and%20OPTOPICS%2062b9e52fb4994fd2902dc10fb082e592.md)
Status: Not started
Task Summary: This task aims to test and evaluate the functionality and usability of JokeRace, a voting and topic submission software created by Dan Singjoy. The focus will be on testing the user interface, poll creation, and exploring potential alternatives to the current fee-based model. Additionally, questions regarding the open-source nature of the software and its integration into other applications will be addressed.
Summary: This document is a test for the JokeRace software. It includes a to-do list for testing the UI and creation of polls, as well as questions about the cost, open-source nature, and integration of the software. The document also mentions the functionality of the first version and the compatibility with different browsers.
Created time: May 31, 2024 5:35 PM
Last edited time: June 2, 2024 9:40 AM
Created by: Dan Singjoy

# To Do

- [ ]  test the UI of voting and submitting topic

- [ ]  test the creation of the poll and see how it works

- [ ]  consider testing it at an upcoming town hall

# Key Points and Questions to Ask

## Questions

- Is there a way to do a JokeRace without charging people to vote or submit?
    - Currently it costs 2.65 to submit a topic and 26 cents to vote. This isn’t ideal
    
    ![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled.png)
    
    ![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%201.png)
    
    ![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%202.png)
    

- Is the JokeRace software all open source or only a part of it?
    - Perhaps a free version can be forked?
    - if only some is open sourced, then what would be missing?
    - Perhaps a free version can be forked?
    - if only some is open sourced, then what would be missing?

- This may be the JokeRace business model right now- to earn 50% of all of the fees. In this case, it’s like their service charge to allow us to use JokeRace.
- These fees are a barrier and free is better, but it isn’t super high and could be worth it.
    - It does add up though… say if i propose 4 topics a week then it costs 10 dollars a week or 40 per month… which is a lot but could be worth it if it makes the events much better
        - If others propose topics and I take half of the earnings then it could be profitable for me. I’m not sure if i’d want to take profit here but it could work (and that might be weird to explain at the events), but it could potentially be a good revenue opportunity for fractal hosts like me in the long term
            - [ ]  Review tweet about this in [Respond or DM David Phelps about jokerace demo - Sounds fascinating! I host three game shows a week and am interested in using JokeRace. Is there a video recording of this demo? ](Respond%20or%20DM%20David%20Phelps%20about%20jokerace%20demo%20-%20S%20564829d6ddda48b0bbb83226d37e8054.md)
    - At this stage we’re not worried about spam and free topics+votes would generally be much better to encourage more participation. Perhaps it makes more sense to use this kind of revenue model as the community grows and many people want to

- What is the ranked choice voting algorithm? How many votes get distributed to the top option compared to the second top and so forth?

- Can it be integrated into our app? ie a town hall app UI branding instead of JokeRace branding?

- Is the first version functional?
    - [Test if the first version of JokeRace enables free Contests](Test%20if%20the%20first%20version%20of%20JokeRace%20enables%20free%20a613d47e9c48412cb56d0f70ba7fa5cf.md)

- Is the first version functional?
    - [Test if the first version of JokeRace enables free Contests](Test%20if%20the%20first%20version%20of%20JokeRace%20enables%20free%20a613d47e9c48412cb56d0f70ba7fa5cf.md)

## Key Points

- Safari allows me to create poll with OPF, whereas firefox did not

- The features that allow anyone to submit topics seem like they may work much better than snapshot currently does

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%203.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%204.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%205.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%206.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%207.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%208.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%209.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2010.png)

# It works on Safari but not firefox

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2011.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2012.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2013.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2014.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2015.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2016.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2017.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2018.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2019.png)

![Untitled](Test%20JokeRace%206ebd70fe0ca54e14afde63e3c6875329/Untitled%2020.png)