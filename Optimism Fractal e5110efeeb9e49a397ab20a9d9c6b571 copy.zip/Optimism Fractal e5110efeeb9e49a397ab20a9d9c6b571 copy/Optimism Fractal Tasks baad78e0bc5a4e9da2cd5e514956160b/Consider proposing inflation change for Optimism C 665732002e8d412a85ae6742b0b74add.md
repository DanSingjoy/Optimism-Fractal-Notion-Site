# Consider proposing inflation change for Optimism Collective

Assignee: Dan Singjoy
Due: January 30, 2026
Project: Implement contributor funding in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Implement%20contributor%20funding%20in%20the%20Optimism%20Coll%20e94cb8eb2b5246ebaa47d1088b49b1cc.md), Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md), Create Topics for Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Topics%20for%20Optimism%20Town%20Hall%2069e19236e45d4dd8b0a4b7c6fc12ae19.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md)
Status: On Pause
Task Summary: This task aims to propose a change in inflation for the Optimism Collective. By evaluating the current inflation adjustment process, the goal is to explore potential modifications that could enhance the overall efficiency and effectiveness of the inflation mechanism within the collective.
Summary: A proposal is being considered to change inflation for the Optimism Collective, which can be adjusted once a year around the end of May. Clarification is needed on the process related to the May 31st deadline.
Created time: May 20, 2024 9:57 AM
Last edited time: August 27, 2024 4:33 PM
Created by: Dan Singjoy
Description: A proposal is being considered to change inflation for the Optimism Collective, which can be adjusted once a year around the end of May. Clarification is needed on the process related to the May 31st deadline.

- This can be changed once per year, but it seems that it can only be changed around the end of may…. What if we proposed inflation for OF?
    - How does this part about May 31st work?

[https://gov.optimism.io/t/inflation-adjustment-proposal-template/5923](https://gov.optimism.io/t/inflation-adjustment-proposal-template/5923)

![Untitled](Consider%20proposing%20inflation%20change%20for%20Optimism%20C%20665732002e8d412a85ae6742b0b74add/Untitled.png)

[https://drive.google.com/file/d/1mAWfVMQkG0O_aWdPRtk5ojHuMXhsAgNg/view](https://drive.google.com/file/d/1mAWfVMQkG0O_aWdPRtk5ojHuMXhsAgNg/view)

![Untitled](Consider%20proposing%20inflation%20change%20for%20Optimism%20C%20665732002e8d412a85ae6742b0b74add/Untitled%201.png)

![Untitled](Consider%20proposing%20inflation%20change%20for%20Optimism%20C%20665732002e8d412a85ae6742b0b74add/Untitled%202.png)

![Untitled](Consider%20proposing%20inflation%20change%20for%20Optimism%20C%20665732002e8d412a85ae6742b0b74add/Untitled%203.png)

![Untitled](Consider%20proposing%20inflation%20change%20for%20Optimism%20C%20665732002e8d412a85ae6742b0b74add/Untitled%204.png)

[https://github.com/ethereum-optimism/OPerating-manual/blob/main/manual.md#valid-proposal-types](https://github.com/ethereum-optimism/OPerating-manual/blob/main/manual.md#valid-proposal-types)

[Consider following up with Gonna about Token House Requests to adjust budgets and research submitting a proposal to token house](https://www.notion.so/Consider-following-up-with-Gonna-about-Token-House-Requests-to-adjust-budgets-and-research-submittin-e728b19859014a9d983c32788401a451?pvs=21)