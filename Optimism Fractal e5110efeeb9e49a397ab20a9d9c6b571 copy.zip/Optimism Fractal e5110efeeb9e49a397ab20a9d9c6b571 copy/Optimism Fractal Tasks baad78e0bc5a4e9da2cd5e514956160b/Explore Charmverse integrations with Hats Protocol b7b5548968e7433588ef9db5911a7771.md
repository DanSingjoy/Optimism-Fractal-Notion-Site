# Explore Charmverse integrations with Hats Protocol

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: In progress
Task Summary: This task aims to explore the various integrations between Charmverse and Hats Protocol. By investigating these connections, we seek to uncover potential enhancements in functionality and user experience that can be achieved through their collaboration.
Summary: The document discusses exploring Charmverse integrations with Hats Protocol, but lacks detailed content in the description section.
Parent-task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created time: March 18, 2024 7:16 PM
Last edited time: September 26, 2024 5:07 PM
Parent task: Explore and Test Integrations with Respect Eligibility Module (Explore%20and%20Test%20Integrations%20with%20Respect%20Eligibi%20d1a76266e195446fb2fd1fbaca210d55.md)
Created by: Dan Singjoy
Description: No content

## Description

-