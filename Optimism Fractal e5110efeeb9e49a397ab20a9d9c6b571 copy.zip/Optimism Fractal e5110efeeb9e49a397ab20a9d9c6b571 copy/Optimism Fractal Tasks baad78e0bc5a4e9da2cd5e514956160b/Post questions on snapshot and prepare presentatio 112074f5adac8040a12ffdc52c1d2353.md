# Post questions on snapshot and prepare presentation for OF 44 topic with David Ehrlichman

Assignee: Dan Singjoy
Due: October 2, 2024
Project: Prepare for Optimism Fractal 44 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20Optimism%20Fractal%2044%20114074f5adac80f1b58afdd32fcefefd.md)
Status: Done
Task Summary: This task aims to facilitate the preparation and discussion of key topics related to the OF 44 presentation with David Ehrlichman. It includes posting questions on the snapshot platform, organizing related content, and ensuring effective communication with the community to enhance engagement and collaboration.
Summary: The document outlines the next steps for preparing a presentation on the Hats Protocol with David Ehrlichman, including organizing links, formulating questions, and engaging the community. It details specific questions to be posed during the presentation, voting mechanisms, and emphasizes the importance of community involvement and feedback. Additionally, it discusses the structure of the presentation, aiming for a conversational format while covering various topics related to Hats and its future integrations.
Parent-task: Create Topic Proposal for OF 44 and Agenda for Optimism Town Hall with David Ehrlichman (Create%20Topic%20Proposal%20for%20OF%2044%20and%20Agenda%20for%20Opt%20dce6f714064a4a158952d89582b48940.md)
Created time: October 1, 2024 9:10 AM
Last edited time: October 4, 2024 9:26 AM
Created by: Dan Singjoy
Description: The document outlines the preparation for a presentation on the Hats Protocol with David Ehrlichman, including steps to organize content, post questions, and engage the community. Key topics include David's inspirations, thoughts on the Hatathon, potential integrations with Optimism Fractal, and his vision for the future of Hats. The document also emphasizes the importance of community involvement and outlines the structure for the Town Hall discussion.

# Next Steps

- [ ]  organize the following links into the introductory  OTH presentation

- [ ]  create the following 4 of my questions on the snapshot topic so that there are some questions already up there, then vote on them with a staggered amount of Respect so that other’s could potentially vote for their topics over mine
    
    
- [ ]  add the rules of the Community Interview game to an aisle in Arc and show it at the beginning and end of the presentation, then ask him if he’s ready to try it

- [ ]  make a post letting everyone know that i created four questions and everyone can propose questions. though rosmari already mentioned that people can propose questions so maybe i’ll just say i look forward to seeing any other questions proposed!
    - [ ]  also remind people about the council

# Post Questions on Snapshot

### What inspired David on this path with Impact Networks and Converge over for over a decade… and how, if so, is this thread of progress continuing with Hats?

- [ ]  vote with 50 Respect

- Share brief overview of Hats Protocol for anyone who is unfamiliar
- Thank you for organizing the call at ETH Denver
    - It was great to meet the Haberdasher Labs team there and the community
        - Shout out to Spencer, Nick, Ido, Hodlon, Jacob, and others
- Share a bit of background about [Impact Networks](https://www.converge.net/book), [Converge](https://www.converge.net/), and the thread of inspiration behind Hats would also be nice

### What does David think of the inaugural Hatathon and Optimism Fractal Hats Tree?

- [ ]  Vote with 500 Respect

- Thank you for organizing the Hatathon and selecting the Optimism Fractal Hats Tree as a co-winner
- Briefly showcasing the Mad Hatter winning Hats Trees, the show notes from [OptimismFractal.com/41](http://OptimismFractal.com/41) and new Optimystics article, as well the other winners

### What does David think about future integrations between Hats Protocol and Optimism Fractal? What integrations sound most exciting or helpful?

- [ ]  Vote with 300 Respect

- This project: [Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
- Potential integrations with [roles and reputations](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d.md) from @jacob
- The plans and milestones related to Hats in my [mission proposal](https://app.charmverse.io/op-grants/optimism-fractal-respect-game-8230548535268414) for OF Respect Game
- Potential synergies with [Hats ProtoDAO](https://blog.hatsprotocol.xyz/hats-protodao-s3) and integrations with Optimism Fractal

- What does David think of these potential integrations?

### What is David’s vision and plans for the future with Hats? What is David most excited about?

- [ ]  100 Respect

- [David’s tweet](https://twitter.com/davehrlichman/status/1787538350276264082)
    
    
    [https://twitter.com/davehrlichman/status/1787538350276264082](https://twitter.com/davehrlichman/status/1787538350276264082)
    
- [Vision article](https://blog.hatsprotocol.xyz/organizational-graphs)
- Hats Season 4
- New ReHash [episode](https://twitter.com/rehashweb3/status/1837191224836641109)
- How should people get involved:
    - Hats ProtoDAO
        - Hats Town Hall events and youtube channel
        - Community telegram chat
    - Optimism Fractal
    - Hats Protocol + Optimism Fractal chat
    - Other communities using hats on Optimism, such as Lets GROW
        - Nick or Spencer’s tweet about adoption of Hats Protocol?

- What is David’s vision and plans for the future with Hats? What is David most excited about?

# Older notes

## Topics for Town Hall with David about Hats

I think it would be good to break it up into a more conversational presentation, where i present an overview of about 5 sections, then i present one section and then ask david what he thinks, then i present the second section and ask what he thinks, and so forth. And roughly try to time that for 5 minutes for each section.

Alternatively, it might be better if i just give an introductory presentation for 5 minutes in the beginning, then ask a question to David and have a more open discussion where people can start participating sooner. It’s not really an interview show where I’m doing the interview, but there are some questions i want to ask and there’s not much time, so consider the best way to do it

### Introduction to David and Hats Protocol

- Share brief overview of Hats Protocol for anyone who is unfamiliar
- Thank you for organizing the call at ETH Denver
    - It was great to meet the Haberdasher Labs team there and the community
        - Shout out to Spencer, Nick, Ido, Hodlon, Jacob, and others
- Share a bit of background about [Impact Networks](https://www.converge.net/book), [Converge](https://www.converge.net/), and the thread of inspiration behind Hats would also be nice

- What inspired David on this path and how is the progress going with Hats?

### Recap of the inaugural Hatathon

- Thank you for organizing the Hatathon and selecting the Optimism Fractal Hats Tree as a co-winner
- Briefly showcasing the Mad Hatter winning Hats Trees, the show notes from [OptimismFractal.com/41](http://OptimismFractal.com/41) and new Optimystics article, as well the other winners

- What does David think of the Hatathon and Optimism Fractal Hats Tree?

### Preview of planned integrations with Hats and Optimism Fractal

- This project: [Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
- Potential integrations with [roles and reputations](Research%20Roles%20and%20Reputations%20System%20(from%20Jacob%20%20c5d6d85383464c5f851fc78efef3309d.md) from @jacob
- The plans and milestones related to Hats in my [mission proposal](https://app.charmverse.io/op-grants/optimism-fractal-respect-game-8230548535268414) for OF Respect Game
- Potential synergies with [Hats ProtoDAO](https://blog.hatsprotocol.xyz/hats-protodao-s3) and integrations with Optimism Fractal

- What does David think of these potential integrations?

### Next steps and Vision for Hats Protocol

- [David’s tweet](https://twitter.com/davehrlichman/status/1787538350276264082)
    
    
    [https://twitter.com/davehrlichman/status/1787538350276264082](https://twitter.com/davehrlichman/status/1787538350276264082)
    
- [Vision article](https://blog.hatsprotocol.xyz/organizational-graphs)
- Hats Season 4
- New ReHash [episode](https://twitter.com/rehashweb3/status/1837191224836641109)
- How should people get involved:
    - Hats ProtoDAO
        - Hats Town Hall events and youtube channel
        - Community telegram chat
    - Optimism Fractal
    - Hats Protocol + Optimism Fractal chat
    - Other communities using hats on Optimism, such as Lets GROW
        - Nick or Spencer’s tweet about adoption of Hats Protocol?

- What is David’s vision and plans for the future with Hats? What is David most excited about?

- Open discussion and Community Q & A

- [ ]  Mention State of the Fractals Eden Fractal episode?

## Diving Deeper into Hats Protocol with David Ehrlichman

At this week’s Optimism Town Hall we’ll dive deeper into the organizational powers of Hats with [David Ehrlichman](https://linktr.ee/davidehrlichman), who is a cofounder of [Hats Protocol](https://www.hatsprotocol.xyz/) and Haberdasher Labs. 

David is also the author of [Impact Networks](https://www.converge.net/book), an acclaimed book showing how purpose-driven networks create lasting change by embracing interdependence and generating impact through collaboration. Prior to starting Hats Protocol, David cofounded [Converge](https://www.converge.net/), a network of independent consultants who cultivated impact networks (as you can learn more about in this [documentary](https://www.youtube.com/watch?v=VunUVvGFpb4)).

Some topics that we may discuss include a recap of the inaugural [Hatathon](https://optimismfractal.com/41) (in which the Optimism Fractal Hats Tree was selected as a co-winner), future integrations and synergies between Hats and Fractals, and David’s vision for Hats Protocol. In addition, I also plan to preview some of the next steps for Optimism Fractal Hats integrations that I’m planning in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md) and a new mission proposal for a Respect Game fund distribution and reputation system inspired by MMORPGs (massive multiplayer online role playing games).  

After a brief introductory segment, we’ll jump into a Community Interview game where community members can propose and vote on questions on the Optimism Town Hall snapshot space. If there are questions or topics related to Hats Protocol that you’d like to be discussed during the Town Hall, then you can post it on the snapshot space at any time and vote with Respect to influence the discussion. The questions proposed in the Optimism Town Hall snapshot space will be prioritized in order of Respect votes.

Feel free to share any related thoughts in the [group chat](http://t.me/hatsprotocolandoptimismfractal) with the founders of Hats Protocol and Optimism Fractal or our community discord. I hope you enjoy the event and am looking forward to hearing your thoughts!

 and am curious to hear    potential next steps for the Optimism Fractal Hats Tree that I wrote about in my Mission for the Optimism Fractal Respect Game. 

After this there will be a few more weeks before season 4 of Optimism Fractal ends on 

- Topics for Town Hall with David about Hats
    
    [Create Topic Proposal for OF 44 and Agenda for Optimism Town Hall with David Ehrlichman](Create%20Topic%20Proposal%20for%20OF%2044%20and%20Agenda%20for%20Opt%20dce6f714064a4a158952d89582b48940.md) 
    

Hat

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image.png)

Everyone can join the 

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image%201.png)

Shout out to Abraham and Howard who are planning to integrate Hats into the 

zaal is planning hats trees 

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image%202.png)

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image%203.png)

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image%204.png)

thank you for sharing the interview and the nice feedback about Optimism Fractal at the end

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image%205.png)

thanks for curating

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image%206.png)

![image.png](Post%20questions%20on%20snapshot%20and%20prepare%20presentatio%20112074f5adac8040a12ffdc52c1d2353/image%207.png)

## Glad you’re loving the community, appreciate t

- Proposal
    - 

-