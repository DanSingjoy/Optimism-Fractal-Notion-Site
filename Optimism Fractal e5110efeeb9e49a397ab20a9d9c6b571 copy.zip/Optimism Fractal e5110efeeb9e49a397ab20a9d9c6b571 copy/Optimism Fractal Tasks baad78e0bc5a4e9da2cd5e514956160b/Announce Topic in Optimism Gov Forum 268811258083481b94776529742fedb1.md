# Announce Topic in Optimism Gov Forum

Due: May 3, 2024
Status: Not started
Task Summary: This task aims to announce a topic in the Optimism Gov Forum. The page includes information such as the creator, due date, status, and timestamps. The specific topic being announced is related to the "Citizen's house category."
Summary: The topic for announcement in the Optimism Gov Forum is "Citizen's house category?"
Created time: May 11, 2024 3:24 AM
Last edited time: May 11, 2024 3:24 AM
Created by: Dan Singjoy

Citizen’s house category?