# Organize these notes in EAS project and Review Ideas for Message to Vlad

Due: April 19, 2024
Project: Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: In progress
Summary: Tasks to be completed include organizing EAS notes into the EAS project, adding a high-level overview of EAS notes, syncing EAS notes, and responding to Vlad regarding the EAS section. Additionally, there are tasks related to organizing messages to Vlad and syncing notes about hosts to the "Define Importance of Host" task in the EVM Respect Game project.
Parent-task: Create Optimism Fractal Project to Build UI to Give Respect  (Create%20Optimism%20Fractal%20Project%20to%20Build%20UI%20to%20Giv%2055d8f59b057345fabed5b98ac00c1403.md)
Created time: April 9, 2024 10:14 AM
Last edited time: April 24, 2024 3:40 AM
Parent task: Create Optimism Fractal Project to Build UI to Give Respect  (Create%20Optimism%20Fractal%20Project%20to%20Build%20UI%20to%20Giv%2055d8f59b057345fabed5b98ac00c1403.md)
Created by: Dan Singjoy

- [ ]  organize the EAS notes below into EAS project

- [ ]  add high level overview of EAS notes to [Dan’s Feedback and Suggestions for Fractal App (including comparison between apps that generate zoom link or not)](https://www.notion.so/Dan-s-Feedback-and-Suggestions-for-Fractal-App-including-comparison-between-apps-that-generate-zoom-08ff855371f04c71956dce7a5eac3c62?pvs=21)

- [ ]  sync EAS notes to [EAS (Ethereum Attestation Service Integration)](https://www.notion.so/EAS-Ethereum-Attestation-Service-Integration-78907e50406d4b4a8c641eed1f80a080?pvs=21)

- [ ]  respond to Vlad and also let him know that i added the EAS section in the [Add notes about host to the document ](https://www.notion.so/Add-notes-about-host-to-the-document-9e5282bfd9274354a711ff29c7e1e9cd?pvs=21)
    - [ ]  first organize the messages to vlad here
    - [ ]  then sync over the notes about hosts to a new task in the evm respect game project called “Define Importance of Host” .
        - Set it as a subtask of go - to market strategy and other tasks?
        - [ ]  also sync over the notes about hosts that i wrote last night
        - [ ]  also move the task of responding to vlad last night to the respect game evm project

# Integrating the Fractal App with EAS

Consider adding a tag section in the respect game app instead of section specifically for community. This could enable more broad uses than just adding community or organization name. It can work kind of like hashtags or channels or gudasol’s idea for memos. Make it easily searchable and linked to other kinds of communities, organizations, trends, memes, or whatever else people creatively want to add. 

[https://chat.openai.com/share/09074994-067f-4bb0-b491-b37dd7e7c46f](https://chat.openai.com/share/09074994-067f-4bb0-b491-b37dd7e7c46f)

Okay, so I have a technical question. It's related to the Ethereum attestation service, and I'm wondering if you have a game, and you have six people who are playing a game together, it's a consensus game, and they each need to come to consensus and submit the same exact result with an on-chain action, which could also be an attestation with the EAS at the same time, then is it possible to make some sort of automation where an event only gets triggered and it automatically gets sent out if at least four of the six people or at least four or five or at least 66% basically of the participants, whether there's six participants or five participants or four participants, if at least 66% of the participants who also submit the same attestation or submit it on-chain during that specific game instance, if it only triggers the event to send out a token if 66% of the participants make the exact same attestation with the exact same data and rankings that the other participants in their room do as well? So is that possible to create a schema, have a property in the schema for something like game instance number, and then make it so that 66% of players in that game instance also have, if they also have the same attestation and on-chain thing that they put in, then they get a token in a certain way, in a certain amount. But if they do not, then they do not get that amount. Is that possible to automate this?

ChatGPT

Yes, it's possible to automate such a process using smart contracts on the Ethereum blockchain, combined with the Ethereum Attestation Service (EAS). Here's a high-level overview of how you might design this system:

1. **Smart Contract Development:** First, you'd develop a smart contract to manage the game logic and token distribution. This smart contract would include functions to handle game instances, participant attestations, and consensus checking.
2. **Game Instance Management:** Each game instance can be uniquely identified within the smart contract, possibly through a game instance number or ID. This would allow the contract to track participants and their attestations for each specific game.
3. **Attestation and Consensus Logic:** Within the smart contract, you would implement logic to allow participants to submit their attestations (which could be specific outcomes or decisions made during the game). The contract would check if at least 66% of the participants in a game instance have submitted matching attestations.
4. **Threshold Mechanism:** The consensus logic would be designed to trigger an event (like token distribution) only if the condition of having at least 66% agreement among participants is met. This requires implementing a mechanism to count and verify the matching attestations against the total number of participants active in the game instance.
5. **Token Distribution:** If the consensus condition is met, the smart contract would then automatically execute the token distribution to the participants who were part of the consensus. If the condition is not met, no tokens would be distributed.
6. **Schema and Data Verification:** To ensure that attestations are correctly submitted and verified, you can use a schema within your smart contract or an off-chain solution that interacts with your contract. This schema would define the necessary data structure for attestations, ensuring that only valid and correctly formatted data is considered for consensus checking.
7. **Ethereum Attestation Service Integration:** Integrating with EAS would provide an additional layer of verification and trust to the attestations, making the process more secure and tamper-proof. This could involve using EAS for verifying the authenticity of the attestations submitted on-chain.
8. **Testing and Optimization:** Before deployment, thorough testing is crucial to ensure that the smart contract correctly handles all scenarios, including different participant numbers, matching and non-matching attestations, and correct token distribution.

Developing such a system requires a good understanding of smart contract programming, typically in Solidity, as well as knowledge of Ethereum's development tools and frameworks. It's also essential to consider gas optimization and security best practices to ensure the system is efficient and secure.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

I have heard that it's possible for the Ethereum attestation service and having attestation there to automatically trigger an event. So would it perhaps make sense if you're making an app to simply put in a Ethereum attestation service kind of action being triggered from the app first, and then that is also an on-chain attestation at the same time, which then triggers another token event where the token is being distributed?

ChatGPT

Yes, using the Ethereum Attestation Service (EAS) as a trigger for on-chain events, including token distribution, is a viable approach, especially in applications where trust and verification of data or actions are crucial. Here's how this could work in the context of your application:

1. **Attestation as a Trigger:** When a participant in your app performs a specific action that requires consensus (like making a decision in a game), this action is attested through the EAS. This means that the participant's action is verified and recorded on the blockchain as an attestation.
2. **Smart Contract Listening for Attestations:** You would have a smart contract on the Ethereum blockchain designed to listen for these specific attestations. This can be achieved through event listeners or oracles that monitor the EAS for attestations matching certain criteria (e.g., related to a particular game instance).
3. **Verifying Consensus:** Once an attestation is detected, the smart contract checks if it meets the consensus requirement (for example, if 66% of participants have made similar attestations). This involves comparing the newly received attestation against others related to the same game instance.
4. **Triggering Token Distribution:** If the consensus requirement is met, the smart contract then automatically triggers a token distribution event. This could involve minting new tokens or transferring existing tokens to the wallets of the participants who were part of the consensus.
5. **Flexibility and Scalability:** By using EAS and smart contracts in this way, you add a layer of flexibility and scalability to your app. Attestations provide a secure and verifiable way to capture actions or decisions on the blockchain, while smart contracts allow for automatic execution of predefined logic (like token distribution) based on those attestations.
6. **Security and Transparency:** This approach also enhances the security and transparency of the consensus and reward process. Since attestations and smart contract executions are recorded on the blockchain, they are immutable and publicly verifiable, reducing the risk of fraud or disputes.

Implementing this design would require careful planning, especially around the structure of attestations, the logic for detecting and verifying consensus, and the mechanics of the token distribution event. It also necessitates a solid understanding of the Ethereum Attestation Service, smart contract development, and possibly external services or oracles for monitoring attestations. Lastly, considering the user experience and gas costs associated with blockchain transactions is crucial for ensuring the application is practical and user-friendly.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Okay, so I have another question now about how the EAS would be integrated into the app. Like, is it possible to program a Bluetooth mounted app to automatically do a preset attestation with the EAS? And can you also have some customizability there? Like, for example, is it possible, like, say, if you wanted to have it where it created a NFT with a picture automatically, then would that be possible to include the picture in the attestation, or would it create a token that creates the picture? And then could you create an app that has a flow where people are automatically making an attestation while also generating an on-chain attestation? And then from there, they get a token, and they can configure that token with a picture of their choosing. And then another question, too, is could you embed some sort of feed of the Ethereum attestation service that only includes a certain filter? Like, for example, from a certain smart contract or from a certain person, if this game was played, then could you just filter it by that and have a search ability embedded into the website? And then could you make it very easy for people to give their tokens to different people who had played these games or different communities that had played these games and do that all within the app? And then lastly, if you did that, would there be any risk of spam of people misusing this, especially if there are very low fees about sending each other soulbound tokens and attestations and so forth if they didn't want that? And then if so, what would be the safeguards against that? Is it possible to turn on a kind of a shield or close the door for an account owner to say, no, I don't accept those tokens? Or is it possible for somebody to delete a soulbound token if it gets sent to their account, or is it possible for them to only filter that and have some way to get rid of some tokens they don't want if they are soulbound tokens?

1 / 2

ChatGPT

Integrating the Ethereum Attestation Service (EAS) into an app, particularly for Bluetooth-mounted devices, and handling customizations such as NFT creation with pictures, involves several layers of functionality. Let's break down your queries to address them effectively:

### **Bluetooth Device Integration and Automatic Attestations**

Yes, it's possible to program a Bluetooth-enabled app to automatically perform attestations with the EAS. This could involve the app detecting specific conditions or actions, then triggering an attestation process. Customizability is key here, so you could design the app to allow users to set the conditions under which attestations are made.

### **NFT Creation with Custom Pictures**

For the creation of an NFT with a custom picture:

- The attestation itself could reference data or a hash of the picture, indicating that the action (or condition met) involves this specific image.
- To create an NFT, you'd typically store the picture on a decentralized storage solution (like IPFS) and then mint an NFT that points to this picture's location. The NFT minting could be the result of a successful attestation, with the smart contract handling the NFT creation process once the attestation criteria are met.

### **App Flow for Attestation and Token Configuration**

Designing an app flow where users make an attestation, trigger on-chain actions, and then receive a token they can configure with a picture is feasible. The app would guide users through the attestation, possibly including uploading a picture for NFT creation. Upon successful attestation and verification, a smart contract could mint an NFT with the provided image, associating it with the user's account.

### **Ethereum Attestation Service**

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Please provide an overview of features and a comparison of features and a contrast of features between Manifold.xyz and MintKnight. I'm particularly interested in minting ERC-1155 tokens and I'm curious as well if they have the following features. Can they be a kind of a proxy contract where the creator of the token could be able to revoke it if they want or change it if they want afterwards so it would be mutable or can you make it immutable as well? And then also can you make it so that it is a soulbound token as well and could you also program it such that it is a soulbound token but the owner could burn it or remove it if they want as well or delete it as well so does it have those functionalities to be able to make the token soulbound and deletable and then as far as both of these could both of these have open source code that could be easily built into another application's interface so that you could use that app's functionalities but basically put the buttons on your own website so that would happen and then I'll leave it at that for now.

ChatGPT

Manifold.xyz and MintKnight are platforms that cater to creators and developers in the NFT space, but each has distinct features and offerings. I'll focus on Manifold.xyz for now, as I didn't find specific details on MintKnight in my recent search.

### **Manifold.xyz Features:**

- **Creator Empowerment**: Manifold.xyz empowers digital creators with tools and applications, enabling them to create innovative NFT experiences for their audiences ([Manifold](https://manifold.xyz/)).
- **No Code NFTs**: It offers a no-code solution for creating and minting NFTs, making it accessible for creators without technical backgrounds ([NFT Evening](https://nftevening.com/manifold-studio-guide-from-no-code-nfts-to-open-edition-nft-minting/)) ([Changelly](https://changelly.com/blog/manifold-nft/)).
- **Smart Contract Customization**: Creators have complete control over their smart contracts after deployment, allowing for the minting of both ERC-721 and ERC-1155 tokens ([NFT Evening](https://nftevening.com/manifold-studio-guide-from-no-code-nfts-to-open-edition-nft-minting/)). The platform supports high-resolution video and images for NFTs and offers compatibility with major NFT marketplaces ([Changelly](https://changelly.com/blog/manifold-nft/)).
- **Extension Framework**: Manifold includes an extension framework enabling creators to enhance their creator contracts with various blockchain apps. This framework supports functionalities like open editions, burn-to-redeem, and custom galleries or marketplaces ([NFT Evening](https://nftevening.com/manifold-studio-guide-from-no-code-nfts-to-open-edition-nft-minting/)).

### **Regarding Your Specific Queries:**

- **Proxy Contract for Revocation or Modification**: While Manifold allows creators to have control over their smart contracts, the specific ability to revoke or change tokens post-minting would depend on how the smart contract is set up. The flexibility exists, but implementing such features would require careful planning during the contract creation phase.
- **Mutable vs. Immutable Tokens**: The mutability of tokens (whether they can be changed after being created) is a feature that can be coded into the smart contract. Manifold.xyz provides the foundation for creating custom smart contracts, which could include mutable or immutable characteristics based on the creator's requirements.
- **Soulbound Tokens**: The concept of soulbound tokens (non-transferable tokens) and allowing the owner the option to burn or delete them is something that can be implemented through smart contract logic. Although Manifold.xyz supports a wide range of functionalities through its extension framework, the creation of soulbound tokens with specific conditions like deletion by the owner would require custom smart contract coding.
- **Open Source and Integration**: Manifold.xyz is designed to be accessible and supports integration with other applications. While the specifics of using its codebase directly on another website weren't detailed in the information I found, Manifold does offer APIs and widgets that can likely facilitate such integrations for creating custom NFT experiences ([Manifold](https://manifold.xyz/)).

### **Safeguards Against Spam and Unwanted Tokens:**

The issues of spam and handling unwanted tokens, including soulbound tokens, are broader blockchain concerns. Solutions typically involve smart contract mechanisms for token management, like enabling token burning or specifying conditions under which tokens can be returned or deleted. Implementing a "shield" or opt-out feature for receiving tokens would be an innovative feature but is not standard in most platforms. The feasibility of such features would again depend on the smart contract's design and the blockchain network's capabilities.

In conclusion, while Manifold.xyz offers a robust platform for NFT creation and customization, including ERC-1155 tokens, achieving specific functionalities like mutable tokens, soulbound tokens with burn options, and seamless app integration requires detailed smart contract programming. As for MintKnight, without direct information, it's challenging to compare the two on these specific features.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Thank you. Can you please tell me more about the plugin capabilities, or I think you mentioned widget capabilities, actually. So how do those work, and do those require custom coding, and could you use those to embed a kind of creation tool on your site? And then also, are there any tools that work with Manifold or other tools in the space that can allow people to create something right in the app? For example, have a simple kind of image editor where people could add a GIF, or add text and stylize text, and also add a picture, or perhaps write something with a paintbrush, something like some small open source tool that might work with Manifold for being able to create visual art very quickly. And then also, is it possible with Manifold to program a specific amount of the NFTs that would be created, basically, when somebody hits a button in the website, so it creates, say, 50 of them, and 30 of them, and 20 of them, and so forth, and that's all pre-programmed to the user. And then also, another question I have, too, regarding the Ethereum attestation service, is whether you can make it so that you can pre-fill the Ethereum attestation service.

ChatGPT

Manifold.xyz provides several widget capabilities that you can integrate into your website to add web3 functionality easily. These widgets include options for wallet connections, campaign management, and NFT information retrieval, among others. To use them, you simply need to install the corresponding widget's JavaScript and CSS in the **`<head>`** component of your site and place **`<div>`** blocks with specific properties in the **`<body>`** of your site. The widgets are designed to be fully customizable to match your website's look and feel, allowing for a seamless integration of Manifold's web3 functionalities into your digital space ([Welcome! | Welcome | Manifold Docs](https://docs.manifold.xyz/v/manifold-for-developers/resources/widgets)) ([Welcome! | Welcome | Manifold Docs](https://docs.manifold.xyz/v/manifold-for-developers/developer-widgets/connect-widget)) ([Welcome! | Welcome | Manifold Docs](https://docs.manifold.xyz/v/manifold-for-developers/resources/widgets/campaign-widget)).

For creators looking to add creation tools to their app or website, such as a simple image editor where users can add GIFs, stylize text, or draw with a paintbrush, you might need to look beyond what Manifold offers directly. While Manifold focuses on the minting, managing, and selling of NFTs, integrating an image editor would require third-party tools or custom development. You would then use Manifold to mint the created artwork as NFTs.

Regarding the functionality to pre-program a specific amount of NFTs to be created upon an action, such as hitting a button on the website, Manifold’s platform supports the creation of ERC721 and ERC1155 tokens, which could potentially include batch minting capabilities. This, however, would depend on the specifics of how your smart contract is set up and may require custom smart contract programming to achieve the desired functionality.

For integrating with the Ethereum Attestation Service (EAS) and pre-filling data for attestations, Manifold's widgets and API could potentially be used to interact with Ethereum for various purposes, including NFT creation and management. However, specific integration with EAS for pre-filling attestations would likely require additional custom development and direct interaction with the Ethereum blockchain and EAS APIs. Manifold provides a robust foundation for NFT and blockchain-related functionalities, but achieving highly specific workflows like this would necessitate a deeper dive into smart contracts and blockchain interactions.

In summary, Manifold.xyz offers powerful tools and widgets for integrating web3 functionalities into your website, with extensive customization options to match your site's design. While creating visual art directly on the platform might require external tools, Manifold facilitates the minting and management of these creations as NFTs. For specific needs like batch minting or integrating with the Ethereum Attestation Service, additional custom development may be necessary.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Thank you. Can you please tell me more about the plugin capabilities, or I think you mentioned widget capabilities, actually. So how do those work, and do those require custom coding, and could you use those to embed a kind of creation tool on your site? And then also, are there any tools that work with Manifold or other tools in the space that can allow people to create something right in the app? For example, have a simple kind of image editor where people could add a GIF, or add text and stylize text, and also add a picture, or perhaps write something with a paintbrush, something like some small open source tool that might work with Manifold for being able to create visual art very quickly. And then also, is it possible with Manifold to program a specific amount of the NFTs that would be created, basically, when somebody hits a button in the website, so it creates, say, 50 of them, and 30 of them, and 20 of them, and so forth, and that's all pre-programmed to the user. And then also, another question I have, too, regarding the Ethereum attestation service, is whether you can make it so that you can pre-fill the Ethereum attestation service.

ChatGPT

Manifold.xyz offers widget capabilities that simplify integrating web3 functionalities into your website, which can include wallet connections, displaying NFTs, and more. These widgets are designed to be easily embedded within your site without extensive coding knowledge. Essentially, you add specific JavaScript and CSS files to your webpage and use **`<div>`** elements with particular properties to place the widgets. This approach offers a no-code or low-code solution for adding complex blockchain interactions to your website ([Welcome! | Welcome | Manifold Docs](https://docs.manifold.xyz/v/manifold-for-developers/resources/widgets)) ([Welcome! | Welcome | Manifold Docs](https://docs.manifold.xyz/v/manifold-for-developers/developer-widgets/connect-widget)).

For more advanced or custom functionalities, such as

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Thank you. Can you please tell me more about the plugin capabilities, or I think you mentioned widget capabilities, actually. So how do those work, and do those require custom coding, and could you use those to embed a kind of creation tool on your site? And then also, are there any tools that work with Manifold or other tools in the space that can allow people to create something right in the app? For example, have a simple kind of image editor where people could add a GIF, or add text and stylize text, and also add a picture, or perhaps write something with a paintbrush, something like some small open source tool that might work with Manifold for being able to create visual art very quickly. And then also, is it possible with Manifold to program a specific amount of the NFTs that would be created, basically, when somebody hits a button in the website, so it creates, say, 50 of them, and 30 of them, and 20 of them, and so forth, and that's all pre-programmed to the user. And then also, another question I have, too, regarding the Ethereum attestation service, is whether you can make it so that you can pre-fill the Ethereum attestation service.

ChatGPT

Manifold.xyz's widget capabilities are designed to integrate web3 functionalities into your website without requiring extensive blockchain knowledge or advanced programming skills. These widgets can facilitate a range of actions, such as connecting a wallet, displaying NFTs, or managing token-gated content. They work by embedding a piece of JavaScript and corresponding CSS into your website, enabling the widgets to interact with Ethereum blockchain functionalities in a user-friendly manner. While the installation and basic customization of these widgets can be straightforward, leveraging them for complex functionalities or integrating them into custom user flows might require some programming knowledge ([Welcome! | Welcome | Manifold Docs](https://docs.manifold.xyz/v/manifold-for-developers/resources/widgets)) ([Welcome! | Welcome | Manifold Docs](https://docs.manifold.xyz/v/manifold-for-developers/developer-widgets/connect-widget)).

Regarding the creation of visual art directly within an app or website, Manifold.xyz itself does not provide built-in tools like an image editor for adding GIFs, text, or drawing with a paintbrush. However, you could integrate third-party open-source image editing libraries into your project to enable these functionalities. After users create their artwork using these tools, you can then utilize Manifold.xyz's capabilities to mint the artwork as NFTs. Integrating such tools would require some custom coding, especially to ensure a seamless experience from creation to NFT minting.

For programmatically creating a specific number of NFTs upon a user action (like hitting a button), Manifold.xyz supports the minting of both unique (ERC-721) and multiple edition (ERC-1155) tokens. While Manifold provides the infrastructure for minting and managing these tokens, implementing a feature that automatically mints a predetermined number of tokens based on user interaction would involve custom smart contract development. This functionality would rely on your smart contract's logic to define how many tokens should be minted in response to specific triggers on your website.

As for integrating with the Ethereum Attestation Service (EAS) to pre-fill attestations, this would again require custom development. Manifold.xyz's focus is on NFT creation and management, and specific interactions with EAS or automating attestations based on predefined criteria would involve directly interacting with Ethereum smart contracts and possibly developing a custom backend service that handles these operations based on the triggers or conditions you define.

In conclusion, while Manifold.xyz offers robust tools for NFT minting and management, extending its functionalities to include custom creation tools, batch minting based on user actions, or integrating with services like the Ethereum Attestation Service would require additional programming work. This might involve both frontend developments, such as integrating image editing tools, and backend development for managing smart contract interactions and blockchain data.