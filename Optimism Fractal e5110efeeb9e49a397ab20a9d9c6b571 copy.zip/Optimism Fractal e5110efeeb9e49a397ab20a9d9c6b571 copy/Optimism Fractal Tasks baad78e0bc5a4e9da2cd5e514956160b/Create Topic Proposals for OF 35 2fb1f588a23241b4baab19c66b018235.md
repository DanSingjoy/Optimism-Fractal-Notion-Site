# Create Topic Proposals for OF 35

Assignee: Dan Singjoy
Project: Prepare for OF 35 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2035%2043a435f5f5aa4de28b4fcfeb7673cd2a.md)
Status: Not started
Task Summary: This task aims to create topic proposals for the upcoming Optimism Town Hall event. These proposals will focus on enhancing Optimism Fractal's initiatives, including social media strategies, video production, and mission requests aimed at fostering community engagement and collaboration within the Optimism ecosystem.
Summary: Dan Singjoy has created three topic proposals for the upcoming Optimism Town Hall: Optimism Mission Requests, Optimism Fractal Video Production, and Optimism Fractal Social Media. Each proposal focuses on enhancing community engagement, collaborative media creation, and developing onchain social games to benefit the Optimism Collective. The proposals aim to explore the potential of social media platforms, video production improvements, and mission requests that require additional votes for approval.
Created time: July 17, 2024 5:18 PM
Last edited time: September 25, 2024 1:57 PM
Created by: Dan Singjoy
Description: Dan Singjoy has created three topic proposals for the upcoming Optimism Town Hall: Optimism Mission Requests, Optimism Fractal Video Production, and Optimism Fractal Social Media. The proposals aim to enhance collaborative media creation, explore social media potential, and develop onchain social games and educational programs to benefit the Optimism Collective and Superchain. Each Mission Request requires additional votes for approval, and discussions will take place at the event.

## Discord announcement

I just created the following three topic proposals for tomorrow’s Optimism Town Hall event:

**🔴 [Optimism Mission Requests](https://snapshot.org/#/optimismtownhall.eth/proposal/0xff4ff6c84605bc02a0e7f22e96c94419acf9859d89ab35514cf9a050a6925956)**

**🎥 [Optimism Fractal Video Production](https://snapshot.org/#/optimismtownhall.eth/proposal/0xf61c19fb7051833e6c85bb32786802d10b23d13585e6eb4a85463582a8669b07)**

**🔊 [Optimism Fractal Social Media](https://snapshot.org/#/optimismtownhall.eth/proposal/0xed9c82f2e1dfb15c615f73f0fc2220c216ef04b8ed51d67204d7d3059c1143aa)**

## 🌐 Fractal Social Media

How can Optimism Fractal enhance social media?

Upvote this topic to explore the rich history of fractal social platforms, plans for an Optimism Fractal social media app, the potential for Respect on protocols like Farcaster and Lens, and how the Respect Game can empower the future of onchain social media networks. 

I recently created project with more details about Optimism Fractal social media, which you can see [here](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md).

![edencreators_phone_screen_with_sunflowers_below_it_and_the_sky__f65f19e7-0992-4e94-a781-1347d8f2b9e2.png](Create%20Topic%20Proposals%20for%20OF%2035%202fb1f588a23241b4baab19c66b018235/edencreators_phone_screen_with_sunflowers_below_it_and_the_sky__f65f19e7-0992-4e94-a781-1347d8f2b9e2.png)

## Optimism Fractal Builder Profiles

Upvote this topic to explore how the Respect Game at Optimism Fractal can enable a new kind social network, collaborative blog, and directory for builders on Optimism. You can explore this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Builders%20Site%20b2364cd97d724ac78f2b7f30c2f476c2.md) and see this [task](Plan%20and%20discuss%20ideas%20for%20Networking%20Site%20with%20Op%2010c074f5adac809ead27dc395e772369.md) to learn more about the work underway for Optimism Fractal Builder Profiles.

## 🎥 Optimism Fractal Videos

### **Lights, Camera, Action!**

Optimism Fractal provides a powerful new way to collaboratively create videos together. The Respect Game provides an innovative, spectacular way for communities to collaborate to make awesome media and legendary stories. Our shows and tools give you the opportunity to join the stage, share your thoughts, and play your part in the greatest stories of all time.

Upvote to discuss our plans for improving video production at Optimism Fractal, how our videos can provide more value for Superchain Builders, and the wonderful potential for the Respect Game to benefit creators throughout society. You can watch videos of each event at [OptimismFractal.com/videos](http://OptimismFractal.com/videos) and explore this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Optimism%20Fractal%20video%20production%20processe%201ddaaa3c112a4449ab121ec9df944d9e.md) to learn more about how Optimism Fractal can revolutionize collaborative media creation. 

![optimystics videos.webp](Create%20Topic%20Proposals%20for%20OF%2035%202fb1f588a23241b4baab19c66b018235/optimystics_videos.webp)

## Optimism Mission Requests

After discussing Mission Requests at the past few events, I’m excited to share a few Mission Requests that I created in Optimism Season 6:

[Develop Onchain Social Games that attract Builders to Optimism](https://gov.optimism.io/t/mission-request-v2-develop-onchain-social-games-that-attract-builders-to-optimism/8547)

[Create Educational Programs that Empower Developers on Optimism](https://gov.optimism.io/t/mission-request-create-educational-programs-that-empower-developers-on-optimism-modified-with-lower-budget/8553) 

[Create and Distribute Videos about Optimism Collective Governance](https://gov.optimism.io/t/mission-request-create-and-distribute-videos-about-optimism-collective-governance/8544)

Each of these Mission Requests are designed to help Optimism Fractal grow and create a more positive impact for the Optimism Collective and Superchain. You can learn more about these Mission Requests in the links above and also see this [post](https://gov.optimism.io/t/mission-request-develop-onchain-social-games-that-attract-builders-to-optimism/8526/7?u=dansingjoy) for more details about why the first Mission Request can be so helpful for Optimism (which also partly applies to the other two Mission Requests as it includes a detailed section about Optimism Fractal).

The first Mission Request about developing onchain social games has reached the quorum and the other two Mission Requests need an additional 2-4 million OP votes from Optimism Delegates in order to be approved by the Token House. I plan to apply for each of these Mission Requests in the coming weeks and it would be great for all of them to be approved so that they each could benefit Optimism Fractal, the Collective, and the Superchain in different ways. In the near future, I also plan to request additional budget allocations for each of these Mission Requests.

### More Details

For anyone who missed our prior discussions about Mission Requests and would like to learn more, you can watch the Optimism Town Hall episode where we spoke about Optimism Season 6 in this [video](https://youtu.be/d8QCL5b4aoU?si=8C9DgIBeaHB4TNt7&t=3724) and explore more in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md).

In addition you can also see more of our discussions about Missions related to Optimism Fractal during our past two events, which you can find by exploring the timestamps or transcripts of the episodes. For convenience, I also curated some timestamps of discussions about the Missions that we’re planning, which you can find in our 34th episode ([1](https://www.youtube.com/watch?v=F9nwIxjoIts&t=2225s) and [2](https://youtu.be/F9nwIxjoIts?si=MiFyiFkriO4I7cCs&t=6067)) and 33rd episode ([1](https://www.youtube.com/watch?v=F9nwIxjoIts&t=2225s) and [2](https://www.youtube.com/watch?v=xwyjJnqdkrQ&t=4013s)).

I’ll propose these Missions as a topic for discussion at tomorrow’s Optimism Town Hall event tomorrow where we can discuss these in more detail if the community would like. Looking forward to seeing you all at the events tomorrow!

![optimism fractal 32 v2 thumbnail final copy 2.png](Create%20Topic%20Proposals%20for%20OF%2035%202fb1f588a23241b4baab19c66b018235/optimism_fractal_32_v2_thumbnail_final_copy_2.png)