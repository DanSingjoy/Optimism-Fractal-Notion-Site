# Explore Neynar - seems super helpful for integrating with Farcaster . Listen to podcast, ask chatgpt, and check out the demo

Project: Explore and Create Integrations between Farcaster and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20between%20Farcaster%20%206d0a962a29a74d0e81ac169464abe21d.md)
Status: Not started
Summary: Explore Neynar, a platform that helps integrate with Farcaster. Features include listening to a podcast, asking ChatGPT, checking out the demo, and using the Frame Studio for building multi-step frames. Neynar offers APIs, hosted databases, and community-built developer tools. Testimonials from users highlight the ease of use and reliability of Neynar. Pricing plans are available starting from $9/month.
Created time: February 11, 2024 8:15 PM
Last edited time: March 12, 2024 5:56 PM
Created by: Dan Singjoy

[https://neynar.com/](https://neynar.com/)

[https://warpcast.com/rish/0x8868e5cd](https://warpcast.com/rish/0x8868e5cd)

The easiest way to build on Farcaster

We helped 300+ developers and companies bring their vision to life. Get started today from $9 / month.

[Get Started](https://neynar.com/#get-started)

Introducing

Frame Studio

Beta

No-code, multi-step frame builder with templates for galleries, memes & product checkout flows

[Try it now](https://neynar.com/#get-started)

Road-tested

We're the magic behind the scenes

Supercast

Launchcaster

[Hear it from them:](https://neynar.com/#testimonials)

Introducing

Sign in with Neynar

Connect Farcaster accounts with write access for free, 10x your conversions

![Explore%20Neynar%20-%20seems%20super%20helpful%20for%20integrati%20362f8ea8b59848dfa91559fc2cd872b3/KdcnyNt4d3GRo0wasGbjyhHvC5s.png](Explore%20Neynar%20-%20seems%20super%20helpful%20for%20integrati%20362f8ea8b59848dfa91559fc2cd872b3/KdcnyNt4d3GRo0wasGbjyhHvC5s.png)

[Check out our demo →](https://demo.neynar.com/)

Everything you need to start building on Farcaster

We've got you covered

v9NDvCmSCYT7HrluIdM2N4ytoL7mvSO1at2ZsMlcfC9SV0w6jnVMB6OUuocmfkIc

**/user/{fid}**

**/verification/{fid}**

**/cast/{hash}**

Full suite of read and write APIs for easier application development

APIs

[Read more →](https://docs.neynar.com/reference/neynar-farcaster-api-overview)

[Get raw data from hubs directly without needing to set up your own](https://neynar.com/#get-started)

[Hubs](https://neynar.com/#get-started)

[Get started](https://neynar.com/#get-started)

```
// npm i @neynar/nodejs-sdk
import { NeynarAPIClient, FeedType, FilterType } from "@neynar/nodejs-sdk";

// make sure to set your NEYNAR_API_KEY .env
// don't have an API key yet? get one at neynar.com
const client = new NeynarAPIClient(process.env.NEYNAR_API_KEY);

```

**User info from .eth**

**Cast info from URL**

**Mutual follows**

**Trending casts**

**Casts from /memes**

SDKs to use our APIs as simple functions in your codebase

Hosted Postgres SQL databases for Farcaster data

Database

[Get started](https://neynar.com/#get-started)

Community built developer tools on Neynar

Ecosystem

[Read more →](https://docs.neynar.com/docs/neynar-developer-ecosystem-for-farcaster)

![Explore%20Neynar%20-%20seems%20super%20helpful%20for%20integrati%20362f8ea8b59848dfa91559fc2cd872b3/IuYmofaVeLX1tC3OGsJvGZqiCRE.svg](Explore%20Neynar%20-%20seems%20super%20helpful%20for%20integrati%20362f8ea8b59848dfa91559fc2cd872b3/IuYmofaVeLX1tC3OGsJvGZqiCRE.svg)

Write queries, publish dashboards with zero setup

Don't just take

our word for it

### Jordan

onceupon.gg

Neynar made it fast and seamless to spin up a hub, allowing our team to focus on building and not worry about managing infrastructure.

### Jayme

Launcher

If you're building something Farcaster-related into your app, check out Neynar.

Loving that @launch can rely on them for hubs/apis while we work on other stuff.

It just works, and @rish @manan keep shipping more features 🙏

### Brian

frens.lol

Neynar enabled us to seamlessly work with core Warpcast APIs without having to learn complex auth flows or data architecture.

As social protocols evolve, it's awesome to have a reliable source of data that doesn't break our application.

Questions?

Reach out anytime on [Warpcast](https://warpcast.com/rish) or [Telegram](https://t.me/rishdoteth).

Builder-friendly pricing

Starter

$

9

/ month

Frame Studio

1 read-only hub

Read APIs, 25k reads / mo

Sign In with Neynar (SIWN) for 1 bot

Write APIs, 1k writes / mo for 1 bot

100 webhook events / mo

Hosted SQL db and playground, 250 queries/mo

Email support

Subscribe

Growth

$

49

/ month

Frame Studio

1 read-write hub

Read APIs, 100k reads / mo

Sign In with Neynar (SIWN) for unlimited users

Write APIs, 5k writes / mo

500 webhook events / mo

Hosted SQL db and playground, 2.5k requests/mo

Email & telegram support

Subscribe

Enterprise

Reach out

Frame Studio

Multiple globally distributed hubs

Read APIs

Write APIs

Sign In with Neynar (SIWN)

Dedicated managed signers

Hosted SQL db and playground

Custom tables, data export

Email, telegram & call support

[Contact us](mailto:team@neynar.com)

Save hours of work

…and hundreds of dollars a month

Build your own

Neynar

Set up your own hub

Set up Optimism node

Upgrade and maintain your hub

Build APIs to read and write

Manage signers for users

Build your product

Sign up for Neynar

Build your product

Backed by the best

- HYPERSPHERE
- Social Graph Ventures
- HYPERSPHERE
- Social Graph Ventures
- HYPERSPHERE
- Social Graph Ventures
- HYPERSPHERE
- Social Graph Ventures

# Get building, anon

Get started today **from $9/month**