# Message Zaal March 26th about ZAO discussions at Optimism Fractal

Assignee: Dan Singjoy
Project: Explore opportunities for collaboration and community engagement to expand our reach, educate about Optimism Fractal, and promote the Respect Game   (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20opportunities%20for%20collaboration%20and%20commun%20dc057e22dba746aeab00fce108cd9a9a.md)
Status: Done
Task Summary: This task aims to summarize the message sent by Zaal on March 26th regarding discussions about ZAO at Optimism Fractal. The message includes plans for creating new consensus games, implementing the Respect Game with musicians, and exploring new forms of awards. The summary provides an overview of the content and invites further discussion on the proposed topics.
Summary: This document is a message discussing the topic of creating new consensus games, giving new forms of awards, and implementing the Respect Game with musicians. The message includes a video clip and proposes discussing the topic during a planning session. It also mentions a canceled tokenomics call and offers to discuss the topic with Zaal before or after the event.
Created time: March 26, 2024 12:27 PM
Last edited time: May 6, 2024 4:45 AM
Created by: Dan Singjoy

## Description

## Discord Chat

## Review Ideas about Personal Respect, Community Member Hosted Respect Games, and Optimism Fractal Referral System inspired by Zaal

Last week @Zaal said that he’d like to discuss a topic at this week’s event related to creating new consensus games, giving new forms of awards, and implementing the Respect Game with musicians. Here is the video [clip](https://youtu.be/Jdm9GKzFoiU?si=9uij7y9tekmqsaff&t=3679). 

I think this is a fascinating topic and propose that we discuss it during this week’s planning session. Zaal, feel free to let us know if there’s anything in particular that you’d like us to discuss or organize in the agenda.

## Review Ideas about Respect Network, Community Member Hosted Respect Games, and Optimism Fractal Referral System

[1:01:27](https://youtu.be/Jdm9GKzFoiU?si=9uij7y9tekmqsaff&t=3679) Zaal comments that he’s trying to implement something like respect game on weekly zooms, talks about creating new consensus games, interested in this or other ways to play this with musicians. 

Last week @Zaal said that he’d like to discuss a topic at this week’s event related to creating new consensus games, giving new forms of awards, and implementing the Respect Game with musicians. Here is the video [clip](https://youtu.be/Jdm9GKzFoiU?si=9uij7y9tekmqsaff&t=3679). 

- I can see potential for Optimism Fractal to award Respect or some other token for people hosting their own respect games

- Similar to our prior discussions about referral systems, but also for people who play the respect game with their friends, community, or organization. I’m curious to hear your thoughts about this and explore how such a system could be designed.

## Idea for Referral System with Network of Respect

I had idea about how a hat could be given to people who have earned enough respect, then there could be a pool of respect each week to people who host respect games . 

Maybe a certain limit of how many games you can host or people you can invite per week. Maybe this somehow synergize with Optimystics respect game too and gives more incentive for us to reach consensus. It could synergize very nicely with the release of the new app and basically respect people who are playing it with their communities and spreading it. 

There could also be some fractal respecting happening, for example If zaal host a game in zao with attabotty then attabotty hosts game with another community then maybe it makes sense for zaal to get a portion of recruitment respect that attabotty earns from hosting a game with his other community

Maybe a certain limit of how many games you can host or people you can invite per week. Maybe this somehow synergize with Optimystics respect game too and gives more incentive for us to reach consensus. It could synergize very nicely with the release of the new app and basically respect people who are playing it with their communities and spreading it. 

There could also be some fractal respecting happening, for example If zaal host a game in zao with attabotty then attabotty hosts game with another community then maybe it makes sense for zaal to get a portion of recruitment respect that attabotty earns from hosting a game with his other community

I have idea about how a hat could be given to people who have earned enough respect, then there could be a pool of respect each week to people who host respect games. 

## PM Zaal

Hey Zaal, I tried joining the tokenomics call today but saw it was cancelled. I meant to tell you last week that I usually have a meeting at the same time, but will try to join the tokenomics session halfway through next week if it’s happening.

Let me know if you’d like to discuss anything related to your topic before or after this week’s event. I remember you suggested meeting beforehand to create a proposal and I was planning to message you sooner but didn’t get a chance. I listened to the recording of last week’s event again and got very inspired by your ideas about new consensus games, forms of respect for implementing the respect game, and collaborating with musicians. I’d be happy to discuss this and can imagine many exciting opportunities along these lines :)

- [ ]  he mentioned meeting up to discuss it before the proposal- let me know if you’d like to discuss it sometime this week before making the proposal
    - [ ]  also [Let Zaal know if i can attend the tokenomic design session](https://www.notion.so/Let-Zaal-know-if-i-can-attend-the-tokenomic-design-session-17be53c8bced4232aa4f33aec27ce077?pvs=21) and [Apply for Attabotty’s form for zao palooza ](https://www.notion.so/Apply-for-Attabotty-s-form-for-zao-palooza-362b3986b69043b4aeb80035982ca143?pvs=21)

- [ ]  consider asking him or mentioning if he wants to make a topic proposal by making a poll in snapshot or if we should just do more casual

Hey all, I hope you’re having a great week and am looking forward to seeing you at our meeting tomorrow!

If you’d like to participate in the next week’s council, please remember to register in this week’s [registration poll](https://snapshot.org/#/optimismfractal.eth/proposal/0x90ace740caaff36826fba604bc11310b37d5bc4076be778471095b801cd35482) before the meeting starts at 17 UTC.

When I message zaal , it may be good to mention that the episode thumbnail etc can be themed related to music and zao. We could also do promotions before hand if we have time, or we can save those for another second conversations in the future . Maybe it’d be good to invite zao people again sometime for these kinds of discussions