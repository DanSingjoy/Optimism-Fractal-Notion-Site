# Organize notes about Submitting Contributions for Hats Community and Starting Async Respect Game

Assignee: Dan Singjoy
Due: July 15, 2024
Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md), Build Optimism Fractal App (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20App%206d7693f1bbc6437d85a0ac991a8416f1.md)
Status: In progress
Task Summary: This task aims to organize notes about submitting contributions for the Hats Community and starting the Async Respect Game. The page includes details about the project, the creator and assignee, and the due date, along with a description of integrating Optimism Fractal with Hats Protocol and the idea of coordinating through a weekly Respect Game.
Summary: This document is about submitting contributions for integrating Optimism Fractal with Hats Protocol and starting an asynchronous Respect Game. It includes tasks to organize notes, review contribution submission and protoREP distribution processes, and a conversation with Hodlon. The document also mentions curating information and asking for permission to share it publicly.
Parent-task: Respond to Spencer about Hats Protocol and Optimism Fractal Updates (Respond%20to%20Spencer%20about%20Hats%20Protocol%20and%20Optimis%20878c493ea73c4f7b859c45845ee9ad19.md)
Created time: April 6, 2024 11:33 PM
Last edited time: June 17, 2024 1:46 PM
Parent task: Consider Ideas for submitting contributions for the Hats Community, Distributing ProtoREP,  and Starting Async Respect Game (Consider%20Ideas%20for%20submitting%20contributions%20for%20th%20f4ee398465ea4c3791c01bfd204dde2e.md)
Created by: Dan Singjoy

## Description

Have you thought more about submitting contributions for integrating Optimism Fractal with Hats Protocol in the upcoming season?

I saw the post in the Hats chat about submitting contributions to Hats Protocol and wrote some notes about what kind of contributions might be good to submit below. I started wondering if we should try doing a weekly Respect Game (perhaps asynchronously) to coordinate integrations with Optimism Fractal and distribute ProtoREP amongst contributors.

## To Do

- [ ]  organize the following notes into tasks in [Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)

- [ ]  organize this note to make it clearer for people who aren’t familiar with the processes and rationale

- [ ]  See more details in [Review and Respond to Hodlon about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer](Review%20and%20Respond%20to%20Hodlon%20about%20Hats%20Contributi%20ede1b147525948b6a4c82818cbf962df.md) and consider asking if he minds if i share it publicly
    - This has the most detailed and up to date conversation about this and is probably good to share most of it if Hodlon is up for it

## Consider Ideas for submitting contributions for the Hats ProtoREP

- Do you think that we submit some of our contributions that we plan to make to the Hats Ecosystem to be eligible for Hats protoREP?
    - I see it says that “Each contribution on this form should be associated with a single contribution. Please submit one form per contribution.”
        - I’m thinking about creating a weekly asynchronous Respect game to facilitate the distribution of protoREP according to the scores in the weekly Respect Games.
            - You can see more ideas about this in the toggle
                - We could also potentially make a proposal to Optimism Fractal council so that some Respect goes to the people who participate in this game as well.
                    - This might be too complex for this season, it may be better to keep respect distribution simple with just people who join events for now and everyone might be sufficiently motivated to make the integrations right now without Respect. And we have a lot of other things to focus on in addition, like retrofunding integrations and etc…
                    - But it also could perhaps be a good way to incentivize and award extra work. Maybe it would be good to give the Hats team Respect so it’s more reciprocal and they’re more aligned and motivated to help OF and etc. It’s worth considering for this season and/or future seasons
                - We could invite me, tadas, vlad, abraham, hodlon, and the hats team and perhaps others like joshua, jake hominax, and anyone who may make a contribution.
                - We could invite anyone to join the games each week perhaps with some promotional posts in the Optimism Fractal and Hats Protocol chats. Would that works?
                - Another idea is that we could keep it small with just 6 people are perhaps grow it to multiple groups, which hasn’t been tried yet in async respect games
                - [ ]  Consider out to best organize this outside of the toggle to make it more visible
                    - [ ]  It’s probably good to create a task with this within [Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
        - I’m wondering if we would just make one contribution like “Integrate Hats Protocol with Optimism Fractal” or if it would be better to make multiple contributions like “Integrate Hats Protocol with the Respect Game app” and “Integrate Hats Protocol Agreement with Optimism Fractal community” and “Build Respect Eligibility Module” and so forth. Do you have any insights or suggestions on the scope of contribution or are there similar example that we should learn from?
    - @hodlon made a quest (link) for integrating Optimism Fractal. Would it be best to make this again?
    - [ ]  consider setting up a 0xsplit account with . maybe a mutable 0xsplit with an msig where we’ll agree to
    - [ ]  consider setting up an asynchronous respect game quest for integrating with optimism fractal

More related ideas:

- [Review and Respond to Hodlon about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer](Review%20and%20Respond%20to%20Hodlon%20about%20Hats%20Contributi%20ede1b147525948b6a4c82818cbf962df.md)
- [Respond to Hodlon about OF 22 and Hats Protocol Contribution Submissions](Respond%20to%20Hodlon%20about%20OF%2022%20and%20Hats%20Protocol%20Co%208628edca8518499b8c50ac86c4bf0f00.md)

## Review the contribution submission and protoREP distribution processes

[https://hatsprotocol.deform.cc/contribution/?page_number=0](https://hatsprotocol.deform.cc/contribution/?page_number=0)

![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled.png)

![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%201.png)

![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%202.png)

![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%203.png)

- [ ]  read the details about Hats Protocol Contribution Submissions, Recognition, and Reputation [https://app.charmverse.io/hats-protocol/page-0225506388762724](https://app.charmverse.io/hats-protocol/page-0225506388762724)

- [ ]  curate the above and following into a task in [Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)

- Screenshots and text from charmverse
    
    
    ![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%204.png)
    
    Overview: How we track and award reputation and voting power in Hats protoDAO
    
    The following two methods will be used to track reputation and provide voting power in Hats protoDAO:
    
    1. **protoRep:** Reputation in Hats protoDAO will be tracked using protoRep, valueless and nontransferrable ERC20 non-voting stake tokens in the Hats protoDAO Moloch v3 contract.
    2. **protoVotes:** protoRep can be converted to protoVotes at a 1:1 ratio by Steward hat-wearers. protoVotes reflect voting power in Hats protoDAO. The moment an address loses its Steward hat, their protoVotes will be converted back to protoRep at a 1:1 ratio. Like protoRep, protoVotes are also valueless and nontransferrable ERC20 tokens in the Hats protoDAO Moloch v3 contract.
    
    ## **protoREP will be awarded in three ways**
    
    ![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%205.png)
    
    - **Stewardship:** distributed to Hats Stewards for their contributions during that season
    - **Contributions:** distributed to contributors based on the value of their contributions as assessed by the protoDAO
    - **Championing:** distributed to those who played a key role in an app's integration of Hats or an organization’s adoption of Hats into their core operations (importantly, champions must not be a member of or paid contributor for the organization in question, as this would create incentive misalignment)
    
    See here for a detailed overview of the protoREP distribution process used in Season 1:
    
    ## Hats protoDAO Reputation
    
    Submitted contributions will be considered for protoDAO reputation points if eligible, with distribution scheduled for the end of each season.
    
    ![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%206.png)
    
    ![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%207.png)
    
    ![Untitled](Organize%20notes%20about%20Submitting%20Contributions%20for%20%207a971c53ac3644179006dfa4c75a4936/Untitled%208.png)
    
    [[https://docs.google.com/spreadsheets/d/1W8lXWijBaEjF50wGpWbhEoyFlzisTT-EqgEs0zA-hPQ/edit#gid=0](https://docs.google.com/spreadsheets/d/1W8lXWijBaEjF50wGpWbhEoyFlzisTT-EqgEs0zA-hPQ/edit#gid=0)](https://docs.google.com/spreadsheets/d/1W8lXWijBaEjF50wGpWbhEoyFlzisTT-EqgEs0zA-hPQ/preview#gid=0)
    

## Conversation with Hodlon

- [ ]  Consider asking Hodlon if we can/should curate some of this in task or subproject in [Integrate with Hats Protocol ](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
    - [Review and Respond to Hodlon about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer](Review%20and%20Respond%20to%20Hodlon%20about%20Hats%20Contributi%20ede1b147525948b6a4c82818cbf962df.md)

Have you thought more about submitting contributions for integrating Optimism Fractal with Hats Protocol in the upcoming season?

I saw the post in the Hats chat about submitting contributions to Hats Protocol earlier today and wrote some notes about what kind of contributions might be good to submit. I started wondering if we should try doing a weekly Respect Game (perhaps asynchronously) to coordinate integrations with Optimism Fractal and distribute ProtoREP amongst contributors. I’m curious if you have ideas about this or other ways to make the most of the opportunity in Season 2 of the Hats Community…