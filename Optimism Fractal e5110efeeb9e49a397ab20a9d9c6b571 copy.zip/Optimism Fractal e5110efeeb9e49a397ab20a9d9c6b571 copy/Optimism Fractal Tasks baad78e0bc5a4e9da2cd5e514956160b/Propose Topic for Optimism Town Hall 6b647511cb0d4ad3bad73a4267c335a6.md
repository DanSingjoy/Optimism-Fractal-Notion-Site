# Propose Topic for Optimism Town Hall

Due: May 3, 2024
Status: Not started
Task Summary: This task aims to propose a topic for the Optimism Town Hall. The proposed topic should be a concise and engaging summary that captures the essence of the discussion to be held during the town hall meeting.
Summary: No content
Created time: May 11, 2024 2:50 AM
Last edited time: May 11, 2024 3:19 AM
Created by: Dan Singjoy

- [Create topics for discussion to propose for Cagendas at Optimism Town Hall](Create%20topics%20for%20discussion%20to%20propose%20for%20Cagend%206ae17a37abe741d79914a64d0aca6ff5.md)

[Untitled](Propose%20Topic%20for%20Optimism%20Town%20Hall%206b647511cb0d4ad3bad73a4267c335a6/Untitled%20413dc924f6fe41c78f7b884465cc3e81.csv)

## Strategy

- [ ]  Propose 1-4 topics every Friday and share the message in the discord

- For each question, I should take extra time and care to prepare a great overview of materials for review
    - I should share this before the event as part of the promotional event as well so people can read up on it and have very informed opinions during the event
    - I should also prepare a nice presentation for each topic that includes all the best resources
    - For example, we can include relevant forum posts, blog posts, metrics garden, tweets, etc to give people a good overview of the discussion and set the stage for a great conversation

- If a topic includes polls where people can vote during the event to help answer a question, then this can be a big value add