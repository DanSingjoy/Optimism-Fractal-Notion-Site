# Set up Automatic Due Dates for Task Templates

Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Not started
Task Summary: This task aims to set up automatic due dates for task templates. The goal is to learn how to configure different due dates for each task that are not the default 'today'. The page provides instructions on how to accomplish this and includes a question about whether Rosmari remembers an easy way to do it.
Summary: To set up automatic due dates for task templates, ask Rosmari for instructions on how to set different due dates for each task. If she doesn't remember, save it for later.
Created time: June 5, 2024 8:57 PM
Last edited time: June 5, 2024 9:01 PM
Created by: Dan Singjoy

- [ ]  Ask Rosmari how to set these up with different due dates for each task that are different than ‘today’
    - Does she remember how to do this easily?
        - If not, then consider just saving this for later