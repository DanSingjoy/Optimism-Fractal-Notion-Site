# Summarize Articles about Optimism Collective Season 6

Assignee: Dan Singjoy
Due: May 23, 2024
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Prepare for OF 27 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20OF%2027%20a3a902d398094d0b826538ac88183391.md)
Status: Done
Task Summary: This task aims to summarize articles and information about Optimism Collective Season 6. It provides an overview of the season, including key initiatives such as Retro Funding rounds, protocol upgrades, and enhanced governance structures. The engagement with Optimism Collective in Season 6 can be achieved through participating in Optimism Town Hall meetings and the Respect Game at Optimism Fractal, where community contributions are recognized and rewarded.
Summary: Optimism Season 6 focuses on refining existing programs and enhancing governance to support the strategic goals of the Optimism Superchain. Engagement can be achieved through participation in the Optimism Town Hall for governance discussions and the Respect Game at Optimism Fractal, where community contributions are ranked and rewarded. The season aims to increase community participation, enhance recognition of valuable contributions, and support the growth and development of the Optimism ecosystem. To engage with Season 6, participate in the Optimism Town Hall, actively contribute to the Respect Game, and support Retro Funding rounds by developing and reviewing proposals.
Created time: May 23, 2024 11:37 AM
Last edited time: May 23, 2024 11:38 AM
Created by: Dan Singjoy

Provide an introduction to Optimism, an overview of Optimism Season 6, and project outline to engage with Optimism Collective Season 6 via Optimism Town Hall and the Respect Game at Optimism Fractal. Create a brief summary of this in 2 paragraphs or less

Recording: [May 14, 2024 S6 AMA and Token House Call.mp4 - Google Drive 6](https://drive.google.com/file/d/1mAWfVMQkG0O_aWdPRtk5ojHuMXhsAgNg/view?usp=sharing)

- [Cycle 22 Final Grants Roundup 1](https://gov.optimism.io/t/cycle-22-final-grants-roundup/8086)
    - Total of 530 mission request applications and 130 finalists.
    - The season is now closed and new applications for season 6 will open on July 18th.
- [Season 6 AMA 4](https://gov.optimism.io/t/season-6-guide-to-season-6/8113)
    - We are currently in Season 6 Reflection Period: Reading Period. The reflection period will last till June 26th, read [Season 6: Reflection Period Guide 1](https://gov.optimism.io/t/season-6-reflection-period-guide/8130) for all dates and details.
    - Season 6 will start on June 27th till December 11th.
    - Seasons are now standardized to be six months long, a six week reflection period and three week voting cycles.
    - Retro Funding rounds 4, 5, 6 and 7 will all take place during season 6 this year.
    - The goal for season 6 is to refine and improve existing programs and structures to support strategic goals for the Superchain.
    - Read the [Season 6: Guide 4](https://gov.optimism.io/t/season-6-guide-to-season-6/8113) to learn more about this season Intents, each intent has a target metric.
    - The process for mission requests will be slightly different in order to make a better experience for builders. [Season 6: Missions v2.5 2](https://gov.optimism.io/t/season-6-missions-v2-5/8106)
    - Grants Council will continue to process applications for grants on
    the OP Mainnet but other OP Chains will also be able to apply to the
    governance fund to request tokens and run their own grants program.
    - There are going to be some small changes based on feedback for the
    Anticapture Commision, resizing from 10M OP to 20M to be delegated
    across different OP Chains and incentivise more participation in
    governance. Read the post [Season 6: Anticapture Commission Amendment 1](https://gov.optimism.io/t/season-6-anticapture-commission-amendment/8124)
    - Anybody who would like to lead a board or a council can put forward a proposal for an operating budget to support that board or council. It
    needs to be posted in the forums and be approved by four top 100
    delegates by May 22nd 19:00 UTC.
    - Use the [Collective Reward Framework 2](https://gov.optimism.io/t/season-6-collective-reward-framework/8112) as a guideline to assess operating budgets for boards and councils. (optional)
    - Protocol upgrades will continue to be voted on during reflection periods.
    - A separate AMA will be hosted the 21st during the community call to
    have the upgrade proposals authors and engineer team walk through those
    protocol upgrades.

# [Season 6: Guide to Season 6](https://gov.optimism.io/t/season-6-guide-to-season-6/8113)

[Governance  Design 📐](https://gov.optimism.io/c/gov-design/84)

[Metagovernance](https://gov.optimism.io/c/gov-design/metagovernance/53)

[season-6](https://gov.optimism.io/tag/season-6)[season-guide](https://gov.optimism.io/tag/season-guide)

May 10

9d

!https://global.discourse-cdn.com/business7/uploads/bc41dd/original/1X/391d6e71a279a9f881f75bfa7df5cdf3cf905b3f.png

[system](https://gov.optimism.io/u/system)

[13d](https://gov.optimism.io/t/season-6-guide-to-season-6/8113?u=dansingjoy)

*Thanks to members of the [Feedback Commission 4](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863) for providing input and feedback on Season 6 drafts.*

# Guide to Season 6

!https://emoji.discourse-cdn.com/twitter/tada.png?v=12

---

**Season 6 begins on June 27th and runs through December 11th. 
Grant applications open on July 18th and run every 3 weeks through 
December. You can find all dates on the [public governance calendar 7](https://calendar.google.com/calendar/embed?src=c_4hui70itm089e7t8q50heh1kno%40group.calendar.google.com&ctz=Europe%2FBerlin).**

**All details about what happens between now and then are in the [Reflection Period Voting Guide](https://gov.optimism.io/t/season-6-voting-guide/8130).**

Don’t want to read? Watch the [Season 6 Overview 4](https://drive.google.com/file/d/1mAWfVMQkG0O_aWdPRtk5ojHuMXhsAgNg/view) from the Token House Community Call on 5/14.

**Time stamps**

06:50 - Lavande gives S6 overview

28:55 - Ben gives overview of Blockspace Charter Framework

52:32 - Brief Q&A at the end

---

## Acknowledging Season 5 Contributions

Delegates are rewarded retroactively for their participation in the Token House. You can find retro rewards for Season 5 [here 16](https://gov.optimism.io/t/season-5-retro-governance-participation-rewards/8105). Rewards are made in accordance with a new [Collective Rewards Framework 7](https://gov.optimism.io/t/season-6-collective-reward-framework/8112), which is the first step in transitioning this responsibility to a Budget Board, likely to be elected in Season 7.

---

## How did we get here? Seasons 1 - 5

- **Season 1 Theme:** Genesis and unstructured community grants
- **[Season 2 Theme: 2](https://gov.optimism.io/t/committees-next-steps-for-season-2/3436)** Establishing structure with grant committees
- **[Season 3 Theme: 1](https://gov.optimism.io/t/guide-to-season-3-course-correcting/3942)** Refining structure with the Grants Council
- **[Season 4 Theme:](https://gov.optimism.io/t/guide-to-season-4-as-a-collective/5886)** Working as a Collective (Introduction of Missions, Intents, and Trust Tiers)
- **[Season 5 Theme: 1](https://gov.optimism.io/t/guide-to-season-5/6894)** Governance resiliency (Introduction of the Security Council, Law of
Chains, Developer Advisory Board, and Anticapture Commission)

## Season 6 Theme: Optimizing to support the Superchain

!https://emoji.discourse-cdn.com/twitter/red_circle.png?v=12

!https://emoji.discourse-cdn.com/twitter/large_blue_circle.png?v=12

!https://emoji.discourse-cdn.com/twitter/yellow_circle.png?v=12

!https://emoji.discourse-cdn.com/twitter/white_circle.png?v=12

!https://emoji.discourse-cdn.com/twitter/red_circle.png?v=12

As you can see above, [Season 5](https://gov.optimism.io/t/guide-to-season-5/6894/13)
 introduced many new programs. In Season 6, we’ll pause to reflect and 
refine these programs, optimizing them to support strategic goals for 
the Superchain. Throughout Season 6, we also aim to provide more 
transparency into key milestones for transferring more control over the 
governance system to the community via various public roadmaps.

These proposals are based on 100’s of pieces of feedback documented 
by the Foundation throughout the Season, reports and analysis conducted 
by the community, periodic feedback surveys, public feedback threads, 
the [Collective Feedback Commission 4](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863), [retrospectives](https://gov.optimism.io/tags/c/elected-reps/council-communication-threads/70/retrospective) conducted by community representatives, etc.

---

## **[Intents 4](https://gov.optimism.io/t/season-6-intents-ratification/8104/2)**

*Intents are high level strategic goals the entire Collective 
works towards. Each Intent has a target metric indicating what success 
looks like for each Intent.*

- **Season 5:** Intents applied to the entire Collective
but specified that the Governance Fund was only meant to support OP
Mainnet. The Foundation set 3 out of 4 Intents, and the community set
Intent #3: Improve the Consumer Experience.
- **Season 6:** The Foundation will propose all Intents,
which will now be ratified by governance. Intents will apply to the
entire Collective. The Governance Fund will support the Superchain but
will no longer support *technical* decentralization under Intent #1.
- You can see the Foundation’s Suggested Mission Requests under each Intent [here 5](https://gov.optimism.io/t/season-6-suggested-mission-requests/8107/2).

[🧰  Asset Container (4)4000×1310 79.6 KB](https://global.discourse-cdn.com/business7/uploads/bc41dd/original/2X/f/ff192b6911a9190dc3a0981567e8a70b4727ac03.png)

!https://global.discourse-cdn.com/business7/uploads/bc41dd/optimized/2X/f/ff192b6911a9190dc3a0981567e8a70b4727ac03_2_690x225.png

## Intent 1: Progress Towards Decentralization

*In Season 6, Intent #1 encompasses both governance and technical decentralization. In Season 5, it only encompassed technical decentralization.*

- **[Developer Advisory Board Renewal (DAB) 2](https://gov.optimism.io/t/season-6-developer-advisory-board-renewal/8099):**
    
    *The Developer Advisory Board was created to help the Collective evaluate technical decisions.*
    
    - **Season 5:** The DAB reviewed all technical Missions under Intent #1 (Progress Towards Technical Decentralization) and helped the Grants Council assess any technical milestones.
    - **Season 6:** If renewed, the DAB will help the Grants
    Council assess all technical grants and milestones. They will also
    provide plain english explanations of all protocol upgrades and be
    required to provide 1/4 delegate approvals on Protocol Upgrade drafts.
- **[Anticapture Commission Amendments (ACC):** 1](https://gov.optimism.io/t/season-6-anticapture-commission-amendment/8124)
    
    *The anticapture commission was created to empower a group of high
     context delegates with 10M OP in delegation with the mandate to inform 
    the Citizens’ House of any capture in the Token House.*
    
    - **Season 5:** The anticapture commission was delegated
    10M OP in delegation to counter the voting power of other large
    stakeholder groups (investors, OP Chains, etc.) and mandated to prevent
    capture in the Token House.
    - **Season 6:** The ACC was initially authorized through
    the end of Season 6. To date, the ACC’s primary impact has been in
    pushing the Foundation (a key stakeholder in the Collective) to provide
    more transparency into technical governance parameters and to reduce our control over those parameters. Governor Upgrades require governance
    approval as a result of these efforts. Amendments are proposed to make
    minor changes based on learnings in Season 5.
- **[Code of Conduct Rescoping:** 2](https://gov.optimism.io/t/season-6-code-of-conduct-rescoping-2/8101) The Code of Conduct has been rescoped multiple times since the end of
Season 4, based on continuous learnings. Please reference [CoC Rescoping #2 2](https://gov.optimism.io/t/season-6-code-of-conduct-rescoping-2/8101) to understand the option to [renew the Code of Conduct Council](https://gov.optimism.io/t/season-6-code-of-conduct-council-renewal/8100) for an additional Season.
- **NEW in Season 6: Continuous Transition of Governance Power to the Community:**
    - **Stage 1 Decentralization:** A variety of protocol upgrades will help Optimism reach Stage 1 decentralization. See the [Season 6 Reflection Period Guide](https://gov.optimism.io/t/season-6-voting-guide/8130) for more details.
    - **Blockspace Charters:** [Introducing Blockspace Charters 2](https://gov.optimism.io/t/season-6-introducing-blockspace-charters-superchain-first-governance/8133), a practical implementation of the [Law of Chains](https://gov.optimism.io/t/final-law-of-chains-v0-1/6514)! [The Standard Rollup Charter](https://gov.optimism.io/t/season-6-draft-standard-rollup-charter/8135) will be ratified during Season 6.
    - **On-Chain Execution:** In Season 6, we plan to share a roadmap outlining the path to on-chain execution. Delegates may also be asked to approve multiple Protocol Upgrades that bring us closer to
    on-chain execution throughout Season 6.
    - **Security Council Election:** The Security Council
    enacts Protocol Upgrades and is comprised of a group of trusted
    community members. The first Security Council election for Cohort A will occur in August!

## Intent 2: **Bring Chains to the Superchain**

- **[Chain Delegation Program Amendments (CDP): 3](https://gov.optimism.io/t/season-6-chain-delegation-program-amendment/8125/2)**
    
    *The Chain Delegation Programs enables OP Chains to become active participants in Optimism Governance.*
    
    - **Season 5:** The Chain Delegation Program approved 10M
    OP to be used to grant temporary delegation of 1M OP to any OP Chain
    joining the Superchain.
    - **Season 6:** The program was initially approved to run
    through Season 6. The program wasn’t utilized in Season 5, due to a
    variety of factors. Amendments are proposed to rescope and extend the
    program to support our strategy of onboarding new OP Chains to
    governance (more details [here 4](https://gov.optimism.io/t/onboarding-op-chains-to-optimism-governance/7858))

## Intent 3: **Grow Application Developers on the Superchain**

*Missions grants are made out of the Governance Fund and support 
the Collective’s strategic Intents. Select delegates can make a Mission 
Request outlining the specific types of grants they’d like the 
Governance Fund to make.*

- **[Mission Requests v2.5 4](https://gov.optimism.io/t/season-6-missions-v2-5/8106/2):**
    - **Season 5:** We iterated on the Mission Request process in Season 5. You can read the full retrospective [here 2](https://gov.optimism.io/t/season-5-missions-v2-retrospective/8103).
    - **Season 6:** Members of the Grants Council and
    Collective Feedback Commission will be able to create Mission Requests,
    subject to Token House approval. The application process will be
    simplified and refined based on grant applicant user research and closer collaboration with the Grants Council. As always, v2.5 will be treated
    as an experiment to re-assessed at the end of Season 6. See also:
        - [Mission Request Creation Guide 5](https://gov.optimism.io/t/season-6-mission-request-creation-guide/8123)
        - [Suggested Mission Requests 5](https://gov.optimism.io/t/season-6-suggested-mission-requests/8107)
        - [Missions: Applicant Guide 2](https://gov.optimism.io/t/season-6-mission-application-guide/8114)
        - [Mission Request: Voting Guide](https://gov.optimism.io/t/season-6-mission-voting-guide/8122)

As last year, the Foundation will share an Annual Budget Report and delegates may choose to put forward proposals for [Inflation Adjustment](https://gov.optimism.io/t/inflation-adjustment-proposal-template/5923).

---

### Some other changes you might notice in Season 6:

- **[Collective Rewards Framework** 3](https://gov.optimism.io/t/season-6-collective-reward-framework/8112/2)
    - An impact-focused framework (non-binding) to standardize rewards
    across the Collective. The primary use case will be in the Token House’s evaluation of prospective budgets, but these guidelines can also help
    ensure more consistency and predictability for voter rewards (delivered
    retroactively at the end of each Season, based on governance
    participation.)
- Trust Tiers
    - We will improve the Trust Tiers, based on user research, and
    transition them from a conceptual minimal viable product to an
    attestation based mechanism for building reputation within the
    Collective. More information will be provided before the start of Season 6.
- Open Design Process
    - We’ve embarked on Phase 1 on the [Path to Open Metagovernance 2](https://gov.optimism.io/t/the-path-to-open-metagovernance/7728), launching the [Collective Feedback Commission 4](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863), which informed early drafts of Season 6 designs.
- The govNERDs
    - govNERDs facilitate community understanding and participation in
    more governance processes. In Season 6, we will transition this program
    from a Foundation Mission Request to an [open contribution path 8](https://github.com/ethereum-optimism/ecosystem-contributions/issues/182), enabling more community members to get involved (more details at the start of Season 6!)
- Steady State [Governance Calendar 4](https://calendar.google.com/calendar/u/0/r?cid=Y19mbm10Z3VoNm5vbzZxZ2JuaTJncGVyaWQ0a0Bncm91cC5jYWxlbmRhci5nb29nbGUuY29t)
    - As our governance system matures and we grow the number of external
    contributors interacting with it, we need more predictability in our
    governance calendar. Seasons are now standardized into 6 month periods
    broken up by 6 week Reflection Periods. There will be no downtime for
    Protocol Upgrades and we strive to limit the downtime for the grants
    program to 9 weeks, twice per year.

---

### **See the [Season 6 Reflection Period Guide 15](https://gov.optimism.io/t/season-6-reflection-period-guide/8130) for detailed outline of what you’ll need to do during the Reflection Period!**

Citizens will be asked to opt-in to participate in governance in Season 6, more details soon!

We understand delegates have other commitments and may need to step away. Please see the [Delegate Resignation Process 4](https://gov.optimism.io/t/delegate-resignation-process/8127).

ChatGPT

**Memory updated**

Optimism is a Layer 2 scaling solution for Ethereum, designed to improve transaction speed and reduce costs while maintaining the security and decentralization of the Ethereum network. It achieves this through Optimistic Rollups, a technology that batches multiple transactions into a single transaction for efficiency. Optimism aims to create a more scalable and accessible Ethereum ecosystem, fostering innovation and growth in the decentralized space.

Optimism Season 6, running from June 27th to December 11th, is focused on refining and improving existing programs to support the strategic goals for the Superchain. Key initiatives include multiple Retro Funding rounds, protocol upgrades, and enhanced governance structures. Engagement with the Optimism Collective during this season can be achieved through participating in Optimism Town Hall meetings and the Respect Game at Optimism Fractal, where community contributions are recognized and rewarded through a collaborative ranking process. This interaction helps shape the future of Optimism while fostering a vibrant and supportive community environment.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Provide more about a brief project outline to engage with season 6

ChatGPT

### **Project Outline to Engage with Optimism Collective Season 6**

**Objective:**
To actively participate in Optimism Collective Season 6 through the Optimism Town Hall and the Respect Game at Optimism Fractal, fostering community engagement, enhancing governance processes, and contributing to the strategic goals of the Superchain.

**Key Activities:**

1. **Participate in the Optimism Town Hall:**
    - **Attend Meetings:** Regularly attend the bi-weekly Optimism Town Hall meetings to stay updated on the latest developments, proposals, and governance discussions.
    - **Active Participation:** Engage in discussions, provide feedback, and contribute to the decision-making process during the Town Hall sessions.
    - **Proposal Submission:** Prepare and submit proposals or amendments that align with Season 6’s strategic intents, particularly focusing on governance improvements, decentralization efforts, and community-driven initiatives.
2. **Engage in the Respect Game at Optimism Fractal:**
    - **Organize Sessions:** Coordinate and participate in Respect Game sessions where community members present their contributions and collaboratively rank each other's efforts.
    - **Community Recognition:** Use the Respect Game as a platform to recognize and reward valuable contributions within the Optimism community, fostering a culture of appreciation and collaboration.
    - **Feedback Collection:** Gather feedback from participants on the effectiveness of the Respect Game and suggest improvements to enhance its impact on community engagement.
3. **Support Retro Funding Rounds:**
    - **Proposal Development:** Work on developing proposals for Retro Funding rounds 4, 5, 6, and 7, ensuring they align with the strategic goals and intents of Season 6.
    - **Community Outreach:** Engage with potential grant applicants, offering guidance on proposal submission and aligning their projects with Optimism’s strategic goals.
    - **Review and Voting:** Participate in the review and voting process for Retro Funding proposals, ensuring fair and impactful distribution of resources.
4. **Contribute to Governance Enhancements:**
    - **Feedback and Surveys:** Actively participate in feedback surveys and public feedback threads to provide insights and suggestions for governance improvements.
    - **Collaborate with Councils:** Engage with the Grants Council, Developer Advisory Board, and other governance bodies to support their efforts and contribute to strategic discussions.
    - **Protocol Upgrades:** Stay informed about proposed protocol upgrades, participate in the reflection period discussions, and contribute to the decision-making process for these upgrades.

**Milestones:**

1. **June 27th:** Start of Season 6 and initial participation in Town Hall and Respect Game sessions.
2. **July 18th:** Opening of grant applications for the first Retro Funding round.
3. **August:** Participation in the first Security Council election for Cohort A.
4. **September:** Mid-season review and reflection, gathering feedback and adjusting engagement strategies as needed.
5. **December 11th:** Conclusion of Season 6, final review of contributions, and preparation for the next season’s engagement plan.

**Expected Outcomes:**

- Increased community participation and engagement in Optimism’s governance processes.
- Enhanced recognition and rewarding of valuable community contributions through the Respect Game.
- Successful proposal submissions and approvals for Retro Funding rounds, contributing to the growth and development of the Optimism ecosystem.
- Meaningful contributions to the governance enhancements and strategic goals of the Superchain.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Write a bit more about the optimism superchain and how it rewards public goods creators and pioneers better ways for humanity to cooperate and how this is very aligned with optimism fractal

Write a brief summary that includes all of these. Provide an overview of Optimism Season 6, and project outline to engage with Optimism Collective Season 6 via Optimism Town Hall and the Respect Game at Optimism Fractal. Create a brief summary of this in 2 paragraphs or less

ChatGPT

The Optimism Superchain is a vision for a scalable, interconnected ecosystem built on Ethereum, designed to enhance cooperation and innovation. By leveraging Optimistic Rollups, the Superchain improves transaction efficiency and reduces costs, making decentralized applications more accessible. Central to this vision is the commitment to rewarding public goods creators, supporting projects that benefit the broader community, and pioneering new methods for human cooperation. This aligns closely with the values of Optimism Fractal, which emphasizes community-driven decision-making and the recognition of valuable contributions.

Optimism Season 6, running from June 27th to December 11th, focuses on refining existing programs and enhancing governance to support the Superchain’s strategic goals. Engagement can be achieved through participation in the Optimism Town Hall for governance discussions and the Respect Game at Optimism Fractal, where community contributions are collaboratively ranked and rewarded. This involvement fosters a vibrant, supportive community, driving forward the mission of optimizing human cooperation and supporting public goods.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

Now provide a summary of project outline to engage with season 6 in 1 paragraph or less

ChatGPT

To engage with Optimism Season 6, participate in the bi-weekly Optimism Town Hall meetings to stay informed and contribute to governance discussions, and actively take part in the Respect Game at Optimism Fractal to recognize and rank community contributions. Additionally, support Retro Funding rounds by developing and reviewing proposals, providing guidance to applicants, and participating in feedback surveys to enhance governance processes. This approach will foster community engagement, reward public goods creators, and contribute to the strategic goals of the Optimism Superchain.

Provide an introduction to Optimism, an overview of Optimism Season 6, and project outline to engage with Optimism Collective Season 6 via Optimism Town Hall and the Respect Game at Optimism Fractal. Create a brief summary of this in 2 paragraphs

Recording: [May 14, 2024 S6 AMA and Token House Call.mp4 - Google Drive 6](https://drive.google.com/file/d/1mAWfVMQkG0O_aWdPRtk5ojHuMXhsAgNg/view?usp=sharing)

- [Cycle 22 Final Grants Roundup 1](https://gov.optimism.io/t/cycle-22-final-grants-roundup/8086)
    - Total of 530 mission request applications and 130 finalists.
    - The season is now closed and new applications for season 6 will open on July 18th.
- [Season 6 AMA 4](https://gov.optimism.io/t/season-6-guide-to-season-6/8113)
    - We are currently in Season 6 Reflection Period: Reading Period. The reflection period will last till June 26th, read [Season 6: Reflection Period Guide 1](https://gov.optimism.io/t/season-6-reflection-period-guide/8130) for all dates and details.
    - Season 6 will start on June 27th till December 11th.
    - Seasons are now standardized to be six months long, a six week reflection period and three week voting cycles.
    - Retro Funding rounds 4, 5, 6 and 7 will all take place during season 6 this year.
    - The goal for season 6 is to refine and improve existing programs and structures to support strategic goals for the Superchain.
    - Read the [Season 6: Guide 4](https://gov.optimism.io/t/season-6-guide-to-season-6/8113) to learn more about this season Intents, each intent has a target metric.
    - The process for mission requests will be slightly different in order to make a better experience for builders. [Season 6: Missions v2.5 2](https://gov.optimism.io/t/season-6-missions-v2-5/8106)
    - Grants Council will continue to process applications for grants on
    the OP Mainnet but other OP Chains will also be able to apply to the
    governance fund to request tokens and run their own grants program.
    - There are going to be some small changes based on feedback for the
    Anticapture Commision, resizing from 10M OP to 20M to be delegated
    across different OP Chains and incentivise more participation in
    governance. Read the post [Season 6: Anticapture Commission Amendment 1](https://gov.optimism.io/t/season-6-anticapture-commission-amendment/8124)
    - Anybody who would like to lead a board or a council can put forward a proposal for an operating budget to support that board or council. It
    needs to be posted in the forums and be approved by four top 100
    delegates by May 22nd 19:00 UTC.
    - Use the [Collective Reward Framework 2](https://gov.optimism.io/t/season-6-collective-reward-framework/8112) as a guideline to assess operating budgets for boards and councils. (optional)
    - Protocol upgrades will continue to be voted on during reflection periods.
    - A separate AMA will be hosted the 21st during the community call to
    have the upgrade proposals authors and engineer team walk through those
    protocol upgrades.

# [Season 6: Guide to Season 6](https://gov.optimism.io/t/season-6-guide-to-season-6/8113)

[Governance  Design 📐](https://gov.optimism.io/c/gov-design/84)

[Metagovernance](https://gov.optimism.io/c/gov-design/metagovernance/53)

[season-6](https://gov.optimism.io/tag/season-6)[season-guide](https://gov.optimism.io/tag/season-guide)

May 10

9d

![https://global.discourse-cdn.com/business7/uploads/bc41dd/original/1X/391d6e71a279a9f881f75bfa7df5cdf3cf905b3f.png](https://global.discourse-cdn.com/business7/uploads/bc41dd/original/1X/391d6e71a279a9f881f75bfa7df5cdf3cf905b3f.png)

[system](https://gov.optimism.io/u/system)

[13d](https://gov.optimism.io/t/season-6-guide-to-season-6/8113?u=dansingjoy)

*Thanks to members of the [Feedback Commission 4](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863) for providing input and feedback on Season 6 drafts.*

# Guide to Season 6

![https://emoji.discourse-cdn.com/twitter/tada.png?v=12](https://emoji.discourse-cdn.com/twitter/tada.png?v=12)

---

**Season 6 begins on June 27th and runs through December 11th. 
Grant applications open on July 18th and run every 3 weeks through 
December. You can find all dates on the [public governance calendar 7](https://calendar.google.com/calendar/embed?src=c_4hui70itm089e7t8q50heh1kno%40group.calendar.google.com&ctz=Europe%2FBerlin).**

**All details about what happens between now and then are in the [Reflection Period Voting Guide](https://gov.optimism.io/t/season-6-voting-guide/8130).**

Don’t want to read? Watch the [Season 6 Overview 4](https://drive.google.com/file/d/1mAWfVMQkG0O_aWdPRtk5ojHuMXhsAgNg/view) from the Token House Community Call on 5/14.

**Time stamps**

06:50 - Lavande gives S6 overview

28:55 - Ben gives overview of Blockspace Charter Framework

52:32 - Brief Q&A at the end

---

## Acknowledging Season 5 Contributions

Delegates are rewarded retroactively for their participation in the Token House. You can find retro rewards for Season 5 [here 16](https://gov.optimism.io/t/season-5-retro-governance-participation-rewards/8105). Rewards are made in accordance with a new [Collective Rewards Framework 7](https://gov.optimism.io/t/season-6-collective-reward-framework/8112), which is the first step in transitioning this responsibility to a Budget Board, likely to be elected in Season 7.

---

## How did we get here? Seasons 1 - 5

- **Season 1 Theme:** Genesis and unstructured community grants
- [**Season 2 Theme: 2**](https://gov.optimism.io/t/committees-next-steps-for-season-2/3436) Establishing structure with grant committees
- [**Season 3 Theme: 1**](https://gov.optimism.io/t/guide-to-season-3-course-correcting/3942) Refining structure with the Grants Council
- [**Season 4 Theme:**](https://gov.optimism.io/t/guide-to-season-4-as-a-collective/5886) Working as a Collective (Introduction of Missions, Intents, and Trust Tiers)
- [**Season 5 Theme: 1**](https://gov.optimism.io/t/guide-to-season-5/6894) Governance resiliency (Introduction of the Security Council, Law of
Chains, Developer Advisory Board, and Anticapture Commission)

## Season 6 Theme: Optimizing to support the Superchain

![https://emoji.discourse-cdn.com/twitter/red_circle.png?v=12](https://emoji.discourse-cdn.com/twitter/red_circle.png?v=12)

![https://emoji.discourse-cdn.com/twitter/large_blue_circle.png?v=12](https://emoji.discourse-cdn.com/twitter/large_blue_circle.png?v=12)

![https://emoji.discourse-cdn.com/twitter/yellow_circle.png?v=12](https://emoji.discourse-cdn.com/twitter/yellow_circle.png?v=12)

![https://emoji.discourse-cdn.com/twitter/white_circle.png?v=12](https://emoji.discourse-cdn.com/twitter/white_circle.png?v=12)

![https://emoji.discourse-cdn.com/twitter/red_circle.png?v=12](https://emoji.discourse-cdn.com/twitter/red_circle.png?v=12)

As you can see above, [Season 5](https://gov.optimism.io/t/guide-to-season-5/6894/13)
 introduced many new programs. In Season 6, we’ll pause to reflect and 
refine these programs, optimizing them to support strategic goals for 
the Superchain. Throughout Season 6, we also aim to provide more 
transparency into key milestones for transferring more control over the 
governance system to the community via various public roadmaps.

These proposals are based on 100’s of pieces of feedback documented 
by the Foundation throughout the Season, reports and analysis conducted 
by the community, periodic feedback surveys, public feedback threads, 
the [Collective Feedback Commission 4](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863), [retrospectives](https://gov.optimism.io/tags/c/elected-reps/council-communication-threads/70/retrospective) conducted by community representatives, etc.

---

## [**Intents 4**](https://gov.optimism.io/t/season-6-intents-ratification/8104/2)

*Intents are high level strategic goals the entire Collective 
works towards. Each Intent has a target metric indicating what success 
looks like for each Intent.*

- **Season 5:** Intents applied to the entire Collective
but specified that the Governance Fund was only meant to support OP
Mainnet. The Foundation set 3 out of 4 Intents, and the community set
Intent #3: Improve the Consumer Experience.
- **Season 6:** The Foundation will propose all Intents,
which will now be ratified by governance. Intents will apply to the
entire Collective. The Governance Fund will support the Superchain but
will no longer support *technical* decentralization under Intent #1.
- You can see the Foundation’s Suggested Mission Requests under each Intent [here 5](https://gov.optimism.io/t/season-6-suggested-mission-requests/8107/2).

[🧰  Asset Container (4)4000×1310 79.6 KB](https://global.discourse-cdn.com/business7/uploads/bc41dd/original/2X/f/ff192b6911a9190dc3a0981567e8a70b4727ac03.png)

![https://global.discourse-cdn.com/business7/uploads/bc41dd/optimized/2X/f/ff192b6911a9190dc3a0981567e8a70b4727ac03_2_690x225.png](https://global.discourse-cdn.com/business7/uploads/bc41dd/optimized/2X/f/ff192b6911a9190dc3a0981567e8a70b4727ac03_2_690x225.png)

## Intent 1: Progress Towards Decentralization

*In Season 6, Intent #1 encompasses both governance and technical decentralization. In Season 5, it only encompassed technical decentralization.*

- [**Developer Advisory Board Renewal (DAB) 2](https://gov.optimism.io/t/season-6-developer-advisory-board-renewal/8099):**
    
    *The Developer Advisory Board was created to help the Collective evaluate technical decisions.*
    
    - **Season 5:** The DAB reviewed all technical Missions under Intent #1 (Progress Towards Technical Decentralization) and helped the Grants Council assess any technical milestones.
    - **Season 6:** If renewed, the DAB will help the Grants
    Council assess all technical grants and milestones. They will also
    provide plain english explanations of all protocol upgrades and be
    required to provide 1/4 delegate approvals on Protocol Upgrade drafts.
- [**Anticapture Commission Amendments (ACC):** 1](https://gov.optimism.io/t/season-6-anticapture-commission-amendment/8124)
    
    *The anticapture commission was created to empower a group of high
     context delegates with 10M OP in delegation with the mandate to inform 
    the Citizens’ House of any capture in the Token House.*
    
    - **Season 5:** The anticapture commission was delegated
    10M OP in delegation to counter the voting power of other large
    stakeholder groups (investors, OP Chains, etc.) and mandated to prevent
    capture in the Token House.
    - **Season 6:** The ACC was initially authorized through
    the end of Season 6. To date, the ACC’s primary impact has been in
    pushing the Foundation (a key stakeholder in the Collective) to provide
    more transparency into technical governance parameters and to reduce our control over those parameters. Governor Upgrades require governance
    approval as a result of these efforts. Amendments are proposed to make
    minor changes based on learnings in Season 5.
- [**Code of Conduct Rescoping:** 2](https://gov.optimism.io/t/season-6-code-of-conduct-rescoping-2/8101) The Code of Conduct has been rescoped multiple times since the end of
Season 4, based on continuous learnings. Please reference [CoC Rescoping #2 2](https://gov.optimism.io/t/season-6-code-of-conduct-rescoping-2/8101) to understand the option to [renew the Code of Conduct Council](https://gov.optimism.io/t/season-6-code-of-conduct-council-renewal/8100) for an additional Season.
- **NEW in Season 6: Continuous Transition of Governance Power to the Community:**
    - **Stage 1 Decentralization:** A variety of protocol upgrades will help Optimism reach Stage 1 decentralization. See the [Season 6 Reflection Period Guide](https://gov.optimism.io/t/season-6-voting-guide/8130) for more details.
    - **Blockspace Charters:** [Introducing Blockspace Charters 2](https://gov.optimism.io/t/season-6-introducing-blockspace-charters-superchain-first-governance/8133), a practical implementation of the [Law of Chains](https://gov.optimism.io/t/final-law-of-chains-v0-1/6514)! [The Standard Rollup Charter](https://gov.optimism.io/t/season-6-draft-standard-rollup-charter/8135) will be ratified during Season 6.
    - **On-Chain Execution:** In Season 6, we plan to share a roadmap outlining the path to on-chain execution. Delegates may also be asked to approve multiple Protocol Upgrades that bring us closer to
    on-chain execution throughout Season 6.
    - **Security Council Election:** The Security Council
    enacts Protocol Upgrades and is comprised of a group of trusted
    community members. The first Security Council election for Cohort A will occur in August!

## Intent 2: **Bring Chains to the Superchain**

- [**Chain Delegation Program Amendments (CDP): 3**](https://gov.optimism.io/t/season-6-chain-delegation-program-amendment/8125/2)
    
    *The Chain Delegation Programs enables OP Chains to become active participants in Optimism Governance.*
    
    - **Season 5:** The Chain Delegation Program approved 10M
    OP to be used to grant temporary delegation of 1M OP to any OP Chain
    joining the Superchain.
    - **Season 6:** The program was initially approved to run
    through Season 6. The program wasn’t utilized in Season 5, due to a
    variety of factors. Amendments are proposed to rescope and extend the
    program to support our strategy of onboarding new OP Chains to
    governance (more details [here 4](https://gov.optimism.io/t/onboarding-op-chains-to-optimism-governance/7858))

## Intent 3: **Grow Application Developers on the Superchain**

*Missions grants are made out of the Governance Fund and support 
the Collective’s strategic Intents. Select delegates can make a Mission 
Request outlining the specific types of grants they’d like the 
Governance Fund to make.*

- [**Mission Requests v2.5 4](https://gov.optimism.io/t/season-6-missions-v2-5/8106/2):**
    - **Season 5:** We iterated on the Mission Request process in Season 5. You can read the full retrospective [here 2](https://gov.optimism.io/t/season-5-missions-v2-retrospective/8103).
    - **Season 6:** Members of the Grants Council and
    Collective Feedback Commission will be able to create Mission Requests,
    subject to Token House approval. The application process will be
    simplified and refined based on grant applicant user research and closer collaboration with the Grants Council. As always, v2.5 will be treated
    as an experiment to re-assessed at the end of Season 6. See also:
        - [Mission Request Creation Guide 5](https://gov.optimism.io/t/season-6-mission-request-creation-guide/8123)
        - [Suggested Mission Requests 5](https://gov.optimism.io/t/season-6-suggested-mission-requests/8107)
        - [Missions: Applicant Guide 2](https://gov.optimism.io/t/season-6-mission-application-guide/8114)
        - [Mission Request: Voting Guide](https://gov.optimism.io/t/season-6-mission-voting-guide/8122)

As last year, the Foundation will share an Annual Budget Report and delegates may choose to put forward proposals for [Inflation Adjustment](https://gov.optimism.io/t/inflation-adjustment-proposal-template/5923).

---

### Some other changes you might notice in Season 6:

- [**Collective Rewards Framework** 3](https://gov.optimism.io/t/season-6-collective-reward-framework/8112/2)
    - An impact-focused framework (non-binding) to standardize rewards
    across the Collective. The primary use case will be in the Token House’s evaluation of prospective budgets, but these guidelines can also help
    ensure more consistency and predictability for voter rewards (delivered
    retroactively at the end of each Season, based on governance
    participation.)
- Trust Tiers
    - We will improve the Trust Tiers, based on user research, and
    transition them from a conceptual minimal viable product to an
    attestation based mechanism for building reputation within the
    Collective. More information will be provided before the start of Season 6.
- Open Design Process
    - We’ve embarked on Phase 1 on the [Path to Open Metagovernance 2](https://gov.optimism.io/t/the-path-to-open-metagovernance/7728), launching the [Collective Feedback Commission 4](https://gov.optimism.io/t/introducing-the-collective-feedback-commission/7863), which informed early drafts of Season 6 designs.
- The govNERDs
    - govNERDs facilitate community understanding and participation in
    more governance processes. In Season 6, we will transition this program
    from a Foundation Mission Request to an [open contribution path 8](https://github.com/ethereum-optimism/ecosystem-contributions/issues/182), enabling more community members to get involved (more details at the start of Season 6!)
- Steady State [Governance Calendar 4](https://calendar.google.com/calendar/u/0/r?cid=Y19mbm10Z3VoNm5vbzZxZ2JuaTJncGVyaWQ0a0Bncm91cC5jYWxlbmRhci5nb29nbGUuY29t)
    - As our governance system matures and we grow the number of external
    contributors interacting with it, we need more predictability in our
    governance calendar. Seasons are now standardized into 6 month periods
    broken up by 6 week Reflection Periods. There will be no downtime for
    Protocol Upgrades and we strive to limit the downtime for the grants
    program to 9 weeks, twice per year.

---

### **See the [Season 6 Reflection Period Guide 15](https://gov.optimism.io/t/season-6-reflection-period-guide/8130) for detailed outline of what you’ll need to do during the Reflection Period!**

Citizens will be asked to opt-in to participate in governance in Season 6, more details soon!

We understand delegates have other commitments and may need to step away. Please see the [Delegate Resignation Process 4](https://gov.optimism.io/t/delegate-resignation-process/8127).

[Season 6: Guide to Season 6](https://gov.optimism.io/t/season-6-guide-to-season-6/8113)

[Season 6: Missions v2.5](https://gov.optimism.io/t/season-6-missions-v2-5/8106)