# Respond to Nuno about optimal Respect Game Description

Assignee: Dan Singjoy
Due: April 25, 2024
Project: Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md), Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md), Build Optimism Fractal Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md)
Status: Done
Task Summary: This task aims to create a 2-4 sentence summary/introduction for the page titled "Respond to Nuno about optimal Respect Game Description". The page discusses different ways to describe the Respect Game, highlighting its value propositions and the challenge of finding a single description that speaks to everyone. It also mentions playing consensus games to define community vision and mission and suggests using democratic processes to determine the best description for the Respect Game on the community website.
Summary: This document contains a response to Nuno regarding the optimal description of the Respect Game. The author explains that the game can be described as a governance mechanism, a methodology, a way to evaluate public goods, and more. The author acknowledges the challenge of describing the game in one way that speaks to everyone and suggests tailoring the description based on the unique preferences of each participant or target market segment. The document also includes a response to Rosmari about the Respect Game description and Eden Fractal spring break, as well as a reminder message about the upcoming event.
Created time: April 29, 2024 12:56 PM
Last edited time: May 8, 2024 8:17 AM
Sub-tasks: Describe the Respect Game as a Governance Mechanism or Methodology (Describe%20the%20Respect%20Game%20as%20a%20Governance%20Mechanis%200bcb3e6f1c9a41a5a5284043250e070c.md)
Parent task: Find the best ways to describe the Respect Game (Find%20the%20best%20ways%20to%20describe%20the%20Respect%20Game%20a48725cf10ce4327be53889ef8f619ea.md)
Created by: Dan Singjoy

## Consider creating project to describe the respect game

![[https://discord.com/channels/1164572177115398184/1164572177878765591/1234444738094956606](https://discord.com/channels/1164572177115398184/1164572177878765591/1234444738094956606)](Find%20the%20best%20ways%20to%20describe%20the%20Respect%20Game%20a48725cf10ce4327be53889ef8f619ea/Untitled.png)

[https://discord.com/channels/1164572177115398184/1164572177878765591/1234444738094956606](https://discord.com/channels/1164572177115398184/1164572177878765591/1234444738094956606)

![Untitled](Respond%20to%20Nuno%20about%20optimal%20Respect%20Game%20Descrip%20a0c4166fd58f420785cc099b4bced10b/Untitled.png)

![Untitled](Respond%20to%20Nuno%20about%20optimal%20Respect%20Game%20Descrip%20a0c4166fd58f420785cc099b4bced10b/Untitled%201.png)

Hey Nuno, I’m doing well and hope you are too!

![Untitled](Respond%20to%20Nuno%20about%20optimal%20Respect%20Game%20Descrip%20a0c4166fd58f420785cc099b4bced10b/Untitled%202.png)

Good question, thanks for asking. I’ve been trying to answer the same question for a long time :D

As Rosmari linked, the best answer that I can offer at the moment is at the top of [Optimystics.io/respectgame](http://optimystics.io/respectgame). It states:

*The Respect Game is a profoundly helpful consensus game that provides a fun way to foster collaborations, promote public goods creators, and fairly award positive impact. This innovative consensus game coordinates decentralized, autonomous organizations with democratic decision-making and a sybil resistant reputation system rooted in onchain attestations during joyful events. It also provides invaluable primitives with a soulbound Respect token that enables communities to cooperate to achieve shared goals far better than ever before.*

This answer is far from perfect from though and I usually explain it differently to each person based upon their interests. The game is also evolving over time so there are new ways that I would describe it now when I get the chance to try writing it again

![Untitled](Respond%20to%20Nuno%20about%20optimal%20Respect%20Game%20Descrip%20a0c4166fd58f420785cc099b4bced10b/Untitled%203.png)

Yes the Respect Game can be described as a governance mechanism and a methodology. This can be a great way to describe it to governance enthusiasts and people who are interested in  methods for decision-making or coordination. I asked ChatGPT about this and it provide a detailed answer that you may find helpful, which you can see on this [notion page](Describe%20the%20Respect%20Game%20as%20a%20Governance%20Mechanis%200bcb3e6f1c9a41a5a5284043250e070c.md).

However, describing it as a governance mechanism or a methodology doesn’t paint the entire picture and might sound limiting to people who aren’t as interested in governance or methodology. For others it may be helpful to describe it more a way to evaluate public goods, measuring the value of contributions, a fun social game that can be used to rank anything, a framework to facilitate deliberative processes like citizen’s assemblies, an onchain coordination game, the next step in the evolution of human collaboration, an MMORPG, a collaborative video production process, a structured ideation process, a fractal consensus process, a cool new way to meet people, or many other things...

I’ve found it elusive to describe the Respect Game in one way that speaks to everyone because the game provides value in so many ways and offers unique value propositions to each person depending on what they’re seeking. Overall I think best description is based on the unique preferences of each participant, audience, or target market segment. While some people are most interested in governance, others may focus more on collaboration, enjoyment, relationships, incentives, sybil protection, or a variety of other [benefits](https://optimystics.io/respectgame#block-2f4565963b0c4790b75176c0f7c6695f). Like in cooking, all ingredients can be the same but the taste will change depending upon how it’s cooked!

How would you describe the Respect Game best? I’m curious to hear your thoughts about this and everyone else’s as well

- 
    
    
    [Create educational resources and webpages on OptimismFractal.com](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md) 
    
     [Create educational resources and webpage explaining Optimism Fractal’s Consensus Process (OptimismFractal.com/council)](Create%20educational%20resources%20and%20webpage%20explainin%209e39e73585f94c6f8407cb636f00883d.md) 
    

## Respond to Rosmari about Respect Game description and Eden Fractal spring break

![Untitled](Respond%20to%20Nuno%20about%20optimal%20Respect%20Game%20Descrip%20a0c4166fd58f420785cc099b4bced10b/Untitled.png)

Hmmm playing a game to see what everyone thinks… interesting idea! :)

At Eden Fractal we played a variety of consensus games to create a community [vision](http://EdenFractal.com/vision) and [mission](http://EdenFractal.com/mission) and it would be cool to do something similar to describe the Respect Game sometime. Perhaps we could play a meta Respect Game and the prompt of the game could be something like, what is the best way to describe the Respect Game…

Another way to answer find the best description for the Respect Game could be to vote with Respect on Snapshot or a notion database. On a related note, I recently created a [page](Review%20Methods%20for%20Voting%20with%20Respect%20in%20Notion%20a%20b037b35cca164e52898682c5957aa1a2.md) about methods for voting with Respect in Notion that could be helpful to answer this kind of question and a [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md) to create educational resources that explain important information about Optimism Fractal (including the Respect Game).

The OptimismFractal.com website currently links to the Optimystics article about the Respect Game, but ideally the community will create it’s own description of the Respect Game to feature on the Optimism Fractal website and use some sort of deliberative, democratic process to decide on the best way(s) to describe the Respect Game. The two pages linked above are intended to help facilitate this process in the future, so perhaps once we build better tooling for voting on matters like this then we could have some sort of ranked choice poll to determine the best description for the Respect Game to feature on the community website.

I created a [task](Find%20the%20best%20ways%20to%20describe%20the%20Respect%20Game%20a48725cf10ce4327be53889ef8f619ea.md) to find the best ways to describe the Respect Game that includes a [database](Find%20the%20best%20ways%20to%20describe%20the%20Respect%20Game%20a48725cf10ce4327be53889ef8f619ea/How%20would%20you%20best%20describe%20the%20Respect%20Game%20da68ed325e684017a80645dd643e7bfd.md) to organize each person’s answers. Everyone is welcome to contribute to this and we can curate more descriptions about the Respect Game over time as people share their thoughts. Everyone is also welcome to use or remix the content created in the Optimystics page linked above as well if it’s helpful

- 
    
    
    [EdenFractal.com/mission](http://EdenFractal.com/mission) 
    
    [Mission ](https://www.notion.so/Mission-102a332998b84428be0aa025a687280a?pvs=21) 
    
    [EdenFractal.com/vision](http://EdenFractal.com/vision)
    
    [Vision](https://www.notion.so/Vision-f11b5bb257444041a954ba61088cecc7?pvs=21) 
    

## Post Reminder Message

![Untitled](Respond%20to%20Nuno%20about%20optimal%20Respect%20Game%20Descrip%20a0c4166fd58f420785cc099b4bced10b/Untitled%204.png)

As a reminder, Optimism Fractal is returning from Spring Break and we’ll meet for our 25th event tomorrow at 17 UTC. I’m working on a proposal to provide structure to discussions after Respect Games and help lead Optimism Collective governance that I’ll share as soon as possible. I hope everyone had an awesome break and is excited for an amazing Season 3 of Optimism Fractal!

Eden Fractal is retu

![Untitled](Respond%20to%20Nuno%20about%20optimal%20Respect%20Game%20Descrip%20a0c4166fd58f420785cc099b4bced10b/Untitled%205.png)