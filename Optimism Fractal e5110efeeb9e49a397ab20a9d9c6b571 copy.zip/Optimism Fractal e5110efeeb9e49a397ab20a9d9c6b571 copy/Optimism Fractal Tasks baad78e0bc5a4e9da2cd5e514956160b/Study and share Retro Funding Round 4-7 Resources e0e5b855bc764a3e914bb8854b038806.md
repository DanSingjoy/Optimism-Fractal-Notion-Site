# Study and share Retro Funding Round 4-7 Resources

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md), Engage and build relationships with leaders in fractal communities (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20and%20build%20relationships%20with%20leaders%20in%20fra%20d03dec56536a4ffbb16a6c0b88c65239.md)
Status: In progress
Task Summary: This task aims to study and share resources related to Retro Funding Round 4-7. The page provides an overview of the task, including the assigned individual, the due date, and its current status. It also includes a description with a checklist of specific actions to be taken, such as reading forum posts, sharing recap posts and videos, and disseminating information to various channels within the organization.
Summary: Dan Singjoy is working on studying and sharing resources for Retro Funding Round 4-7. The tasks include reading a forum post, sharing a recap post and video from a meeting, and sharing the information with various groups.
Created time: March 26, 2024 6:23 PM
Last edited time: July 16, 2024 9:40 AM
Parent task: Create OptimismFractal.com/funding to show how Optimism Fractal can help people earn RetroFunding and other funding (Create%20OptimismFractal%20com%20funding%20to%20show%20how%20Opt%2045915c303ab94868b62bc2124430da06.md)
Created by: Dan Singjoy
Description: Dan Singjoy is working on studying and sharing resources for Retro Funding Round 4-7. The tasks include reading a forum post, sharing a recap post and video from a meeting, and sharing the resources with various groups.

## Description

- [ ]  Read: [https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU)
    - [ ]  read the forum post with more details as well
    - [ ]  share the recap post and video from today’s meeting as well
        - [ ]  listen again to jonas’ answer- i think he said 2.5 months but he provided more details about how it will be quicker and previously it was also 2.5 months?
    - [ ]  share with optimistics, optimism fractal
    - [ ]  share with eden fractal
    - [ ]  share with fractal chats?