# Write Optimism Fractal Participant Agreement

Project: Implement onchain Optimism Fractal participant/contributor agreement (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Implement%20onchain%20Optimism%20Fractal%20participant%20con%206a8b18dff0c242f2bc58a6f260774939.md)
Status: In progress
Task Summary: This task aims to establish a participant agreement for the Write Optimism Fractal initiative. The agreement will clarify the terms and conditions for participants, including consent for using their names and videos in promotional materials. It is essential to create this framework to ensure clarity and transparency as the project progresses.
Summary: The document outlines the ongoing development of the Write Optimism Fractal Participant Agreement, emphasizing the need for clarity on participant consent for name and video usage in promotions. It discusses the importance of reviewing existing agreements, considering modular approaches, and the potential impact of an agreement on participant entry. The author expresses a preference for having an agreement in place before the first meeting but acknowledges the challenges of creating it quickly and the possibility of starting without one, with plans to update it later.
Created time: September 9, 2023 11:58 AM
Last edited time: September 30, 2024 10:59 AM
Created by: Dan Singjoy
Description: The document outlines the development of a participant agreement for the Optimism Fractal project, emphasizing the need for clarity on consent for using names and videos in promotions. It discusses reviewing relevant terms of service, seeking help from various stakeholders, and considering a modular approach to agreements. The author expresses the importance of having a contributor agreement while weighing the potential barrier it may pose for new participants, suggesting a simple initial agreement that can be updated later.

## Description

## Update: August 2024

- I just found this note from September, 2023 before the start of Optimism Fractal. I’ll move it to Optimism Fractal site so it’s more accessible and included in the current project as much of it still may be relevant

- [ ]  Review the following, see what is still relevant, and organize appropriately

## To Do

- [ ]  include a section for consenting for their name and video to be used in promotions
    - This would provide more clarity about whether it’s cool to post people’s names like we did in the tweets for the first 20 weeks
    - This would also help us reach the milestone of 50 videos and enable us to publish videos like during the pitches and speeches games
    
- [ ]  Review/see if there is terms of service for RetroPGF and Grants Council
    - If so then these might be helpful

- [ ]  Ask Claude and/or ChatGPT for help
    - [ ]  Consider- We could add the previous two agreements from fractally team and ask claude to shorten or elaborate

- [ ]  Review prior notes about this and consider if it may be helpful to use some sort of more modular approach as well
    - I think there were interesting insights about this around the time of EF 57
    - Perhaps some sort of graph using cignals, so for example people can consent to eden creators posting their videos (or names in tweets) but not consent to some other organization doing so
    - Perhaps people sign each time by participating?
    

Consider asking for help from fractally

Consider asking for help from the Optimism Foundation or Grants Council

Consider who else it may be good to ask for help

- [ ]  Review [EdenCreators.com/agreements](http://EdenCreators.com/agreements)
    - There is a lot of agreement information and well written agreements here that we might be able to use or repurpose

I’m particularly interested in the part about recording videos and sharing on social media. I can promote our work much better when we have clarity that the participants agree to have their work featured on video and social media

I’m also particularly interested in this agreement in general since there are potentially a lot more funds at stake here

### Fractal Earnings Disclaimers

- Based upon respect points

- Based upon qualification from Optimystics team and/or Fractal Council(s)

- This is not a promise from Optimystics team
    - It is up to Optimystic team and/or Fractal Councils to determine eligibility of individuals
        - I think this may a helpful kind of disclaimer to have in case someone violates the intention of the process somehow, ie if they invite a bunch of people who just try to game the system or if they act disrespectfully to all community members
        
- Receipt of funds is subject to approval from the Optimism Foundation
    - The Optimism Foundation is ultimately the distributor of funds, not the Optimystics.
        - The Optimystics role in this process is limited to:
            - facilitating the process of building tools, hosting events, and educating participants to play the respect game
            - connecting (qualified/eligible) fractal participants with the Optimism Foundation and creating the 0xSplits contract according to onchain respect scores
            - communicating and coordinating with Optimism Foundation and fractal participants to help them accomplish their goals
    - Fund distribution is subject to approval from the Optimism Foundation and the Optimystics are not in any way responsible for fund distribution if the Optimism Foundation changes their mind for whatever reason.
    - The Optimism Foundation has their own procedures and requirements for distributing funding, including (but not limited to):
        - [ ]  Write text from this [screenshot](https://www.notion.so/Review-RetroPGF-Application-Screenshots-fedd2c23e50b4320ab9903a63e4e60ed?pvs=21) below
            - 
                
                
                ![Untitled](../../FractalJoy%202e05dda30cf04fff8b79aa508ca208a4/FractalJoy%20Projects%2019dd74928ad34a0a9f998a205667ddbf/Create%20Optimystics%20Business%20Plan%20c56f5c3cda404b2387c9db61c1aa5c79/Untitled.png)
                
                ![Untitled](../../FractalJoy%202e05dda30cf04fff8b79aa508ca208a4/FractalJoy%20Projects%2019dd74928ad34a0a9f998a205667ddbf/Create%20Optimystics%20Business%20Plan%20c56f5c3cda404b2387c9db61c1aa5c79/Untitled%201.png)
                
        - KYC requirements
        - Sanctioned Countries
            - ie Russia, North Korea, etc
            - This sucks for Evgeny and others, but there’s nothing we can do about it now
        - …

[https://www.notion.so/edencreators/Create-Optimystics-Business-Plan-c56f5c3cda404b2387c9db61c1aa5c79?pvs=4#444230a72b044084a5289545c311220c](https://www.notion.so/Create-Optimystics-Business-Plan-c56f5c3cda404b2387c9db61c1aa5c79?pvs=21)

- Distribution is subject to Optimystics earning funds from RetroPGF. If Optimystics do not receive funds or do not qualify for any reason, then funds will not be be distributed from Optimystics to the fractal participants
- and Optimystics are in no way responsible for sending more

## Conversation with Tadas

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so/edencreators/OP-fractal-process-93a205ded7f24332998cd323ec15d23b?pvs=4](https://www.notion.so/OP-Fractal-intent-93a205ded7f24332998cd323ec15d23b?pvs=21)

Yes, I agree that we should have a contributor agreement. I think this is important and wrote these [notes](Write%20Optimism%20Fractal%20Participant%20Agreement%203259173ddcb549f7af6af7570a0a58e0.md) about it last month, but haven’t had a chance to think about it much since then. Last week I also started writing some [disclaimers](https://www.notion.so/Create-Optimystics-Business-Plan-c56f5c3cda404b2387c9db61c1aa5c79?pvs=21) that may be helpful to include in the agreement.

I suppose we could start the first week or few weeks without an agreement like the Genesis Fractal did. They had a lot more at stake since Dan Larimer’s team was already very wealthy at the time. It would be good to create an agreement before the first meeting if possible, though it’s also worth considering if the agreement would be a big barrier to entry when we’re just getting started and it might be good to make it easier for people to join.

Overall I think it’d be best to have an agreement at the start, but I don’t know if it is feasible to create it this week and it might change in the future, so I think it may be best to start without an agreement and then add to it in the future weeks. However I’d be open to doing it this week if you think it’s a better idea and maybe it’s best to craft a simple agreement now, then we can always update it later and it might not require too much time or effort.

I just added a few more ideas to the notes linked above and will organize this more asap. As always feel free to comment or edit the page. What do you think is best?

![Untitled](Write%20Optimism%20Fractal%20Participant%20Agreement%203259173ddcb549f7af6af7570a0a58e0/Untitled.png)

Yes, I agree that we should have a contributor agreement. I think this is important and wrote these [notes](Write%20Optimism%20Fractal%20Participant%20Agreement%203259173ddcb549f7af6af7570a0a58e0.md) about it last month, but haven’t had a chance to think about it much since then. Last week I also started writing some [disclaimers](https://www.notion.so/Create-Optimystics-Business-Plan-c56f5c3cda404b2387c9db61c1aa5c79?pvs=21) that may be helpful to include in the agreement.

I suppose we could start the first week or few weeks without an agreement like the Genesis Fractal did. They had a lot more at stake since Dan Larimer’s team was already very wealthy at the time. It would be good to create an agreement before the first meeting if possible, though it’s also worth considering if the agreement would be a big barrier to entry when we’re just getting started and it might be good to make it easier for people to join. 

Overall I think it’d be best to have an agreement at the start, but I don’t know if it is feasible to create it this week and it might change in the future, so I think it may be best to start without an agreement and then add to it in the future weeks. However I’d be open to doing it this week if you think it’s a better idea and maybe it’s best to craft a simple agreement now, then we can always update it later and it might not require too much time or effort. 

I just added a few more ideas to the notes linked above and will organize this more asap. As always feel free to comment or edit the page. What do you think is best?

No, the original Genesis Fractal contributor agreement wasn’t published until March 18th, 2022 as you can see [here](https://peakd.com/fractally/@dan/genesis-fractal-contributor-agreement). I participated in the [first genesis fractal meeting](https://twitter.com/DanSingjoy/status/1497805614428397575) on February 27th, which means there was about three weeks of fractal meetings without any agreement in place. Even after a few months in June it still wasn’t required to sign the agreement in order to participate in the meetings, as you can see in the screenshot below:

Ok thank you. I’m curious if this would be any different if the contracts were made immutable or what other solutions may be helpful here

![Untitled](Write%20Optimism%20Fractal%20Participant%20Agreement%203259173ddcb549f7af6af7570a0a58e0/Untitled%201.png)

Ok thanks. I’m curious if this would be any different if the contracts were made immutable or what other solutions may be helpful here