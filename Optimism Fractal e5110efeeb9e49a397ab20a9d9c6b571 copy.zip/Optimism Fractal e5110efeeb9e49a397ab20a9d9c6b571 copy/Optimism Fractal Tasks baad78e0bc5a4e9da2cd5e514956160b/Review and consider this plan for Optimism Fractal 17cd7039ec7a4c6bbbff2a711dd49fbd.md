# Review and consider this plan for Optimism Fractal seasons aligned with RetroPGF and Six Month Anniversary Proposals

Project: Plan 6 month anniversary event for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%206%20month%20anniversary%20event%20for%20Optimism%20Fracta%20764fa2b8767e4fa58470b575be56a697.md), Create seasonal structure for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20seasonal%20structure%20for%20Optimism%20Fractal%204a7f04c638814411ad9ba8d92bf0458d.md)
Status: Done
Summary: This plan proposes aligning the seasons of RetroPGF and Optimism Fractal, with each season lasting 13 weeks. The plan also includes details about the themes and dates for each season. The exact length of RetroFunding is still to be determined. More information can be found in the provided links.
Created time: March 26, 2024 6:24 PM
Last edited time: April 10, 2024 10:05 PM
Created by: Dan Singjoy

## Description

- [x]  scope out the seasons of retropgf and consider aligning seasonal themes for optimism fractal structure

- Perhaps going into the 26th event we could propose to formalize the first 5 seasons of optimism fractal as 13 weeks each
    - at the bottom of page can put that it’s subject to change, so it can be flexible if we want
    
    - [ ]  figure out the exact length of RetroFunding listen again to jonas’ answer- i think he said 2.5 months but he provided more details about how it will be quicker and previously it was also 2.5 months
        - Each round will last about two and half months.
        - The amount of rewards for each round will be announced 8-12 weeks before its start.
    
    - Optimism announced the next four rounds of RetroFunding (aka RetroPGF). More details in this [video](https://drive.google.com/file/d/1tEgcnEPWvb0IOVmHZEBt8w3ySK6Vj-sY/view?usp=sharing) and [recap](https://gov.optimism.io/t/optimism-community-call-recaps-recordings-thread/6937/33)

- Original Notes
    
    
    - Season 1: Bootstrap
        - Meeting #’s:  1-12
        - DatesL October 20th to early February
        - Theme: Bootstrap/sprout/impact/building/winter
        
    - Season 2:  Sprouting
        - Meeting #’s: 13-24
        - Dates: Early Feb to end of April
        - Theme: Council/bloom/spring/governance/decisions
        
    - Season 3: Onchain Builders
        - Meeting #’s: 25-36
        - Dates: Early May to Late July
        - Show: Superchain Builders
    
    - Season 4: Governance
        - Meeting #’s: 37-48
        - Early August to mid October
        - Show: Superchain Leaders
    
    - Season 5: Dev Tooling
        - Meeting #’s: 49-60
        - Mid October to Mid December
        - Show: Superchain Devs

[850M OP Dedicated to the Evolution of Retro Funding](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU)

[https://twitter.com/Optimism/status/1772664299359707556](https://twitter.com/Optimism/status/1772664299359707556)

- 
    - Season 1: Bootstrap
        - Meeting #’s:  1-12
        - Dates: October 20th to early February
        - Theme: Seeding/Bootstrap//sprout/impact/building/winter
        
    - Season 2:  Sprouting
        - Meeting #’s: 13-24
        - Dates: Early Feb to end of April
        - Theme: Sprouting/Council/bloom/spring/governance/decisions
        
    - Season 3: Onchain Builders
        - Meeting #’s: 25-36
        - Dates: Early May to Late July
        - Show: Superchain Builders
    
    - Season 4: Governance
        - Meeting #’s: 37-48
        - Early August to mid October
        - Show: Superchain Leaders
    
    - Season 5: Dev Tooling
        - Meeting #’s: 49-60
        - Mid October to Mid December
        - Show: Superchain Devs