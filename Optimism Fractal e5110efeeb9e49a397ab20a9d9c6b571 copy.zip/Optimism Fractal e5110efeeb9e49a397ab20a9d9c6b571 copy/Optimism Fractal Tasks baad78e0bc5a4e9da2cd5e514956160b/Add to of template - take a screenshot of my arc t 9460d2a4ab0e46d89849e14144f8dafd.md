# Add to of template - take a screenshot of my arc tabs for each presentation and keep them up next to the arc so I can see them without needing to see the sidebar. Also add key things to remember for each Subtask, like to ask each other if it’s the right time to hear feedback yet and to record it

Assignee: Dan Singjoy
Due: August 1, 2024
Project: Create template to prepare for each Optimism Fractal and Town Hall events  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20template%20to%20prepare%20for%20each%20Optimism%20Fract%20b8b3dd27b70f401fa43fbc942b812345.md)
Status: Not started
Task Summary: This task aims to enhance the presentation experience by adding screenshots of arc tabs next to the arc, allowing easy access without needing to view the sidebar. It also includes key reminders for each subtask, such as checking if it's the right time for feedback and recording it. Created by Dan Singjoy, assigned to Dan Singjoy, with a due date of August 1, 2024. The task is currently not started.
Summary: No content
Created time: June 14, 2024 9:07 AM
Last edited time: June 28, 2024 12:58 PM
Created by: Dan Singjoy