# Promote town hall in hats chat

Assignee: Dan Singjoy
Project: Prepare for Optimism Fractal 44 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Prepare%20for%20Optimism%20Fractal%2044%20114074f5adac80f1b58afdd32fcefefd.md)
Status: Done
Task Summary: This task aims to promote the town hall event in the Hats chat, encouraging community engagement and participation. The event will feature a deep dive into Hats Protocol and an innovative Community Interview game with co-founder David Ehrlichman, where attendees can propose and vote on questions.
Summary: The Optimism Town Hall will take place today at 18 UTC, featuring a deep dive into Hats Protocol with co-founder David Ehrlichman. Attendees can propose and vote on questions for a new Community Interview game using onchain reputation tokens. Registration is open, and the event will be recorded for future viewing. Links for RSVP and past event videos are provided.
Created time: October 3, 2024 8:58 AM
Last edited time: October 3, 2024 12:46 PM
Created by: Dan Singjoy
Description: The Optimism Town Hall will take place today at 18 UTC, featuring a discussion on Hats Protocol with co-founder David Ehrlichman. Attendees can propose and vote on questions using on-chain reputation tokens. The event will be recorded for future viewing, and participants are encouraged to RSVP and engage in the community interview game.

Hey Hats Community,

After the Respect Game at [Optimism Fractal](https://x.com/optimystics_/status/1841480075553738968), we'll have a deep dive into Hats Protocol during the Optimism Town Hall today at 18 UTC and everyone is invited! 

We’ll be joined by @DavidEhrlichman, who is a co-founder of Hats Protocol, Haberdasher Labs, and the author of Impact Networks. The topics on the agenda include a recap of the inaugural Hatathon (where the Optimism Fractal Hats Tree was selected as a co-winner), future synergies between Hats and Fractals, and David’s vision for Hats Protocol! You can learn more about David and the topics we’ll cover in this [Snapshot proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0x0cfaa0ece1320271907bc6e544bac6f75348fa4865736375dcff3e1fc4d9fdeb).

After a brief introductory segment, we’ll try a new kind of **Community Interview game** where community members can propose and vote on questions on the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth) using onchain reputation tokens (aka Respect). If there are questions or topics related to Hats Protocol that you’d like to be discussed during the Town Hall, then feel free to let me know so we can post it on the snapshot space for you and vote for your topic. The questions proposed in the Optimism Town Hall snapshot space will be prioritized during the discussion in order of Respect votes.

You’re welcome to [RSVP](http://lu.ma/optimystics) at the events calendar where you can find a link to the [zoom room](https://us06web.zoom.us/j/82510562614), watch exciting [videos](https://optimismfractal.com/videos) from past events (including our previous town hall episode about Hats Protocol from a few weeks ago), and [retweet](https://x.com/optimystics_/status/1841480075553738968)/[recast](https://warpcast.com/rosmari/0xc886b9c9) to support the movement. Today’s event will be recorded and the video will be shared for future watching. I hope to see you at today’s events 🤠 🌻 🧢 

(town hall pic)

Hey all,

I hope you're having a great day and are excited for today's events!

As Rosmari wrote above, we're going to try a new kind of experimental interview game at the Optimism Town Hall with David from Hats Protocol and everyone is welcome to propose their questions on the [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

To kick of the Community Interview game at the town hall, I created four questions to ask David. As Each of these questions are configured with a weighted voting option and the ability to abstain with a portion of your Respect, so you can signal your preferences by upvoting with different amounts on different questions.

As a reminder, there is about 15 minutes remaining to register for the upcoming council. I'm looking forward to seeing you all in a bit, playing the Respect Game together, and hearing your thoughts!

As always, we appreciate likes, retweets, and shares to help spread the word! Thank you for your support!

[https://fxtwitter.com/DanSingjoy/status/1841873865976279503](https://fxtwitter.com/DanSingjoy/status/1841873865976279503)

[https://fxtwitter.com/RosmariDigital/status/1841870642586464552](https://fxtwitter.com/RosmariDigital/status/1841870642586464552)

![image.png](Promote%20town%20hall%20in%20hats%20chat%20114074f5adac805a8703df9de29670aa/image.png)

Thank you Hodlon, good to hear from you! I’ve been wondering what you’ve been up to and hope that all is going well for you. Looking forward to seeing you more often again whenever your schedule allows :)