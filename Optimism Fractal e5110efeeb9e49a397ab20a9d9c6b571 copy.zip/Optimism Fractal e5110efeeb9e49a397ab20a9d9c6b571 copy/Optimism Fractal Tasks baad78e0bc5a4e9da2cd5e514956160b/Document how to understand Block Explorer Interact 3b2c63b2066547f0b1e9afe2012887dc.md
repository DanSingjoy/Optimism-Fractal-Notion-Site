# Document how to understand Block Explorer Interactions

Project: Improve Documentation for Optimism Fractal Tools (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Documentation%20for%20Optimism%20Fractal%20Tools%205e64d804bdda4f75aea849c05124ed55.md)
Status: In progress
Summary: No content
Created time: January 13, 2024 5:34 PM
Last edited time: January 13, 2024 5:37 PM
Created by: Dan Singjoy

## Description

[https://youtu.be/dU7Whneo5yI](https://youtu.be/dU7Whneo5yI)

## Related

[Improve Visibility for Optimism Fractal Respect](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Visibility%20for%20Optimism%20Fractal%20Respect%20d1cf886177f54f75a86b29cc78c6e31e.md)