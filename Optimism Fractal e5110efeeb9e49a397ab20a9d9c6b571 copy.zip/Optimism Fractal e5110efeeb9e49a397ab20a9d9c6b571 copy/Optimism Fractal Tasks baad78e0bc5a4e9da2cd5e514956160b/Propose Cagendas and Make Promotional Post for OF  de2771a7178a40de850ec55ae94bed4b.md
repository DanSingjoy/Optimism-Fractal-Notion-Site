# Propose Cagendas and Make Promotional Post for OF 25

Assignee: Dan Singjoy
Due: May 3, 2024
Project: Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Develop Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md), Plan Optimism Fractal Season 3 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md)
Status: Done
Task Summary: This task aims to propose Cagendas for collaborative agenda setting within the Optimism Fractal community. The proposal includes details on how Cagendas will be implemented, the benefits it offers, and the democratic process of topic selection. It also introduces the Optimism Town Hall as a platform for structured discussions and outlines the steps for community participation.
Summary: This document proposes the implementation of Cagendas for organizing discussion time in weekly events after playing the Respect Game. Cagendas is a social coordination game that allows community members to propose, discuss, and vote on topics with Optimism Fractal Respect. The proposal outlines the rules for proposing and voting on topics, as well as the vision for the Optimism Town Hall as a collaborative forum. The document also includes details about Cagendas, the rationale for the proposal, and information on how to contribute to its development.
Parent-task: Create Proposal to Implement Cagendas in Optimism Fractal Season 3  (Create%20Proposal%20to%20Implement%20Cagendas%20in%20Optimism%20%200c32c54f1a5b4a949dc89363b0012ba5.md)
Created time: May 8, 2024 8:55 AM
Last edited time: May 10, 2024 3:18 AM
Created by: Dan Singjoy

**Table of Contents**

## Create Proposal for Cagendas on Snapshot

**Should we implement Cagendas to organize discussion time in weekly events after playing the Respect Game?**

Cagendas is a social coordination game for collaborative agenda setting that empowers community members to propose, discuss, and vote on topics with Optimism Fractal Respect. There are simple rules to play Cagendas and an introduction to a new event below. Vote YES on this proposal if you agree to implement the following:

1. Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

2. Anyone who has earned Respect at Optimism Fractal can vote on polls with their Respect to help determine the discussion topic for each weekly event. 

3. Whichever poll has received the most votes in the Topic Poll by Monday at 17 UTC will be the topic discussed during the week’s event after the Respect Game.
    1. The poll for the topic proposal must end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event.

The Optimism Town Hall is envisioned as a collaborative forum and weekly event for structured discussions about Optimism. It is intended to replace our planning sessions with a more organized format and a greater focus on facilitating conversations that provide a positive impact for Optimism Collective governance. You can find more details about Cagendas, Optimism Town Hall, and rationale for this proposal on [this page](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md).

![cagendas proposal image2 new.png](Create%20Proposal%20for%20Cagendas%20on%20Snapshot%20c617aa3daef944c19013f656bbf65c26/cagendas_proposal_image2_new.png)

- Image Feedback
    
    
    ![cagendas proposal image2.png](Create%20Proposal%20to%20Implement%20Cagendas%20in%20Optimism%20%200c32c54f1a5b4a949dc89363b0012ba5/cagendas_proposal_image2.png)
    
    Hey @Rosmari,
    
    - I think that that it would be better if the sunny flower is a bit more centered. Right now he’s all the way to the left and there’s much more space to the right of the town hall. I suggest moving him over a bit to the right.
    - We might also want to consider adding:
        - the Sages around the Etherum logo in the bottom right corner
        - pheonix on a building
        - sunny shades
        - optimism sunny
    - It might be good to move Cagendas down a little bit lower too
    
    Hey @Dan Singjoy here it is:
    
    ![cagendas proposal image2 new.png](Create%20Proposal%20for%20Cagendas%20on%20Snapshot%20c617aa3daef944c19013f656bbf65c26/cagendas_proposal_image2_new.png)
    

# Post Proposal and Details on Discord

Hey all, 

I’m thrilled to introduce a proposal to start playing Cagendas after each Optimism Fractal event at a new community forum called Optimism Town Hall. I’d like to present this proposal at today’s event to kick off a fantastic third season and am curious to hear your thoughts about it. You can vote on the proposal [here](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d) and see details below:

**Introducing Cagendas**

Cagendas is a social coordination game for collaborative agenda setting that empowers Optimism Fractal community members to propose, discuss, and vote on topics with Respect.  This community agenda game provides a simple, structured, and scalable way for everyone who has earned Respect at Optimism Fractal to propose topics or vote on topics they want to discuss at weekly events after the Respect Game. Cagendas can create profound benefits by helping us prioritize discussions and ensuring that the topics that matter most get the attention they deserve. We’ve been developing Cagendas for over a year at Eden Fractal and I’m stoked to share it with everyone at Optimism Fractal and the Optimism Collective. You can explore more details and contribute to the development of Cagendas in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md). 

**Introducing Optimism Town Hall**

The Optimism Town Hall is envisioned as a new collaborative space for structured discussions about the Optimism Collective, powered by Optimism Fractal Respect. The Town Hall is intended to be a weekly event that replaces the Optimism Fractal planning sessions with a more organized approach to selecting discussion topics by voting with Respect and a greater focus on facilitating conversations that provide a positive impact for Optimism Collective governance. The Optimism Town Hall can provide you with a platform to help lead the Optimism Collective and create a better world for everyone. We have very exciting plans for the Optimism Town Hall and I look forward to collaborating with everyone there to actualize the [Optimistic Vision](https://www.optimism.io/vision). You can explore more details and contribute to the development of Optimism Town Hall in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md). 

**Implementation Proposal**

The rules of Cagendas are explained below. Please vote yes on this proposal if you agree to implement the following:

1. Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

2. Anyone who has earned Respect at Optimism Fractal can vote on polls with their Respect to help determine the discussion topic for each weekly event. 

3. Whichever poll has received the most votes in the Topic Poll by Monday at 17 UTC will be the topic discussed during the week’s event after the Respect Game.
    1. The poll for the topic proposal must end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event.

I believe that this proposal will position us well in our third season to provide the greatest impact for the Optimism Collective, help Optimism Fractal community members earn Retro Funding in Round 6, and catalyze exponential fractal growth to create profound benefits for all. You can see the proposal and Vote with Respect [here](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d). You can see more rationale about this proposal in this [introductory post](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md). Councilors, please review the proposal and let me know if you have any questions. I’m looking forward to hear everyone’s thoughts and would appreciate feedback!

![cagendas proposal image2.png](Create%20Proposal%20to%20Implement%20Cagendas%20in%20Optimism%20%200c32c54f1a5b4a949dc89363b0012ba5/cagendas_proposal_image2.png)

- Town Hall intro draft
    
    
    The Optimism Town Hall is envisioned as a collaborative forum and weekly event for structured discussions about Optimism. It is intended to replace our planning sessions with a more organized format and a greater focus on facilitating conversations that provide a positive impact for Optimism Collective governance. 
    

- Cagendas intro draft
    
    
    Cagendas provides a way to for communities to create agendas with Respect.
    
    - [x]  ask chat gpt to provide summary about town hall and cagendas
        - [x]  add summary of cagendas here based upon the toggle below
        - [x]  add summary of town hall and cagendas to other tasks in the projects as well
    
    Cagendas is a portmanteau of  provides a simple framework for choosing topics  By using the Respect token, members can influence the agenda based on collective priorities, ensuring inclusive participation and transparent decision-making. Inspired by the principles of respect and participation that underpin the Optimism Collective, Cagendas provide a framework for structuring and prioritizing discussions. They ensure that the topics that matter most to our community get the attention they deserve.
    
    Cagendas is a consensus game for collaborative agenda setting that empowers members to propose, discuss, and vote on important topics within their community. By using the Respect token, members can influence the agenda based on collective priorities, ensuring inclusive participation and transparent decision-making. This model encourages meaningful engagement and aligns discussions with the shared interests of the community, fostering a collaborative environment where all voices are valued.
    
    Cagendas, or Collaborative Agendas, represent a new approach to facilitating conversations and consensus-building within our community. Inspired by the principles of respect and participation that underpin the Optimism Collective, Cagendas provide a framework for structuring and prioritizing discussions. They ensure that the topics that matter most to our community get the attention they deserve.
    
    **Cagendas: Structured Topic Selection for Maximum Impact**
    
    Cagendas is a structured system that empowers anyone who has earned Respect through the Optimism Fractal network to propose discussion topics. This process ensures that the topics addressed at each Optimism Town Hall reflect the community's most pressing concerns. Members can suggest topics by creating polls in the Optimism Town Hall snapshot space, where voting is open to all with Respect credentials. The most popular topic is selected as the focus of the next Town Hall session, allowing for a highly democratic, inclusive, and transparent process.
    
    Cagendas is a structured process within the Town Hall that allows anyone who has earned Respect to propose discussion topics via a poll, ensuring that the most popular and impactful subjects are prioritized. This initiative fosters inclusive participation, meaningful conversations, and collective growth, enabling the community to align its priorities and make informed decisions for decentralized governance.
    
    **Cagendas Implementation Proposal for Optimism Town Hall**
    
    Cagendas, the social coordination game, has been proposed for integration into the Optimism Town Hall to enhance the way topics are chosen and discussed within the Optimism Collective. Powered by Optimism Fractal Respect, this tool is designed to democratize the agenda-setting process by allowing anyone who has earned Respect to propose topics. This is facilitated through the creation of a poll in the new Optimism Town Hall snapshot space, potentially added as a sub-space in the Optimism Fractal snapshot space. The topic that garners the most votes by Monday at 17 UTC each week will be selected for discussion in that week's event after the Respect Game.
    
    **Enhanced Discussion Dynamics at Optimism Town Hall**
    
    The Optimism Town Hall is being envisioned as a new collaborative space where structured discussions can occur about the broader Optimism ecosystem. This new format aims to replace the less structured Optimism Fractal planning sessions with a more organized approach. By voting with Respect, community members can focus discussions on topics that offer the most substantial potential impact for Optimism Collective governance. The initiative reflects a strong commitment to actualizing the Optimistic Vision, enhancing community engagement, and fostering a proactive governance environment.
    
    **Strategic Benefits and Broader Engagement**
    
    Introducing Cagendas into the Optimism Town Hall is expected to streamline how discussions are prioritized and conducted, making meetings more efficient and aligned with community interests. This structure not only encourages broader participation by respecting community members' inputs but also ensures that discussions are centered around topics with significant community backing. Furthermore, the use of a democratic and transparent voting process for topic selection underscores a commitment to inclusive and balanced community representation.
    
    **Future Developments and Community Involvement**
    
    The proposal for Cagendas at Optimism Town Hall is part of broader efforts to innovate and refine community interaction within the Optimism ecosystem. Community members are encouraged to participate in polls and discussions, whether or not they attend weekly events, fostering a deeper understanding of Respect and enhancing overall community engagement. This initiative is expected to inspire further participation and lead to richer, more constructive discussions that could shape the future of the Optimism Collective.
    
    For those interested in more detailed developments or wishing to contribute to the continuous improvement of this initiative, further information and ongoing updates can be found through the project documentation and discussions hosted on platforms like Notion and the respective snapshot space. This is a dynamic project with potential significant impacts on how the Optimism Collective navigates governance and collaborative processes moving forward.
    
    **Cagendas: A Tool for Collaborative Agenda Setting**
    
    Cagendas is a social coordination game designed to help communities create agendas, choose discussion topics, and make collective decisions together. It aims to facilitate creative collaboration and collective decision-making in a structured yet enjoyable way. The game is built to be fair, fast, and fun, making it accessible and engaging for participants.
    
    **Concept and Development**
    Created in late 2022, Cagendas has been continuously developed to improve its functionality and user experience. The game operates by allowing community members to propose topics, which are then voted on. The most popular topics are selected for discussion during weekly events. This process helps allocate time efficiently among discussed topics, ensuring that all voices can be heard and that the most pressing issues are addressed first.
    
    **Community Engagement and Usage**
    The Eden Fractal community has been particularly active in utilizing Cagendas, producing videos and engaging in detailed discussions about its use. Different game modes, like Vlalendas, have been developed to keep the gameplay dynamic and adaptable to different group needs.
    
    **Educational and Organizational Impact**
    Cagendas supports communities in scheduling activities together to maximize benefits for all participants. By moving away from the traditional single-leader agenda-setting model, Cagendas empowers every member of the community to contribute to the agenda, democratizing the process and potentially leading to more thoughtful and inclusive discussions.
    
    For those interested in implementing Cagendas in their community or learning more about the specifics of the game, additional resources and detailed guides are available at EdenCreators.com/cagendas, including historical contexts, variations of the game, and upcoming developments.
    
    This community agenda game enables everyone who has earned Respect at Optimism Fractal to propose or use their Respect to vote on topics they want to discuss at weekly events after the Respect Game. This provides a simple framework for structuring and prioritizing discussions to ensure that the topics that matter most to our community get the attention they deserve. We’ve been developing Cagendas for over a year at Eden Fractal and I’m excited to share it with everyone in the Optimism Collective. You can explore more details and contribute to the development of Cagendas in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md). 
    

- Game rules paragraph
    
    
    Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the new Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth), which may be added as a sub-space in the Optimism Fractal snapshot space. Anyone who has earned Respect at Optimism Fractal can vote on polls with their Respect to help determine the discussion topic for each weekly event. Whichever poll has received the most votes in the Topic Poll by Monday at 17 UTC will be the topic discussed during the week’s event after the Respect Game. The poll for the topic proposal must end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event.
    

## Announce starting promptly at 17 utc and opening the room 5-10 minutes early for anyone who would like to talk before the recording and opening presentation

In this season I plan to start recording the video and sharing an introductory presentation promptly at 17 UTC. This will provide us with more time to finish playing the Respect Game then discuss topics afterwards and help make the most of everyone’s time. I’ll also aim to open the zoom room 5-10 minutes early for each event to provide an open space for anyone who’d like to talk for a bit before the event begins. 

## Reminder

As a reminder, there are currently about x hours left to register for next week’s council. If you’d like to participate in the next week’s council, please [register here](https://snapshot.org/#/optimismfractal.eth/proposal/0x19936a78d2ea6e60c3bb2105f5d5cd230815f2121c73bdcabb30b2b3ab7bf010) before the upcoming event at 17 UTC.  Looking forward to seeing you soon!

## create post about this

[Introducing Cagendas and Optimism Town Hall](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md)

Include rationale about meta governance that I wrote in [Review Methods for Voting with Respect in Notion and Snapshot via the Notion API](Review%20Methods%20for%20Voting%20with%20Respect%20in%20Notion%20a%20b037b35cca164e52898682c5957aa1a2.md) 

- [x]  also add a link to the rationale or state that it’s on the page in the introductory post on discord

[Review Inspiration and Market Need for Optimism Fractal Season 3, Cagendas, and Optimism Town Hall from Optimism Collective](Review%20Inspiration%20and%20Market%20Need%20for%20Optimism%20Fr%20697cb5ced841411ca4c7791e0957d183.md) 

[Explore the Optimism Collective's Experiments in Impact Juries and Deliberative Processes for Impact Evaluation ](Explore%20the%20Optimism%20Collective's%20Experiments%20in%20I%20e43c8c0159e44728b15daca5f6495ce9.md) 

[Plan Optimism Fractal Season 3](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%203%20a43df029ee964a3599c25be55d4387d4.md) 

## promotional message

### To do

- [x]  set the proposal to expire on next Thursday so either this week or next week’s council could approve it
- [x]  consider if the proposal should also include additional text from below.
    - I think that I should include a bit as is currently above, and then link to a notion page with more details