# Research Jokerace Circuits to Gamify OPTOPICS or Cagendas

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Research JokeRace for Cagendas and OPTOPICS  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20JokeRace%20for%20Cagendas%20and%20OPTOPICS%2062b9e52fb4994fd2902dc10fb082e592.md), Develop OPTOPICS Cagendas Game for Optimism Town Hall Events (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20OPTOPICS%20Cagendas%20Game%20for%20Optimism%20Town%20H%20473d58a379594254821c4c59201faaf0.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md)
Status: Not started
Task Summary: This task aims to research Jokerace Circuits and explore their potential for gamifying OPTOPICS or Cagendas. Created by Dan Singjoy, this project is set to be completed by July 31, 2024. The goal is to leverage Jokerace Circuits to enhance onchain UX and enable users to tie transactions on the site to onchain actions, such as buying tokens, minting NFTs, crowdfunding, earning credentials, and more.
Summary: The document discusses the research on Jokerace circuits to gamify OPTOPICS or Cagendas. It introduces the concept of tying transactions on a site to onchain actions, allowing users to buy tokens, mint NFTs, crowdfund, earn credentials, and provide liquidity through voting. The document seeks support in spreading the word about this new onchain UX unlock.
Created time: May 30, 2024 6:33 AM
Last edited time: July 16, 2024 9:40 AM
Created by: Dan Singjoy
Description: The document discusses the research on Jokerace circuits to gamify OPTOPICS or Cagendas. It explains how circuits can tie transactions on a site to onchain actions, allowing users to buy tokens, mint NFTs, crowdfund, earn credentials, and provide liquidity. The document also mentions the potential for onchain UX improvement and requests support in spreading the word about this new feature.

[Telegram](https://t.me/c/1562442437/1/6444)

 David Phelps (send me all your eth), [May 24, 2024 at 10:43 AM]
this is our favorite thing we've ever shipped: it's called circuits.

and it means that you can tie any transaction on our site to any onchain action. so when you vote on our site, you can be buying tokens, minting nfts, crowdfunding for the winning submission, earning credentials, providing liquidity, etc.

imagine a demo day where votes all bought up the token. or imagine a fashion contest where your vote bought you the winning item. that's possible now.

we'd love your support in getting the word out because all else aside, this is the kind of unlock for onchain UX that just was never possible until now.

https://x.com/jokerace_io/status/1794015072077160718