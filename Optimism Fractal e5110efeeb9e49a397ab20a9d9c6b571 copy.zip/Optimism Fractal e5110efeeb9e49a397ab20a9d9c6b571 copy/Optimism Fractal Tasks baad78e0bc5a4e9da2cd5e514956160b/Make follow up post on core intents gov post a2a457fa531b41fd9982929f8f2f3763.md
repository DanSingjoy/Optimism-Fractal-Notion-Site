# Make follow up post on core intents gov post

Assignee: Dan Singjoy, Rosmari
Due: July 31, 2024
Status: Not started
Task Summary: This task aims to create a follow-up post on the core intents government post. The post will include various updates and additional resources related to governance processes on the superchain, along with an invitation to an upcoming event. The assigned creator is Dan Singjoy, with Rosmari also involved in the assignment.
Summary: This follow-up post on core intents for government includes tasks such as including a video of season 6, inviting to this week's event, including an article on the history of fractals, and considering posting on Paragraph and elsewhere. It is also suggested to ask Rosmari to post it instead.
Created time: July 2, 2024 9:03 AM
Last edited time: July 16, 2024 9:41 AM
Created by: Dan Singjoy
Description: This follow-up post on core intents government post includes tasks such as including a video of season 6, inviting to this week's event about helping the superchain, including the history of fractals article as an additional resource, and considering posting on Paragraph and elsewhere. It is also suggested to ask Rosmari to post it instead.

- [ ]  include video of season 6
    - [ ]  include town hall video and/or timestamp

- [ ]  invite to this week’s event about helping the superchain

- [ ]  include the history of fractals article as an additional resource that you can explore to learn more about governance processes.

- [ ]  also consider including link to council page and optimism town hall (where we vote for topics with soulbound reputation tokens) as more specific examples of how we’re optimizing governance on the superchain so far

- [ ]  consider posting this on paragraph, then posting it elsewhere and letting them know about the paragraph post

- [x]  consider asking rosmari to post it
    - i think its better for rosmari to follow up than me