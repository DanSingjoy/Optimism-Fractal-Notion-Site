# Create and Share registration poll for Optimism Fractal Council

Status: Not started
Task Summary: This task aims to create and share a registration poll for the Optimism Fractal Council. The poll will be used to gather registration information from participants interested in joining the council. The creator of the poll is Dan Singjoy, and the task status is currently not started.
Summary: No content
Created time: May 17, 2024 8:25 PM
Last edited time: May 17, 2024 8:26 PM
Created by: Dan Singjoy