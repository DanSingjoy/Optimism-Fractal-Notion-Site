# Create Paragraph post: Introducing Optimism Town Hall

Status: Not started
Task Summary: This task aims to create a 2-4 sentence summary/intro for the page titled "Create Paragraph post: Introducing Optimism Town Hall." The page provides information about Optimism Town Hall, including how to participate in the event, propose topics, and contribute to its development. It also highlights the role of Cagendas, a social coordination game, in organizing discussions and prioritizing topics. The page invites readers to join the event and become part of the Optimism Collective to create a better world.
Summary: Introducing Optimism Town Hall, a platform for collaborative agenda setting and discussions within the Optimism Collective. The Town Hall is powered by Optimism Fractal and features Cagendas, a social coordination game for proposing and prioritizing topics. Participants can earn Respect tokens by playing the Respect Game at weekly events. Join the Town Hall, propose topics, contribute to development, and help lead the Optimism Collective.
Created time: May 20, 2024 10:15 PM
Last edited time: May 21, 2024 4:00 PM
Created by: Dan Singjoy

- [ ]  find and read rosmari’s draft
    - [ ]  consider asking ai about specific sections too in the other chat

Join the event on this Thursday to participate in Optimism Town Hall and feel free to reach out with any questions.

- Join Optimism Town Hall [weekly events](https://lu.ma/optimismtownhall) and share your thoughts. Your opportunity to help lead.
- Propose topics in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth). Choose the most helpful topics and that you think deserve attention.
- Suggest topics on Optimism Town Hall [discord channel](https://discord.gg/ZKv3tRWrSr) or the optimism [governance forum](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Promote%20OTH%201%203de5089a487a4e3ba2aba5d2fa5c8115.md). Explore the new OPTOPICS game for more about this
- Contribute to the development Optimism Town Hall the [notion project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md). Explore subj
- Participate in Optimism Fractal Respect Games to earn Respect and gain influence intt
- Watch videos and share with friends

- Join [weekly events](https://lu.ma/optimismtownhall)
- Propose topics in the [snapshot space](https://snapshot.org/#/optimismtownhall.eth)
- Suggest topics in the [discord channel](https://discord.gg/ZKv3tRWrSr)
- Contribute in the [notion project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Optimism%20Town%20Hall%201c4442c3bbbb4b9bb506b92a6fc9cd8a.md)
- Participate in Optimism Fractal Respect Games to earn Respect and gain influence intt
- Watch videos and share with friends

- 
    
    
    Optimism Town Hall is presented by [Optimystics](https://optimystics.io/) and powered by [Optimism Fractal](https://optimismfractal.com/), a community dedicated to fostering collaboration and awarding public good creators on Optimism. Optimism Fractal hosts weekly events one hour before Optimism Town Hall where anyone can earn an onchain reputation token called [Respect](https://optimystics.io/respect) by playing the [Respect Game](https://optimystics.io/respectgame), a fun consensus process that helps foster collaborations, evaluate positive impact, and coordinate decentralized governance.
    
    One of the unique features of Optimism Town Hall is how discussions are organized in a democratic and interactive manner with Cagendas, a social coordination game for collaborative agenda setting that empowers Optimism Collective community members to propose, deliberate, and prioritize discussion topics with an onchain reputation token called [Respect](https://optimystics.io/respect). Anyone can earn Respect by playing the [Respect Game](https://optimystics.io/respectgame) at Optimism Fractal [weekly events](https://lu.ma/optimismfractal), which occur one hour before Optimism Town Hall events (on Thursdays at 17 UTC).
    
    Anyone can earn Respect by playing the [Respect Game](https://optimystics.io/respectgame) at Optimism Fractal [weekly events](https://lu.ma/optimismfractal), which occur one hour before Optimism Town Hall events (on Thursdays at 17 UTC).
    

## How it Works- Cagendas

Cagendas is a social coordination game for collaborative agenda setting that empowers Optimism Collective community members to propose, deliberate, and prioritize discussion topics with [Respect](https://optimystics.io/respect), an onchain reputation token that people can earn by playing the [Respect Game](https://optimystics.io/respectgame) at Optimism Fractal [weekly events](https://lu.ma/optimismfractal).

Anyone who has earned [Respect](https://optimystics.io/respect) by playing the Respect Game Optimism Fractal [weekly events](https://lu.ma/optimismfractal) can propose a different topic to discuss after this week’s Respect Game event by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth)

 Cagendas can create profound benefits by helping us prioritize discussions and ensuring that the topics that matter most get the attention they deserve. We’ve been developing Cagendas for over a year at Eden Fractal and I’m stoked to share it with everyone at Optimism Fractal and the Optimism Collective. You can explore more details and contribute to the development of Cagendas in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md). 

The Optimism Town Hall can provide you with a platform to help lead the Optimism Collective and create a better world for everyone.

## Next Steps

Design of Cagendas, including a new community agenda game called Optopics. 

Promotional strategy

Rationale

OPC

## Optimism Fractal Season 3

- [ ]  keep this short

If you’re not familiar with Optimism Fractal, check out OptimismFractal.com

After the first event of Optimism Fractal Season 3, the [council](https://optimismfractal.com/council) approved a proposal to start playing a consensus game called Cagendas to organize discussion topics at Optimism Town Hall. Learn more in our article . Remember to sign up for the event.

See the notion project to see how you can get involved

RetroFunding opportunities

join events

council

watch videos

This channel provides a place where we can suggest and discuss topics for Optimism Town Hall [weekly events](https://lu.ma/optimismtownhall) that occur after the Respect Game at Optimism Fractal. 

## Videos

- [ ]  add videos and timestamps of events

[https://www.youtube.com/watch?v=XdzOMH54LrM&t=3975s](https://www.youtube.com/watch?v=XdzOMH54LrM&t=3975s)

- 
    
    [1:06:15](https://www.youtube.com/watch?v=XdzOMH54LrM&t=3975s)
    
    - Dan starts the first Optimism Town Hall presentation, discussing its purpose and the respect game for coordination. Aims to help the Optimism collective
    Dan details the Cagendas game at the Town Hall, urging topic proposals and votes using respect tokens.
    Dan discusses Town Hall projects, including promotional strategies and agendas development.
    
    [1:10:10](https://www.youtube.com/watch?v=XdzOMH54LrM&t=4210s)
    
    Dan note the weekly times of optimism fractal @ 17 utc and Optimism town hall @ 18 utc
    
    [1:13:08](https://www.youtube.com/watch?v=XdzOMH54LrM&t=4388s)
    
    Dan summarizes the Town Hall's rationale, notion site, discussing RPGF rounds and support for public goods creators.
    
    [1:15:25](https://www.youtube.com/watch?v=XdzOMH54LrM&t=4525s)
    
    Dan notes Cagendas has been in use at Eden fractal, shares links for additional articles and resources.
    
    [1:16:20](https://www.youtube.com/watch?v=XdzOMH54LrM&t=4580s)
    
    Dan highlights the Collective's meta-governance path and the Town Hall's role in community engagement.
    
    [1:22:01](https://www.youtube.com/watch?v=XdzOMH54LrM&t=4921s)
    
    Gene asks about RPGF funding, and Dan mentions past funding and goals for financial stability.
    
    [1:24:25](https://www.youtube.com/watch?v=XdzOMH54LrM&t=5065s)
    
    Dan concludes, inviting feedback and emphasizing the Town Hall's importance in governance.
    
    [1:25:03](https://www.youtube.com/watch?v=XdzOMH54LrM&t=5103s)
    
    Gene expresses appreciation for the Optimism Fractal team's work, eager to participate further. The meeting concludes, with Abraham and Gene inspired by the discussions and efforts.
    
    [1:29:30](https://www.youtube.com/watch?v=XdzOMH54LrM&t=5370s)
    
    Go optimism fractal.
    

## Review and curate or link prior posts

- [ ]  [Introducing Cagendas and Optimism Town Hall](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md)

- [ ]  [Introducing OPTOPICS](Create%20Introductory%20post%20for%20Optopics%20at%20Optimism%20%208a4b346168bb412b80d1674b5767263a/Introducing%20OPTOPICS%20ef3bf6a9cc204ddfb0115b60af1c9d6e.md)

- [ ]  Review the following and see which parts should be included

- Update Post and First Topic Proposal, May 12th
    
    
    # Post in Discord, May 12th
    
    Hey everyone! Thanks for the great event on Thursday, it was amazing seeing you all and a wonderful way to start season 3 of Optimism Fractal!
    
    I’m pleased to announce that the [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d) to implement Cagendas after the Respect Game at weekly events was approved by the Optimism Fractal [council](https://optimismfractal.com/council). This means that we’ll host the first Optimism Town Hall event this upcoming Thursday at 18 UTC following our weekly Respect Game (instead of the Optimism Fractal planning sessions) and a topic for the event will be chosen on Monday at 17 UTC according to the rules in the proposal. We’ll also repeat this process at weekly events going forward until some other change is proposed and approved with our community’s consensus [process](https://optimismfractal.com/details#block-e42fb7c2317c49bb92fc4165c01b20ae). I appreciate all the thoughtful feedback shared during the event and the votes in support of the proposal. 
    
    To kick off the first town hall, I just created a [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0xa35337aff287c57648a2dfe3e5d5f44053d9677606fbd26b5b9b7b2bd7e19505) called *Exploring Optimism Town Hall and Cagendas.* At this event, I’d like to share a brief presentation that provides a more in-depth overview of the potential benefits, next steps, and rationale of these new initiatives. The material for this topic can be found in the [introductory post](Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md), which includes links to projects with more details about Optimism Town Hall, Cagendas, Optimism Fractal Season 3, and the value that these initiatives can provide for the Optimism Collective. We’ll have an open discussion after the presentation and I’d love to hear more feedback about this topic, so please feel free to share any thoughts here in the chat or at the upcoming town hall event.
    
    As per the rules approved in the proposal, anyone who has earned Respect at Optimism Fractal can propose a different topic to discuss after this week’s Respect Game event by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth). Anyone who has earned Respect at Optimism Fractal can vote on these polls with their Respect to help determine the discussion topic for each weekly event and whichever topic proposal received the most votes by Monday at 17 UTC will be the topic discussed during the upcoming Town Hall event. If you want to propose a topic, make sure to set your topic proposal poll to end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event. Feel free to propose any topic that is related to Optimism Fractal or the Optimism Collective.
    
    For anyone who missed last week’s event, I recommend watching the videos that Rosmari shared above to see all the great things that happened in our first episode of Optimism Fractal Season 3. We discussed this proposal to start playing Cagendas at Optimism Town Hall in the first 10 minutes and the last 15 minutes of the event, as you can see [here](https://youtu.be/-QbLQgOZKwk?si=1HWE2baRjbiY_lH5&t=4507). In addition there were also outstanding contributions in the Respect Game, awesome discussions with talented newcomers, and a very interesting conversation about collaborating to build the upcoming Optimism Fractal app. 
    
    You can respectfully vote for my [topic proposal](https://snapshot.org/#/optimismtownhall.eth/proposal/0xa35337aff287c57648a2dfe3e5d5f44053d9677606fbd26b5b9b7b2bd7e19505) and/or make an alternative topic proposal for this week’s town hall until Monday at 17 UTC. I encourage everyone to register for our weekly Optimism Town Hall [event](https://lu.ma/optimismtownhall) and invite friends who are interested in Optimism. I’m looking forward to seeing all the topics that the community will propose this season and excited to see you all at our 26th event on Thursday! Thank you! 🙏🏽🌻🌞
    
    ![optimism town hall proposal image final  wider 155 copy.png](Announce%20Cagendas%20Proposal%20Approval%20and%20Create%20Top%204cff51c0dd2a4eb0944594673c0b8c85/optimism_town_hall_proposal_image_final__wider_155_copy.png)
    

- [ ]  consider forage xyz as well