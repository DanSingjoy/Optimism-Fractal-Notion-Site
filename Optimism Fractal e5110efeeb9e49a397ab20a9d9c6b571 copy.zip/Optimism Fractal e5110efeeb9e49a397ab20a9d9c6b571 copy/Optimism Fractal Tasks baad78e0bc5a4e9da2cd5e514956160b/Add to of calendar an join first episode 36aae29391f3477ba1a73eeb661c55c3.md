# Add to of calendar an join first episode

Assignee: Dan Singjoy
Due: May 29, 2024
Status: Done
URL: https://x.com/reformed_normie/status/1795485360102809897?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to add the first episode of the calendar and join it. The page is created by Dan Singjoy and assigned to Dan Singjoy. The task is marked as done and has a due date of May 29, 2024. For more details, you can visit https://x.com/reformed_normie/status/1795485360102809897?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ.
Summary: Add the first episode to the calendar. Task created by Dan Singjoy with a due date of May 29, 2024. The task has been marked as done. For more details, refer to the URL: https://x.com/reformed_normie/status/1795485360102809897?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ.
Created time: May 28, 2024 6:14 PM
Last edited time: June 1, 2024 10:37 PM
Created by: Dan Singjoy

[https://x.com/reformed_normie/status/1795485360102809897?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/reformed_normie/status/1795485360102809897?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)