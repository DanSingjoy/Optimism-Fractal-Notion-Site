# Explore Integrations with Hats Protocol and EAS

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: Explore integrations with Hats Protocol and EAS to review dApps from a Farcaster's frame, powered by EAS behind the scenes. Example available at: https://warpcast.com/maximeservais/0x77a78d12
Created time: April 25, 2024 4:15 AM
Last edited time: April 25, 2024 4:16 AM
Created by: Dan Singjoy

## Description

## EAS Integrations with Hats

Another question that I’ve been wondering is if there has been much integration between Hats Protocol and EAS. 

I searched the Hats Protocol chat for EAS last month and found some 

I’m wondering if we should design our next app with EAS from the first release and if there may be some synergy in integrating Hats with  EAS

- More details in [Explore and Create Integrations with Ethereum Attestation Service (EAS)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20and%20Create%20Integrations%20with%20Ethereum%20Atte%2032090d470ad74557a94230909f21f168.md)

- [ ]  consider this integration again. Why did i start writing this and what integration might make sense to pursue between EAS and Hats?

- I think i should save this as a subtask to review later. I’m not sure why i would ask about it now

[Maxime Servais, [Apr 26, 2024 at 4:52 PM]
Hey everyone, it's now possible to review dApps from a Farcaster's frame :) All powered by EAS behind the scenes

Example here: https://warpcast.com/maximeservais/0x77a78d12
](Explore%20Integrations%20with%20Hats%20Protocol%20and%20EAS%2002d109ffeda34cdeaa3d6ec4570823f8/Maxime%20Servais,%20%5BApr%2026,%202024%20at%204%2052%20PM%5D%20Hey%20ever%20829952fd40ea42f19fe0a8d39b8cfbf5.md)