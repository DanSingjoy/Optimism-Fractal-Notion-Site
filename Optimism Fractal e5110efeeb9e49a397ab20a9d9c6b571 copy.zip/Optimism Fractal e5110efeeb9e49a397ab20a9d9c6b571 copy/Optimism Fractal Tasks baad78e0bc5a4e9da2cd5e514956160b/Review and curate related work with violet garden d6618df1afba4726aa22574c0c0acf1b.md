# Review and curate related work with violet.garden

Project: Build Optimism Fractal Social Media App + Integrations (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Social%20Media%20App%20+%20Integrat%201ae1eec23f4340f4b4b10f51d9f0ba89.md)
Status: Not started
Task Summary: This task aims to review and curate related work with violet.garden. The page, created by Dan Singjoy, provides information about violet.garden and its current status. It also includes several images and a link to additional information on the project's grants page.
Summary: No content
Created time: July 5, 2024 2:01 PM
Last edited time: July 5, 2024 2:30 PM
Parent task: Review and curate historical research and experiments with fractal social media (Review%20and%20curate%20historical%20research%20and%20experime%20ea73c13b0b63432d845e9f534e611504.md)
Created by: Dan Singjoy
Description: No content

[violet.garden](http://violet.garden) 

![Untitled](Review%20and%20curate%20related%20work%20with%20violet%20garden%20d6618df1afba4726aa22574c0c0acf1b/Untitled.png)

![Untitled](Review%20and%20curate%20related%20work%20with%20violet%20garden%20d6618df1afba4726aa22574c0c0acf1b/Untitled%201.png)

![Untitled](Review%20and%20curate%20related%20work%20with%20violet%20garden%20d6618df1afba4726aa22574c0c0acf1b/Untitled%202.png)

![Untitled](Review%20and%20curate%20related%20work%20with%20violet%20garden%20d6618df1afba4726aa22574c0c0acf1b/Untitled%203.png)

[https://pomelo.io/grants/violet](https://pomelo.io/grants/violet)