# Apply for free gas grants from base

Project: Create smooth onboarding experience for people to play the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20smooth%20onboarding%20experience%20for%20people%20to%20%20457af43bf13c4cb5b89919ac19c449cb.md), Build with Base (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20with%20Base%206e7b24bfdcb44020b6d789b186f4df42.md), Build Optimism Fractal Development Hub and Create Educational Resources for Builders (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Development%20Hub%20and%20Create%20%201b19b1098081451c9f593c4bd5552f3b.md)
Status: Not started
URL: https://x.com/jessepollak/status/1788019362148045144?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ
Task Summary: This task aims to provide information and guidance on how to apply for free gas grants from Base. The page, created by Dan Singjoy, includes details such as the status, URL, and creation and last edited times. It is a resource for individuals interested in accessing grants for free gas.
Summary: No content
Created time: May 8, 2024 12:27 AM
Last edited time: May 20, 2024 9:21 PM
Created by: Dan Singjoy

[https://x.com/jessepollak/status/1788019362148045144?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/jessepollak/status/1788019362148045144?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)