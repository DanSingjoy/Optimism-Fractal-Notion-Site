# Curate and create educational resources about the Optimism Collective

Project: Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md), Build Optimism Fractal Education Hub (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Build%20Optimism%20Fractal%20Education%20Hub%20ce3f948a4acf47bb8b9a9b12e87d90f5.md), Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md)
Status: Not started
Task Summary: This task aims to curate and create educational resources about the Optimism Collective. By gathering and organizing valuable information, we seek to enhance understanding and engagement with the Optimism Collective, ultimately fostering a community of informed contributors and learners.
Summary: The document outlines plans to curate and create educational resources about the Optimism Collective, suggesting the development of a dedicated page and possibly an Optimism Fractal Guide. While prioritizing educational efforts for Optimism Fractal, the Optimystics aim to provide basic resources and integrate contributions from others. They have already created various educational materials and identified specific niches for further educational initiatives, emphasizing collaboration and community engagement.
Created time: April 8, 2024 8:55 AM
Last edited time: April 8, 2024 9:34 AM
Created by: Dan Singjoy
Description: The document outlines plans to curate and create educational resources about the Optimism Collective, suggesting the creation of a dedicated page and a guide. While prioritizing educational efforts for Optimism Fractal, it emphasizes the importance of organizing basic resources and leveraging existing contributions from the Optimystics. The document also highlights specific educational niches to focus on, including event promotion and video content creation.

## Description

- [ ]  Consider upgrading this to a project in itself
    - Yes i think it definitely should be
    - [Consider organizing two different subprojects for education about the optimism collective and optimism fractal](Consider%20organizing%20two%20different%20subprojects%20for%20%20c242f7ca8ed04a31a3e6dfecf56b90f8.md)
    
- Perhaps we should create the Optimism Fractal Guide to the Optimism Collective

- Or maybe there should just be a page at the top of the [Education Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Education%20Hub%20225efc918f9f4644a39448be1eb3c7f0.md) to learn more about Optimism
    - Yes this is a good idea. It can just include very high level information of Optimism Collective like the website, then more can gradually be added over time
    - This can provide a place for anyone who is interested in contributing to the education about the Optimism Collective, while also contributing to Optimism Fractal’s education hub
    
- [x]  Create a page about the Optimism Collective at the top of the [Education Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Education%20Hub%20225efc918f9f4644a39448be1eb3c7f0.md) with some basic resources to get it started

- I just created a page called [Optimism Collective Resources](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Optimism%20Collective%20Resources%20c9726d323c53405aa0250f8de90b7822.md)
    
    

## Optimystics Contributions

### Optimystics Educational Strategy

- I plan to start a page about the Optimism Collective at the top of the [Education Hub](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Education%20Hub%20225efc918f9f4644a39448be1eb3c7f0.md) with some basic resources to get it started
    - Creating and curating many educational resources about the Optimism Collective isn’t a big priority for the Optimystics right now, but we should get it
        - Other people already have incentive to do this from RetroFunding and it is a much higher priority for us to organize educational resources about Optimism Fractal. This is Optimism Fractal’s job, so we need to focus on what we are most well positioned to do.
        - We can do well enough with a relatively small amount of curation and organization of content about Optimism that can help people get started in their journey learning about the Collective
            - Then we can benefit from it whenever better resources and curations are published by others and integrate this into our educational guide about the Optimism Collective
            

### More Optimystics Contributions

The Optimystics have already created and curated many educational resources about the Optimism Collective. Here is a quick list that we can contribute or others can see 

- Optimystics Optimism Article
    - See [optimystics.io/blog](http://optimystics.io/blog) for more related articles and videos
    
- We have a playlist with many great videos, though idk if it’s actively updated

- We have made many videos and articles about Optimism at Optimism Fractal and Optimism Fractal

- We have a lot of internal knowledge that we can share at events and then others can write it down. It’s easier to share at events then to create articles or videos specifically about it, and this is service we provide at events.

- Should we openly share prior notion pages with research?
    - There are many helpful links that can be curated and we’ve already done some of it, like links to podcasts about optimism and the reservoir and more
    

### Educational Niches for Optimystics and Optimism Fractal about the Optimism Collective

- There are certain niches of the Optimism Collective where we should lead educational efforts. This includes the [Create Calendar of Events for Optimism Collective](Create%20Calendar%20of%20Events%20for%20Optimism%20Collective%206f142fcf13744f73bf57b2cf7d454160.md).
    - Nobody else has such incentive to promote events like we do, we’ve already made a lot of progress, and it makes sense for us to further build this database
    - Similar things that might make sense for us to curate as well include [Communities](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Communities%2099bfea0c2f8b4900b2de4193321f9636.md) and videos since we’re closely aligned with video creation and collaborating with people from many different communities
    - Another idea is the Superchain Builders notion site, where we can enable contributors to Optimism Fractal to create personal profiles
        - Related ideas: [Eden Builders](https://www.notion.so/Eden-Builders-f1348214661844588bc5ec1b1331397f?pvs=21)
    

[Superchain Eco thread ](Curate%20and%20create%20educational%20resources%20about%20the%20%2058dc4c51824a4e27b6c4863bdcc8cf16/Superchain%20Eco%20thread%20165294e23ab94c23ae5fedab671e6e14.md)