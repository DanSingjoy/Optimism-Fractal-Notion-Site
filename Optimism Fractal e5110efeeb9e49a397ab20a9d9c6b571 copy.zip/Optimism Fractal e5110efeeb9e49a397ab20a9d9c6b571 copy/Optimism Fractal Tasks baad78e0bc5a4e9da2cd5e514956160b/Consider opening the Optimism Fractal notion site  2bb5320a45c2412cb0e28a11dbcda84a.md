# Consider opening the Optimism Fractal notion site to Search Engine Indexing

Assignee: Dan Singjoy
Due: August 2, 2024
Project: Create Optimism Fractal GPT (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20GPT%20115b79befafe400287e5338abca1c60b.md), Improve Promotions for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20Promotions%20for%20Optimism%20Fractal%20e937c2a5d1f1446ba73482490ea0b347.md), Improve OptimismFractal.com Website (and Create Educational Resources) (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20OptimismFractal%20com%20Website%20(and%20Create%20Ed%20b2c9b74af14043dd91d010fafddbd65e.md)
Status: Not started
Task Summary: This task aims to consider the possibility of opening the Optimism Fractal Notion site to search engine indexing. By doing so, it could potentially make the information more accessible and easier for AI or others to search. While there may be some privacy concerns, the potential upside of improved visibility and sharing outweighs the potential drawbacks.
Summary: Consider opening the Optimism Fractal Notion site to search engine indexing to make it easier for AI and others to search and access the information. The potential benefits include improved accessibility and sharing of information, while potential privacy concerns should be considered. Other strategies such as using notion exports or alternative methods may also be explored.
Created time: July 5, 2024 8:44 PM
Last edited time: July 23, 2024 12:06 PM
Created by: Dan Singjoy
Description: Consider opening the Optimism Fractal Notion site to search engine indexing to make it easier for AI and others to search and access the information. Pros include improved accessibility and sharing of information, while potential privacy concerns are a con. Other strategies such as using notion exports may not be necessary if search engine indexing is enabled.

![Untitled](Consider%20opening%20the%20Optimism%20Fractal%20notion%20site%20%202bb5320a45c2412cb0e28a11dbcda84a/Untitled.png)

Currently its off

I think its mostly likely a good idea to open this because this could help make it easier for AI (or others) to search it and there’s doesn’t seem to be much to lose by doing so

then i could add to the instructions of the custom GPT model that 

## Pros

- could help make it easier for AI (or others) to search it
    - using this with AI could be very powerful. then i could add the suggestion to search the notion address for more detailed answers in the instructions for the Optimism Fractal GPT
        - [ ]  try adding something like this also search this notion page and the notion pages within it to provide the best possible answer [https://edencreators.notion.site/OptimismFractal-com-c238e1244229466ba8b7753b74104b6f?pvs=4](https://www.notion.so/OptimismFractal-com-c238e1244229466ba8b7753b74104b6f?pvs=21)
        - [ ]  [Create Instructions for Optimism Fractal GPT](Create%20Instructions%20for%20Optimism%20Fractal%20GPT%2054c44a1c18b444d5afb826af9accc66d.md)
        
- we want to share all the info there far and wide and this will help us do that

## Cons

- potentially maybe there could be some privacy concerns with ai seeing all this data, but really i think the potential upside is much higher because we want to make the information more accessible and

Could enable this on the root page to improve SEO

![Untitled](Consider%20opening%20the%20Optimism%20Fractal%20notion%20site%20%202bb5320a45c2412cb0e28a11dbcda84a/Untitled%201.png)

## Other strategies

- could also [Add Optimism Fractal notion workspace file to Optimism Fractal GPT](Add%20Optimism%20Fractal%20notion%20workspace%20file%20to%20Opti%206b32055a5c1d48afb1f62817c059e8fd.md) to [Create Optimism Fractal GPT](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20GPT%20115b79befafe400287e5338abca1c60b.md), but search engine indexing is easier and may create more updated results
    - this seems to be a very good idea and might make it not necessary to use notion exports