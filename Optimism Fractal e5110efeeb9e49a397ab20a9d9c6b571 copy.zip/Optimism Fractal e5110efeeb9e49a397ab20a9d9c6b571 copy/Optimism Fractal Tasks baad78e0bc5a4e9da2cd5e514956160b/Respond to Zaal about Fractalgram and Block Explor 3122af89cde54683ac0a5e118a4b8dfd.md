# Respond to Zaal about Fractalgram and Block Explorers

Assignee: Dan Singjoy
Due: July 1, 2024
Project: Create educational resources about the history of Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20about%20the%20history%20of%20%20fdcb0d490a9a41ce95992d8947236df6.md), Create educational resources about onchain transactions at Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20about%20onchain%20transac%20f84d5114140a43d4a0f54dee6ac72024.md), Create educational resources and webpages on OptimismFractal.com (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20and%20webpages%20on%20Optim%20956c07fca69c43e1b6a3b5a1cf4598da.md), Create educational resources about the Respect Game (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20educational%20resources%20about%20the%20Respect%20Gam%205358593e00644fea9ceb6e2a741bb3d5.md)
Status: Done
Task Summary: This task aims to respond to Zaal regarding Fractalgram and Block Explorers. It provides information on finding transactions for Optimism Fractal using block explorers like Etherscan and Blockscout. Additionally, it addresses issues related to group limitations and polling options in Fractalgram.
Summary: To find transactions for Optimism Fractal, you can use block explorers like Etherscan or Blockscout. There may be issues with group sizes in Fractalgram, and sometimes poll options take time to appear after the page is loaded.
Created time: July 23, 2024 11:29 AM
Last edited time: July 23, 2024 10:27 PM
Created by: Dan Singjoy
Description: To find transactions for Optimism Fractal, you can use block explorers like Etherscan or Blockscout. There may be some issues with the Fractalgram web app, such as not working in groups with less than three or more than six people, and a delay in poll options appearing after the page is loaded.

![Untitled](Respond%20to%20Zaal%20about%20Fractalgram%20and%20Block%20Explor%203122af89cde54683ac0a5e118a4b8dfd/Untitled.png)

I think that depends on the address where the smart contracts are deployed. For Optimism Fractal, you can find the transactions on this address in block explorers like [Etherscan](https://optimistic.etherscan.io/address/0x53c9e3a44b08e7ecf3e8882996a500eb06c0c5cc) or [Blockscout](https://optimism.blockscout.com/token/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC?tab=token_transfers). You can watch this [video](Watch%20Intro%20Video%20explaining%20Optimism%20Fractal%20Resp%2062c31d4f53724b83adda121764bf9c8b.md) to see how to see the ranks submitted each for breakout room are displayed with the current software implementation.

- Answers
    
    
    It doesn’t work in telegram groups with less than three people or more than six people, so that explains the issue with the group of two. It should work perfectly with a group of 6, though if there were 7 people in the group and then one person left then maybe that could cause an issue. I’ve also needed to re-sign into the fractalgram web app once or twice in the past to refresh it after an update, though haven’t needed to do that in a long time
    
    It also sometimes takes some time for the poll options to appear after the page is loaded. More noticeable when you enter a pre-existing group with more messages.
    
    ## Related Notes
    
    [Troubleshooting Fractalgram](https://www.notion.so/Troubleshooting-Fractalgram-2ad0191414a84d77beb6f33bb7298b64?pvs=21) 
    
    [Produce Fractalgram training video (from OF 12’s recording)](https://www.notion.so/Produce-Fractalgram-training-video-from-OF-12-s-recording-1284c462aa3249c2a1450d3b4eeb6ee1?pvs=21) 
    
    [Create Resources for hosts to implement the Respect Game in their communities or organizations](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Resources%20for%20hosts%20to%20implement%20the%20Respec%204b3a3aacea0647e8b1f527b2d1dadc23.md) 
    

More details:

[How to run the Fractalgram app?](../Optimism%20Fractal%20FAQ%201ce16d6520064186b40f6ad1f211c5f3/How%20to%20run%20the%20Fractalgram%20app%20e65ec065477241e98d330e2d83a194ad.md)