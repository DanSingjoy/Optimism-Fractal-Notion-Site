# Message Antoine Vergnes about his work with citizen's councils, our work with fractals, and collaborations

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Network and collaborate with governance enthusiasts in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Network%20and%20collaborate%20with%20governance%20enthusiast%20d5efbbcde39e4bf9a7a16aec51786709.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md)
Status: Not started
Task Summary: This task aims to message Antoine Vergnes regarding his work with citizen's councils, our work with fractals, and potential collaborations. The page includes a message expressing interest in his articles, presentations, and experiments with deliberative processes in the Optimism Collective. It also provides relevant websites and offers assistance and opportunities for collaboration.
Summary: Dan Singjoy reached out to Antoine Vergnes regarding his work with citizen's councils, their work with fractals, and potential collaborations. Dan mentioned reading Antoine's articles and watching his presentations, and expressed interest in the experiments with deliberative processes in the Optimism Collective. Dan also provided links to relevant websites and expressed willingness to assist and collaborate.
Parent-task: Read Antoine Vergne’s Post(s) and Watch Videos about Citizen Assemblies, RetroPGF, and Governance (Read%20Antoine%20Vergne%E2%80%99s%20Post(s)%20and%20Watch%20Videos%20abo%20cdbe77d6cbd1453fa5a54e2724b34f41.md)
Created time: April 30, 2024 6:24 AM
Last edited time: July 16, 2024 9:40 AM
Parent task: Explore the Optimism Collective's Experiments in Impact Juries and Deliberative Processes for Impact Evaluation  (Explore%20the%20Optimism%20Collective's%20Experiments%20in%20I%20e43c8c0159e44728b15daca5f6495ce9.md)
Created by: Dan Singjoy
Description: Dan Singjoy reaches out to Antoine Vergnes regarding his work with citizen's councils, their work with fractals, and potential collaborations. Dan expresses interest in Antoine's articles and presentations, and mentions websites and articles related to their work. Dan offers assistance with deliberative processes and expresses a desire for collaboration.

- [ ]  See [Read the Optimism Foundation’s Article: Experimenting with Deliberative Processes in the Collective](Read%20the%20Optimism%20Foundation%E2%80%99s%20Article%20Experimenti%2096db7df7bf044574a6c2fde99f00298b.md)

- [ ]  See [Read Antoine Vergne’s Post(s) and Watch Videos about Citizen Assemblies, RetroPGF, and Governance](Read%20Antoine%20Vergne%E2%80%99s%20Post(s)%20and%20Watch%20Videos%20abo%20cdbe77d6cbd1453fa5a54e2724b34f41.md)

I read your article about Citizens Assemblies for , Airdrop via Citizens Assemblies, and some of your other articles

I watched your presentations during the International Perspective on Citizens’ Assemblies and other Democratic Innovations Governance at Yale University and Smart Contract Research Community Call

Looking forward to seeing the experiments with deliberative processes in the Optimism Collective

You may be interested in the following websites and articles

[OptimismFractal.com](http://OptimismFractal.com) 

[EdenFractal.com](http://EdenFractal.com) 

[Optimystics.io/respect](http://Optimystics.io/respect) 

[Optimystics.io/respectgame](http://Optimystics.io/respectgame) 

[Optimystics.io/fractalhistory](http://Optimystics.io/fractalhistory) 

[Fractally.com](http://Fractally.com) 

[EdenElections.com](http://EdenElections.com) 

We’re developing apps and host weekly events with a community people interested in the kind of work that you are doing

Would be happy to assist with deliberative processes in Optimism Collective and help in any other way

See lots of opportunities for collaboration

Feel free to let me know if there’s anything I can do to help