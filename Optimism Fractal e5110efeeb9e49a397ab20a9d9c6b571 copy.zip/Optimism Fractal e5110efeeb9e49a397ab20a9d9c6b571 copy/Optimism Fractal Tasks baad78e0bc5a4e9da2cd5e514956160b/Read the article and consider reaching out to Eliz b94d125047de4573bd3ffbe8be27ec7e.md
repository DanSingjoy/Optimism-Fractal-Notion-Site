# Read the article and consider reaching out to Eliza about deliberative processes and optimism fractal.

Assignee: Dan Singjoy
Due: July 31, 2024
Project: Engage in Optimism Collective Season 6 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20in%20Optimism%20Collective%20Season%206%20334742cad6a844feb30fb97da8ac8ed7.md), Engage with Optimism Collective leadership (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Engage%20with%20Optimism%20Collective%20leadership%2078ce57dc829d4a7b9590140ea70f9ca9.md), Consider pioneering Impact Juries for the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Consider%20pioneering%20Impact%20Juries%20for%20the%20Optimism%2020e58c7a2c564548a148ece84b1ba470.md), Network and collaborate with governance enthusiasts in the Optimism Collective (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Network%20and%20collaborate%20with%20governance%20enthusiast%20d5efbbcde39e4bf9a7a16aec51786709.md), Research and Strategize to provide Optimism Collective with the most value possible (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Research%20and%20Strategize%20to%20provide%20Optimism%20Collec%20ad36d53370ce43a18be5b0ff973a2052.md)
Status: Not started
Task Summary: This task aims to read an article and consider reaching out to Eliza regarding deliberative processes and the concept of optimism fractal. It was created by Dan Singjoy and is due on July 31, 2024. The task is currently in the "Not started" status.
Summary: The document suggests reading an article and reaching out to Eliza regarding deliberative processes and the optimism fractal. Eliza is a new team member focused on this topic and may be easier to contact. The document also mentions that Eliza is tagged in a post on the government forum and provides links to the article and contact information.
Created time: May 20, 2024 8:48 PM
Last edited time: July 15, 2024 8:07 PM
Created by: Dan Singjoy
Description: The task is to read an article and reach out to Eliza regarding deliberative processes and the optimism fractal. Eliza is a new member of the optimism team and may be easier to contact since this is her focus. There are links provided to the article and to reach out to Eliza.

Eliza is new optimism team member who decided to do deliberative processes I think and she may be more easy to contact and discuss with since this is her focus and she may not have as many incoming messages  

eliza is also on gov forum tagged in post about this

[https://x.com/lalalavendr/status/1787960696304795663?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/lalalavendr/status/1787960696304795663?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/eliza_oak/status/1714714422046752889?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/eliza_oak/status/1714714422046752889?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[](https://x.com/optimismgov/status/1799132608795910568?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

- Read this article from Eliza
    
    [https://x.com/optimismgov/status/1799132608795910568?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/optimismgov/status/1799132608795910568?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)
    

[](https://x.com/eliza_oak/status/1799124533229789271?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

- Reach out to Eliza here
    
    [https://x.com/eliza_oak/status/1799124533229789271?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/eliza_oak/status/1799124533229789271?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)