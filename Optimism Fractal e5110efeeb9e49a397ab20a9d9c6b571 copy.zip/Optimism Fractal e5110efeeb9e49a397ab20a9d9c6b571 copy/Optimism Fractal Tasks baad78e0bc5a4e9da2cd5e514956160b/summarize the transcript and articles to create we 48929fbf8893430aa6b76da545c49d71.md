# summarize the transcript and articles to create welcome guide or starter guide to optimism fractal

Assignee: Dan Singjoy, Rosmari
Project: Create Welcome Guide for Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Welcome%20Guide%20for%20Optimism%20Fractal%20a337ed6dfe9148af8a317b2d759aa9f3.md)
Status: Not started
Task Summary: This task aims to summarize the transcript and articles to create a comprehensive welcome guide or starter guide for the Optimism Fractal. The guide will serve as an essential resource for newcomers, providing clear instructions and resources to facilitate participation in the Respect Game and enhance community engagement.
Summary: The document outlines the creation of a welcome guide for the Optimism Fractal Respect Game, detailing game rules, participant roles, and necessary tools. Key components include forming groups, sharing contributions, ranking efforts, and distributing Respect based on contributions. The guide aims to simplify participation, facilitate breakout room discussions, and encourage community engagement while continuously improving resources for a better experience.
Created time: May 10, 2024 3:16 PM
Last edited time: August 8, 2024 2:07 PM
Created by: Dan Singjoy
Description: The guide for the Optimism Fractal Respect Game outlines the game rules, emphasizing participant contributions, ranking, and the distribution of Respect based on helpfulness. It includes instructions for facilitating gameplay, managing breakout rooms, and ensuring community engagement. The guide aims to simplify participation and improve the overall experience, with ongoing updates to meet community needs.

# Game Rules

- [ ]  consider making a separate tasks to create game rules and welcome guide

- [x]  add instructions from respect game site without all the other information on that page

## Rules for Respect Game

- 
    
    (written on Respect Game Figma App)
    

These are the rules of the Respect Game played at Optimism Fractal. For more detailed rules, see here. The Respect Game provides a vast design space of different variations and these rules can be customized to fit the unique needs of any community or organization.

1. Participants gather in randomized groups of three to six players. If there are many participants, they split into multiple groups. The Respect Game can accommodate any amount of players due to it’s fractal nature.

2. Each participant of the group is given up to 4 minutes to introduce themselves, present their contributions, and share what they've done recently to help the community. This could include creating content, building software, inviting friends, or any other helpful activities.

3. After everyone has shared their contributions, the group discusses and ranks each other’s work in order of helpfulness. The players try to rank who did the most to help the community in the past week, then who helped the second most, the third most, and so forth. In order to win, the players must reach consensus by at least 2/3rds of the group agreeing to the ranks.

4. Once the group reaches consensus the participants of the group signal it onchain, which calls a function of smart contract. Everyone in the group earns Respect if at least 2/3rds of the break-out group participants submit this result onchain by calling smart contract during the game.

5. Based on these rankings, Respect is distributed to each participant. The better your contribution is ranked, the more respect you earn. The highest contributor earns 55 Respect and 34 Respect is given to second place, 21 Respect to third place, 13 Respect to fourth place, 8 Respect to fifth place, and 5 Respect is given to sixth place in each breakout room where consensus is formed.

6. The game repeats with regular meetings where members share their latest contributions and receive more respect over time.Respect is not transferable, meaning you keep them as a personal token of your contributions and they build up for each person over time.Replace call action with hit button to submit ranks

## What You’ll Need

- Telegram account
- Optimism account

## Chat GPT Responses

## Rules from Optimystics.io/respectgame

- I think the Rules for Respect Game written on Respect Game Figma App may be a bit simpler and better than the rules on the optimystics website
    
    
    Here’s an overview of how to play:
    
    1. **Forming Groups**: Participants gather in randomized groups of three to six players. If there are many participants, they split into multiple groups. The Respect Game can accommodate any amount of players due to it’s fractal nature.
    2. **Sharing Contributions**: Each person in the group gets a chance to share what they've done recently to help the community. Each participant can take up to 4 minutes to do this. This could be anything from creating content, building software, inviting friends, or other helpful activities for the Optimism Collective.
    3. **Ranking and Consensus**: After everyone has shared their contributions, the group discusses and ranks each other’s work in order of helpfulness. The players try to rank who did the most to help the community in the past week, then who helped the second most, the third most, and so forth. In order to win, the players must reach consensus by at least 2/3rds of the group agreeing to the ranks.
    4. **Awarding Respect**: Based on these rankings, Respect is distributed to each participant. The better your contribution is ranked, the more respect you earn. Respect is not ****transferable, meaning you keep them as a personal token of your contributions and they build up for each person over time. You can learn more about Respect in this [article](https://optimystics.io/respect).
    5. **Optimistic Technology**: You can play the Respect Game without using special tools, but the game is better when using a blockchain. At Optimism Fractal, the results of these rankings and the distribution of respect points are recorded on the OP Mainnet. This ensures transparency and allows everyone to see the contributions and respect of each member.
    6. **Ongoing Participation**: The game repeats with regular meetings where members share their latest contributions and receive more respect over time for continually growing Optimism.
    
    In the current configuration at Optimism Fractal, participants earn about 60% more Respect for each higher level that they earn. 55 Respect is given to the first place, 34 Respect to second place, 21 Respect to third place, 13 Respect to fourth place, 8 Respect to fifth place, and 5 Respect is given to sixth place in each breakout room where consensus is formed.
    
    In this way, the respect game encourages community participation and recognizes each member's contributions in a fair and transparent way.
    

*Share links and descriptions to help your group understand how are you contributing to Optimism. Feel free to introduce yourself and share anything that you’d like participants in your group to know.* 

Feel free to share your screen to give the participants in the group and viewers of the video recording a more visual understanding of your work.  

# Transcript

we should basically make like an easy quick start guide or a starter kit guide. We'll figure out the best thing to call it that we can send to people. And I can also include that in my presentation every week to just say, and here's the website you can go, Rosemary can share the link in the Zoom chat while we do that. And then that will also have the encouragement for people to record the video and also instructions as simple as possible to host fractalgram as well, as well as a link to some other sort of guide to like, lead the breakout room. And it'll also have independently of everything else on the respect game website or the respect game article, it'll just have the instructions to respect game as simple as possible. It might have a link to the recycling article as a whole, but it won't have all the benefits and everything like that. It'll just keep it very simple with just the instructions to play the game, plus other things that practically people will want to do or we want to encourage people to do during the event. I think that was it, right? Was there anything else? Yeah, and I want to add, if you have your tabs that you've presented during the 

Well, for one thing, we already have some of the guide instructions on the respect game article and we should... - But there are more, we need like more formal ones. - Okay. - These ones are more so for people who don't know anything about it and there's like loads of details there, how like the benefits of it. 

A lot of it is about benefits. - Well, there's a section that's specifically about just how you play the game. So we could take that and then put it on its own. That might be a good idea to do it and have it away from the benefits. Yes, because they may not know where to go to look for that, you know? If it's... Let's say it's someone's... meal... meal news. And... it might be good to just... at the beginning of the event... might be good at the beginning of the event to share this as a link. This is just a link for everyone to have. So we're now going to be splitting into small groups and we're going to go to breakout rooms where we'll play the respect game.

 I just briefly explained how it works but I'm sending this PDF file on the chat or you just send a link that goes to Notion for example. where you can have the rules if you want to like check them again because you know you might have forgotten half of the things already so you can just have them there are you saying that you have a starter kit? something like that that people can refer to once they go to the breakout room and like you're in your own breakout room so obviously they cannot reach out to you you know unless you take the lead to like go into their breakout room to say something they may not know what to do so it should be called so that's what I wanted to say so maybe just like something to share in the communal area, in the main room as maybe part of your presentation or maybe I can share it in the chat, you don't have to share it, I can share it and say here is a summary of the game rules and you know there may be different options there such as what to do if there's no lead in your breakout room what to do if there's no one to run fractogram and there they can see if there's no you know the things that you that you just said that if there's no no one to lead maybe do something that's never happened before those no I don't think that it's necessary put the deck is watching these people if we were up there maybe if there's no I think that's more so for us I mean I'm just listing out all the possibilities that could happen. I understand, I'm just saying that I don't think that that possibility would be there. I agree with having the game rules for people, and then I think that there should just be like a simple link that says here's how you can use factogram, but there shouldn't be much.

## ChatGPT Summary of the Transcript

**Introduction to the Optimism Fractal Respect Game**

Welcome to the quick start guide for the Optimism Fractal Respect Game. This guide is designed to make your participation as straightforward and impactful as possible.

**Game Instructions and Resources**

The core of this guide is the Respect Game instructions, tailored to ensure that newcomers can grasp and participate effectively right away. These instructions are deliberately concise, omitting the broader benefits of the game to maintain focus. The guide may also link to a comprehensive article on the Respect Game for those interested in deeper details.

**Facilitating the Game**

Included are tools to facilitate gameplay, such as hosting on Fractalgram and leading breakout rooms. These tools are essential for organizing the game flow and ensuring that everyone has a smooth experience during the event.

**Breakout Room Leadership**

A critical part of our discussions involves splitting into breakout rooms to play the Respect Game. The host will provide a brief explanation at the beginning of each event and detailed rules will be available through a link shared in the chat. This ensures that all participants can refresh their memory on the game rules as needed.

**Handling Breakout Rooms Without a Leader**

The guide will also address what to do if your breakout room lacks a designated leader or if there is no one available to run Fractalgram. These sections are designed to empower participants to self-manage their discussions and gameplay, ensuring that the game can proceed smoothly regardless of unexpected situations.

**Community Sharing and Support**

To facilitate community engagement and support, the guide will be shared in the communal area before we break into smaller groups. This approach allows every participant to access the game rules and understand their role within the breakout sessions.

**Conclusion and Continuous Improvement**

This starter kit is part of our ongoing effort to enhance the community's experience and involvement in the Optimism Fractal Respect Game. We are committed to refining these resources continuously to meet the community's needs and ensure that everyone can contribute to and benefit from our collective efforts.

## Breakout Room Preparation

- Create a task for preparing the breakout room presentation
- Include a summary of contributions and achievements
- Develop guidelines for being good hosts and growing the community

### Key Points

- Enhances the breakout room experience
- Encourages community engagement and growth
- Provides a framework for future hosts

### To-Do

- Create a task template for breakout room preparation
- Develop a set of host guidelines for community growth
- Invite new members to Discord and ensure they have Telegram and ETH