# Respond to Zaal about season 3/4

Assignee: Dan Singjoy
Due: July 1, 2024
Project: Plan Optimism Fractal Season 4 (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Plan%20Optimism%20Fractal%20Season%204%2042304244bc404fceb0b2c1279508ed7e.md)
Status: Done
Task Summary: This task aims to respond to Zaal regarding season 3/4 of Optimism Fractal. It provides information about the last event of the season, a summer break, and the upcoming fourth season starting on August 15th.
Summary: The last event of season 3 is happening on July 25th, followed by a two-week summer break. Season 4 of Optimism Fractal will begin on August 15th. There will also be office hours events scheduled, with more details to be shared soon.
Created time: July 21, 2024 9:00 AM
Last edited time: July 22, 2024 7:33 PM
Created by: Dan Singjoy
Description: The last event of season 3 is happening on July 25th, followed by a two-week summer break. Season 4 of Optimism Fractal will start on August 15th. There will be office hours events scheduled, including one on Wednesday at 16-16:30 UTC, and potentially another during the summer break.

Yes, the last event of the season is happening this Thursday, July 25th. Hope you can make it!

After that we'll have a two week summer break and return for Optimism Fractal's fourth season on August 15th. You can find more details about this [here](https://gov.optimism.io/t/optimism-fractal-season-3/8095/18?u=dansingjoy) if you'd like.

- [ ]  reply to july 4th message

On a related note, I'm planning to schedule an office hours event this Wednesday at 16-16:30 UTC, which will be followed by an office hours hosted by the Optimism Foundation. I might also host another office hours event during the Optimism Fractal summer break if there's sufficient interest. I'll make the event page and share a link here soon.