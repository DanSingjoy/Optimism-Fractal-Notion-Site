# Research Privy’s Security Model

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: In progress
Summary: This document is a research in progress on Privy's security model. It aims to answer questions about how accounts are secured and their level of security. There is a reference to high level answers in one of the overview podcasts.
Created time: February 23, 2024 10:01 AM
Last edited time: March 8, 2024 2:55 PM
Created by: Dan Singjoy

- How are accounts secured?
- How secure are they?
- There was some good high level answers about this in the one of the overview podcasts in [Watch Videos and listen to podcasts about Privy. Consider Creating a Playlist](Watch%20Videos%20and%20listen%20to%20podcasts%20about%20Privy%20Co%20af675c3ad4564d66b7e0918cfcf32570.md)

[https://www.youtube.com/watch?v=LrmEJYzGUpI&pp=ygULcHJpdnkgIHdlYjM=](https://www.youtube.com/watch?v=LrmEJYzGUpI&pp=ygULcHJpdnkgIHdlYjM=)