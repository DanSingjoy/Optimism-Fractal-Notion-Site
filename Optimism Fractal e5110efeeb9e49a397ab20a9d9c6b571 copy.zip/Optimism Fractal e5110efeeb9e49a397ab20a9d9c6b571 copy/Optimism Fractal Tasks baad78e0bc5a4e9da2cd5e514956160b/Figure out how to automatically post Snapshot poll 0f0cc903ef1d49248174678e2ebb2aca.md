# Figure out how to automatically post Snapshot polls on Discord

Project: Explore deeper integrations between Optimism Fractal and Discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Optimism%20Fract%20337d632e686e44e68cd899e6e12e05f3.md), Develop Cagendas at Optimism Town Hall (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Develop%20Cagendas%20at%20Optimism%20Town%20Hall%2074c52c5499054d1da5ad21461e80f510.md), Improve optimism fractal discord (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Improve%20optimism%20fractal%20discord%20f0810fb48cfc4a08b49fc433c1ebaffb.md), Explore deeper integrations between Snapshot and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20deeper%20integrations%20between%20Snapshot%20and%20O%204ac722d0200941a78b92d3824426542a.md)
Status: Not started
Summary: To automatically post Snapshot polls on Discord, you can use Discord bots and webhooks or integration services like Zapier or Integromat. With Discord bots, you'll need programming knowledge to create a custom bot that listens for new polls on Snapshot and posts them to a Discord channel. Integration services like Zapier or Integromat can connect Snapshot with Discord through webhooks. It's also recommended to research existing Discord bots, check Snapshot plugins, and explore third-party services for easier integration. Snapshot itself does not natively support webhooks, but there are workarounds like polling the Snapshot API or using smart contract events. Examples and solutions can be found in the Snapshot and Discord communities, Snapshot documentation, Discord bot directories, developer forums, and by contacting projects directly.
Parent-task: Improve Process for Creating Registration Polls (Improve%20Process%20for%20Creating%20Registration%20Polls%20f9d262227ae24e49adf82285d60d8773.md)
Created time: April 4, 2024 11:31 AM
Last edited time: April 4, 2024 12:45 PM
Created by: Dan Singjoy

## Description

- The following is a conversation with chatgpt intended to figure out how to automatically post Snapshot polls on Discord

Table of Contents

## Related Chats

![Untitled](Improve%20Process%20for%20Creating%20Registration%20Polls%20f9d262227ae24e49adf82285d60d8773/Untitled.png)

![[https://discord.com/channels/1164572177115398184/1164572177878765591/1225270180398239808](https://discord.com/channels/1164572177115398184/1164572177878765591/1225270180398239808)](Improve%20Process%20for%20Creating%20Registration%20Polls%20f9d262227ae24e49adf82285d60d8773/Untitled%201.png)

[https://discord.com/channels/1164572177115398184/1164572177878765591/1225270180398239808](https://discord.com/channels/1164572177115398184/1164572177878765591/1225270180398239808)

# Is there a way to automatically post snapshot polls and votes in discord? How?

ChatGPT

Yes, you can automatically post snapshot polls and votes in Discord using a combination of Discord bots and webhooks, or through integration services like Zapier or Integromat. The process generally involves creating a snapshot poll on a platform like Snapshot.org (popular for decentralized governance votes) and then setting up an automation to post these polls and their results to a Discord channel. Here's a simplified overview of how you can achieve this:

### **Using Discord Bots**

1. **Create a Custom Discord Bot**: You'll need some programming knowledge, especially in JavaScript (using discord.js library) or Python (using discord.py library). Your bot can listen for new polls on Snapshot via their API and then post the details to a specified Discord channel.
2. **Use Snapshot API**: Check the Snapshot documentation for APIs that allow you to fetch new polls or votes. Your bot will need to make periodic checks to the Snapshot API to see if there are new polls or votes.
3. **Post to Discord**: Once your bot detects a new poll or vote, format a message with the poll's details (title, options, link to vote, etc.) and use Discord's API to post this message to your server.

### **Using Integration Services (No-code/Low-code)**

1. **Zapier/Integromat**: These platforms offer a way to connect different services without writing code. Although they might not have direct support for Snapshot, you can use Webhooks as a bridge.
2. **Setup Webhook in Snapshot**: If Snapshot supports webhooks, you can set one up to trigger every time there's a new poll or vote. This webhook would send data to Zapier or Integromat.
3. **Configure Zapier/Integromat**: Set up a workflow where the trigger is the Snapshot webhook. The action would be posting a message to Discord. You'll need to use the Discord integration provided by Zapier or Integromat, which may require you to configure a Discord Webhook URL for the specific channel where you want to post.

### **Steps for Discord Webhook Setup:**

1. **Create a Webhook in Discord**: Go to your Discord server settings, find the "Integrations" tab, and create a new webhook for the channel where you want to post polls. Copy the webhook URL.
2. **Integrate Webhook with Your Bot or Service**: Use this URL in your custom bot or in the Zapier/Integromat configuration to post messages automatically.

### **Important Considerations:**

- **Permissions**: Ensure your bot has the necessary permissions in your Discord server to post messages.
- **Rate Limits**: Be aware of rate limits for both Discord and any external APIs you use to avoid getting blocked.
- **Privacy and Security**: Handle any data and webhooks securely to protect your server and its members.

This approach requires some setup and possibly coding, but once in place, it can streamline the process of sharing snapshot polls and votes with your Discord community.

# Is there anything that's already built for this so I don't need to have programming knowledge or do custom programming?

ChatGPT

For those looking to integrate Snapshot polls and votes into Discord without custom programming, the landscape of readily available tools is a bit more limited, as Snapshot operates within a niche area primarily associated with decentralized governance and cryptocurrency projects. However, there are a few avenues you might explore to achieve this functionality with minimal or no coding:

### **1. Existing Discord Bots**

Search for existing Discord bots that might offer integration with Snapshot or similar functionality. These bots can vary in their capabilities, and while there might not be a bot specifically designed for Snapshot polls and votes, there are bots focused on community voting and notifications that might be repurposed or used as a workaround. Websites like top.gg list various Discord bots for different purposes.

### **2. Zapier or Integromat**

While a direct Zapier or Integromat integration with Snapshot might not exist, these platforms offer flexible webhook functionality. If Snapshot provides webhook support for new polls or votes, you could set up a webhook to trigger a Zapier or Integromat workflow that posts messages to Discord. This method would involve:

- Setting up a webhook in Snapshot to send data to Zapier or Integromat when a new poll is created or a vote is cast.
- Creating a workflow in Zapier or Integromat that catches these webhook events and posts a formatted message to a Discord channel via Discord's webhook functionality.

### **3. Snapshot Plugins**

Snapshot itself is an open platform, and its ecosystem may include plugins or extensions that offer additional functionality, such as notifications. Checking the Snapshot documentation or community forums might reveal existing solutions or plugins that can be directly used or easily adapted for Discord integration.

### **4. Third-party Services**

There might be third-party services or platforms that specialize in bridging the gap between blockchain-based applications like Snapshot and social platforms like Discord. These services could offer a more user-friendly way to connect Snapshot polls to Discord without direct programming but might require subscription fees or have limitations on their use.

### **5. Manual Integration with Webhooks**

As a last resort, if you're unable to find a no-code solution and Snapshot offers webhook support, you could manually set up a Discord webhook to receive notifications. This would involve configuring the webhook URL in Snapshot's settings (if supported) to send notifications directly to a Discord channel. This method wouldn't be fully automated in terms of creating polls but could work for notifications.

### **Next Steps:**

- **Research**: Look into the current offerings of Discord bots that might fit your needs. The situation can change, and new bots are developed regularly.
- **Community Forums**: Engage with communities on platforms like Reddit, Discord, or Snapshot's own forums to ask if anyone has developed a solution or knows of an existing tool.
- **Snapshot Documentation**: Review Snapshot's official documentation and community resources for any new features or integrations that might have been introduced.

If you're part of a project or community with a specific need for this functionality and cannot find an existing solution, it might be worth reaching out to developers within the community. There's always a chance that someone else has had a similar requirement and has developed a custom solution they're willing to share.

# Does snapshot support web hooks?

As of my last update in April 2023, Snapshot, the decentralized voting platform widely used by blockchain and cryptocurrency projects for governance, does not natively support webhooks directly through its platform. Snapshot's primary functionality focuses on creating and managing proposals for decentralized voting without direct, built-in support for webhooks for notifying external systems or services of new votes or proposals.

However, there are a few workarounds that projects and developers use to integrate Snapshot voting events with other platforms like Discord:

### **1. Polling the Snapshot API:**

Developers can create a service that periodically polls the Snapshot API for new proposals or votes and then triggers an action, such as sending a notification through a Discord webhook. This requires programming knowledge and server resources to host the polling service.

### **2. Using Third-Party Services:**

Some third-party services and middleware platforms (like Zapier or Integromat) can be used to create custom workflows that include polling external APIs and sending notifications. While this might not be a direct webhook integration, it can achieve a similar outcome by checking for new Snapshot events at regular intervals and then posting messages to Discord or other platforms.

### **3. Smart Contract Events (for blockchain-based notifications):**

For projects that use Ethereum or other blockchain technologies, smart contract events can sometimes be used to trigger notifications. If a Snapshot proposal is tied to a specific smart contract action (e.g., changing a parameter in a DeFi protocol), events emitted by these contracts can be monitored and used to notify a Discord channel via a bot or webhook. This method is more indirect and depends on the nature of what the Snapshot vote is intended to achieve.

### **4. Custom Development:**

Developing a custom solution that listens to Snapshot events through its API and then uses webhooks to post notifications is often the route taken by projects with specific needs. This would involve developing a bot or service that interfaces with both Snapshot and Discord APIs.

### **Checking for New Features:**

Snapshot is an actively developed platform, and its features can evolve. It's a good idea to check the official Snapshot documentation or contact their support for the most current information regarding webhook support or new integration features that might have been introduced after my last update.

For real-time or the most recent updates on Snapshot's capabilities, including potential webhook support, you should consult Snapshot's official documentation or their GitHub repository.

# Please search the internet for the easiest solution possible. Also search for examples of other communities that have done this. I feel like its been done many times before and should be very easy

ChatGPT

It seems there's a technical issue preventing me from searching the internet for the information you requested. While I can't directly search for the easiest solution for integrating Snapshot polls with Discord or examples of communities that have successfully done this, I can still offer some general advice based on common practices within the crypto and decentralized governance communities.

### **Steps to Find Solutions and Examples:**

1. **Snapshot and Discord Communities**: Many crypto projects and DAOs (Decentralized Autonomous Organizations) use both Snapshot for voting and Discord for community engagement. Visiting forums, Discord servers, or subreddits related to DAOs and crypto governance might provide insights into how others have integrated these tools.
2. **Snapshot Documentation and GitHub**: The Snapshot documentation or their GitHub repository might have guides, third-party tools, or integration examples shared by the community. It's also a place where developers discuss issues and solutions, which could include webhook integration or Discord notifications.
3. **Discord Bots Directories**: Websites that list and rank Discord bots (like top.gg) might have a bot that specifically mentions Snapshot integration or offers customizable webhook functionalities that can be used for this purpose.
4. **Developer Forums and Q&A Sites**: Platforms like Stack Overflow, GitHub discussions, or specialized forums in the DeFi and DAO space often have discussions about integrating different services. Searching these sites for "Snapshot Discord integration" could yield relevant discussions or code snippets.
5. **Contact Projects Directly**: If you know of specific projects that have successfully integrated Snapshot with Discord, reaching out to them directly through their community channels might be a fruitful approach. Many projects are open to sharing knowledge and tools with the broader community.

### **Alternative Approach:**

Since direct searching is not available now, I recommend manually exploring these avenues. The crypto and open-source communities are generally very collaborative, and there's a good chance that solutions or at least useful advice can be found through these channels.

[https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png](https://s.gravatar.com/avatar/74d51a304caf988c48d4aed3653ffaff?s=480&r=pg&d=https%3A%2F%2Fcdn.auth0.com%2Favatars%2Fku.png)

# Please try again to search the internet for the easiest solution possible. Also search for examples of other communities that have done this. I feel like its been done many times before and should be very easy

ChatGPT

Based on a [quick search](https://chat.openai.com/backend-api/bing/redirect?query=Snapshot.org%20Discord%20integration%20easiest%20solution), here's what I found.

I'm currently unable to access the internet to search for solutions or examples of communities integrating Snapshot polls with Discord. Given this limitation, I recommend exploring the options and resources I previously mentioned.

For finding the easiest solution and examples of communities that have implemented such integrations, consider the following steps:

1. **Explore GitHub**: Search for repositories related to Snapshot and Discord integration. Developers often share their projects and scripts that could serve as a direct solution or a starting point for your needs.
2. **Snapshot Community Forum**: Snapshot might have a community forum or a Discord server where users share tips, tools, and integration methods. This can be an invaluable resource for finding pre-made solutions or advice from others who have tackled similar challenges.
3. **Discord Bot Directories**: Look through directories that list Discord bots to find one that might offer Snapshot integration capabilities or customizable webhooks that can be adapted for your purpose.
4. **Crypto and DAO Subreddits**: Subreddits focused on cryptocurrency, DAOs, and blockchain technology can be great places to ask for advice or find posts where others have shared their integration solutions.
5. **Technical Blogs and Articles**: Crypto and tech-focused blogs often publish guides and case studies on integrating various tools and platforms. A search might reveal articles outlining the process of linking Snapshot to Discord.

Since direct internet searches are not working at the moment, using these suggestions should help you begin your exploration. If you have a specific community in mind or a platform you prefer, starting there could yield quicker, more targeted results.