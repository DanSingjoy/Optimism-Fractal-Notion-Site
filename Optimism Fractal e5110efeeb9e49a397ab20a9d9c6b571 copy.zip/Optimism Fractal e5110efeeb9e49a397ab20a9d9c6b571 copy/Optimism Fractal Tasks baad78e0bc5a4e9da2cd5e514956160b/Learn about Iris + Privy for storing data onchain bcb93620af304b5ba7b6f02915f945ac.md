# Learn about Iris + Privy for storing data onchain?

Project: Integrate Embedded Wallet and/or Smart Wallet Solutions like Privy, Alchemy, Coinbase Smart Wallet, Third Web, or Magic into the Optimism Fractal / Respect Game Web Apps (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Embedded%20Wallet%20and%20or%20Smart%20Wallet%20Solu%20438a716ff3a14bffb6f9b95c8eb63cca.md)
Status: Not started
Summary: No content
Created time: February 23, 2024 10:24 AM
Last edited time: March 8, 2024 2:58 PM
Created by: Dan Singjoy

[https://twitter.com/privy_io/status/1756015102871105783](https://twitter.com/privy_io/status/1756015102871105783)

[https://twitter.com/josh_benaron/status/1755998557386027216](https://twitter.com/josh_benaron/status/1755998557386027216)

[https://twitter.com/privy_io/status/1761036732701843807](https://twitter.com/privy_io/status/1761036732701843807)