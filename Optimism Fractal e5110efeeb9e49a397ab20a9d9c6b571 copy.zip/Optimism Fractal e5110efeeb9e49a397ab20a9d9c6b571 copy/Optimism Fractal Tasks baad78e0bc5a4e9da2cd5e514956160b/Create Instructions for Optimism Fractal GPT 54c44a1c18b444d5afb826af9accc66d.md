# Create Instructions for Optimism Fractal GPT

Project: Create Optimism Fractal GPT (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20GPT%20115b79befafe400287e5338abca1c60b.md)
Status: Not started
Task Summary: This task aims to create instructions for Optimism Fractal GPT, a language model developed by Dan Singjoy. The instructions will provide guidance on how to use and optimize the model effectively. The status of the task is currently marked as "Not started."
Summary: No content
Created time: July 5, 2024 8:45 PM
Last edited time: July 5, 2024 8:46 PM
Created by: Dan Singjoy
Description: No content

![Untitled](Create%20Instructions%20for%20Optimism%20Fractal%20GPT%2054c44a1c18b444d5afb826af9accc66d/Untitled.png)

- [ ]  See [Consider opening the Optimism Fractal notion site to Search Engine Indexing](Consider%20opening%20the%20Optimism%20Fractal%20notion%20site%20%202bb5320a45c2412cb0e28a11dbcda84a.md)