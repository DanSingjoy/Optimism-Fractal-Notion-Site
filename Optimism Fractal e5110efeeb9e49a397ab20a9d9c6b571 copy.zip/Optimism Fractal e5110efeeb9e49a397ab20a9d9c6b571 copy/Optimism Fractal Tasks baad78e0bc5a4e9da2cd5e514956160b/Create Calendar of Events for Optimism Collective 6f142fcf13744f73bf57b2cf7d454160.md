# Create Calendar of Events for Optimism Collective

Project: Create Educational and Community Resources for the Optimism Collective and Optimism Fractal (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Educational%20and%20Community%20Resources%20for%20the%20155c098237d44501b2c159942e5906bb.md), Create Optimism Events Calendar (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Events%20Calendar%20ca8d2c50f36145fe898e2f9de1cd90f6.md)
Status: In progress
Task Summary: This task aims to create a calendar of events for the Optimism Collective. The page includes a list of optimism events, tasks to complete, and links to public governance and Optimystics calendars.
Summary: This document is a work in progress for creating a calendar of events for the Optimism Collective. It includes tasks such as adding a calendar view, creating a project to curate events, organizing them into a database, and merging them with other related projects. It also mentions existing calendars like the Optimism public governance calendar and the Optimystics Calendar.
Created time: March 25, 2024 2:41 PM
Last edited time: June 26, 2024 4:09 PM
Created by: Dan Singjoy

## Optimism Events

[Calendar of Optimism Events](Create%20Calendar%20of%20Events%20for%20Optimism%20Collective%206f142fcf13744f73bf57b2cf7d454160/Calendar%20of%20Optimism%20Events%2051e8db4276b448479129e9fb5ccbb6a3.csv)

- [ ]  Add calendar view
- 
    
    
    [https://edencreators.notion.site/Create-Calendar-of-Events-for-Optimism-Collective-6f142fcf13744f73bf57b2cf7d454160?pvs=4](Create%20Calendar%20of%20Events%20for%20Optimism%20Collective%206f142fcf13744f73bf57b2cf7d454160.md)
    
    - [ ]  create OF project to curate Optimism Events
        - [ ]  add the events at the bottom of [Explore Opportunities for Optimism Missions, Season 5 ](Explore%20Opportunities%20for%20Optimism%20Missions,%20Seaso%20e8a78a65283f42f7a7b3c682c941ecda.md)
        - [ ]  organize them into a database
            - [ ]  add a brief description for each
        - [ ]  merge them with [](https://www.notion.so/9fe995ccda1b492daae39353c5452549?pvs=21)
            - [ ]  retitle this and move all of them to this notion page where it’s public
        - [ ]  do this before sharing the [Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md) in the discord because this will make that prjoject better
    

## Calendars

**Optimism [public governance calendar](https://calendar.google.com/calendar/u/0/r?cid=Y19mbm10Z3VoNm5vbzZxZ2JuaTJncGVyaWQ0a0Bncm91cC5jYWxlbmRhci5nb29nbGUuY29t)**

Optimystics Calendar

- [ ]  merge [](Create%20Optimystics%20Seasonal%20Events%20Calendar%2066bb985046cd49248792dc3dc8dc5481/Optimystics%20Seasonal%20Events%20Calendar%205da6374d95d746029b2672d1bf248614.md)
    - [ ]  [https://calendar.google.com/calendar/u/0?cid=b3B0aW15c3RpY3N4QGdtYWlsLmNvbQ](https://calendar.google.com/calendar/u/0?cid=b3B0aW15c3RpY3N4QGdtYWlsLmNvbQ)
    - [ ]  [Create Optimystics Content Calendar and Strategy](https://www.notion.so/Create-Optimystics-Content-Calendar-and-Strategy-39119c21cab94b8cacecb2355461c2e2?pvs=21)
    - [ ]  [Propose 4 week summer break from Eden fractal, Eden Fractal Epoch 2, biweekly optimystics office hours events, and two week break from optimism fractal](https://www.notion.so/Propose-4-week-summer-break-from-Eden-fractal-Eden-Fractal-Epoch-2-biweekly-optimystics-office-hou-e7bdb4a20b5047a6943e8043e0e94f3d?pvs=21)