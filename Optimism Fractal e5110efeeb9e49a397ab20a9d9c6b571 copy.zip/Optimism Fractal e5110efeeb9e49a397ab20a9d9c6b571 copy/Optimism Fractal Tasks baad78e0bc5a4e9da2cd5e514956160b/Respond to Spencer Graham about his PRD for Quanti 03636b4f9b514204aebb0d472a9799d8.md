# Respond to Spencer Graham about his PRD for Quantitative Value Creation Measurement for Decentralized Work

Project: Integrate with Hats Protocol  (../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20with%20Hats%20Protocol%20e5ffb3df961f404eb15d6d5f6de158aa.md)
Status: Not started
Summary: No content
Parent-task: Respond to the thread with Seth Benton, Spencer Graham, and SudoFerraz.eth about Quantitative Value Creation Measurement for Decentralized Work with sourcecred, optimism fractal, and armitage (Respond%20to%20the%20thread%20with%20Seth%20Benton,%20Spencer%20Gr%203631f0a5782d40bea7e190480f5391b7.md)
Sub-task: Review and Respond to Hodlon about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer (Review%20and%20Respond%20to%20Hodlon%20about%20Hats%20Contributi%20ede1b147525948b6a4c82818cbf962df.md)
Created time: April 17, 2024 11:02 AM
Last edited time: May 1, 2024 11:51 AM
Sub-tasks: Review and Respond to Hodlon about Hats Contribution Submissions with Optimism Fractal, the IC-Fractal PRD, and the PRD from Spencer (Review%20and%20Respond%20to%20Hodlon%20about%20Hats%20Contributi%20ede1b147525948b6a4c82818cbf962df.md)
Parent task: Respond to the thread with Seth Benton, Spencer Graham, and SudoFerraz.eth about Quantitative Value Creation Measurement for Decentralized Work with sourcecred, optimism fractal, and armitage (Respond%20to%20the%20thread%20with%20Seth%20Benton,%20Spencer%20Gr%203631f0a5782d40bea7e190480f5391b7.md)
Created by: Dan Singjoy