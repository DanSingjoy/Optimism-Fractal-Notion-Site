# What is the contract address for the fractal token?

Status: Not started
Summary: The contract address for the fractal token can be found on the blockscout block explorer, specifically at the optimism account and OPF token links provided. The etherscan link also leads to the contract but requires an additional click. Additionally, the document mentions Tadas' ORDAO deployment on the Sepolia testnet and provides links for further context and instructions for testing the ORDAO mainnet version.

## Current contract address

It's better to check the blockscout block explorer instead of the etherscan, as this displays our token better

- This is the optimism account: [https://optimism.blockscout.com/address/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC](https://optimism.blockscout.com/address/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC)
- This is the OPF token: [https://optimism.blockscout.com/token/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC](https://optimism.blockscout.com/token/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC)

If you click on holders on the OPF token page then it shows all accounts and ENS names there, whereas that doesnt show on etherscan due to the current token standard (which will be fixed in the next iteration of the app)

The address of the contract that deployed the token on etherscan. You can find the token easily from that page but it requires another click [https://optimistic.etherscan.io/address/0x53c9e3a44b08e7ecf3e8882996a500eb06c0c5cc](https://optimistic.etherscan.io/address/0x53c9e3a44b08e7ecf3e8882996a500eb06c0c5cc) 

## Tadas’ ORDAO (new candidate version)

The testnet address where tadas deployed ORDAO and tested the NFT images (Sepolia is the testnet) [https://optimism-sepolia.blockscout.com/token/0xF7640995eAffAf5dB5ABEa7cE1F06Be968BFF5e5](https://optimism-sepolia.blockscout.com/token/0xF7640995eAffAf5dB5ABEa7cE1F06Be968BFF5e5)'

Website: [https://of.frapps.xyz/](https://of.frapps.xyz/)

Intro to ORDAO for context: [https://github.com/sim31/frapps/tree/main/concepts/apps/of2](https://github.com/sim31/frapps/tree/main/concepts/apps/of2)

**Deployment of ORDAO for Optimism Fractal:**

[https://discord.com/channels/1164572177115398184/1238193186661466316/1281184054259089419](https://discord.com/channels/1164572177115398184/1238193186661466316/1281184054259089419)

**Instructions for testing ORDAO mainnet version during OF meeting**

[https://discord.com/channels/1164572177115398184/1238193186661466316/1281189114061914142](https://discord.com/channels/1164572177115398184/1238193186661466316/1281189114061914142)