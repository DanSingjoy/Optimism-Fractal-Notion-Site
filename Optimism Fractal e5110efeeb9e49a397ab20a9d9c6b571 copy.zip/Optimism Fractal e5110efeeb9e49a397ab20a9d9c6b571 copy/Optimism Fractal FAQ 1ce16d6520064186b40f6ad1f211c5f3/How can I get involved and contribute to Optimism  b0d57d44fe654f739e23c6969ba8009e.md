# How can I get involved and contribute to Optimism Fractal?

Status: Not started

[Create webpages and educational resources about how you can contribute to Optimism Fractal and the Respect Game (OptimismFractal.com/contribute)](../Optimism%20Fractal%20Tasks%20baad78e0bc5a4e9da2cd5e514956160b/Create%20webpages%20and%20educational%20resources%20about%20ho%208e6257e6981545b6869f8fc4e57330c7.md) 

[Projects](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2.md) 

[contribute.optimism.io](http://contribute.optimism.io) 

- 
    
    ![[https://hackmd.io/@Hodlon/H1lNc_DOa](https://hackmd.io/@Hodlon/H1lNc_DOa)](How%20can%20I%20get%20involved%20and%20contribute%20to%20Optimism%20%20b0d57d44fe654f739e23c6969ba8009e/Untitled.png)
    
    [https://hackmd.io/@Hodlon/H1lNc_DOa](https://hackmd.io/@Hodlon/H1lNc_DOa)