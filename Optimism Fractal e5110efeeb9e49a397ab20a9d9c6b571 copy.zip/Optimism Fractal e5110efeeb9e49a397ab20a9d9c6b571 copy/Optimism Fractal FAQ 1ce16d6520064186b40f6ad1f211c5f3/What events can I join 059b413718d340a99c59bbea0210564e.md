# What events can I join?

Status: Not started

[Untitled](What%20events%20can%20I%20join%20059b413718d340a99c59bbea0210564e/Untitled%205561e81c0020474d873d3bd0765cfb76.csv)

- 
    
    
    - [ ]  I also started creating of Optimism ecosystem calendar of events, which you can see [here](../Optimism%20Fractal%20Tasks%20baad78e0bc5a4e9da2cd5e514956160b/Create%20Calendar%20of%20Events%20for%20Optimism%20Collective%206f142fcf13744f73bf57b2cf7d454160.md).
    
    [Untitled](What%20events%20can%20I%20join%20059b413718d340a99c59bbea0210564e/Untitled%2054e88043395547e085782b8f8a1b4e74.csv)