# What is the history and origin of Fractals?

Status: Not started
Summary: To learn about the history and origin of fractals, you can watch a presentation during the Optimism Fractal 26th event or read articles on the history of fractals and the roots of Optimism Fractal. There are also related tasks and projects that provide more information on the history behind Optimism Fractal.

You can watch a presentation which answers this question during the Optimism Fractal 26th event [here](https://youtu.be/XdzOMH54LrM?t=3637).

In addition, you can read more about the history of Fractals in the below articles:

## **A History of Fractal Communities**

[https://optimystics.io/blog/fractalhistory](https://optimystics.io/blog/fractalhistory)

## **The Roots of Optimism Fractal**

[https://optimystics.io/blog/the-roots-of-optimism-fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)

## Communities

[https://optimystics.io/communities](https://optimystics.io/communities)

# Related Tasks and Projects

[Create educational resources and webpage explaining Fractals, History, and about (OptimismFractal.com/history)?](../Optimism%20Fractal%20Tasks%20baad78e0bc5a4e9da2cd5e514956160b/Create%20educational%20resources%20and%20webpage%20explainin%20ea9769f10a90484191496aa32b54a3a1.md) 

 Below are a few links where you can learn more about the history behind Optimism Fractal:

- [The History of Fractals](https://optimystics.io/blog/fractalhistory)

- [Overview of Fractal Communities](https://www.notion.so/Message-links-to-Will-and-update-on-education-hub-2809406e947d44ec9110a8a2ffb85493?pvs=21)

- [fractally.com](http://fractally.com)

- [Introduction to Fractal Democracy](https://fractally.com/blog/what-is-fractal-democracy)

- More Equal Animals [book](https://moreequalanimals.com/posts/book-launch) and [audiobook](https://www.youtube.com/watch?v=xepUoQbOzr4&t=10s&pp=ygUSbW9yZSBlcXVhbCBhbmltYWxz)

The first article links to the other resources and provides context for each. The Respect Game was largely inspired by ƒractally, which has a great whitepaper, keynote video, and other resources on their website. The More Equal Animals book written by Daniel Larimer originally inspired our consensus processes and provides an excellent philosophical underpinning for our work.

You can also see this [video clip](https://www.youtube.com/watch?v=XdzOMH54LrM&t=3637s) from a recent Optimism Fractal event where for a five minute overview about our roots.