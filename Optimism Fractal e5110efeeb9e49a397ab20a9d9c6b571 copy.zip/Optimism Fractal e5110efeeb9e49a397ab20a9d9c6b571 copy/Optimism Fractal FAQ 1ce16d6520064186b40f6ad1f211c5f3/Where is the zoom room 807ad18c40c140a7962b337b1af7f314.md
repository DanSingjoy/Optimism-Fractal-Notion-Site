# Where is the zoom room?

Status: Not started

For future reference, here are a few ways to find the zoom room.

1. The zoom room is the same each week, here is the link: [https://us06web.zoom.us/j/82510562614](https://us06web.zoom.us/j/82510562614)
2. You can join the meeting by clicking on ‘zoom room’ on this page: [https://lu.ma/optimismfractal](https://lu.ma/optimismfractal)
3. If you RSVP, then you’ll receive an email with the zoom link an hour before each event.
4. I just added this to the Resources section at the bottom of the [Optimism Fractal](../../Optimism%20Fractal%20e5110efeeb9e49a397ab20a9d9c6b571.md) notion site
5. Feel free to ask here or on telegram as well :)