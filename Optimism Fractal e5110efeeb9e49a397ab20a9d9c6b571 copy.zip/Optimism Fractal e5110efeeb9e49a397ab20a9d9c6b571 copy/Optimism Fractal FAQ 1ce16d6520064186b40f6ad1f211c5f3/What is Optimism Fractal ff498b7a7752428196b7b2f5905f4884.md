# What is Optimism Fractal?

Status: Not started
Summary: No content

[OptimismFractal.com](http://OptimismFractal.com) 

[https://optimystics.io/blog/the-roots-of-optimism-fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)