# What is a blockchain? Onchain Clarity Co. | Blockchains are MMODBs. Also add Balaji article and community computer notes

Status: Not started
Summary: No content
URL: https://paragraph.xyz/@occ.eth/blockchains_are_mmodbs

[https://paragraph.xyz/_next/image?url=https%3A%2F%2Fstorage.googleapis.com%2Fpapyrus_images%2F4918855c0e0cb0fe379b6adebc505b9f&w=96&q=75](https://paragraph.xyz/_next/image?url=https%3A%2F%2Fstorage.googleapis.com%2Fpapyrus_images%2F4918855c0e0cb0fe379b6adebc505b9f&w=96&q=75)

User avatar

[https://paragraph.xyz/_next/image?url=https%3A%2F%2Fstorage.googleapis.com%2Fpapyrus_images%2F4918855c0e0cb0fe379b6adebc505b9f&w=384&q=75](https://paragraph.xyz/_next/image?url=https%3A%2F%2Fstorage.googleapis.com%2Fpapyrus_images%2F4918855c0e0cb0fe379b6adebc505b9f&w=384&q=75)

Onchain Clarity Co. logo