# Add to OF FAQ

Status: Inbox
Summary: To contribute to optimism and earn more respect, visit http://optimismfractal.com/contribute and http://contribute.optimism.io/. Be creative and contribute in any way you see fit, as your ideas and actions will be reviewed by peers.

## Description

How can I contribute to optimism and earn more respect? Go to [optimismfractal.com/contribute](http://optimismfractal.com/contribute) and [contribute.optimism.io](http://contribute.optimism.io) . Projects and tasks . Be creative , any ideas and things you did will be reviewed by peers and you have freedom to contribute however you see fit

How can I earn more respect?

How can I contribute to optimism /fractal?