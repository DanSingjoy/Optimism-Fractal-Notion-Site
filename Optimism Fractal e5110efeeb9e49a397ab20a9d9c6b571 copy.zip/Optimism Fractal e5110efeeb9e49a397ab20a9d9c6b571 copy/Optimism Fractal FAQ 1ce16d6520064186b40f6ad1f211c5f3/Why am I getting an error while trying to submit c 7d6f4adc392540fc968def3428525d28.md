# Why am I getting an error while trying to submit consensus?

Answer: See Tips for dealing with errors while using Fractalgram (../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Fractalgram%203d7832cdb4254335aba4d079470986dc/Tips%20for%20dealing%20with%20errors%20while%20using%20Fractalgr%20643b870d5f5045d9961b688063acedb3.md) 
Status: Not started

### Desktop

when you have multiple wallet plugins in the browser and said that disabling other wallets could fix for this

Multiple wallet applications

### Mobile

We recommend copying the link from telegram and pasting it into the browser of your wallet application, instead of opening it directly from telegram

See [Tips for dealing with errors while using Fractalgram](../Optimism%20Fractal%20Resources%2054045345f5c748b2b6c7fcba5e8b274b/Fractalgram%203d7832cdb4254335aba4d079470986dc/Tips%20for%20dealing%20with%20errors%20while%20using%20Fractalgr%20643b870d5f5045d9961b688063acedb3.md) 

- Related Project: [Optimize Optimism Fractal Web App, Fractalgram, and Fix Errors](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Optimize%20Optimism%20Fractal%20Web%20App,%20Fractalgram,%20an%201699ced1d9b243e4a375610e2222a983.md)
    
    
     [Fix the ‘Failed to Load Web3’ Error that happens when trying to submit results](../Optimism%20Fractal%20Tasks%20baad78e0bc5a4e9da2cd5e514956160b/Fix%20the%20%E2%80%98Failed%20to%20Load%20Web3%E2%80%99%20Error%20that%20happens%20w%20171fe01e35bc48a694eba1f00cf1198f.md)
    
    [Fix the ‘Blockchain Not Ready’ Error that happens when trying to submit results](../Optimism%20Fractal%20Tasks%20baad78e0bc5a4e9da2cd5e514956160b/Fix%20the%20%E2%80%98Blockchain%20Not%20Ready%E2%80%99%20Error%20that%20happens%20%20a5b7f3c7aa6b4241b31925ea113cd9de.md)