# How can I earn funding by helping Optimism Fractal?

Status: Not started

Related Project: [Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md)