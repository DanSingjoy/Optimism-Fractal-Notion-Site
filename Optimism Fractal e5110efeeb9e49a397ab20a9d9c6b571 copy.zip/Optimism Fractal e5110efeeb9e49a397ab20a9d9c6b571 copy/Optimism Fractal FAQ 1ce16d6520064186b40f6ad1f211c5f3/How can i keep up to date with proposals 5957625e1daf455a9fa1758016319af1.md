# How can i keep up to date with proposals?

Status: Not started
Summary: To stay updated with proposals, join Snapshot Spaces and configure email reminders through Snapshot. This allows you to receive important information even if you don't frequently check Discord. Watch the https://youtu.be/F9nwIxjoIts?si=ZrETn0PjMt0SFiEK&t=4049 for more details on email reminders and joining Snapshot Spaces.

## Joining Snapshot Spaces and Configuring Email Reminders

You can join the Snapshot space and/or set up email reminders via Snapshot to stay informed about proposals and updates. This helps ensure you don't miss important information even if not frequently checking Discord. Here's a link to the [video timestamp](https://youtu.be/F9nwIxjoIts?si=ZrETn0PjMt0SFiEK&t=4049) where we discussed email reminders, Snapshot spaces, and how anyone can join them to make it easier to follow.