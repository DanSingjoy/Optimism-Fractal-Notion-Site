# Exploring Optimism Town Hall and Cagendas

Upvotes: 0

To kick off the first Optimism Town Hall and Cagendas topic selection game, I’d like to share a brief presentation that provides a more in-depth overview of the potential benefits, next steps, and rationale of these new initiatives. 

The material for this topic can be found in the [introductory post](../Optimism%20Fractal%20Tasks%20baad78e0bc5a4e9da2cd5e514956160b/Propose%20Cagendas%20and%20Make%20Promotional%20Post%20for%20OF%20%20de2771a7178a40de850ec55ae94bed4b/Introducing%20Cagendas%20and%20Optimism%20Town%20Hall%203be08af1fc734845942d75e24cbdd864.md), which includes links to projects with more details about Optimism Town Hall, Cagendas, Optimism Fractal Season 3, and the value that these initiatives can provide for the Optimism Collective. We’ll have an open discussion after the presentation and I’d love to hear more feedback about this topic, so please feel free to share any thoughts here in the discord chat or at the upcoming town hall event.

You can upvote this proposal with your Respect below or create an alternative topic proposal in the Optimism Town Hall snapshot space before Monday at 17 UTC, as described in the [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d) that was recently approved to organize discussions with Cagendas after Optimism Fractal Respect Game events.