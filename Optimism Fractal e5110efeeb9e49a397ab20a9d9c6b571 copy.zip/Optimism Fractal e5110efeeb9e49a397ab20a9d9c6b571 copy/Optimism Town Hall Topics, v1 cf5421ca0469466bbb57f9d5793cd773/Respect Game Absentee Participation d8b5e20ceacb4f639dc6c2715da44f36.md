# Respect Game Absentee Participation

Tags: Resolved
Upvoters: Hodlon, Dan Singjoy, Tadas Vaitiekunas
Upvotes: 3

I’ll be in ETH Denver next week and would like to know if my contributions this week will be considered for the game next Monday or not.

Discussion:

- Can rollover contributions from previous weeks if can’t make it