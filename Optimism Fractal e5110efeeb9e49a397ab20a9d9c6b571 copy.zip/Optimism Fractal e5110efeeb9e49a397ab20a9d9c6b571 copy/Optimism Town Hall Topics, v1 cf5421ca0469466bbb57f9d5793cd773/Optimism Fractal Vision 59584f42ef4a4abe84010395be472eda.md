# Optimism Fractal Vision

Tags: Discussed
Upvoters: Hodlon, Dan Singjoy
Upvotes: 2

Alex: improving the process of putting votes onchain

Dan: helping Optimism and making an optimistic world

Hodlon: using the Optimism L2 to experiment with consensus processes to refine and share with the world. 

Rosmari: Help communities on Optimism and the broader web3 to reach consensus through social games

Gudasol: A world empowered by mutual-benefit games on Optimism

- Vision = idealized version of the world, what resonates with people. Mission unites vision of the world with actual strategies.
- Mission = what you hope to accomplish, Vision = how you will accomplish it

Zaal: an opportunity to empower builders on Optimism to better the world

Tadas’ mission: **Make retroactive public good funding decisions easy and fair, through effective recognition and evaluation of public goods and their impact;**

### Tadas: combine visions of Optimism and vision of EdenFractal

EdenFractal vision: [https://edenfractal.com/vision](https://edenfractal.com/vision)
Optimistic vision: [https://www.optimism.io/vision](https://www.optimism.io/vision)

So I propose that OF vision should either simply state that its intent is to serve visions of EdenFractal and Optimism or we should take the main ideas from Optimistic vision and EdenFractal vision and build OF vision / mission from that.

Rationale:

- It seems aligned with participants who come to OF meetings. I think most of the people here care about new and better consensus processes or Optimism or both. I think it would also be aligned with vision ideas proposed here
    - Dan suggested that we take inspiration from Optimistic vision
    - Alex suggested that a mission more focused on improving Optimism;
    - Hodlon’s vision seems very aligned with EdenFractal’s mission (the best way to discover better decision-making processes is to make experiments like this one);
    - Rosmari’s vision is aligned with EdenFractal’s vision;
    - Gudasoul’s vision seems to combine EdenFractal’s vision as well as Optimism;
    - Zaal’s vision seems very aligned with Optimistic vision.
- Optimism Fractal was born out bringing what we learned and built in EdenFractal to Optimism. In some sense EdenFractal and Optimism are like two parents Optimism Fractal. Makes sense that it inherits something from both;

Now it seems to me that Optimistic vision could go into vision of Optimism Fractal and EdenFractal's vision is more about how we get there.

I think the main thing that OF can help Optimism with is improving recognition of public goods and measurement of positive impact by using Respect game and its derivatives. Specifically, this can help RetroPGF review process (one of the main pain points of RetroPGF). This review process is about making decisions who should be awarded how much, so in a sense we would be helping RetroPGF make better funding decisions with our consensus signals and this would be serving the vision of EdenFractal (make decision-making easier, more fun, etc).

Version 1:

- **Make retroactive *impact=profit* public good funding decisions easy and fair, through effective recognition and evaluation of public goods and their impact;**

Version 2:

- **Make retroactive public good funding decisions easy and fair, through effective recognition and evaluation of public goods and their impact;**

On related note: it’s good that an organization with this kind of mission is separate from an organization that does actual funding. That way these two organizations can keep each other in check. If funding source would get corrupt community could see onchain evidence that their funding does not reflect reality of impact=profit. And the other way around, if a fractal gets corrupt, it’s good that it’s process does not directly determine rewards distribution - funding source can recognize corruption in a fractal and fallback to some other mechanism for recognizing public goods.

### Resources

[https://www.optimism.io/vision](https://www.optimism.io/vision)

[https://douglas-life.medium.com/temple-branding-the-visual-business-plan-7cfc811c2469](https://douglas-life.medium.com/temple-branding-the-visual-business-plan-7cfc811c2469)

[The Vision Temple; Illuminating Founding Documents | by Douglas James Butner 🜛 Gudasol | Medium](Optimism%20Fractal%20Vision%2059584f42ef4a4abe84010395be472eda/The%20Vision%20Temple;%20Illuminating%20Founding%20Documents%203a2a272c290944dd8ec385cec96e56eb.md)

[https://edenfractal.com/vision](https://edenfractal.com/vision)

### Organization

Here are some questions and suggestions

- Should we coordinate our vision in a project?
    
    [Create Optimism Fractal Vision](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Optimism%20Fractal%20Vision%205bda87b5ea56446ab12ed5fbb1e684a8.md) 
    

- Should we create headers or database with each person’s vision?
    
    
    - This could give each person more space to write their vision
    
    [OF Visions Database](Optimism%20Fractal%20Vision%2059584f42ef4a4abe84010395be472eda/OF%20Visions%20Database%205052ebb8be8041ccb15f6f0646a414aa.csv)
    

- How should we form consensus about the vision?
    
    
    - The Sages Council can form consensus with the process defined in [OptimismFractal.com/details](http://OptimismFractal.com/details)
        - We could also experiment with different kinds of votes on snapshot
        - We could also experiment with different kinds of respect games