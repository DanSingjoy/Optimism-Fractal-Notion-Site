# Sybil Protection for Optimism Fractal

Upvotes: 0