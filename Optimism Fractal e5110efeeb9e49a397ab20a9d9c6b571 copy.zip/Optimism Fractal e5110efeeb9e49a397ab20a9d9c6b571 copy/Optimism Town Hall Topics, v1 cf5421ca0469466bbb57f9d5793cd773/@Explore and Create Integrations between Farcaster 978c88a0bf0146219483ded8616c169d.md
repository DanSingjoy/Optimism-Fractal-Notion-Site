# @Explore and Create Integrations between Farcaster and Optimism Fractal

Upvoters: Rosmari, Dan Singjoy
Upvotes: 2