# ❓Questions and Answers Game

## ❓Questions and Answers Game

Feel free to ask any questions related to Optimism,  then me or other knowledgeable community members will do our best to answer them.  

You can write your questions the chat, raise your hand in zoom, or post your question on the Optimism Town Hall snapshot space.  Questions that receive the most Respect votes will be prioritized, so you can post your question on Snapshot and vote for it if you want to discuss it sooner.

This Questions and Answers game features an optimistic transition system as OPTOPICS, so you can influence the discussion and help the group move onto the next question if you’d like. Here are the rules for switching questions:

- **Next Question:** Type ‘next question’ in the zoom chat to propose moving to the next question. This starts a one-minute countdown.
- **Same Question:** Type ‘same question’ within one minute to veto the change. If vetoed, neither person can propose to switch or veto again for the current question.
- **New Question:** If over half of well respected community members agree (each with at least 50 Respect), any question can be introduced and discussed immediately.

This is an experimental conversation game and we can also have a more casual Q&A session without this kind of structure, but the rules will be in effect in case anyone wants to play with them :)