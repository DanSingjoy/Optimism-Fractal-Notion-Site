# 🔴 Optimism Missions Updates

## Season 6 Mission Proposals

I created two Mission Proposals in the Optimism Season 6. They each reached the final stage of review, but were not approved by the council. I received valuable feedback during the process and will apply again in the upcoming cycle with improved proposals.

[Optimism Fractal Respect Games](https://app.charmverse.io/op-grants/optimism-fractal-respect-game-38883790721315004)

[Eden Creators Videos](https://app.charmverse.io/op-grants/eden-creators-videos-5662222309650244)

### Announcements from the Optimism Grants Council

The Grants Council has made several announcements which are related to Missions in Optimism Season 6. Here are some examples:

[Rolling Mission Requests](https://gov.optimism.io/t/rolling-mission-requests/8756)

[Cycle 27 Intent 3A Mission Request Sponsorship](https://gov.optimism.io/t/cycle-27-intent-3a-mission-request-sponsorship/8807)

[Cycle 26 Grants final roundup](https://gov.optimism.io/t/cycle-26-grants-final-roundup/8797)

[Cycle 27 Grants final roundup](https://gov.optimism.io/t/cycle-27-grants-final-roundup/8885)

### V1 Mission Requests

I created several Mission Requests in this Optimism Season 6. Each of these Mission Requests are designed to help Optimism Fractal grow and create a more positive impact for the Optimism Collective and Superchain. 

Here are a few Mission Requests that I created in Optimism Season 6:

V1: [Develop Onchain Social Games that attract Builders to Optimism](https://gov.optimism.io/t/mission-request-v2-develop-onchain-social-games-that-attract-builders-to-optimism/8547)

V1: [Create Educational Programs that Empower Developers on Optimism](https://gov.optimism.io/t/mission-request-create-educational-programs-that-empower-developers-on-optimism-modified-with-lower-budget/8553) 

V1: [Create and Distribute Videos about Optimism Collective Governance](https://gov.optimism.io/t/mission-request-create-and-distribute-videos-about-optimism-collective-governance/8544)

V2: [Grow Developers on Optimism via Community Events](https://gov.optimism.io/t/looking-for-sponsor-grow-developers-on-optimism-via-community-events/8835)

The first three Mission Requests were all sponsored and approved, though the first two were approved at a lower budget than originally requested.

### V2 Mission Requests

V2: [Develop Onchain Social Games that attract Builders to Optimism](https://gov.optimism.io/t/looking-for-sponsor-develop-onchain-social-games-that-attract-builders-to-optimism/8836)

V2: [Grow Developers on Optimism via Community Events](https://gov.optimism.io/t/looking-for-sponsor-grow-developers-on-optimism-via-community-events/8835)

[Cycle 27 Grants final roundup](https://gov.optimism.io/t/cycle-27-grants-final-roundup/8885)

The Mission Requests did not get sponsored and approved I’m planning to request a larger budget for these Mission Requests in the future.

### More Details

For anyone who missed our prior discussions about Mission Requests and would like to learn more, you can watch the Optimism Town Hall episode where we spoke about Optimism Season 6 in this [video](https://youtu.be/d8QCL5b4aoU?si=8C9DgIBeaHB4TNt7&t=3724) and explore more in this [project](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Explore%20Mission%20Opportunities%20in%20Optimism%20Season%206%20cbd6bf906386424f88cabba2154281d0.md).

In addition you can also see more of our discussions about Missions related to Optimism Fractal during our past two events, which you can find by exploring the timestamps or transcripts of the episodes. For convenience, I also curated some timestamps of discussions about the Missions that we’re planning, which you can find in our 34th episode ([1](https://www.youtube.com/watch?v=F9nwIxjoIts&t=2225s) and [2](https://youtu.be/F9nwIxjoIts?si=MiFyiFkriO4I7cCs&t=6067)) and 33rd episode ([1](https://www.youtube.com/watch?v=F9nwIxjoIts&t=2225s) and [2](https://www.youtube.com/watch?v=xwyjJnqdkrQ&t=4013s)). Our most detailed walkthrough about Mission Requests can be found in this [video](../Optimism%20Fractal%20Tasks%20baad78e0bc5a4e9da2cd5e514956160b/Consider%20how%20Optimism%20Fractal%20can%20offer%20Consensus%20%2078d921affd5a49c0af5133133eae25bc.md) where I shared an overview of the requesting process and we had discussions about it for about 25 minutes.

You can explore [Optimystics.io/blog](http://Optimystics.io/blog) and [Optimystics.io/missions](http://Optimystics.io/missions) (work in progress) for details and videos about prior missions that I created.

Looking forward to hearing your thoughts!

![[https://optimismfractal.com/32](https://optimismfractal.com/32)](%F0%9F%94%B4%20Optimism%20Missions%20Updates%209bcd023e16ba4141b2e70b4ec9473979/optimism_fractal_32_v2_thumbnail_final.png)

[https://optimismfractal.com/32](https://optimismfractal.com/32)

### [OF 32: Optimism Season 6](https://optimismfractal.com/32)

How can you be rewarded in Season 6 of Optimism? We play a Respect Game with innovators then explore how Superchain builders can get involved in this city of growth and opportunities  🌈🔴

![[https://optimismfractal.com/35](https://optimismfractal.com/35)](%F0%9F%94%B4%20Optimism%20Missions%20Updates%209bcd023e16ba4141b2e70b4ec9473979/thumbnail_of_35_final.png)

[https://optimismfractal.com/35](https://optimismfractal.com/35)

### [**OF 35: Mission Requests**](https://optimismfractal.com/35)

What do mission requests offer to builders in Optimism? After a great Respect Game, we explore how these requests open funding opportunities and how to effectively contribute to support core intents within the Superchain 🔴📝

- [ ]  add notes to and from [optimystics.io/missions](http://optimystics.io/missions)

- 
    
    
    [Optimystics.io/missions](http://Optimystics.io/missions) 
    

## Topic Proposals

I can provide updates about Missions and Mission Requests in Optimism Season 6. You can find details in this [notion page](%F0%9F%94%B4%20Optimism%20Missions%20Updates%209bcd023e16ba4141b2e70b4ec9473979.md).