# 👁️ Optimism Collective Identity

## 👁️ Optimism Collective Identity

The Optimism Foundation is working to create a robust system for identity and reputation within the Optimism Collective, which can improve RetroFunding, the Citizen’s House, and many other systems.

At this week’s event we can explore the Optimism Foundation’s thinking on identity systems in the Collective and how Optimism Fractal can help. I can share a brief overview of identity systems on Optimism and we can have an open discussion about it.

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can find related resources and learn more about identity in the Optimism Collective in these [tabs](https://arc.net/folder/1A6CF438-10DE-4161-9851-F26018B96591) and this [notion page](%F0%9F%91%81%EF%B8%8F%20Optimism%20Collective%20Identity%2052fe94446c2645cab1aca7de0d67925c.md). 

[https://arc.net/folder/1A6CF438-10DE-4161-9851-F26018B96591](https://arc.net/folder/1A6CF438-10DE-4161-9851-F26018B96591)