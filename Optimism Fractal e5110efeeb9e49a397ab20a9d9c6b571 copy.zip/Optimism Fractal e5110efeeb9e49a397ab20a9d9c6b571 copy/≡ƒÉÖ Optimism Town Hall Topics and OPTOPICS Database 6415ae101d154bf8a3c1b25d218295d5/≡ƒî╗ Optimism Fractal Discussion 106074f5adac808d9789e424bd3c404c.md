# 🌻 Optimism Fractal Discussion

## 🌻 Optimism Fractal Discussion

At this week’s event we can have an open discussion about Optimism Fractal, the Respect Game, and/or other related topics. What would you like to discuss about Optimism Fractal?

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can learn more at [OptimismFractal.com](http://OptimismFractal.com) and by joining our weekly events!