# The SUNNYs Awards

The SUNNYs are an awards show designed to honor the outstanding achievements of Superchain builders. Builders from all across live Superchain mainnets are eligible to win 20 awards and 540k OP in prizes. Registration closes on September 29th and the award show will take place in October.

We can discuss the exciting details of the SUNNYs and how Optimism Fractal can enhance future iterations of the SUNNYs with the Respect Game, Cagendas, and RetroPitches. You can find details on this [notion page](The%20SUNNYs%20Awards%20106074f5adac80c89e8bd876cadea462.md) and [thesunnyawards.fun](http://thesunnyawards.fun).

![image.png](The%20SUNNYs%20Awards%20106074f5adac80c89e8bd876cadea462/image.png)

[https://x.com/Optimism/status/1826321837266972713](https://x.com/Optimism/status/1826321837266972713)

[https://x.com/binji_x/status/1826323470978109770?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/binji_x/status/1826323470978109770?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

![image.png](The%20SUNNYs%20Awards%20106074f5adac80c89e8bd876cadea462/image%201.png)

![image.png](The%20SUNNYs%20Awards%20106074f5adac80c89e8bd876cadea462/image%202.png)

[https://twitter.com/Optimism/status/1835831525755220369](https://twitter.com/Optimism/status/1835831525755220369)

![image.png](The%20SUNNYs%20Awards%20106074f5adac80c89e8bd876cadea462/image%203.png)

[https://x.com/Optimism/status/1826321841319018680](https://x.com/Optimism/status/1826321841319018680)