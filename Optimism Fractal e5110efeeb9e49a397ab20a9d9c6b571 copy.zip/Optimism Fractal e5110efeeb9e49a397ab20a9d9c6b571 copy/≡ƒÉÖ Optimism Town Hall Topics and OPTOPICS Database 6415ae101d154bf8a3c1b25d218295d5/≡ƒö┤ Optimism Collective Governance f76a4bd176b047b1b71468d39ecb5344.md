# 🔴 Optimism Collective Governance

## 🔴 Optimism Collective Governance

The Optimism Collective is a band of companies, communities, and citizens working together to reward public goods and build a sustainable future on Ethereum. 

At this week’s event we can explore the innovative governance structures of the Optimism Collective, including the Citizen’s House, Token House, and opportunities for optimizations with Optimism Fractal. I can share a brief overview of Optimism Collective governance and we can have an open discussion about it.

Upvote if you’d like to discuss this topic and feel free to share any related questions or comments. You can find related resources and learn more about governance in the Optimism Collective in these [tabs](https://arc.net/folder/C17785E4-FAB6-4CD1-9298-4436CCDCB1BD) and this [notion page](%F0%9F%94%B4%20Optimism%20Collective%20Governance%20f76a4bd176b047b1b71468d39ecb5344.md). 

[https://twitter.com/Optimism/status/1836089823695626299](https://twitter.com/Optimism/status/1836089823695626299)

[Accelerated Decentralization Proposal For Optimism](https://gov.optimism.io/t/accelerated-decentralization-proposal-for-optimism/8875/7)

![image.png](%F0%9F%94%B4%20Optimism%20Collective%20Governance%20f76a4bd176b047b1b71468d39ecb5344/image.png)

[https://arc.net/folder/C17785E4-FAB6-4CD1-9298-4436CCDCB1BD](https://arc.net/folder/C17785E4-FAB6-4CD1-9298-4436CCDCB1BD)