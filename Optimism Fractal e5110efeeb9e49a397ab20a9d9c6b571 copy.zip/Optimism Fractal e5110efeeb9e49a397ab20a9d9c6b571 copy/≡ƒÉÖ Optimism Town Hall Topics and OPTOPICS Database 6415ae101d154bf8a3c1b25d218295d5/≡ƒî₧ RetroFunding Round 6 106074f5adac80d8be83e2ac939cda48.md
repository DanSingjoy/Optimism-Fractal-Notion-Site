# 🌞 RetroFunding Round 6

[https://twitter.com/Optimism/status/1835648663777140821](https://twitter.com/Optimism/status/1835648663777140821)

Retroactive Public Goods Funding (Retro Funding) 6 will reward contributions to Optimism Governance, including governance infrastructure & tooling, governance analytics, and governance leadership.

[Retro Funding 6: Governance - Round details](https://gov.optimism.io/t/retro-funding-6-governance-round-details/8870)

[Retro Funding 6: Announcing Guest Voter participation](https://gov.optimism.io/t/retro-funding-6-announcing-guest-voter-participation/8816)

[Optimism Community Call Recaps & Recordings Thread](https://gov.optimism.io/t/optimism-community-call-recaps-recordings-thread/6937/50?u=dansingjoy)

[Retro Funding 5: OP Stack - round details](https://gov.optimism.io/t/retro-funding-5-op-stack-round-details/8612)

[Retro Funding 5: OP Stack - round details](https://gov.optimism.io/t/retro-funding-5-op-stack-round-details/8612)

[https://warpcast.com/optimism/0x295b83f2](https://warpcast.com/optimism/0x295b83f2)

[Warpcast](https://warpcast.com/optimism/0x295b83f2)

## Related Projects

[Create Auxiliary Respect Tokens for Optimism Collective (ie OPC)](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Create%20Auxiliary%20Respect%20Tokens%20for%20Optimism%20Colle%20b78abde1bff54c499c648628e459c689.md) 

[Integrate Optimism Fractal and the Respect Game with RetroFunding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Integrate%20Optimism%20Fractal%20and%20the%20Respect%20Game%20wi%207eb4300be4ac4b1395c5d73510d520bb.md) 

[Curate Funding Opportunities and Create Educational Content to help Optimism Fractal community members earn funding](../Optimism%20Fractal%20Projects%206fb468421d4b49f6adf7615ac7b1a8c2/Curate%20Funding%20Opportunities%20and%20Create%20Educationa%202a2fefab5a734ff48f141c5ad8b307eb.md) 

## Related Videos

![[https://optimismfractal.com/22](https://optimismfractal.com/22)](%F0%9F%8C%9E%20RetroFunding%20Round%206%20106074f5adac80d8be83e2ac939cda48/optimism_fractal_22_thumbnail_draft.png)

[https://optimismfractal.com/22](https://optimismfractal.com/22)

### [**OF 22: Retro Funding Optimism Fractal**](https://optimismfractal.com/22)

How can Optimism Fractal help you earn Retro Funding? We measure each other’s impact in the Collective, then help public goods creators to profit by growing Optimism and contributing to Optimism Fractal  🧑🏽‍🌾 📏 🔴

![[https://optimismfractal.com/23](https://optimismfractal.com/23)](%F0%9F%8C%9E%20RetroFunding%20Round%206%20106074f5adac80d8be83e2ac939cda48/optimism_fractal_23_thumbnail_final.png)

[https://optimismfractal.com/23](https://optimismfractal.com/23)

### [OF 23: Optimism Fractal Seasons](https://optimismfractal.com/23)

How can a seasonal structure help communities thrive? Following a rhythmic Respect Game we explore heliotropic ideas to align Optimism Fractal seasons with Retro Funding rounds 🌻 🔴 🌞

## Topic Proposal

Retroactive Public Goods Funding (Retro Funding) 6 will reward contributions to Optimism Governance, including governance infrastructure & tooling, governance analytics, and governance leadership.

You can learn more about Retro Funding 6 in this [tweet](https://x.com/Optimism/status/1835648663777140821?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1835648663777140821%7Ctwgr%5Eede8d590f5377b2d27d2c064affbbdf64e8a347e%7Ctwcon%5Es1_c10&ref_url=https%3A%2F%2Fwww.notion.so%2Fedencreators%2FPropose-Topics-For-OF-42-390f1067a2d1403387cf8e20a811730e9bcd023e16ba4141b2e70b4ec9473979) and [notion page](%F0%9F%8C%9E%20RetroFunding%20Round%206%20106074f5adac80d8be83e2ac939cda48.md).

![image.png](%F0%9F%8C%9E%20RetroFunding%20Round%206%20106074f5adac80d8be83e2ac939cda48/image.png)