# 👨🏽‍💻 Optimism Fractal Software Development Updates

Tadas, Vlad, Abraham, and several other developers are building exciting apps for Optimism Fractal.

Last week Vlad provided an overview of