# OPTOPICS Proposal, October 7th Version

Upvote to play the OPTOPICS Cagendas game at this week’s Optimism Town Hall!

## Overview

OPTOPICS is a community agenda game that enables participants to propose, vote, and dynamically choose discussion topics for Optimism Town Hall events.

As a reminder, there is now a new [snapshot space](https://snapshot.org/#/optopics.eth) to post topic proposals for OPTOPICS, which allows us to use the Optimism Town Hall snapshot space for scheduling topics in advance for each event and use the new OPTOPICS snapshot space for organizing topics on an ongoing basis or during events. In addition to more clearly organizing topics scheduled in advance and topics that can be discussed at any time, this also allows us to propose topics that could be discussed at many events rather than just proposing topics for each single event.

The game rules are below and you can learn more at [Optimystics.io/OPTOPICS](http://optimystics.io/OPTOPICS).

## Game Rules

There are three main actions that you can take while playing OPTOPICS: propose topics, vote on topics, and switch topics.

### Propose Topics

Create a topic proposal in the OPTOPICS snapshot space at any time to propose a topic. Feel free to propose anything related to Optimism.

Tip: When creating a topic proposal you can set the Voting Type to Weighted Voting, then set two poll options to Upvote and Abstain. This isn’t necessary, but provides greater ability for everyone to weigh their preferences while voting for topics.

### Vote on Topics

Vote on topics with [Respect](https://optimystics.io/respect) to help set the agenda. The topic with the most votes will be discussed until the group decides to switch topics. Feel free to change your vote at any time.

### Switch Topics

OPTOPICS features an optimistic topic transition system that allows anyone to influence the discussion as the game progresses and help move the group to the next topic. Here’s how it works:

Next Topic: Type ‘next topic’ in the zoom chat to propose moving to the next topic. This starts a one-minute countdown.

Same Topic: Type ‘same topic’ within one minute to veto the change. If vetoed, neither person can propose to switch or veto again for the current topic.

New Topic: If over half of well respected community members agree (each with at least 50 Respect), any topic can be introduced and discussed immediately.

## Topic Proposals

You can propose a topic on the

[OPTOPICS snapshot space](https://snapshot.org/#/optopics.eth)

at any time if there’s something you’d like to discuss or propose a topic on the Optimism Town Hall snapshot space if you’d like to schedule a topic for an upcoming town hall. Feel free to propose any topics related to Optimism. Looking forward to hearing your thoughts and seeing you at the events!